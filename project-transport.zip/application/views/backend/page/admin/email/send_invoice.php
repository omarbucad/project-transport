<div style="margin-top: 100px;"></div>
<div class="container">

	<h2>Welcome to Transport Checklist - Bill Statement</h2>

	<p>Dear Valued Customer,</p>

	<p class="help-block">Thank you for availing a subscription in Transport Checklist. Attached is a bill statement of your transaction.</p>

	<p>If you have any comments or questions, please don't hesitate to reach us at <a href="mailto:cherlaj@trackerteer.com">cherlaj@trackerteer.com</a></p>
</div>
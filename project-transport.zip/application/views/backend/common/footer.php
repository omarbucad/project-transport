<footer class="app-footer">
	<div class="wrapper">
		<span class="pull-right"><?php echo $version; ?> <a href="#"><i class="fa fa-long-arrow-up"></i></a></span> © <?php echo $year; ?> Copyright. <?php echo $company_name; ?> 
	</div>
</footer>
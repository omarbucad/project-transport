<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<p>Dear Valued Customer,</p>
	<p>Someone requested a new password for your Transport Checklist account.</p>
	<p>Please use the following link to <a href="<?php echo $link; ?>"><?php echo $link; ?></a>. this link will expire 24 hours after you received this email.</p>
	<p>If you did not request this password change please feel free to ignore it.</p>
	<p>If you have any comments or questions, please don't hesitate to reach us at <a href="mailto:mhar@trackerteer.com">mhar@trackerteer.com</a></p>
	<p>Please feel free to respond to this email. it was sent from a monitored email address , and we would <strong style="color:red">LOVE</strong> to hear from you.</p>
</body>
</html>
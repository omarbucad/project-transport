<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-31 03:16:29 --> The path to the image is not correct.
ERROR - 2018-05-31 03:16:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 03:16:36 --> The path to the image is not correct.
ERROR - 2018-05-31 03:16:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 03:16:40 --> The path to the image is not correct.
ERROR - 2018-05-31 03:16:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 03:18:26 --> The path to the image is not correct.
ERROR - 2018-05-31 03:18:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 03:18:56 --> The path to the image is not correct.
ERROR - 2018-05-31 03:18:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 03:19:30 --> The path to the image is not correct.
ERROR - 2018-05-31 03:19:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 03:20:41 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-31 03:20:41 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-31 03:20:41 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-31 03:20:41 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-31 03:20:41 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-31 07:31:16 --> The path to the image is not correct.
ERROR - 2018-05-31 07:31:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:31:24 --> The path to the image is not correct.
ERROR - 2018-05-31 07:31:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:31:34 --> The path to the image is not correct.
ERROR - 2018-05-31 07:31:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:31:36 --> The path to the image is not correct.
ERROR - 2018-05-31 07:31:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:31:41 --> The path to the image is not correct.
ERROR - 2018-05-31 07:31:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:31:53 --> The path to the image is not correct.
ERROR - 2018-05-31 07:31:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:31:55 --> The path to the image is not correct.
ERROR - 2018-05-31 07:31:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:31:56 --> The path to the image is not correct.
ERROR - 2018-05-31 07:31:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:32:17 --> The path to the image is not correct.
ERROR - 2018-05-31 07:32:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:32:17 --> The path to the image is not correct.
ERROR - 2018-05-31 07:32:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:32:17 --> The path to the image is not correct.
ERROR - 2018-05-31 07:32:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:32:25 --> The path to the image is not correct.
ERROR - 2018-05-31 07:32:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:32:27 --> The path to the image is not correct.
ERROR - 2018-05-31 07:32:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:32:31 --> The path to the image is not correct.
ERROR - 2018-05-31 07:32:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 07:34:47 --> The path to the image is not correct.
ERROR - 2018-05-31 07:34:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:23:38 --> The path to the image is not correct.
ERROR - 2018-05-31 08:23:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:23:40 --> The path to the image is not correct.
ERROR - 2018-05-31 08:23:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:23:42 --> The path to the image is not correct.
ERROR - 2018-05-31 08:23:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:26:59 --> The path to the image is not correct.
ERROR - 2018-05-31 08:26:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:27:38 --> The path to the image is not correct.
ERROR - 2018-05-31 08:27:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:27:54 --> The path to the image is not correct.
ERROR - 2018-05-31 08:27:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:27:57 --> The path to the image is not correct.
ERROR - 2018-05-31 08:27:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:28:05 --> The path to the image is not correct.
ERROR - 2018-05-31 08:28:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-05-31 08:28:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-05-31 08:28:16 --> The path to the image is not correct.
ERROR - 2018-05-31 08:28:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-05-31 08:29:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-05-31 08:29:13 --> The path to the image is not correct.
ERROR - 2018-05-31 08:29:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:29:16 --> The path to the image is not correct.
ERROR - 2018-05-31 08:29:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:34:36 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-31 08:34:36 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-31 08:34:36 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-31 08:34:36 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-31 08:34:36 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-31 08:34:53 --> The path to the image is not correct.
ERROR - 2018-05-31 08:34:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:34:56 --> The path to the image is not correct.
ERROR - 2018-05-31 08:34:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:37:14 --> The path to the image is not correct.
ERROR - 2018-05-31 08:37:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:37:15 --> 404 Page Not Found: app/Report/index
ERROR - 2018-05-31 08:37:18 --> The path to the image is not correct.
ERROR - 2018-05-31 08:37:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:37:23 --> The path to the image is not correct.
ERROR - 2018-05-31 08:37:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:37:24 --> The path to the image is not correct.
ERROR - 2018-05-31 08:37:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:37:50 --> The path to the image is not correct.
ERROR - 2018-05-31 08:37:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:37:50 --> The path to the image is not correct.
ERROR - 2018-05-31 08:37:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:38:09 --> The path to the image is not correct.
ERROR - 2018-05-31 08:38:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:38:13 --> The path to the image is not correct.
ERROR - 2018-05-31 08:38:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:38:13 --> The path to the image is not correct.
ERROR - 2018-05-31 08:38:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:38:15 --> The path to the image is not correct.
ERROR - 2018-05-31 08:38:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:38:20 --> The path to the image is not correct.
ERROR - 2018-05-31 08:38:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:38:25 --> The path to the image is not correct.
ERROR - 2018-05-31 08:38:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:38:25 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-05-31 08:38:25 --> The provided image is not valid.
ERROR - 2018-05-31 08:38:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 08:38:47 --> The path to the image is not correct.
ERROR - 2018-05-31 08:38:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 11:15:43 --> The path to the image is not correct.
ERROR - 2018-05-31 11:15:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-31 11:15:43 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-05-31 11:15:43 --> The provided image is not valid.
ERROR - 2018-05-31 11:15:43 --> Your server does not support the GD function required to process this type of image.

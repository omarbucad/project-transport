<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-17 04:18:21 --> The path to the image is not correct.
ERROR - 2018-08-17 04:18:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 04:18:24 --> The path to the image is not correct.
ERROR - 2018-08-17 04:18:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 04:18:46 --> The path to the image is not correct.
ERROR - 2018-08-17 04:18:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 05:20:02 --> The path to the image is not correct.
ERROR - 2018-08-17 05:20:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 07:52:21 --> The path to the image is not correct.
ERROR - 2018-08-17 07:52:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 07:52:23 --> The path to the image is not correct.
ERROR - 2018-08-17 07:52:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 07:55:53 --> The path to the image is not correct.
ERROR - 2018-08-17 07:55:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 07:55:58 --> The path to the image is not correct.
ERROR - 2018-08-17 07:55:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 07:56:00 --> The path to the image is not correct.
ERROR - 2018-08-17 07:56:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 07:59:40 --> The path to the image is not correct.
ERROR - 2018-08-17 07:59:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 07:59:44 --> The path to the image is not correct.
ERROR - 2018-08-17 07:59:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 07:59:45 --> The path to the image is not correct.
ERROR - 2018-08-17 07:59:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:02:33 --> The path to the image is not correct.
ERROR - 2018-08-17 08:02:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:02:34 --> The path to the image is not correct.
ERROR - 2018-08-17 08:02:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:02:36 --> The path to the image is not correct.
ERROR - 2018-08-17 08:02:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:10:42 --> The path to the image is not correct.
ERROR - 2018-08-17 08:10:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:10:44 --> The path to the image is not correct.
ERROR - 2018-08-17 08:10:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:10:46 --> The path to the image is not correct.
ERROR - 2018-08-17 08:10:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:13:03 --> The path to the image is not correct.
ERROR - 2018-08-17 08:13:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:13:38 --> The path to the image is not correct.
ERROR - 2018-08-17 08:13:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:13:41 --> The path to the image is not correct.
ERROR - 2018-08-17 08:13:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:13:41 --> The path to the image is not correct.
ERROR - 2018-08-17 08:13:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:13:48 --> The path to the image is not correct.
ERROR - 2018-08-17 08:13:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:13:49 --> The path to the image is not correct.
ERROR - 2018-08-17 08:13:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:14:19 --> The path to the image is not correct.
ERROR - 2018-08-17 08:14:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 08:14:19 --> The path to the image is not correct.
ERROR - 2018-08-17 08:14:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:02:43 --> The path to the image is not correct.
ERROR - 2018-08-17 09:02:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:02:43 --> The path to the image is not correct.
ERROR - 2018-08-17 09:02:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:02:46 --> The path to the image is not correct.
ERROR - 2018-08-17 09:02:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:02:48 --> The path to the image is not correct.
ERROR - 2018-08-17 09:02:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:02:49 --> The path to the image is not correct.
ERROR - 2018-08-17 09:02:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:03:56 --> The path to the image is not correct.
ERROR - 2018-08-17 09:03:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:03:56 --> The path to the image is not correct.
ERROR - 2018-08-17 09:03:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:28:41 --> The path to the image is not correct.
ERROR - 2018-08-17 09:28:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:28:45 --> The path to the image is not correct.
ERROR - 2018-08-17 09:28:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:31:11 --> The path to the image is not correct.
ERROR - 2018-08-17 09:31:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:31:13 --> The path to the image is not correct.
ERROR - 2018-08-17 09:31:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:31:15 --> The path to the image is not correct.
ERROR - 2018-08-17 09:31:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:34:57 --> The path to the image is not correct.
ERROR - 2018-08-17 09:34:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:34:59 --> The path to the image is not correct.
ERROR - 2018-08-17 09:34:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:53:15 --> The path to the image is not correct.
ERROR - 2018-08-17 09:53:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:53:20 --> The path to the image is not correct.
ERROR - 2018-08-17 09:53:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:53:25 --> The path to the image is not correct.
ERROR - 2018-08-17 09:53:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:53:26 --> The path to the image is not correct.
ERROR - 2018-08-17 09:53:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:54:06 --> The path to the image is not correct.
ERROR - 2018-08-17 09:54:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 09:54:06 --> The path to the image is not correct.
ERROR - 2018-08-17 09:54:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:00:10 --> The path to the image is not correct.
ERROR - 2018-08-17 10:00:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:00:13 --> The path to the image is not correct.
ERROR - 2018-08-17 10:00:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:00:43 --> The path to the image is not correct.
ERROR - 2018-08-17 10:00:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:00:43 --> The path to the image is not correct.
ERROR - 2018-08-17 10:00:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:00:48 --> The path to the image is not correct.
ERROR - 2018-08-17 10:00:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:00:52 --> The path to the image is not correct.
ERROR - 2018-08-17 10:00:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:02:09 --> The path to the image is not correct.
ERROR - 2018-08-17 10:02:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:02:10 --> The path to the image is not correct.
ERROR - 2018-08-17 10:02:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:02:27 --> The path to the image is not correct.
ERROR - 2018-08-17 10:02:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:02:35 --> The path to the image is not correct.
ERROR - 2018-08-17 10:02:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:02:35 --> The path to the image is not correct.
ERROR - 2018-08-17 10:02:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:03:22 --> The path to the image is not correct.
ERROR - 2018-08-17 10:03:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:03:23 --> The path to the image is not correct.
ERROR - 2018-08-17 10:03:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:05:56 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-17 10:05:56 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-17 10:05:57 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-17 10:05:57 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-17 10:05:57 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-17 10:07:22 --> The path to the image is not correct.
ERROR - 2018-08-17 10:07:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:07:28 --> The path to the image is not correct.
ERROR - 2018-08-17 10:07:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:09:41 --> The path to the image is not correct.
ERROR - 2018-08-17 10:09:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:09:44 --> The path to the image is not correct.
ERROR - 2018-08-17 10:09:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:09:45 --> The path to the image is not correct.
ERROR - 2018-08-17 10:09:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:09:48 --> The path to the image is not correct.
ERROR - 2018-08-17 10:09:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:09:51 --> The path to the image is not correct.
ERROR - 2018-08-17 10:09:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:09:54 --> The path to the image is not correct.
ERROR - 2018-08-17 10:09:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:09:59 --> The path to the image is not correct.
ERROR - 2018-08-17 10:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:11:27 --> The path to the image is not correct.
ERROR - 2018-08-17 10:11:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:16:39 --> The path to the image is not correct.
ERROR - 2018-08-17 10:16:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:16:49 --> The path to the image is not correct.
ERROR - 2018-08-17 10:16:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:42:37 --> The path to the image is not correct.
ERROR - 2018-08-17 10:42:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:42:40 --> The path to the image is not correct.
ERROR - 2018-08-17 10:42:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 10:42:42 --> The path to the image is not correct.
ERROR - 2018-08-17 10:42:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:12:48 --> The path to the image is not correct.
ERROR - 2018-08-17 11:12:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:12:50 --> The path to the image is not correct.
ERROR - 2018-08-17 11:12:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:12:50 --> The path to the image is not correct.
ERROR - 2018-08-17 11:12:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:12:53 --> The path to the image is not correct.
ERROR - 2018-08-17 11:12:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:12:54 --> The path to the image is not correct.
ERROR - 2018-08-17 11:12:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:22:27 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 21041025 bytes) D:\xampp\htdocs\project-transport\system\core\Common.php 725
ERROR - 2018-08-17 11:23:04 --> The path to the image is not correct.
ERROR - 2018-08-17 11:23:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:23:09 --> The path to the image is not correct.
ERROR - 2018-08-17 11:23:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:29:53 --> The path to the image is not correct.
ERROR - 2018-08-17 11:29:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:29:55 --> The path to the image is not correct.
ERROR - 2018-08-17 11:29:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:51:47 --> The path to the image is not correct.
ERROR - 2018-08-17 11:51:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:51:49 --> The path to the image is not correct.
ERROR - 2018-08-17 11:51:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:51:51 --> The path to the image is not correct.
ERROR - 2018-08-17 11:51:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:52:10 --> The path to the image is not correct.
ERROR - 2018-08-17 11:52:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:52:12 --> The path to the image is not correct.
ERROR - 2018-08-17 11:52:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:55:39 --> The path to the image is not correct.
ERROR - 2018-08-17 11:55:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-17 11:55:42 --> The path to the image is not correct.
ERROR - 2018-08-17 11:55:42 --> Your server does not support the GD function required to process this type of image.

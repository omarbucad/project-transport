<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-08 08:41:54 --> The path to the image is not correct.
ERROR - 2018-06-08 08:41:54 --> Your server does not support the GD function required to process this type of image.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-05 03:19:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:19:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:21:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:21:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:21:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:21:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:21:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:21:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:21:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:23:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:24:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:24:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:24:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:25:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 03:25:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:09:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:11:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:16:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:21:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:21:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:22:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:24:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:26:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:26:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:31:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:31:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:33:59 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\project-transport\application\controllers\Welcome.php 27
ERROR - 2018-04-05 04:34:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:34:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:34:51 --> Query error: Table 'project_transport.store_address' doesn't exist - Invalid query: INSERT INTO `store_address` (`country`, `city`) VALUES ('PH', 'Angeles City')
ERROR - 2018-04-05 04:35:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:35:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:35:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:35:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:35:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:35:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:35:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:36:28 --> Query error: Unknown column 'default_currency' in 'field list' - Invalid query: INSERT INTO `store` (`store_name`, `user_id`, `physical_address`, `postal_address`, `default_currency`, `contact_id`, `created`) VALUES ('COMPANY 1', 1, 2, 2, NULL, 1, 1522895788)
ERROR - 2018-04-05 04:37:03 --> Query error: Table 'project_transport.customer_group' doesn't exist - Invalid query: INSERT INTO `customer_group` (`store_id`, `group_name`, `created`, `deletable`) VALUES (1, 'All Customer', 1522895823, 'NO')
ERROR - 2018-04-05 04:39:52 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 04:43:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:44:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:45:54 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 04:46:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:46:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:47:57 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 04:48:37 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 04:48:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:49:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:50:25 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 04:51:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:52:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:57:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 04:57:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:26:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:26:25 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 91
ERROR - 2018-04-05 05:26:25 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 96
ERROR - 2018-04-05 05:26:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:26:37 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 91
ERROR - 2018-04-05 05:26:37 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 96
ERROR - 2018-04-05 05:26:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:26:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:27:50 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 91
ERROR - 2018-04-05 05:27:50 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 96
ERROR - 2018-04-05 05:27:50 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:33:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:34:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:35:04 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 92
ERROR - 2018-04-05 05:35:04 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 97
ERROR - 2018-04-05 05:35:04 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:01 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:02 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:21 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:22 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:23 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:23 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:23 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:23 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:23 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:24 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:25 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:25 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:25 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:26 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:26 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:26 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:26 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:27 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:27 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:28 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:36:28 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:37:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:37:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:38:00 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 92
ERROR - 2018-04-05 05:38:00 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 97
ERROR - 2018-04-05 05:38:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:38:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:38:42 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 92
ERROR - 2018-04-05 05:38:42 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 97
ERROR - 2018-04-05 05:38:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:39:29 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 92
ERROR - 2018-04-05 05:39:29 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 97
ERROR - 2018-04-05 05:39:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:41:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:41:31 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 92
ERROR - 2018-04-05 05:41:31 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 96
ERROR - 2018-04-05 05:41:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:41:39 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 92
ERROR - 2018-04-05 05:41:39 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 96
ERROR - 2018-04-05 05:41:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:41:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:41:56 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 92
ERROR - 2018-04-05 05:41:56 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\project-transport\application\models\Register_model.php 96
ERROR - 2018-04-05 05:43:02 --> Severity: Notice --> Undefined index: username D:\xampp\htdocs\project-transport\application\models\Register_model.php 93
ERROR - 2018-04-05 05:43:02 --> Severity: Notice --> Undefined index: password D:\xampp\htdocs\project-transport\application\models\Register_model.php 94
ERROR - 2018-04-05 05:43:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:43:22 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:43:44 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-05 05:43:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:43:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:49:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:51:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:51:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:51:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:51:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:56:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 05:58:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 06:00:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 08:47:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-05 08:48:29 --> 404 Page Not Found: Public/lib

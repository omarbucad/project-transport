<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-20 04:36:18 --> Severity: Notice --> Undefined property: stdClass::$store_id D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 43
ERROR - 2018-07-20 04:36:22 --> Severity: Notice --> Undefined property: stdClass::$store_id D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 43

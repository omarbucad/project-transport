<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-17 07:37:49 --> 404 Page Not Found: Public/upload
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-17 07:37:49 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-17 07:37:49 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-17 07:37:50 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-17 07:37:51 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-17 08:38:07 --> 404 Page Not Found: app/Login/index
ERROR - 2018-07-17 08:38:21 --> The path to the image is not correct.
ERROR - 2018-07-17 08:38:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-17 08:38:27 --> The path to the image is not correct.
ERROR - 2018-07-17 08:38:27 --> Your server does not support the GD function required to process this type of image.

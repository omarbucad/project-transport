<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-02 03:17:46 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:17:46 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:17:46 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:17:46 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-02 03:17:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:17:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:17:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:17:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:17:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-02 03:17:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-02 03:17:46 --> The path to the image is not correct.
ERROR - 2018-05-02 03:17:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-02 03:20:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:49 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:20:49 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:20:49 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:20:49 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-02 03:20:49 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:20:49 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:20:49 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:20:49 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:20:49 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-02 03:20:49 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-02 03:20:49 --> The path to the image is not correct.
ERROR - 2018-05-02 03:20:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-02 03:20:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:20:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:21:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:21:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:21:37 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:21:37 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:21:37 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:21:37 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-02 03:21:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:21:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:21:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:21:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:21:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-02 03:21:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-02 03:21:37 --> The path to the image is not correct.
ERROR - 2018-05-02 03:21:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-02 03:21:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:22:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:22:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:22:14 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:22:14 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:22:14 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:22:14 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-02 03:22:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:22:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:22:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:22:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:22:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-02 03:22:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-02 03:22:14 --> The path to the image is not correct.
ERROR - 2018-05-02 03:22:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-02 03:22:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:22:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:22:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:22:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:22:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:22:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:22:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:24:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:24:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:24:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:24:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:24:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:24:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-02 03:24:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:24:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:24:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:24:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:24:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-02 03:24:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-02 03:24:00 --> The path to the image is not correct.
ERROR - 2018-05-02 03:24:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-02 03:24:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:24:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:24:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:24:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:24:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:24:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:24:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:25:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:25:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-02 03:25:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-02 03:25:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:25:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-02 03:25:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:25:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-02 03:25:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-02 03:25:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-02 03:25:00 --> The path to the image is not correct.
ERROR - 2018-05-02 03:25:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-02 03:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:25:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:26:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:26:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:26:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:26:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:26:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:26:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:26:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:31:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 03:31:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:12:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:12:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:12:23 --> The path to the image is not correct.
ERROR - 2018-05-02 04:12:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-02 04:12:51 --> 404 Page Not Found: app/Pos/sell
ERROR - 2018-05-02 04:12:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:12:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:12:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:12:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:13:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:13:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:14:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:14:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:14:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:14:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:26:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:26:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:26:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:26:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:26:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:26:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:26:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:26:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:39:08 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 50
ERROR - 2018-05-02 04:39:08 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-05-02 04:39:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:39:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:39:50 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 53
ERROR - 2018-05-02 04:39:50 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 56
ERROR - 2018-05-02 04:39:50 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 42
ERROR - 2018-05-02 04:39:50 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-05-02 04:39:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:39:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:40:24 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 54
ERROR - 2018-05-02 04:40:24 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 57
ERROR - 2018-05-02 04:40:24 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 54
ERROR - 2018-05-02 04:40:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 57
ERROR - 2018-05-02 04:40:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 54
ERROR - 2018-05-02 04:40:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 57
ERROR - 2018-05-02 04:40:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 54
ERROR - 2018-05-02 04:40:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 57
ERROR - 2018-05-02 04:40:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 54
ERROR - 2018-05-02 04:40:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 57
ERROR - 2018-05-02 04:40:26 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 54
ERROR - 2018-05-02 04:40:26 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 57
ERROR - 2018-05-02 04:40:26 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 54
ERROR - 2018-05-02 04:40:26 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 57
ERROR - 2018-05-02 04:41:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 54
ERROR - 2018-05-02 04:41:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 57
ERROR - 2018-05-02 04:41:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 42
ERROR - 2018-05-02 04:41:25 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-05-02 04:41:33 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 54
ERROR - 2018-05-02 04:41:33 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 57
ERROR - 2018-05-02 04:41:33 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 42
ERROR - 2018-05-02 04:41:33 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-05-02 04:42:11 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 56
ERROR - 2018-05-02 04:42:11 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 59
ERROR - 2018-05-02 04:42:11 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 42
ERROR - 2018-05-02 04:42:11 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-05-02 04:42:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 48
ERROR - 2018-05-02 04:47:32 --> Severity: Notice --> Undefined variable: store_id D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 56
ERROR - 2018-05-02 04:47:32 --> Severity: Notice --> Undefined variable: store_id D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 60
ERROR - 2018-05-02 04:47:32 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 60
ERROR - 2018-05-02 04:47:32 --> Severity: Notice --> Undefined variable: store_id D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 44
ERROR - 2018-05-02 04:47:32 --> Severity: Notice --> Undefined variable: store_id D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 48
ERROR - 2018-05-02 04:47:32 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 48
ERROR - 2018-05-02 04:47:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:47:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:47:59 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 65
ERROR - 2018-05-02 04:47:59 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 50
ERROR - 2018-05-02 04:47:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:47:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:48:33 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 50
ERROR - 2018-05-02 04:48:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:48:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:48:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:48:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:50:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:50:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:51:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:51:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:55:18 --> Severity: Notice --> Undefined variable: total_pending_order D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 46
ERROR - 2018-05-02 04:55:18 --> Severity: Notice --> Undefined variable: total_confirmed_order D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 62
ERROR - 2018-05-02 04:55:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:55:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:55:49 --> Severity: Notice --> Undefined variable: total_confirmed_order D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 62
ERROR - 2018-05-02 04:55:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:55:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:56:07 --> Severity: Notice --> Undefined variable: total_confirmed_order D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 62
ERROR - 2018-05-02 04:56:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:56:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:56:16 --> Severity: Notice --> Undefined variable: total_confirmed_order D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 62
ERROR - 2018-05-02 04:56:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:56:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:57:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:57:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:57:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:57:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:57:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:57:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:59:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 04:59:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:00:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:00:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:00:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:00:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:01:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:01:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:01:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:01:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:02:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:02:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:03:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:03:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:03:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:03:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:03:48 --> Severity: Notice --> Undefined variable: trailer D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 92
ERROR - 2018-05-02 05:03:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:03:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:03:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:03:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:03:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:03:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:04:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:04:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:11:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:11:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:11:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:11:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:11:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:11:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:13:55 --> The path to the image is not correct.
ERROR - 2018-05-02 05:13:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-02 05:18:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:18:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:29:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:29:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:29:26 --> The path to the image is not correct.
ERROR - 2018-05-02 05:29:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:29:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-02 05:29:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:32:32 --> 404 Page Not Found: app/Users/view_user_info
ERROR - 2018-05-02 05:32:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 05:32:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 07:04:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 07:04:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 07:04:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 07:04:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 08:18:55 --> Severity: Notice --> Undefined variable: new_order D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 146
ERROR - 2018-05-02 08:18:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 146
ERROR - 2018-05-02 08:18:55 --> Severity: Notice --> Undefined variable: unpaid_invoice D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 188
ERROR - 2018-05-02 08:18:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 188
ERROR - 2018-05-02 08:18:55 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 205
ERROR - 2018-05-02 08:18:55 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 217
ERROR - 2018-05-02 08:18:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 217
ERROR - 2018-05-02 08:18:55 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 237
ERROR - 2018-05-02 08:18:55 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 249
ERROR - 2018-05-02 08:18:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 249
ERROR - 2018-05-02 08:18:55 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 269
ERROR - 2018-05-02 08:18:55 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 281
ERROR - 2018-05-02 08:18:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 281
ERROR - 2018-05-02 08:18:56 --> Severity: Notice --> Undefined variable: new_order D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 146
ERROR - 2018-05-02 08:18:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 146
ERROR - 2018-05-02 08:18:56 --> Severity: Notice --> Undefined variable: unpaid_invoice D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 188
ERROR - 2018-05-02 08:18:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 188
ERROR - 2018-05-02 08:18:56 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 205
ERROR - 2018-05-02 08:18:56 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 217
ERROR - 2018-05-02 08:18:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 217
ERROR - 2018-05-02 08:18:56 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 237
ERROR - 2018-05-02 08:18:56 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 249
ERROR - 2018-05-02 08:18:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 249
ERROR - 2018-05-02 08:18:56 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 269
ERROR - 2018-05-02 08:18:56 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 281
ERROR - 2018-05-02 08:18:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 281
ERROR - 2018-05-02 08:29:24 --> Severity: Notice --> Undefined variable: new_order D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 146
ERROR - 2018-05-02 08:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 146
ERROR - 2018-05-02 08:29:24 --> Severity: Notice --> Undefined variable: unpaid_invoice D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 188
ERROR - 2018-05-02 08:29:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 188
ERROR - 2018-05-02 08:29:25 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 205
ERROR - 2018-05-02 08:29:25 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 217
ERROR - 2018-05-02 08:29:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 217
ERROR - 2018-05-02 08:29:25 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 237
ERROR - 2018-05-02 08:29:25 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 249
ERROR - 2018-05-02 08:29:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 249
ERROR - 2018-05-02 08:29:25 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 269
ERROR - 2018-05-02 08:29:25 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 281
ERROR - 2018-05-02 08:29:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 281
ERROR - 2018-05-02 08:29:28 --> Severity: Notice --> Undefined variable: new_order D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 146
ERROR - 2018-05-02 08:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 146
ERROR - 2018-05-02 08:29:28 --> Severity: Notice --> Undefined variable: unpaid_invoice D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 188
ERROR - 2018-05-02 08:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 188
ERROR - 2018-05-02 08:29:28 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 205
ERROR - 2018-05-02 08:29:28 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 217
ERROR - 2018-05-02 08:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 217
ERROR - 2018-05-02 08:29:28 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 237
ERROR - 2018-05-02 08:29:28 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 249
ERROR - 2018-05-02 08:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 249
ERROR - 2018-05-02 08:29:28 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 269
ERROR - 2018-05-02 08:29:28 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 281
ERROR - 2018-05-02 08:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 281
ERROR - 2018-05-02 08:29:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 08:29:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 08:33:02 --> Severity: Notice --> Undefined variable: trailer D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 146
ERROR - 2018-05-02 08:33:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 146
ERROR - 2018-05-02 08:33:02 --> Severity: Notice --> Undefined variable: unpaid_invoice D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 178
ERROR - 2018-05-02 08:33:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 178
ERROR - 2018-05-02 08:33:02 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 195
ERROR - 2018-05-02 08:33:02 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 207
ERROR - 2018-05-02 08:33:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 207
ERROR - 2018-05-02 08:33:02 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 227
ERROR - 2018-05-02 08:33:02 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 239
ERROR - 2018-05-02 08:33:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 239
ERROR - 2018-05-02 08:33:02 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 259
ERROR - 2018-05-02 08:33:02 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 271
ERROR - 2018-05-02 08:33:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 271
ERROR - 2018-05-02 08:33:09 --> Severity: Notice --> Undefined variable: unpaid_invoice D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 178
ERROR - 2018-05-02 08:33:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 178
ERROR - 2018-05-02 08:33:09 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 195
ERROR - 2018-05-02 08:33:09 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 207
ERROR - 2018-05-02 08:33:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 207
ERROR - 2018-05-02 08:33:09 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 227
ERROR - 2018-05-02 08:33:09 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 239
ERROR - 2018-05-02 08:33:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 239
ERROR - 2018-05-02 08:33:09 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 259
ERROR - 2018-05-02 08:33:09 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 271
ERROR - 2018-05-02 08:33:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 271
ERROR - 2018-05-02 08:33:25 --> Severity: Notice --> Undefined variable: unpaid_invoice D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 178
ERROR - 2018-05-02 08:33:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 178
ERROR - 2018-05-02 08:33:25 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 195
ERROR - 2018-05-02 08:33:25 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 207
ERROR - 2018-05-02 08:33:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 207
ERROR - 2018-05-02 08:33:25 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 227
ERROR - 2018-05-02 08:33:25 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 239
ERROR - 2018-05-02 08:33:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 239
ERROR - 2018-05-02 08:33:25 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 259
ERROR - 2018-05-02 08:33:25 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 271
ERROR - 2018-05-02 08:33:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 271
ERROR - 2018-05-02 08:36:19 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 178
ERROR - 2018-05-02 08:36:19 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 178
ERROR - 2018-05-02 08:36:19 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 178
ERROR - 2018-05-02 08:36:19 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 201
ERROR - 2018-05-02 08:36:19 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 212
ERROR - 2018-05-02 08:36:19 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 224
ERROR - 2018-05-02 08:36:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 224
ERROR - 2018-05-02 08:36:19 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 244
ERROR - 2018-05-02 08:36:19 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 256
ERROR - 2018-05-02 08:36:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 256
ERROR - 2018-05-02 08:38:06 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 176
ERROR - 2018-05-02 08:38:06 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:38:06 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:38:06 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:38:06 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 202
ERROR - 2018-05-02 08:38:06 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 213
ERROR - 2018-05-02 08:38:06 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:38:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:38:06 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 245
ERROR - 2018-05-02 08:38:06 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:38:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:38:17 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 176
ERROR - 2018-05-02 08:38:17 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 180
ERROR - 2018-05-02 08:38:17 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 180
ERROR - 2018-05-02 08:38:17 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 180
ERROR - 2018-05-02 08:38:17 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 203
ERROR - 2018-05-02 08:38:17 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 214
ERROR - 2018-05-02 08:38:17 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 226
ERROR - 2018-05-02 08:38:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 226
ERROR - 2018-05-02 08:38:17 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 246
ERROR - 2018-05-02 08:38:17 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 258
ERROR - 2018-05-02 08:38:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 258
ERROR - 2018-05-02 08:39:14 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 174
ERROR - 2018-05-02 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 202
ERROR - 2018-05-02 08:39:14 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 213
ERROR - 2018-05-02 08:39:14 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:39:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:39:14 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 245
ERROR - 2018-05-02 08:39:14 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:39:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 174
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 202
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 213
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 245
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 174
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 202
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 213
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 245
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 174
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 179
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 202
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 213
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 245
ERROR - 2018-05-02 08:39:15 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:39:30 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 174
ERROR - 2018-05-02 08:39:30 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 202
ERROR - 2018-05-02 08:39:30 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 213
ERROR - 2018-05-02 08:39:30 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:39:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 225
ERROR - 2018-05-02 08:39:30 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 245
ERROR - 2018-05-02 08:39:30 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:39:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 257
ERROR - 2018-05-02 08:45:29 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 212
ERROR - 2018-05-02 08:45:29 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 224
ERROR - 2018-05-02 08:45:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 224
ERROR - 2018-05-02 08:45:30 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 244
ERROR - 2018-05-02 08:45:30 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 256
ERROR - 2018-05-02 08:45:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 256
ERROR - 2018-05-02 08:46:20 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 212
ERROR - 2018-05-02 08:46:20 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 224
ERROR - 2018-05-02 08:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 224
ERROR - 2018-05-02 08:46:20 --> Severity: Notice --> Undefined variable: card_info D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 244
ERROR - 2018-05-02 08:46:20 --> Severity: Notice --> Undefined variable: sales_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 256
ERROR - 2018-05-02 08:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 256
ERROR - 2018-05-02 10:30:38 --> Severity: Error --> Call to undefined method Report_model::get_inactivetruck() D:\xampp\htdocs\project-transport\application\controllers\app\Dashboard.php 23
ERROR - 2018-05-02 10:30:38 --> Severity: Error --> Call to undefined method Report_model::get_inactivetruck() D:\xampp\htdocs\project-transport\application\controllers\app\Dashboard.php 23
ERROR - 2018-05-02 10:30:48 --> Severity: Error --> Call to undefined method Report_model::get_inactivetruck() D:\xampp\htdocs\project-transport\application\controllers\app\Dashboard.php 23
ERROR - 2018-05-02 10:58:54 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 10:59:35 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:00:21 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:01:26 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:02:00 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:03:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:03:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:03:15 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:03:18 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:03:18 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:04:46 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:04:46 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:05:51 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:05:54 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:06:00 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:06:01 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:06:19 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:06:19 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:06:19 --> 404 Page Not Found: app/Reports/daily
ERROR - 2018-05-02 11:06:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:06:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:06:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:06:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:07:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:07:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:08:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:08:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:12:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:12:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:12:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-02 11:12:52 --> 404 Page Not Found: Public/lib

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-27 02:40:13 --> The path to the image is not correct.
ERROR - 2018-06-27 02:40:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 03:03:19 --> The path to the image is not correct.
ERROR - 2018-06-27 03:03:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 03:03:19 --> The path to the image is not correct.
ERROR - 2018-06-27 03:03:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 03:03:19 --> The path to the image is not correct.
ERROR - 2018-06-27 03:03:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 04:31:06 --> The path to the image is not correct.
ERROR - 2018-06-27 04:31:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 05:31:57 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-06-27 05:31:57 --> The provided image is not valid.
ERROR - 2018-06-27 05:31:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 05:31:57 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-06-27 05:31:57 --> The provided image is not valid.
ERROR - 2018-06-27 05:31:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 05:34:00 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-27 05:34:00 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-27 05:34:00 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-27 05:34:00 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-27 05:34:00 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-27 05:44:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-27 05:44:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-27 05:44:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-27 05:44:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-27 05:45:00 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-27 07:30:01 --> The path to the image is not correct.
ERROR - 2018-06-27 07:30:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 08:35:36 --> The path to the image is not correct.
ERROR - 2018-06-27 08:35:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 08:35:36 --> The path to the image is not correct.
ERROR - 2018-06-27 08:35:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 08:35:38 --> The path to the image is not correct.
ERROR - 2018-06-27 08:35:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 08:36:18 --> The path to the image is not correct.
ERROR - 2018-06-27 08:36:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 08:41:10 --> The path to the image is not correct.
ERROR - 2018-06-27 08:41:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 11
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 209
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 222
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 234
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 29
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-27 09:37:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-27 09:37:55 --> 404 Page Not Found: admin/Accounts/%3Cdiv%20style=
ERROR - 2018-06-27 09:37:55 --> The path to the image is not correct.
ERROR - 2018-06-27 09:37:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:37:55 --> The path to the image is not correct.
ERROR - 2018-06-27 09:37:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:38:01 --> 404 Page Not Found: admin/Accounts/add
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 11
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 209
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 222
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 234
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 29
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-27 09:38:02 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-27 09:38:02 --> The path to the image is not correct.
ERROR - 2018-06-27 09:38:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-27 09:38:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-27 09:38:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-27 09:38:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\dashboard.php 95
ERROR - 2018-06-27 09:38:21 --> The path to the image is not correct.
ERROR - 2018-06-27 09:38:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:38:23 --> The path to the image is not correct.
ERROR - 2018-06-27 09:38:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:38:23 --> The path to the image is not correct.
ERROR - 2018-06-27 09:38:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:40:27 --> The path to the image is not correct.
ERROR - 2018-06-27 09:40:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:43:35 --> The path to the image is not correct.
ERROR - 2018-06-27 09:43:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:43:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:43:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:43:42 --> The path to the image is not correct.
ERROR - 2018-06-27 09:43:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:43:43 --> The path to the image is not correct.
ERROR - 2018-06-27 09:43:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:43:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:43:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:43:43 --> The path to the image is not correct.
ERROR - 2018-06-27 09:43:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:43:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:43:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:43:43 --> The path to the image is not correct.
ERROR - 2018-06-27 09:43:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:43:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:43:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:44:05 --> The path to the image is not correct.
ERROR - 2018-06-27 09:44:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:44:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:44:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:50:45 --> The path to the image is not correct.
ERROR - 2018-06-27 09:50:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 09:50:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 09:50:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 10:49:52 --> The path to the image is not correct.
ERROR - 2018-06-27 10:49:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:49:53 --> The path to the image is not correct.
ERROR - 2018-06-27 10:49:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:49:53 --> The path to the image is not correct.
ERROR - 2018-06-27 10:49:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:49:58 --> Severity: Notice --> Undefined property: Accounts::$invoice D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 143
ERROR - 2018-06-27 10:49:58 --> Severity: Error --> Call to a member function get_invoice_by_id() on null D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 143
ERROR - 2018-06-27 10:50:34 --> Severity: Error --> Call to undefined method Invoice_model::get_invoice_by_id() D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 144
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 84
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 47
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: payment_method D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 63
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 68
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: display_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 75
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: company_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 84
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 85
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 94
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: items_list D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 106
ERROR - 2018-06-27 10:51:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 106
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: items D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 117
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 119
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: gst D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 123
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: gst_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 124
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 129
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: gst D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 159
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 160
ERROR - 2018-06-27 10:51:38 --> Severity: Notice --> Undefined variable: gst_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 161
ERROR - 2018-06-27 10:51:39 --> The path to the image is not correct.
ERROR - 2018-06-27 10:51:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:51:39 --> The path to the image is not correct.
ERROR - 2018-06-27 10:51:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:52:36 --> The path to the image is not correct.
ERROR - 2018-06-27 10:52:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:52:36 --> The path to the image is not correct.
ERROR - 2018-06-27 10:52:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:52:37 --> The path to the image is not correct.
ERROR - 2018-06-27 10:52:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:52:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 84
ERROR - 2018-06-27 10:52:40 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 47
ERROR - 2018-06-27 10:52:40 --> Severity: Notice --> Undefined variable: payment_method D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 63
ERROR - 2018-06-27 10:52:40 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 68
ERROR - 2018-06-27 10:52:40 --> Severity: Notice --> Undefined variable: display_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 75
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: company_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 84
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 85
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 94
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: items_list D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 106
ERROR - 2018-06-27 10:52:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 106
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: items D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 117
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 119
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: gst D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 123
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: gst_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 124
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 129
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: gst D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 159
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 160
ERROR - 2018-06-27 10:52:41 --> Severity: Notice --> Undefined variable: gst_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 161
ERROR - 2018-06-27 10:52:41 --> The path to the image is not correct.
ERROR - 2018-06-27 10:52:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:52:41 --> The path to the image is not correct.
ERROR - 2018-06-27 10:52:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:52:41 --> The path to the image is not correct.
ERROR - 2018-06-27 10:52:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:53:32 --> The path to the image is not correct.
ERROR - 2018-06-27 10:53:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:53:32 --> The path to the image is not correct.
ERROR - 2018-06-27 10:53:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:53:32 --> The path to the image is not correct.
ERROR - 2018-06-27 10:53:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 84
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 47
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: payment_method D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 63
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 68
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: display_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 75
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: company_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 84
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 85
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 94
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: items_list D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 106
ERROR - 2018-06-27 10:54:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 106
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: items D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 117
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 119
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: gst D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 123
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: gst_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 124
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 129
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: gst D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 159
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 160
ERROR - 2018-06-27 10:54:15 --> Severity: Notice --> Undefined variable: gst_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 161
ERROR - 2018-06-27 10:55:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 41
ERROR - 2018-06-27 10:55:09 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 41
ERROR - 2018-06-27 10:55:55 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting ']' D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 43
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: payment_method D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 63
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: company_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 84
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 85
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 94
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: items_list D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 106
ERROR - 2018-06-27 10:56:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 106
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: items D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 117
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: gst D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 123
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: gst_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 124
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 129
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: gst D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 159
ERROR - 2018-06-27 10:56:24 --> Severity: Notice --> Undefined variable: gst_price D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 161
ERROR - 2018-06-27 11:01:26 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 84
ERROR - 2018-06-27 11:01:26 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 85
ERROR - 2018-06-27 11:01:26 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:02:11 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 84
ERROR - 2018-06-27 11:02:11 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 85
ERROR - 2018-06-27 11:02:11 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:08:12 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 84
ERROR - 2018-06-27 11:08:12 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 85
ERROR - 2018-06-27 11:08:12 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:08:37 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 84
ERROR - 2018-06-27 11:08:37 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 85
ERROR - 2018-06-27 11:08:37 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:08:39 --> The path to the image is not correct.
ERROR - 2018-06-27 11:08:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:08:39 --> The path to the image is not correct.
ERROR - 2018-06-27 11:08:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:08:43 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 84
ERROR - 2018-06-27 11:08:43 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 85
ERROR - 2018-06-27 11:08:43 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:10:09 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 84
ERROR - 2018-06-27 11:10:09 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 85
ERROR - 2018-06-27 11:10:09 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:14:03 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 84
ERROR - 2018-06-27 11:14:03 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-06-27 11:14:03 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:16:02 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 84
ERROR - 2018-06-27 11:16:02 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-06-27 11:16:02 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:19:15 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 86
ERROR - 2018-06-27 11:19:23 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 47
ERROR - 2018-06-27 11:19:23 --> Severity: Notice --> Undefined variable: display_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 75
ERROR - 2018-06-27 11:19:23 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 84
ERROR - 2018-06-27 11:19:23 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-06-27 11:19:23 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:19:23 --> Severity: Notice --> Undefined variable: price D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 119
ERROR - 2018-06-27 11:20:32 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 84
ERROR - 2018-06-27 11:20:32 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-06-27 11:20:32 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:22:26 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:23:19 --> The path to the image is not correct.
ERROR - 2018-06-27 11:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:19 --> The path to the image is not correct.
ERROR - 2018-06-27 11:23:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:19 --> The path to the image is not correct.
ERROR - 2018-06-27 11:23:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:26 --> The path to the image is not correct.
ERROR - 2018-06-27 11:23:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:23:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:26 --> The path to the image is not correct.
ERROR - 2018-06-27 11:23:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:23:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:26 --> The path to the image is not correct.
ERROR - 2018-06-27 11:23:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:23:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:23:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:30:08 --> The path to the image is not correct.
ERROR - 2018-06-27 11:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:30:08 --> The path to the image is not correct.
ERROR - 2018-06-27 11:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:31:58 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:32:58 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:33:19 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:33:37 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:35:05 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:35:16 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-27 11:35:16 --> The path to the image is not correct.
ERROR - 2018-06-27 11:35:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:35:16 --> The path to the image is not correct.
ERROR - 2018-06-27 11:35:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:35:20 --> The path to the image is not correct.
ERROR - 2018-06-27 11:35:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:35:24 --> The path to the image is not correct.
ERROR - 2018-06-27 11:35:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:36:00 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::order_by() D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 17
ERROR - 2018-06-27 11:36:10 --> The path to the image is not correct.
ERROR - 2018-06-27 11:36:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:36:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:36:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:37:54 --> The path to the image is not correct.
ERROR - 2018-06-27 11:37:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:37:57 --> The path to the image is not correct.
ERROR - 2018-06-27 11:37:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:38:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:38:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:38:30 --> The path to the image is not correct.
ERROR - 2018-06-27 11:38:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:38:30 --> The path to the image is not correct.
ERROR - 2018-06-27 11:38:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:38:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:38:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:38:31 --> The path to the image is not correct.
ERROR - 2018-06-27 11:38:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:38:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:38:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:39:22 --> The path to the image is not correct.
ERROR - 2018-06-27 11:39:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:39:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:39:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:39:31 --> The path to the image is not correct.
ERROR - 2018-06-27 11:39:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:39:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:39:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:39:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:39:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:39:41 --> The path to the image is not correct.
ERROR - 2018-06-27 11:39:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:39:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:39:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:39:42 --> The path to the image is not correct.
ERROR - 2018-06-27 11:39:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:39:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:39:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:42:45 --> The path to the image is not correct.
ERROR - 2018-06-27 11:42:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-27 11:42:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-27 11:42:45 --> 404 Page Not Found: Public/lib

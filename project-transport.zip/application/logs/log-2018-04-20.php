<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-20 04:13:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 04:13:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 04:13:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 04:17:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 04:17:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 04:17:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 04:17:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 04:24:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 04:51:36 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 04:51:36 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:00:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:00:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:00:12 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:00:12 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:00:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:00:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:00:13 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:00:13 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:00:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:00:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:00:15 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:00:15 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:00:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:00:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:04:57 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:04:57 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:04:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:04:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:04:57 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:04:57 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:04:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:04:58 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:04:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:04:58 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:04:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:04:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:18:48 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:18:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:18:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:18:56 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:18:56 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:18:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:18:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:19:01 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:19:01 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:19:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:19:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:19:02 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:19:02 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:19:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:19:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:20:31 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:20:31 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:20:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:20:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:20:32 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:20:32 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:20:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:20:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:20:32 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:20:32 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:20:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:20:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:20:32 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:20:32 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:20:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:20:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:20:33 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:20:33 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:20:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:20:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:22:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:22:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:22:06 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:22:06 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:22:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:22:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:22:11 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:22:11 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:22:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:22:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:22:40 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:22:40 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:22:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:22:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:23:28 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:23:28 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:23:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:23:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:23:29 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:23:29 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:23:30 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:23:30 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:23:30 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:23:30 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:24:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 05:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:24:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:24:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:25:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-20 05:25:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-20 05:25:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:25:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:27:51 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:27:51 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:27:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:27:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:28:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:28:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:28:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:28:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:28:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:28:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:28:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:28:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:29:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:29:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:29:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:29:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:30:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:30:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:30:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:30:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:30:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:30:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:30:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:30:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:57:29 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 8
ERROR - 2018-04-20 05:57:29 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-20 05:57:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:57:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:58:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:58:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:58:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 05:58:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 15
ERROR - 2018-04-20 06:18:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:18:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:19:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:19:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:20:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:20:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:22:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:22:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:24:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:24:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:25:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:25:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:26:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:26:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:26:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:26:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:27:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:27:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:27:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:27:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:28:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:28:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:28:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:28:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:28:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:28:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:29:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:29:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:29:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:29:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:30:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:30:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:30:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:30:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:31:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:31:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:36:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:36:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:37:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:37:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:38:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:38:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:38:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 06:38:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:35:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:35:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:37:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 102
ERROR - 2018-04-20 07:40:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:40:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:41:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:41:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:47:25 --> Severity: Parsing Error --> syntax error, unexpected '$result' (T_VARIABLE), expecting function (T_FUNCTION) D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-20 07:47:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:47:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:52:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:52:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:52:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:52:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:53:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:53:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:54:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:54:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:55:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:55:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:57:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 07:57:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:22:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:22:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:22:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:22:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:22:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:22:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:22:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:22:57 --> 404 Page Not Found: app/Report/create_pdf
ERROR - 2018-04-20 08:26:26 --> 404 Page Not Found: app/Report/create_pdf
ERROR - 2018-04-20 08:27:45 --> 404 Page Not Found: app/Report/create_pdf
ERROR - 2018-04-20 08:27:46 --> 404 Page Not Found: app/Report/create_pdf
ERROR - 2018-04-20 08:27:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:27:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:28:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:28:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:28:18 --> 404 Page Not Found: app/Report/create_pdf
ERROR - 2018-04-20 08:28:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:28:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 08:29:05 --> Severity: Notice --> Undefined property: Report::$report D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 72
ERROR - 2018-04-20 08:29:06 --> Severity: Error --> Call to a member function get_report_by_id() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 72
ERROR - 2018-04-20 08:29:31 --> Severity: Notice --> Undefined property: Report::$report D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 72
ERROR - 2018-04-20 08:29:31 --> Severity: Error --> Call to a member function get_report_by_id() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 72
ERROR - 2018-04-20 08:30:03 --> Severity: Notice --> Undefined property: Report::$report D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 72
ERROR - 2018-04-20 08:30:03 --> Severity: Error --> Call to a member function get_report_by_id() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 72
ERROR - 2018-04-20 08:31:31 --> Severity: Notice --> Undefined property: Report::$report D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 72
ERROR - 2018-04-20 08:31:31 --> Severity: Error --> Call to a member function get_report_by_id() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 72
ERROR - 2018-04-20 08:36:21 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 08:36:21 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 08:46:09 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 08:46:09 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 08:46:55 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 08:46:55 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:03 --> Severity: Notice --> Undefined property: stdClass::$invoice_pdf D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:03 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:17 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:18 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:18 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:19 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:19 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:19 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:19 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:19 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:20 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:20 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:20 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:20 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:20 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:21 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:21 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:21 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:21 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:21 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:22 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:22 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:22 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:22 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:23 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:23 --> Severity: Notice --> Undefined property: stdClass::$report D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-20 09:05:33 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:33 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:34 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:34 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:34 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:34 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:35 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:35 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:35 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:35 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:35 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:35 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:35 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:35 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:35 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:35 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:36 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:36 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:36 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:36 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:46 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:46 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:49 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:05:49 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:06:15 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:06:15 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:43:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 09:43:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 09:43:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 09:43:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 09:43:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 09:43:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 09:43:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 09:43:22 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:43:22 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:48:44 --> Severity: Warning --> require(D:\xampp\htdocs\project-transport\application\third_party/pdf/vendor/autoload.php): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 4
ERROR - 2018-04-20 09:48:44 --> Severity: Compile Error --> require(): Failed opening required 'D:\xampp\htdocs\project-transport\application\third_party/pdf/vendor/autoload.php' (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 4
ERROR - 2018-04-20 09:51:46 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 09:51:46 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:28:07 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:28:07 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:28:07 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:28:07 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:28:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 10:28:18 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:28:18 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:35:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 10:35:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 10:35:45 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:35:45 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:37:18 --> 404 Page Not Found: app/Report/create_pdf
ERROR - 2018-04-20 10:37:19 --> 404 Page Not Found: app/Report/create_pdf
ERROR - 2018-04-20 10:37:19 --> 404 Page Not Found: app/Report/create_pdf
ERROR - 2018-04-20 10:37:19 --> 404 Page Not Found: app/Report/create_pdf
ERROR - 2018-04-20 10:37:20 --> 404 Page Not Found: app/Report/create_pdf
ERROR - 2018-04-20 10:37:24 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:37:24 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:46:32 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:46:32 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:46:32 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:46:32 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 10:47:13 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:13 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:13 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:15 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:15 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:15 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:15 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:15 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:23 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:23 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:23 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:23 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:23 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 10:47:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 15
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 17
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 21
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 23
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 27
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 29
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 33
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 37
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 54
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 79
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:31 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:38 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:42 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:43 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:44 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:46 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:47:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:47:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:47:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:47:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:47:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:47:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:47:48 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$hash D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 76
ERROR - 2018-04-20 10:47:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-04-20 10:47:48 --> Severity: Error --> Call to a member function decrypt() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 76
ERROR - 2018-04-20 10:54:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 10:54:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 10:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 10:54:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 10:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:24 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:26 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 10:54:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 10:54:31 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$hash D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 76
ERROR - 2018-04-20 10:54:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-04-20 10:54:31 --> Severity: Error --> Call to a member function decrypt() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 76
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:01:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:01:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:01:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:01:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:01:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:01:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:01:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:01:59 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:02:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:02:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:02:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:02:01 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:02:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:02:01 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 11:02:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:02:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:02:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:02:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:02:03 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:04 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:05 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:06 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:07 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:02:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:07 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:07 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:08 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:09 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:02:10 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$hash D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 76
ERROR - 2018-04-20 11:02:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-04-20 11:02:11 --> Severity: Error --> Call to a member function decrypt() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 76
ERROR - 2018-04-20 11:02:39 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:39 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:39 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:39 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:39 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:39 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:40 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:40 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:40 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:40 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:40 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:40 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:40 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:40 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:41 --> Severity: Notice --> Undefined property: Report::$pdf D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:02:41 --> Severity: Error --> Call to a member function create_report_checklist() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:03 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:03:04 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:03:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:03:07 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:07 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:03:07 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:03:07 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:07 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:07 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:03:07 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:03:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 11:03:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 11:04:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 11:04:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:30 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:31 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:32 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:33 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:36 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$hash D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 75
ERROR - 2018-04-20 11:04:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-04-20 11:04:36 --> Severity: Error --> Call to a member function decrypt() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 75
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:04:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:43 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:43 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 11:04:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:45 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:47 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:48 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:49 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:50 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:04:51 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:04:52 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$hash D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:04:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-04-20 11:04:53 --> Severity: Error --> Call to a member function decrypt() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:05:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:05:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:05:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:37 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:05:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:38 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:38 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:39 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:40 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-04-20 11:05:41 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-04-20 11:05:42 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-04-20 11:05:42 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-04-20 11:05:42 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$hash D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:05:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-04-20 11:05:42 --> Severity: Error --> Call to a member function decrypt() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:06:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:06:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:06:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 14
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 16
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 20
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 22
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 26
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 28
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 32
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:06:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 50
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:06:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:06:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 71
ERROR - 2018-04-20 11:08:48 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$hash D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74
ERROR - 2018-04-20 11:08:48 --> Severity: Error --> Call to a member function decrypt() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 74

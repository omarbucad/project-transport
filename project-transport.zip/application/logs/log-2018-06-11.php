<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-11 02:35:38 --> The path to the image is not correct.
ERROR - 2018-06-11 02:35:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 02:36:22 --> The path to the image is not correct.
ERROR - 2018-06-11 02:36:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 02:36:25 --> The path to the image is not correct.
ERROR - 2018-06-11 02:36:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 03:15:12 --> The path to the image is not correct.
ERROR - 2018-06-11 03:15:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 03:15:20 --> The path to the image is not correct.
ERROR - 2018-06-11 03:15:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 03:15:20 --> The path to the image is not correct.
ERROR - 2018-06-11 03:15:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 03:15:24 --> The path to the image is not correct.
ERROR - 2018-06-11 03:15:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 03:16:36 --> Severity: Notice --> Use of undefined constant angelleye - assumed 'angelleye' D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 199
ERROR - 2018-06-11 05:30:33 --> The path to the image is not correct.
ERROR - 2018-06-11 05:30:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 05:30:57 --> The path to the image is not correct.
ERROR - 2018-06-11 05:30:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 05:31:01 --> The path to the image is not correct.
ERROR - 2018-06-11 05:31:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 05:55:34 --> The path to the image is not correct.
ERROR - 2018-06-11 05:55:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 05:55:44 --> The path to the image is not correct.
ERROR - 2018-06-11 05:55:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 05:55:47 --> The path to the image is not correct.
ERROR - 2018-06-11 05:55:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 05:56:01 --> The path to the image is not correct.
ERROR - 2018-06-11 05:56:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 05:57:48 --> The path to the image is not correct.
ERROR - 2018-06-11 05:57:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 05:58:23 --> The path to the image is not correct.
ERROR - 2018-06-11 05:58:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:21:51 --> The path to the image is not correct.
ERROR - 2018-06-11 06:21:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:21:55 --> The path to the image is not correct.
ERROR - 2018-06-11 06:21:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:22:06 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-11 06:22:06 --> The path to the image is not correct.
ERROR - 2018-06-11 06:22:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:23:53 --> The path to the image is not correct.
ERROR - 2018-06-11 06:23:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:23:53 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-11 06:24:25 --> The path to the image is not correct.
ERROR - 2018-06-11 06:24:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:24:25 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-11 06:24:29 --> The path to the image is not correct.
ERROR - 2018-06-11 06:24:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:24:36 --> The path to the image is not correct.
ERROR - 2018-06-11 06:24:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:24:40 --> The path to the image is not correct.
ERROR - 2018-06-11 06:24:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:24:40 --> 404 Page Not Found: Public/upload
ERROR - 2018-06-11 06:27:04 --> The path to the image is not correct.
ERROR - 2018-06-11 06:27:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:27:05 --> The path to the image is not correct.
ERROR - 2018-06-11 06:27:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:27:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 06:27:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 06:27:19 --> The path to the image is not correct.
ERROR - 2018-06-11 06:27:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:27:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 06:27:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 06:27:21 --> The path to the image is not correct.
ERROR - 2018-06-11 06:27:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 06:27:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 06:27:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:33:50 --> The path to the image is not correct.
ERROR - 2018-06-11 07:33:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:33:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:33:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:34:49 --> The path to the image is not correct.
ERROR - 2018-06-11 07:34:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:34:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:34:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:35:24 --> The path to the image is not correct.
ERROR - 2018-06-11 07:35:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:35:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:35:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:38:30 --> The path to the image is not correct.
ERROR - 2018-06-11 07:38:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:38:33 --> 404 Page Not Found: app/Report/index
ERROR - 2018-06-11 07:39:09 --> The path to the image is not correct.
ERROR - 2018-06-11 07:39:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:39:11 --> The path to the image is not correct.
ERROR - 2018-06-11 07:39:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:39:12 --> The path to the image is not correct.
ERROR - 2018-06-11 07:39:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:39:12 --> The path to the image is not correct.
ERROR - 2018-06-11 07:39:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:39:14 --> 404 Page Not Found: app/Report/index
ERROR - 2018-06-11 07:39:40 --> The path to the image is not correct.
ERROR - 2018-06-11 07:39:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:39:41 --> The path to the image is not correct.
ERROR - 2018-06-11 07:39:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:39:41 --> The path to the image is not correct.
ERROR - 2018-06-11 07:39:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:39:41 --> The path to the image is not correct.
ERROR - 2018-06-11 07:39:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:39:41 --> The path to the image is not correct.
ERROR - 2018-06-11 07:39:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:40:26 --> The path to the image is not correct.
ERROR - 2018-06-11 07:40:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:40:43 --> The path to the image is not correct.
ERROR - 2018-06-11 07:40:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:40:44 --> The path to the image is not correct.
ERROR - 2018-06-11 07:40:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:42:21 --> The path to the image is not correct.
ERROR - 2018-06-11 07:42:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:42:26 --> The path to the image is not correct.
ERROR - 2018-06-11 07:42:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:42:41 --> The path to the image is not correct.
ERROR - 2018-06-11 07:42:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:42:46 --> The path to the image is not correct.
ERROR - 2018-06-11 07:42:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:42:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:42:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:42:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:42:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:06 --> The path to the image is not correct.
ERROR - 2018-06-11 07:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:45:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:07 --> The path to the image is not correct.
ERROR - 2018-06-11 07:45:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:45:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:07 --> The path to the image is not correct.
ERROR - 2018-06-11 07:45:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:45:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:08 --> The path to the image is not correct.
ERROR - 2018-06-11 07:45:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:45:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:08 --> The path to the image is not correct.
ERROR - 2018-06-11 07:45:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:45:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:08 --> The path to the image is not correct.
ERROR - 2018-06-11 07:45:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:45:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:14 --> Query error: Unknown column 'c.display_name' in 'where clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
WHERE `c`.`display_name` = 'Trailer Checklist'
ORDER BY `r`.`created` DESC
ERROR - 2018-06-11 07:45:25 --> The path to the image is not correct.
ERROR - 2018-06-11 07:45:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:45:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:45:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-11 07:46:26 --> The path to the image is not correct.
ERROR - 2018-06-11 07:46:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:46:26 --> The path to the image is not correct.
ERROR - 2018-06-11 07:46:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:46:29 --> 404 Page Not Found: app/Users/view_user_info
ERROR - 2018-06-11 07:46:36 --> The path to the image is not correct.
ERROR - 2018-06-11 07:46:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:46:36 --> The path to the image is not correct.
ERROR - 2018-06-11 07:46:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:46:46 --> The path to the image is not correct.
ERROR - 2018-06-11 07:46:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:47:05 --> 404 Page Not Found: app/Users/view_user_info
ERROR - 2018-06-11 07:53:41 --> The path to the image is not correct.
ERROR - 2018-06-11 07:53:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:53:41 --> The path to the image is not correct.
ERROR - 2018-06-11 07:53:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:53:49 --> The path to the image is not correct.
ERROR - 2018-06-11 07:53:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 07:53:49 --> The path to the image is not correct.
ERROR - 2018-06-11 07:53:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 09:20:11 --> The path to the image is not correct.
ERROR - 2018-06-11 09:20:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-11 09:20:14 --> The path to the image is not correct.
ERROR - 2018-06-11 09:20:14 --> Your server does not support the GD function required to process this type of image.

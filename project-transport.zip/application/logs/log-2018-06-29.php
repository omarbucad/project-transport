<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-29 02:31:39 --> The path to the image is not correct.
ERROR - 2018-06-29 02:31:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 02:36:42 --> The path to the image is not correct.
ERROR - 2018-06-29 02:36:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 02:36:43 --> The path to the image is not correct.
ERROR - 2018-06-29 02:36:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 03:32:56 --> The path to the image is not correct.
ERROR - 2018-06-29 03:32:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 03:35:12 --> The path to the image is not correct.
ERROR - 2018-06-29 03:35:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 03:35:12 --> The path to the image is not correct.
ERROR - 2018-06-29 03:35:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 03:35:12 --> The path to the image is not correct.
ERROR - 2018-06-29 03:35:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 03:44:57 --> The path to the image is not correct.
ERROR - 2018-06-29 03:44:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:31:16 --> The path to the image is not correct.
ERROR - 2018-06-29 04:31:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:32:23 --> The path to the image is not correct.
ERROR - 2018-06-29 04:32:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:35:56 --> The path to the image is not correct.
ERROR - 2018-06-29 04:35:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:36:13 --> The path to the image is not correct.
ERROR - 2018-06-29 04:36:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:36:34 --> The path to the image is not correct.
ERROR - 2018-06-29 04:36:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:37:10 --> The path to the image is not correct.
ERROR - 2018-06-29 04:37:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:37:23 --> The path to the image is not correct.
ERROR - 2018-06-29 04:37:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:37:48 --> The path to the image is not correct.
ERROR - 2018-06-29 04:37:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:38:09 --> The path to the image is not correct.
ERROR - 2018-06-29 04:38:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:38:52 --> The path to the image is not correct.
ERROR - 2018-06-29 04:38:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:39:12 --> The path to the image is not correct.
ERROR - 2018-06-29 04:39:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:40:05 --> The path to the image is not correct.
ERROR - 2018-06-29 04:40:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:41:09 --> The path to the image is not correct.
ERROR - 2018-06-29 04:41:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:41:20 --> The path to the image is not correct.
ERROR - 2018-06-29 04:41:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 04:41:25 --> The path to the image is not correct.
ERROR - 2018-06-29 04:41:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-29 07:05:19 --> The path to the image is not correct.
ERROR - 2018-06-29 07:05:19 --> Your server does not support the GD function required to process this type of image.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-04 03:09:07 --> The path to the image is not correct.
ERROR - 2018-06-04 03:09:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:28:56 --> The path to the image is not correct.
ERROR - 2018-06-04 03:28:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:28:56 --> The path to the image is not correct.
ERROR - 2018-06-04 03:28:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:29:00 --> The path to the image is not correct.
ERROR - 2018-06-04 03:29:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:29:03 --> The path to the image is not correct.
ERROR - 2018-06-04 03:29:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:29:04 --> Severity: Notice --> Undefined variable: paypal_url D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 297
ERROR - 2018-06-04 03:29:04 --> The path to the image is not correct.
ERROR - 2018-06-04 03:29:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:30:03 --> The path to the image is not correct.
ERROR - 2018-06-04 03:30:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:32:40 --> The path to the image is not correct.
ERROR - 2018-06-04 03:32:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:33:44 --> The path to the image is not correct.
ERROR - 2018-06-04 03:33:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:34:00 --> The path to the image is not correct.
ERROR - 2018-06-04 03:34:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:35:09 --> The path to the image is not correct.
ERROR - 2018-06-04 03:35:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:35:39 --> The path to the image is not correct.
ERROR - 2018-06-04 03:35:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:35:51 --> The path to the image is not correct.
ERROR - 2018-06-04 03:35:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:36:08 --> The path to the image is not correct.
ERROR - 2018-06-04 03:36:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:36:20 --> The path to the image is not correct.
ERROR - 2018-06-04 03:36:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:55:51 --> The path to the image is not correct.
ERROR - 2018-06-04 03:55:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 03:55:52 --> The path to the image is not correct.
ERROR - 2018-06-04 03:55:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:08:36 --> The path to the image is not correct.
ERROR - 2018-06-04 05:08:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:08:38 --> The path to the image is not correct.
ERROR - 2018-06-04 05:08:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:17:14 --> The path to the image is not correct.
ERROR - 2018-06-04 05:17:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:17:27 --> The path to the image is not correct.
ERROR - 2018-06-04 05:17:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:17:35 --> The path to the image is not correct.
ERROR - 2018-06-04 05:17:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:23:59 --> The path to the image is not correct.
ERROR - 2018-06-04 05:23:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:23:59 --> The path to the image is not correct.
ERROR - 2018-06-04 05:23:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:24:02 --> The path to the image is not correct.
ERROR - 2018-06-04 05:24:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:24:18 --> The path to the image is not correct.
ERROR - 2018-06-04 05:24:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:25:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:25:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:32:40 --> The path to the image is not correct.
ERROR - 2018-06-04 05:32:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:32:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:32:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:32:53 --> The path to the image is not correct.
ERROR - 2018-06-04 05:32:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:32:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:32:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:33:04 --> The path to the image is not correct.
ERROR - 2018-06-04 05:33:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:33:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:33:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:33:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:33:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:33:19 --> The path to the image is not correct.
ERROR - 2018-06-04 05:33:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:33:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:33:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:02 --> The path to the image is not correct.
ERROR - 2018-06-04 05:42:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:42:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:06 --> The path to the image is not correct.
ERROR - 2018-06-04 05:42:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:42:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:06 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-06-04 05:42:06 --> The provided image is not valid.
ERROR - 2018-06-04 05:42:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:42:06 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-06-04 05:42:06 --> The provided image is not valid.
ERROR - 2018-06-04 05:42:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:42:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:26 --> The path to the image is not correct.
ERROR - 2018-06-04 05:42:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:42:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:35 --> The path to the image is not correct.
ERROR - 2018-06-04 05:42:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:42:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:41 --> The path to the image is not correct.
ERROR - 2018-06-04 05:42:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:42:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:49 --> The path to the image is not correct.
ERROR - 2018-06-04 05:42:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:42:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:55 --> The path to the image is not correct.
ERROR - 2018-06-04 05:42:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:42:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:42:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:44:04 --> The path to the image is not correct.
ERROR - 2018-06-04 05:44:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:44:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:44:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:44:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:44:50 --> The path to the image is not correct.
ERROR - 2018-06-04 05:44:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:44:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:44:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:44:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:44:52 --> The path to the image is not correct.
ERROR - 2018-06-04 05:44:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:44:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:44:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:44:52 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-06-04 05:44:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:44:52 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-06-04 05:44:52 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-06-04 05:44:52 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-06-04 05:44:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-06-04 05:44:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-06-04 05:44:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-06-04 05:44:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-06-04 05:44:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-06-04 05:44:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-06-04 05:44:52 --> The path to the image is not correct.
ERROR - 2018-06-04 05:44:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-06-04 05:45:02 --> The path to the image is not correct.
ERROR - 2018-06-04 05:45:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:45:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:04 --> The path to the image is not correct.
ERROR - 2018-06-04 05:45:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:45:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:25 --> The path to the image is not correct.
ERROR - 2018-06-04 05:45:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:45:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:45:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:55:35 --> The path to the image is not correct.
ERROR - 2018-06-04 05:55:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:55:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:55:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:55:38 --> The path to the image is not correct.
ERROR - 2018-06-04 05:55:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:55:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:55:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:55:41 --> The path to the image is not correct.
ERROR - 2018-06-04 05:55:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:55:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:55:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:56:00 --> The path to the image is not correct.
ERROR - 2018-06-04 05:56:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 05:56:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 05:56:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 07:01:27 --> The path to the image is not correct.
ERROR - 2018-06-04 07:01:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 07:01:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 07:01:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 07:56:38 --> The path to the image is not correct.
ERROR - 2018-06-04 07:56:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 07:56:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 07:56:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 07:56:40 --> The path to the image is not correct.
ERROR - 2018-06-04 07:56:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 07:56:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 07:56:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 08:14:45 --> The path to the image is not correct.
ERROR - 2018-06-04 08:14:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:19:01 --> The path to the image is not correct.
ERROR - 2018-06-04 08:19:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:25:56 --> The path to the image is not correct.
ERROR - 2018-06-04 08:25:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:27:30 --> The path to the image is not correct.
ERROR - 2018-06-04 08:27:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:28:53 --> The path to the image is not correct.
ERROR - 2018-06-04 08:28:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:33:21 --> Query error: Column 'report_id' in where clause is ambiguous - Invalid query: SELECT `rc`.*, `ci`.`item_name`, `ri`.`image_path`, `ri`.`image_name`
FROM `report_checklist` `rc`
JOIN `checklist_items` `ci` ON `ci`.`id` = `rc`.`checklist_item_id`
JOIN `report_images` `ri` ON `ri`.`report_checklist_id` = `rc`.`checklist_item_id`
WHERE `report_id` = '26'
ERROR - 2018-06-04 08:33:30 --> Query error: Column 'report_id' in where clause is ambiguous - Invalid query: SELECT `rc`.*, `ci`.`item_name`, `ri`.`image_path`, `ri`.`image_name`
FROM `report_checklist` `rc`
JOIN `checklist_items` `ci` ON `ci`.`id` = `rc`.`checklist_item_id`
JOIN `report_images` `ri` ON `ri`.`report_checklist_id` = `rc`.`checklist_item_id`
WHERE `report_id` = '26'
ERROR - 2018-06-04 08:34:02 --> The path to the image is not correct.
ERROR - 2018-06-04 08:34:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:34:24 --> The path to the image is not correct.
ERROR - 2018-06-04 08:34:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:35:31 --> The path to the image is not correct.
ERROR - 2018-06-04 08:35:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:38:12 --> The path to the image is not correct.
ERROR - 2018-06-04 08:38:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:39:26 --> The path to the image is not correct.
ERROR - 2018-06-04 08:39:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:39:33 --> The path to the image is not correct.
ERROR - 2018-06-04 08:39:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:39:37 --> The path to the image is not correct.
ERROR - 2018-06-04 08:39:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:39:40 --> The path to the image is not correct.
ERROR - 2018-06-04 08:39:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:39:43 --> The path to the image is not correct.
ERROR - 2018-06-04 08:39:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:39:48 --> The path to the image is not correct.
ERROR - 2018-06-04 08:39:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:39:54 --> The path to the image is not correct.
ERROR - 2018-06-04 08:39:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:40:13 --> The path to the image is not correct.
ERROR - 2018-06-04 08:40:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:40:17 --> The path to the image is not correct.
ERROR - 2018-06-04 08:40:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:50:05 --> The path to the image is not correct.
ERROR - 2018-06-04 08:50:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:50:22 --> The path to the image is not correct.
ERROR - 2018-06-04 08:50:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:50:46 --> The path to the image is not correct.
ERROR - 2018-06-04 08:50:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 08:51:00 --> The path to the image is not correct.
ERROR - 2018-06-04 08:51:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 10:38:57 --> The path to the image is not correct.
ERROR - 2018-06-04 10:38:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 10:39:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 10:39:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:02:41 --> 404 Page Not Found: app/Report/index
ERROR - 2018-06-04 11:02:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:02:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:03:03 --> The path to the image is not correct.
ERROR - 2018-06-04 11:03:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 11:03:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:03:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:03:03 --> The path to the image is not correct.
ERROR - 2018-06-04 11:03:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 11:03:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:03:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:06:38 --> The path to the image is not correct.
ERROR - 2018-06-04 11:06:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 11:06:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:06:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:13:09 --> The path to the image is not correct.
ERROR - 2018-06-04 11:13:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 11:13:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:13:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:14:32 --> The path to the image is not correct.
ERROR - 2018-06-04 11:14:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 11:14:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:14:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:14:38 --> The path to the image is not correct.
ERROR - 2018-06-04 11:14:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 11:14:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:14:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:14:45 --> The path to the image is not correct.
ERROR - 2018-06-04 11:14:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-04 11:14:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-04 11:14:45 --> 404 Page Not Found: Public/lib

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-17 03:46:58 --> The path to the image is not correct.
ERROR - 2018-04-17 03:46:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:47:00 --> The path to the image is not correct.
ERROR - 2018-04-17 03:47:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:47:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:47:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:47:15 --> The path to the image is not correct.
ERROR - 2018-04-17 03:47:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:47:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:47:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:47:34 --> The path to the image is not correct.
ERROR - 2018-04-17 03:47:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:47:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:47:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:47:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:47:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:47:43 --> The path to the image is not correct.
ERROR - 2018-04-17 03:47:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:49:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:49:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:49:29 --> The path to the image is not correct.
ERROR - 2018-04-17 03:49:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:50:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:50:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:50:03 --> The path to the image is not correct.
ERROR - 2018-04-17 03:50:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:51:16 --> The path to the image is not correct.
ERROR - 2018-04-17 03:51:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:51:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:51:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:53:57 --> The path to the image is not correct.
ERROR - 2018-04-17 03:53:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:53:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:53:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:53:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:53:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:54:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:54:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:54:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:54:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:54:42 --> The path to the image is not correct.
ERROR - 2018-04-17 03:54:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:54:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:54:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:54:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:54:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:54:46 --> The path to the image is not correct.
ERROR - 2018-04-17 03:54:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 03:54:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:54:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:55:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:55:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:56:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 03:56:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 04:00:24 --> The path to the image is not correct.
ERROR - 2018-04-17 04:00:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:00:31 --> The path to the image is not correct.
ERROR - 2018-04-17 04:00:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:01:38 --> The path to the image is not correct.
ERROR - 2018-04-17 04:01:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:01:40 --> The path to the image is not correct.
ERROR - 2018-04-17 04:01:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:01:43 --> The path to the image is not correct.
ERROR - 2018-04-17 04:01:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:01:45 --> The path to the image is not correct.
ERROR - 2018-04-17 04:01:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:01:48 --> The path to the image is not correct.
ERROR - 2018-04-17 04:01:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:02:19 --> The path to the image is not correct.
ERROR - 2018-04-17 04:02:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:05:11 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 103
ERROR - 2018-04-17 04:05:11 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 103
ERROR - 2018-04-17 04:05:11 --> The path to the image is not correct.
ERROR - 2018-04-17 04:05:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:05:44 --> The path to the image is not correct.
ERROR - 2018-04-17 04:05:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:05:47 --> The path to the image is not correct.
ERROR - 2018-04-17 04:05:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:05:51 --> The path to the image is not correct.
ERROR - 2018-04-17 04:05:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:09:08 --> The path to the image is not correct.
ERROR - 2018-04-17 04:09:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:09:17 --> The path to the image is not correct.
ERROR - 2018-04-17 04:09:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:11:02 --> The path to the image is not correct.
ERROR - 2018-04-17 04:11:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:11:04 --> The path to the image is not correct.
ERROR - 2018-04-17 04:11:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:11:05 --> The path to the image is not correct.
ERROR - 2018-04-17 04:11:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:11:11 --> Severity: Error --> Call to undefined method Accounts_model::edit_users() D:\xampp\htdocs\project-transport\application\controllers\app\Accounts.php 86
ERROR - 2018-04-17 04:11:36 --> The path to the image is not correct.
ERROR - 2018-04-17 04:11:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:11:38 --> The path to the image is not correct.
ERROR - 2018-04-17 04:11:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:11:40 --> The path to the image is not correct.
ERROR - 2018-04-17 04:11:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 04:14:45 --> The path to the image is not correct.
ERROR - 2018-04-17 04:14:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 05:18:22 --> The path to the image is not correct.
ERROR - 2018-04-17 05:18:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 05:20:29 --> The path to the image is not correct.
ERROR - 2018-04-17 05:20:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:13:54 --> 404 Page Not Found: app/Report/view
ERROR - 2018-04-17 07:14:28 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-17 07:14:30 --> The path to the image is not correct.
ERROR - 2018-04-17 07:14:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:16:39 --> The path to the image is not correct.
ERROR - 2018-04-17 07:16:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:16:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:16:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:17:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:17:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:17:48 --> The path to the image is not correct.
ERROR - 2018-04-17 07:17:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:18:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:18:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:18:05 --> The path to the image is not correct.
ERROR - 2018-04-17 07:18:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:18:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:18:10 --> The path to the image is not correct.
ERROR - 2018-04-17 07:18:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:18:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:18:18 --> The path to the image is not correct.
ERROR - 2018-04-17 07:18:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:18:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:18:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:18:26 --> The path to the image is not correct.
ERROR - 2018-04-17 07:18:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:18:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:18:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:18:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:18:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:18:34 --> The path to the image is not correct.
ERROR - 2018-04-17 07:18:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:27:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:27:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:25 --> The path to the image is not correct.
ERROR - 2018-04-17 07:28:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:28:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:28:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:30:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:30:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:30:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:31:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:31:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:31:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:31:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:31:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:31:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:31:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:31:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:31:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:32:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:32:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:32:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:32:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:32:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:39:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:39:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:39:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:39:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:39:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:39:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:39:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:39:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:40:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:41:11 --> The path to the image is not correct.
ERROR - 2018-04-17 07:41:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:41:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 07:41:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:41:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:41:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:41:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:42:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:42:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:42:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:42:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:49:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:49:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:50:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:50:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:50:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:50:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:51:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 07:52:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:12:51 --> Severity: Compile Error --> Cannot redeclare Login::forgot_password() D:\xampp\htdocs\project-transport\application\controllers\Login.php 40
ERROR - 2018-04-17 08:13:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:13:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:13:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:13:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:13:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:13:35 --> The path to the image is not correct.
ERROR - 2018-04-17 08:13:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 08:13:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:13:50 --> 404 Page Not Found: Login/forgot-password
ERROR - 2018-04-17 08:19:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:20:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:22:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:23:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:26:50 --> Query error: Table 'project_transport.customer' doesn't exist - Invalid query: SELECT `display_name`
FROM `customer`
WHERE `email` = 'cherlaj@trackerteer.com'
ERROR - 2018-04-17 08:27:02 --> Query error: Table 'project_transport.customer' doesn't exist - Invalid query: SELECT `display_name`
FROM `customer`
WHERE `email_address` = 'cherlaj@trackerteer.com'
ERROR - 2018-04-17 08:27:39 --> Query error: Table 'project_transport.customer' doesn't exist - Invalid query: SELECT `display_name`
FROM `customer`
WHERE `email_address` = 'cherlaj@trackerteer.com'
ERROR - 2018-04-17 08:57:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 08:58:05 --> Query error: Unknown column 'email' in 'field list' - Invalid query: SELECT `email`
FROM `user`
WHERE `email_address` = 'cherlaj@trackerteer.com'
ERROR - 2018-04-17 09:00:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:01:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:03:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:03:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:10:55 --> Severity: Notice --> Undefined property: Login::$product D:\xampp\htdocs\project-transport\application\controllers\Login.php 96
ERROR - 2018-04-17 09:10:55 --> Severity: Error --> Call to a member function get_category() on null D:\xampp\htdocs\project-transport\application\controllers\Login.php 96
ERROR - 2018-04-17 09:15:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:15:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:15:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:15:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:16:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:18:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:18:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:20:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:28:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:29:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:29:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:29:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:29:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:30:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:30:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:30:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:30:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:30:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:30:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:30:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:31:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:32:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:32:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:33:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:33:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:33:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:33:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:36:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:36:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:36:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:36:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:36:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:36:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:36:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:36:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:38:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:38:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:38:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:39:03 --> Severity: Notice --> Undefined index: username D:\xampp\htdocs\project-transport\application\models\Register_model.php 91
ERROR - 2018-04-17 09:39:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:39:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:39:48 --> Severity: Notice --> Undefined index: username D:\xampp\htdocs\project-transport\application\models\Register_model.php 91
ERROR - 2018-04-17 09:39:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:49:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:50:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:50:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:50:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 09:51:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:03:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:07:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:17:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:17:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:17:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:17:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:20:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:20:53 --> 404 Page Not Found: app/Login/index
ERROR - 2018-04-17 10:21:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:21:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:21:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:44:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:46:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:46:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 10:46:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:01:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:02:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:02:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:02:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:12:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:12:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:12:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:12:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:12:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:12:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:12:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:12:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:12:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:18:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:18:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:18:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:18:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:18:52 --> The path to the image is not correct.
ERROR - 2018-04-17 11:18:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 11:19:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:19:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:20:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:20:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:20:02 --> The path to the image is not correct.
ERROR - 2018-04-17 11:20:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-17 11:20:09 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-17 11:20:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:20:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:20:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:20:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-17 11:30:47 --> 404 Page Not Found: Api/login

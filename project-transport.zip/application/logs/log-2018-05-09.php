<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-09 07:24:57 --> The path to the image is not correct.
ERROR - 2018-05-09 07:24:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:25:09 --> The path to the image is not correct.
ERROR - 2018-05-09 07:25:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:25:52 --> The path to the image is not correct.
ERROR - 2018-05-09 07:25:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:27:41 --> The path to the image is not correct.
ERROR - 2018-05-09 07:27:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:27:53 --> The path to the image is not correct.
ERROR - 2018-05-09 07:27:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:29:15 --> The path to the image is not correct.
ERROR - 2018-05-09 07:29:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:30:00 --> The path to the image is not correct.
ERROR - 2018-05-09 07:30:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:32:21 --> The path to the image is not correct.
ERROR - 2018-05-09 07:32:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:37:18 --> The path to the image is not correct.
ERROR - 2018-05-09 07:37:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:38:00 --> The path to the image is not correct.
ERROR - 2018-05-09 07:38:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:41:11 --> The path to the image is not correct.
ERROR - 2018-05-09 07:41:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:54:17 --> The path to the image is not correct.
ERROR - 2018-05-09 07:54:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 07:56:02 --> The path to the image is not correct.
ERROR - 2018-05-09 07:56:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:11:37 --> The path to the image is not correct.
ERROR - 2018-05-09 08:11:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:12:07 --> The path to the image is not correct.
ERROR - 2018-05-09 08:12:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:12:57 --> The path to the image is not correct.
ERROR - 2018-05-09 08:12:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:13:35 --> The path to the image is not correct.
ERROR - 2018-05-09 08:13:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:14:38 --> The path to the image is not correct.
ERROR - 2018-05-09 08:14:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:15:11 --> The path to the image is not correct.
ERROR - 2018-05-09 08:15:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:15:45 --> The path to the image is not correct.
ERROR - 2018-05-09 08:15:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:18:54 --> The path to the image is not correct.
ERROR - 2018-05-09 08:18:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:18:55 --> Severity: Parsing Error --> syntax error, unexpected '&' D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\weekly_report.php 107
ERROR - 2018-05-09 08:19:15 --> Severity: Parsing Error --> syntax error, unexpected '&' D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\weekly_report.php 107
ERROR - 2018-05-09 08:19:17 --> The path to the image is not correct.
ERROR - 2018-05-09 08:19:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:19:18 --> Severity: Parsing Error --> syntax error, unexpected '&' D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\weekly_report.php 107
ERROR - 2018-05-09 08:19:28 --> Severity: Parsing Error --> syntax error, unexpected '&' D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\weekly_report.php 107
ERROR - 2018-05-09 08:19:29 --> Severity: Parsing Error --> syntax error, unexpected '&' D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\weekly_report.php 107
ERROR - 2018-05-09 08:19:29 --> Severity: Parsing Error --> syntax error, unexpected '&' D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\weekly_report.php 107
ERROR - 2018-05-09 08:19:30 --> Severity: Parsing Error --> syntax error, unexpected '&' D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\weekly_report.php 107
ERROR - 2018-05-09 08:19:30 --> Severity: Parsing Error --> syntax error, unexpected '&' D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\weekly_report.php 107
ERROR - 2018-05-09 08:19:32 --> The path to the image is not correct.
ERROR - 2018-05-09 08:19:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:19:33 --> Severity: Parsing Error --> syntax error, unexpected '&' D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\weekly_report.php 107
ERROR - 2018-05-09 08:21:55 --> The path to the image is not correct.
ERROR - 2018-05-09 08:21:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:27:41 --> The path to the image is not correct.
ERROR - 2018-05-09 08:27:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:27:59 --> The path to the image is not correct.
ERROR - 2018-05-09 08:27:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:29:41 --> The path to the image is not correct.
ERROR - 2018-05-09 08:29:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:32:36 --> The path to the image is not correct.
ERROR - 2018-05-09 08:32:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:33:09 --> The path to the image is not correct.
ERROR - 2018-05-09 08:33:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 08:56:05 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 2490
ERROR - 2018-05-09 08:56:05 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 2496
ERROR - 2018-05-09 08:56:10 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 2490
ERROR - 2018-05-09 08:56:10 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 2496
ERROR - 2018-05-09 08:56:17 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 2927
ERROR - 2018-05-09 08:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-05-09 09:01:13 --> The path to the image is not correct.
ERROR - 2018-05-09 09:01:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:02:45 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Parsing\Html.php 80
ERROR - 2018-05-09 09:02:45 --> The path to the image is not correct.
ERROR - 2018-05-09 09:02:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:19:57 --> The path to the image is not correct.
ERROR - 2018-05-09 09:19:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:20:26 --> The path to the image is not correct.
ERROR - 2018-05-09 09:20:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:20:27 --> 404 Page Not Found: app/Report/index
ERROR - 2018-05-09 09:20:38 --> The path to the image is not correct.
ERROR - 2018-05-09 09:20:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:20:53 --> The path to the image is not correct.
ERROR - 2018-05-09 09:20:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:21:09 --> Query error: Table 'project_transport.vehicle_type' doesn't exist - Invalid query: SELECT *
FROM `vehicle_type`
WHERE `deleted` IS NULL
AND `store_id` = '1'
ORDER BY `id` ASC
ERROR - 2018-05-09 09:21:27 --> The path to the image is not correct.
ERROR - 2018-05-09 09:21:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:22:47 --> Query error: Table 'project_transport.vehicle_type' doesn't exist - Invalid query: SELECT *
FROM `vehicle_type`
WHERE `deleted` IS NULL
AND `store_id` = '1'
ORDER BY `id` ASC
ERROR - 2018-05-09 09:23:13 --> The path to the image is not correct.
ERROR - 2018-05-09 09:23:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:23:14 --> The path to the image is not correct.
ERROR - 2018-05-09 09:23:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:29:08 --> The path to the image is not correct.
ERROR - 2018-05-09 09:29:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:29:09 --> 404 Page Not Found: app/Report/index
ERROR - 2018-05-09 09:29:14 --> The path to the image is not correct.
ERROR - 2018-05-09 09:29:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:29:20 --> The path to the image is not correct.
ERROR - 2018-05-09 09:29:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:29:22 --> The path to the image is not correct.
ERROR - 2018-05-09 09:29:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:29:27 --> 404 Page Not Found: app/Report/index
ERROR - 2018-05-09 09:29:49 --> The path to the image is not correct.
ERROR - 2018-05-09 09:29:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:29:51 --> The path to the image is not correct.
ERROR - 2018-05-09 09:29:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:29:53 --> The path to the image is not correct.
ERROR - 2018-05-09 09:29:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:29:57 --> The path to the image is not correct.
ERROR - 2018-05-09 09:29:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:29:59 --> The path to the image is not correct.
ERROR - 2018-05-09 09:29:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:29:59 --> The path to the image is not correct.
ERROR - 2018-05-09 09:29:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:30:00 --> 404 Page Not Found: app/Users/view_user_info
ERROR - 2018-05-09 09:30:05 --> The path to the image is not correct.
ERROR - 2018-05-09 09:30:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:30:05 --> The path to the image is not correct.
ERROR - 2018-05-09 09:30:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:30:18 --> The path to the image is not correct.
ERROR - 2018-05-09 09:30:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:30:18 --> The path to the image is not correct.
ERROR - 2018-05-09 09:30:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:30:22 --> The path to the image is not correct.
ERROR - 2018-05-09 09:30:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-09 09:30:25 --> The path to the image is not correct.
ERROR - 2018-05-09 09:30:25 --> Your server does not support the GD function required to process this type of image.

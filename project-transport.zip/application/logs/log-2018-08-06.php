<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-06 03:12:57 --> Severity: Notice --> Undefined property: stdClass::$user D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 71
ERROR - 2018-08-06 03:12:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 71
ERROR - 2018-08-06 03:12:57 --> Severity: Notice --> Undefined property: stdClass::$user D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 83
ERROR - 2018-08-06 03:12:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 83
ERROR - 2018-08-06 03:12:57 --> Severity: Notice --> Undefined property: stdClass::$checklist_type D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 86
ERROR - 2018-08-06 03:12:57 --> Severity: Notice --> Undefined property: stdClass::$start_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 87
ERROR - 2018-08-06 03:12:57 --> Severity: Notice --> Undefined property: stdClass::$end_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 88
ERROR - 2018-08-06 03:12:57 --> Query error: Column 'report_by' cannot be null - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES (NULL, '', '', NULL, NULL, NULL, '', 1533517977, NULL, 0)
ERROR - 2018-08-06 03:12:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-08-06 03:14:15 --> Severity: Notice --> Undefined property: stdClass::$user D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 71
ERROR - 2018-08-06 03:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 71
ERROR - 2018-08-06 03:14:15 --> Severity: Notice --> Undefined property: stdClass::$user D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 83
ERROR - 2018-08-06 03:14:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 83
ERROR - 2018-08-06 03:14:15 --> Severity: Notice --> Undefined property: stdClass::$checklist_type D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 86
ERROR - 2018-08-06 03:14:15 --> Severity: Notice --> Undefined property: stdClass::$start_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 87
ERROR - 2018-08-06 03:14:15 --> Severity: Notice --> Undefined property: stdClass::$end_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 88
ERROR - 2018-08-06 03:14:15 --> Query error: Column 'report_by' cannot be null - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES (NULL, '', '', NULL, NULL, NULL, '', 1533518055, NULL, 0)
ERROR - 2018-08-06 03:14:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-08-06 03:22:42 --> Severity: Notice --> Undefined property: stdClass::$user D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 71
ERROR - 2018-08-06 03:22:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 71
ERROR - 2018-08-06 03:22:42 --> Severity: Notice --> Undefined property: stdClass::$user D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 83
ERROR - 2018-08-06 03:22:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 83
ERROR - 2018-08-06 03:22:42 --> Severity: Notice --> Undefined property: stdClass::$checklist_type D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 86
ERROR - 2018-08-06 03:22:42 --> Severity: Notice --> Undefined property: stdClass::$start_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 87
ERROR - 2018-08-06 03:22:42 --> Severity: Notice --> Undefined property: stdClass::$end_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 88
ERROR - 2018-08-06 03:22:42 --> Query error: Column 'report_by' cannot be null - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES (NULL, '', '', NULL, NULL, NULL, '', 1533518562, NULL, 0)
ERROR - 2018-08-06 03:22:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-08-06 03:29:59 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:38:23 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:38:25 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:33 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:33 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 43
ERROR - 2018-08-06 03:45:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 34
ERROR - 2018-08-06 03:45:39 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:39 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 43
ERROR - 2018-08-06 03:45:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 34
ERROR - 2018-08-06 03:45:49 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:49 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 34
ERROR - 2018-08-06 03:45:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 43
ERROR - 2018-08-06 03:45:50 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:50 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 43
ERROR - 2018-08-06 03:45:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 34
ERROR - 2018-08-06 03:45:52 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 43
ERROR - 2018-08-06 03:45:52 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 19
ERROR - 2018-08-06 03:45:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 34
ERROR - 2018-08-06 03:48:53 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 65
ERROR - 2018-08-06 03:51:09 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 65
ERROR - 2018-08-06 03:51:11 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 65
ERROR - 2018-08-06 03:56:00 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 65
ERROR - 2018-08-06 03:58:53 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 65
ERROR - 2018-08-06 04:12:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Only one usage of each socket address (protocol/network address/port) is normally permitted.
 D:\xampp\htdocs\project-transport\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-08-06 04:12:08 --> Unable to connect to the database
ERROR - 2018-08-06 04:12:53 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 65
ERROR - 2018-08-06 04:13:38 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 65
ERROR - 2018-08-06 04:13:41 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 65
ERROR - 2018-08-06 04:23:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Only one usage of each socket address (protocol/network address/port) is normally permitted.
 D:\xampp\htdocs\project-transport\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-08-06 04:23:09 --> Unable to connect to the database
ERROR - 2018-08-06 04:23:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Only one usage of each socket address (protocol/network address/port) is normally permitted.
 D:\xampp\htdocs\project-transport\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-08-06 04:23:11 --> Unable to connect to the database
ERROR - 2018-08-06 04:23:16 --> Severity: Notice --> Undefined index: username D:\xampp\htdocs\project-transport\application\models\Register_model.php 91
ERROR - 2018-08-06 04:23:16 --> Severity: Notice --> Undefined index: password D:\xampp\htdocs\project-transport\application\models\Register_model.php 92
ERROR - 2018-08-06 04:23:22 --> The path to the image is not correct.
ERROR - 2018-08-06 04:23:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 04:23:30 --> The path to the image is not correct.
ERROR - 2018-08-06 04:23:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 04:58:39 --> Severity: Notice --> Undefined property: stdClass::$checklist_type D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 88
ERROR - 2018-08-06 04:58:39 --> Severity: Notice --> Undefined property: stdClass::$start_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 89
ERROR - 2018-08-06 04:58:39 --> Severity: Notice --> Undefined property: stdClass::$end_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 90
ERROR - 2018-08-06 04:58:39 --> Query error: Column 'checklist_id' cannot be null - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES ('11', '\"VM 1\"', '', NULL, NULL, NULL, '', 1533524319, NULL, 0)
ERROR - 2018-08-06 05:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 178
ERROR - 2018-08-06 05:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 116
ERROR - 2018-08-06 05:33:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 179
ERROR - 2018-08-06 05:34:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 179
ERROR - 2018-08-06 05:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 179
ERROR - 2018-08-06 05:35:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 179
ERROR - 2018-08-06 05:36:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 179
ERROR - 2018-08-06 05:40:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 179
ERROR - 2018-08-06 06:07:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 180
ERROR - 2018-08-06 06:09:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 180
ERROR - 2018-08-06 07:11:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:19:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:19:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:22:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:24:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:28:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:29:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:29:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:34:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:41:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:46:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 07:55:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 182
ERROR - 2018-08-06 08:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 232
ERROR - 2018-08-06 08:05:38 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2018-08-06 08:15:53 --> Severity: Notice --> Undefined variable: item_images D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 129
ERROR - 2018-08-06 08:15:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 230
ERROR - 2018-08-06 08:15:53 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2018-08-06 08:22:12 --> The path to the image is not correct.
ERROR - 2018-08-06 08:22:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:22:17 --> The path to the image is not correct.
ERROR - 2018-08-06 08:22:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:22:22 --> The path to the image is not correct.
ERROR - 2018-08-06 08:22:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:23:15 --> The path to the image is not correct.
ERROR - 2018-08-06 08:23:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:23:24 --> The path to the image is not correct.
ERROR - 2018-08-06 08:23:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:30:44 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 88
ERROR - 2018-08-06 08:30:44 --> Query error: Column 'checklist_id' cannot be null - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES ('11', '\"VM 1\"', '\"VM 1\"', NULL, '\"1\"', '\"2\"', '\"asdé\"', 1533537044, NULL, 0)
ERROR - 2018-08-06 08:31:06 --> The path to the image is not correct.
ERROR - 2018-08-06 08:31:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:33:16 --> The path to the image is not correct.
ERROR - 2018-08-06 08:33:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:33:19 --> The path to the image is not correct.
ERROR - 2018-08-06 08:33:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:46:54 --> The path to the image is not correct.
ERROR - 2018-08-06 08:46:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:46:57 --> The path to the image is not correct.
ERROR - 2018-08-06 08:46:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:46:57 --> The path to the image is not correct.
ERROR - 2018-08-06 08:46:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:46:58 --> The path to the image is not correct.
ERROR - 2018-08-06 08:46:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:47:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 08:47:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 08:49:49 --> The path to the image is not correct.
ERROR - 2018-08-06 08:49:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:49:51 --> The path to the image is not correct.
ERROR - 2018-08-06 08:49:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:50:50 --> The path to the image is not correct.
ERROR - 2018-08-06 08:50:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:52:11 --> The path to the image is not correct.
ERROR - 2018-08-06 08:52:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:52:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 08:52:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 08:52:35 --> The path to the image is not correct.
ERROR - 2018-08-06 08:52:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:52:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 08:52:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 08:53:33 --> The path to the image is not correct.
ERROR - 2018-08-06 08:53:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:53:34 --> The path to the image is not correct.
ERROR - 2018-08-06 08:53:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:53:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 08:53:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 08:54:04 --> The path to the image is not correct.
ERROR - 2018-08-06 08:54:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:54:13 --> The path to the image is not correct.
ERROR - 2018-08-06 08:54:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:54:23 --> The path to the image is not correct.
ERROR - 2018-08-06 08:54:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:54:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 08:54:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 08:54:28 --> The path to the image is not correct.
ERROR - 2018-08-06 08:54:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:54:37 --> The path to the image is not correct.
ERROR - 2018-08-06 08:54:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:54:53 --> Severity: Warning --> imagecreatefrompng(): gd-png:  fatal libpng error: incorrect header check D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7284
ERROR - 2018-08-06 08:54:53 --> Severity: Warning --> imagecreatefrompng(): gd-png error: setjmp returns error condition D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7284
ERROR - 2018-08-06 08:54:53 --> Severity: Warning --> imagecreatefrompng(): 'http://192.168.1.117/project-transport/public/upload/signature/2018/08/79_1533538434.PNG' is not a valid PNG file D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7284
ERROR - 2018-08-06 08:54:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorsforindex() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7334
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:55 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:56 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:57 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:58 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:54:59 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:00 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:01 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:02 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:03 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:04 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:05 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:06 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:07 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:08 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-06 08:55:20 --> The path to the image is not correct.
ERROR - 2018-08-06 08:55:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:55:25 --> The path to the image is not correct.
ERROR - 2018-08-06 08:55:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:55:33 --> The path to the image is not correct.
ERROR - 2018-08-06 08:55:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 08:59:35 --> The path to the image is not correct.
ERROR - 2018-08-06 08:59:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:02:41 --> The path to the image is not correct.
ERROR - 2018-08-06 09:02:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:02:46 --> The path to the image is not correct.
ERROR - 2018-08-06 09:02:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:02:57 --> The path to the image is not correct.
ERROR - 2018-08-06 09:02:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:45:35 --> The path to the image is not correct.
ERROR - 2018-08-06 09:45:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:45:38 --> The path to the image is not correct.
ERROR - 2018-08-06 09:45:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:51:00 --> The path to the image is not correct.
ERROR - 2018-08-06 09:51:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:51:02 --> The path to the image is not correct.
ERROR - 2018-08-06 09:51:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:51:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 09:51:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 09:51:03 --> The path to the image is not correct.
ERROR - 2018-08-06 09:51:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:51:04 --> The path to the image is not correct.
ERROR - 2018-08-06 09:51:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:51:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 09:51:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 09:51:06 --> The path to the image is not correct.
ERROR - 2018-08-06 09:51:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:51:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 09:51:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 09:51:08 --> The path to the image is not correct.
ERROR - 2018-08-06 09:51:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:51:10 --> The path to the image is not correct.
ERROR - 2018-08-06 09:51:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:51:36 --> The path to the image is not correct.
ERROR - 2018-08-06 09:51:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:51:40 --> The path to the image is not correct.
ERROR - 2018-08-06 09:51:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:51:49 --> The path to the image is not correct.
ERROR - 2018-08-06 09:51:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:56:04 --> The path to the image is not correct.
ERROR - 2018-08-06 09:56:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:56:06 --> The path to the image is not correct.
ERROR - 2018-08-06 09:56:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:56:09 --> The path to the image is not correct.
ERROR - 2018-08-06 09:56:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 09:56:11 --> The path to the image is not correct.
ERROR - 2018-08-06 09:56:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:04:05 --> The path to the image is not correct.
ERROR - 2018-08-06 10:04:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:04:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:04:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:04:06 --> The path to the image is not correct.
ERROR - 2018-08-06 10:04:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:04:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:04:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:06:19 --> The path to the image is not correct.
ERROR - 2018-08-06 10:06:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:06:24 --> The path to the image is not correct.
ERROR - 2018-08-06 10:06:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:07:52 --> The path to the image is not correct.
ERROR - 2018-08-06 10:07:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:07:54 --> The path to the image is not correct.
ERROR - 2018-08-06 10:07:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:28:44 --> The path to the image is not correct.
ERROR - 2018-08-06 10:28:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:28:48 --> The path to the image is not correct.
ERROR - 2018-08-06 10:28:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:29:04 --> The path to the image is not correct.
ERROR - 2018-08-06 10:29:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:37:09 --> The path to the image is not correct.
ERROR - 2018-08-06 10:37:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:37:13 --> The path to the image is not correct.
ERROR - 2018-08-06 10:37:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:40:50 --> The path to the image is not correct.
ERROR - 2018-08-06 10:40:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:51:54 --> The path to the image is not correct.
ERROR - 2018-08-06 10:51:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:52:00 --> The path to the image is not correct.
ERROR - 2018-08-06 10:52:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:52:14 --> The path to the image is not correct.
ERROR - 2018-08-06 10:52:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:52:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:52:56 --> The path to the image is not correct.
ERROR - 2018-08-06 10:52:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:52:59 --> The path to the image is not correct.
ERROR - 2018-08-06 10:52:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:52:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:52:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:53:00 --> The path to the image is not correct.
ERROR - 2018-08-06 10:53:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:53:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:53:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:53:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:53:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 10:55:51 --> The path to the image is not correct.
ERROR - 2018-08-06 10:55:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:55:54 --> The path to the image is not correct.
ERROR - 2018-08-06 10:55:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:55:55 --> The path to the image is not correct.
ERROR - 2018-08-06 10:55:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:56:08 --> The path to the image is not correct.
ERROR - 2018-08-06 10:56:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:56:13 --> The path to the image is not correct.
ERROR - 2018-08-06 10:56:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:56:17 --> The path to the image is not correct.
ERROR - 2018-08-06 10:56:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 10:56:19 --> The path to the image is not correct.
ERROR - 2018-08-06 10:56:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:01:04 --> The path to the image is not correct.
ERROR - 2018-08-06 11:01:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:01:05 --> The path to the image is not correct.
ERROR - 2018-08-06 11:01:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:01:26 --> The path to the image is not correct.
ERROR - 2018-08-06 11:01:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:01:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:01:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:01:27 --> The path to the image is not correct.
ERROR - 2018-08-06 11:01:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:01:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:01:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:01:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:01:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:04:37 --> The path to the image is not correct.
ERROR - 2018-08-06 11:04:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:04:40 --> The path to the image is not correct.
ERROR - 2018-08-06 11:04:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:04:44 --> The path to the image is not correct.
ERROR - 2018-08-06 11:04:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:04:45 --> The path to the image is not correct.
ERROR - 2018-08-06 11:04:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:05:10 --> The path to the image is not correct.
ERROR - 2018-08-06 11:05:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:05:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:05:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:05:13 --> The path to the image is not correct.
ERROR - 2018-08-06 11:05:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:05:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:05:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:05:15 --> The path to the image is not correct.
ERROR - 2018-08-06 11:05:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:05:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:05:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:05:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:05:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:05:54 --> The path to the image is not correct.
ERROR - 2018-08-06 11:05:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:05:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:05:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:11:26 --> The path to the image is not correct.
ERROR - 2018-08-06 11:11:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:11:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:11:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:11:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:11:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:13:02 --> The path to the image is not correct.
ERROR - 2018-08-06 11:13:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:13:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:13:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:13:08 --> The path to the image is not correct.
ERROR - 2018-08-06 11:13:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:13:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:13:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:13:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:13:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:13:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:13:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:13:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:13:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:16:12 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:12 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:12 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Undefined variable: v D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 218
ERROR - 2018-08-06 11:16:13 --> The path to the image is not correct.
ERROR - 2018-08-06 11:16:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:16:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:16:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 141
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-08-06 11:16:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-08-06 11:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-08-06 11:16:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-08-06 11:16:24 --> The path to the image is not correct.
ERROR - 2018-08-06 11:16:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:16:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:16:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:16:51 --> The path to the image is not correct.
ERROR - 2018-08-06 11:16:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:16:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:16:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:17:29 --> The path to the image is not correct.
ERROR - 2018-08-06 11:17:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:17:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:17:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:17:35 --> The path to the image is not correct.
ERROR - 2018-08-06 11:17:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:17:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:17:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:17:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:17:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:18:01 --> The path to the image is not correct.
ERROR - 2018-08-06 11:18:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:18:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:18:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:20:12 --> The path to the image is not correct.
ERROR - 2018-08-06 11:20:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:20:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:20:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:20:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:20:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:20:19 --> The path to the image is not correct.
ERROR - 2018-08-06 11:20:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:20:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:20:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:20:21 --> The path to the image is not correct.
ERROR - 2018-08-06 11:20:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:20:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:20:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:20:26 --> The path to the image is not correct.
ERROR - 2018-08-06 11:20:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-06 11:20:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:20:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-06 11:40:30 --> 404 Page Not Found: Public/lib

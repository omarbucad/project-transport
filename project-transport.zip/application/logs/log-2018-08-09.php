<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-09 07:21:08 --> The path to the image is not correct.
ERROR - 2018-08-09 07:21:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 07:21:13 --> The path to the image is not correct.
ERROR - 2018-08-09 07:21:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 07:21:26 --> The path to the image is not correct.
ERROR - 2018-08-09 07:21:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 07:21:26 --> The path to the image is not correct.
ERROR - 2018-08-09 07:21:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 07:21:36 --> The path to the image is not correct.
ERROR - 2018-08-09 07:21:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 07:21:36 --> The path to the image is not correct.
ERROR - 2018-08-09 07:21:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 07:28:11 --> The path to the image is not correct.
ERROR - 2018-08-09 07:28:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 07:28:11 --> The path to the image is not correct.
ERROR - 2018-08-09 07:28:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 07:28:12 --> The path to the image is not correct.
ERROR - 2018-08-09 07:28:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 07:28:58 --> The path to the image is not correct.
ERROR - 2018-08-09 07:28:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 07:28:58 --> The path to the image is not correct.
ERROR - 2018-08-09 07:28:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:00:10 --> The path to the image is not correct.
ERROR - 2018-08-09 08:00:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:00:47 --> The path to the image is not correct.
ERROR - 2018-08-09 08:00:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:00:48 --> The path to the image is not correct.
ERROR - 2018-08-09 08:00:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:11:42 --> The path to the image is not correct.
ERROR - 2018-08-09 08:11:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:11:47 --> The path to the image is not correct.
ERROR - 2018-08-09 08:11:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:11:49 --> The path to the image is not correct.
ERROR - 2018-08-09 08:11:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:12:10 --> The path to the image is not correct.
ERROR - 2018-08-09 08:12:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:12:12 --> The path to the image is not correct.
ERROR - 2018-08-09 08:12:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:12:14 --> The path to the image is not correct.
ERROR - 2018-08-09 08:12:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:13:39 --> The path to the image is not correct.
ERROR - 2018-08-09 08:13:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:13:48 --> The path to the image is not correct.
ERROR - 2018-08-09 08:13:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:13:50 --> The path to the image is not correct.
ERROR - 2018-08-09 08:13:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 08:13:58 --> The path to the image is not correct.
ERROR - 2018-08-09 08:13:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:15:05 --> The path to the image is not correct.
ERROR - 2018-08-09 09:15:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:15:05 --> The path to the image is not correct.
ERROR - 2018-08-09 09:15:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:15:07 --> The path to the image is not correct.
ERROR - 2018-08-09 09:15:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:15:07 --> The path to the image is not correct.
ERROR - 2018-08-09 09:15:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:15:09 --> The path to the image is not correct.
ERROR - 2018-08-09 09:15:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:15:09 --> The path to the image is not correct.
ERROR - 2018-08-09 09:15:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:15:11 --> The path to the image is not correct.
ERROR - 2018-08-09 09:15:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:15:14 --> The path to the image is not correct.
ERROR - 2018-08-09 09:15:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:15:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-09 09:15:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-09 09:16:56 --> The path to the image is not correct.
ERROR - 2018-08-09 09:16:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:01 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:09 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:12 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:20 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:26 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:34 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:39 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:43 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:45 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:49 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:17:51 --> The path to the image is not correct.
ERROR - 2018-08-09 09:17:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:25:20 --> The path to the image is not correct.
ERROR - 2018-08-09 09:25:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:25:53 --> The path to the image is not correct.
ERROR - 2018-08-09 09:25:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:25:57 --> The path to the image is not correct.
ERROR - 2018-08-09 09:25:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:26:00 --> The path to the image is not correct.
ERROR - 2018-08-09 09:26:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:26:04 --> The path to the image is not correct.
ERROR - 2018-08-09 09:26:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:26:08 --> The path to the image is not correct.
ERROR - 2018-08-09 09:26:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:26:17 --> The path to the image is not correct.
ERROR - 2018-08-09 09:26:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:26:23 --> The path to the image is not correct.
ERROR - 2018-08-09 09:26:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:32:25 --> The path to the image is not correct.
ERROR - 2018-08-09 09:32:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:32:27 --> The path to the image is not correct.
ERROR - 2018-08-09 09:32:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:32:32 --> The path to the image is not correct.
ERROR - 2018-08-09 09:32:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:32:32 --> The path to the image is not correct.
ERROR - 2018-08-09 09:32:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:54:37 --> The path to the image is not correct.
ERROR - 2018-08-09 09:54:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:54:39 --> The path to the image is not correct.
ERROR - 2018-08-09 09:54:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:55:33 --> The path to the image is not correct.
ERROR - 2018-08-09 09:55:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:55:36 --> The path to the image is not correct.
ERROR - 2018-08-09 09:55:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:55:50 --> The path to the image is not correct.
ERROR - 2018-08-09 09:55:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:55:59 --> The path to the image is not correct.
ERROR - 2018-08-09 09:55:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 09:56:03 --> The path to the image is not correct.
ERROR - 2018-08-09 09:56:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 10:06:29 --> The path to the image is not correct.
ERROR - 2018-08-09 10:06:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 10:06:32 --> The path to the image is not correct.
ERROR - 2018-08-09 10:06:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 10:06:34 --> The path to the image is not correct.
ERROR - 2018-08-09 10:06:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 10:07:36 --> The path to the image is not correct.
ERROR - 2018-08-09 10:07:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 10:07:38 --> The path to the image is not correct.
ERROR - 2018-08-09 10:07:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:31:39 --> Severity: Error --> Cannot use [] for reading D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 68
ERROR - 2018-08-09 11:35:43 --> The path to the image is not correct.
ERROR - 2018-08-09 11:35:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:35:46 --> The path to the image is not correct.
ERROR - 2018-08-09 11:35:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:36:29 --> The path to the image is not correct.
ERROR - 2018-08-09 11:36:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:37:02 --> The path to the image is not correct.
ERROR - 2018-08-09 11:37:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:37:03 --> The path to the image is not correct.
ERROR - 2018-08-09 11:37:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:39:31 --> The path to the image is not correct.
ERROR - 2018-08-09 11:39:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:39:44 --> The path to the image is not correct.
ERROR - 2018-08-09 11:39:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:52:46 --> The path to the image is not correct.
ERROR - 2018-08-09 11:52:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:52:46 --> The path to the image is not correct.
ERROR - 2018-08-09 11:52:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:57:38 --> The path to the image is not correct.
ERROR - 2018-08-09 11:57:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:57:41 --> The path to the image is not correct.
ERROR - 2018-08-09 11:57:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 11:57:50 --> The path to the image is not correct.
ERROR - 2018-08-09 11:57:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 12:01:01 --> The path to the image is not correct.
ERROR - 2018-08-09 12:01:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 12:01:02 --> The path to the image is not correct.
ERROR - 2018-08-09 12:01:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-09 12:01:05 --> The path to the image is not correct.
ERROR - 2018-08-09 12:01:05 --> Your server does not support the GD function required to process this type of image.

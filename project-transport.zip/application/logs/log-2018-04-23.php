<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-23 02:53:02 --> Query error: Unknown column 'id' in 'order clause' - Invalid query: SELECT *
FROM `vehicle`
WHERE `deleted` IS NULL
AND `store_id` = '1'
ORDER BY `id` ASC
ERROR - 2018-04-23 02:58:14 --> 404 Page Not Found: app/Vehicle/index
ERROR - 2018-04-23 02:58:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 02:58:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 02:58:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 02:58:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 02:58:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 02:58:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 02:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 02:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:10:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:10:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:16:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:16:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:17:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:17:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:17:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:17:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:17:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:17:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:21:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:21:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:21:45 --> 404 Page Not Found: Public/img
ERROR - 2018-04-23 03:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:23:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:23:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:23:53 --> The path to the image is not correct.
ERROR - 2018-04-23 03:23:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 03:24:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:24:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:24:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:25:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:25:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:26:40 --> 404 Page Not Found: app/Products/index
ERROR - 2018-04-23 03:26:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:26:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:26:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:28:06 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ']' D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 237
ERROR - 2018-04-23 03:29:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:29:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:40:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:40:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:41:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:41:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:41:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:41:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:41:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:41:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:43:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:43:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:43:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:43:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:44:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:44:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:46:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:46:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:46:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:46:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:46:44 --> Severity: Error --> Call to undefined method Vehicle_model::get_type_info() D:\xampp\htdocs\project-transport\application\controllers\app\Vehicle.php 188
ERROR - 2018-04-23 03:48:31 --> Severity: Warning --> Missing argument 1 for Vehicle_model::get_type_info(), called in D:\xampp\htdocs\project-transport\application\controllers\app\Vehicle.php on line 188 and defined D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 232
ERROR - 2018-04-23 03:48:31 --> Severity: Notice --> Undefined variable: type_id D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 233
ERROR - 2018-04-23 03:48:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\vehicle\vehicle_type\edit.php 7
ERROR - 2018-04-23 03:48:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\vehicle\vehicle_type\edit.php 21
ERROR - 2018-04-23 03:48:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\vehicle\vehicle_type\edit.php 29
ERROR - 2018-04-23 03:48:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\vehicle\vehicle_type\edit.php 30
ERROR - 2018-04-23 03:48:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:48:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:49:10 --> Severity: Warning --> Missing argument 1 for Vehicle_model::get_type_info(), called in D:\xampp\htdocs\project-transport\application\controllers\app\Vehicle.php on line 188 and defined D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 232
ERROR - 2018-04-23 03:49:10 --> Severity: Notice --> Undefined variable: type_id D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 233
ERROR - 2018-04-23 03:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\vehicle\vehicle_type\edit.php 7
ERROR - 2018-04-23 03:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\vehicle\vehicle_type\edit.php 21
ERROR - 2018-04-23 03:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\vehicle\vehicle_type\edit.php 29
ERROR - 2018-04-23 03:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\vehicle\vehicle_type\edit.php 30
ERROR - 2018-04-23 03:49:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:49:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:49:26 --> Severity: Warning --> Missing argument 1 for Vehicle_model::get_type_info(), called in D:\xampp\htdocs\project-transport\application\controllers\app\Vehicle.php on line 188 and defined D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 232
ERROR - 2018-04-23 03:49:26 --> Severity: Notice --> Undefined variable: type_id D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 233
ERROR - 2018-04-23 03:49:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:49:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:50:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:50:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:51:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:52:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:53:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:53:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:53:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:53:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:54:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:54:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:54:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:54:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:54:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:54:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:54:32 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 96
ERROR - 2018-04-23 03:54:32 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 97
ERROR - 2018-04-23 03:54:32 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 96
ERROR - 2018-04-23 03:54:32 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 97
ERROR - 2018-04-23 03:54:32 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 96
ERROR - 2018-04-23 03:54:32 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 97
ERROR - 2018-04-23 03:54:32 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 96
ERROR - 2018-04-23 03:54:32 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 97
ERROR - 2018-04-23 03:54:32 --> Severity: Notice --> Undefined property: stdClass::$longitude D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 96
ERROR - 2018-04-23 03:54:32 --> Severity: Notice --> Undefined property: stdClass::$latitude D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 97
ERROR - 2018-04-23 03:54:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 336
ERROR - 2018-04-23 03:54:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 337
ERROR - 2018-04-23 03:54:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 338
ERROR - 2018-04-23 03:54:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 341
ERROR - 2018-04-23 03:54:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 342
ERROR - 2018-04-23 03:54:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 343
ERROR - 2018-04-23 03:54:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 346
ERROR - 2018-04-23 03:54:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 347
ERROR - 2018-04-23 03:56:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:56:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:56:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:56:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:56:43 --> The path to the image is not correct.
ERROR - 2018-04-23 03:56:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 03:57:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\app\Accounts.php 13
ERROR - 2018-04-23 03:58:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:58:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 03:58:15 --> The path to the image is not correct.
ERROR - 2018-04-23 03:58:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 04:01:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:01:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:01:23 --> The path to the image is not correct.
ERROR - 2018-04-23 04:01:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 04:01:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:01:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:01:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:01:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:18 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 66
ERROR - 2018-04-23 04:03:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:21 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 66
ERROR - 2018-04-23 04:03:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:22 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 66
ERROR - 2018-04-23 04:03:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:23 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 66
ERROR - 2018-04-23 04:03:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:23 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 66
ERROR - 2018-04-23 04:03:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:23 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 66
ERROR - 2018-04-23 04:03:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:03:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:04:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:04:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:05:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:05:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:05:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:05:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:06:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:06:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:06:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:06:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:06:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:06:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:09:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:09:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:09:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:10:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:10:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 62
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 62
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 66
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 66
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 75
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 75
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 76
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 76
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 81
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 81
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 81
ERROR - 2018-04-23 04:11:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 81
ERROR - 2018-04-23 04:11:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:11:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:11:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:11:55 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 66
ERROR - 2018-04-23 04:11:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 66
ERROR - 2018-04-23 04:11:55 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 75
ERROR - 2018-04-23 04:11:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 75
ERROR - 2018-04-23 04:11:55 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 76
ERROR - 2018-04-23 04:11:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 76
ERROR - 2018-04-23 04:11:55 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 81
ERROR - 2018-04-23 04:11:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 81
ERROR - 2018-04-23 04:11:55 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 81
ERROR - 2018-04-23 04:11:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 81
ERROR - 2018-04-23 04:11:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:11:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:11:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:12:15 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 66
ERROR - 2018-04-23 04:12:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 66
ERROR - 2018-04-23 04:12:15 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 74
ERROR - 2018-04-23 04:12:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 74
ERROR - 2018-04-23 04:12:15 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 74
ERROR - 2018-04-23 04:12:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 74
ERROR - 2018-04-23 04:12:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:12:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:12:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:12:41 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 66
ERROR - 2018-04-23 04:12:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 66
ERROR - 2018-04-23 04:12:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:12:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:12:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:13:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:13:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:13:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:25:22 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 189
ERROR - 2018-04-23 04:25:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:25:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:25:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:25:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:25:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:27:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:27:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:28:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:28:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:28:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:36:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:36:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:36:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:36:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:36:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:42:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:42:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:43:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:43:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:45:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:45:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 82
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 82
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 88
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 88
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 94
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 94
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 100
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 100
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 106
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 106
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 115
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 115
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 115
ERROR - 2018-04-23 04:52:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 115
ERROR - 2018-04-23 04:52:18 --> The path to the image is not correct.
ERROR - 2018-04-23 04:52:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 04:52:20 --> 404 Page Not Found: app/Users/view_user_info
ERROR - 2018-04-23 04:55:05 --> The path to the image is not correct.
ERROR - 2018-04-23 04:55:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 04:56:15 --> The path to the image is not correct.
ERROR - 2018-04-23 04:56:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 05:00:35 --> The path to the image is not correct.
ERROR - 2018-04-23 05:00:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 05:01:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:01:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:03:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:03:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:05:01 --> 404 Page Not Found: app/Products/index
ERROR - 2018-04-23 05:05:16 --> 404 Page Not Found: app/Products/index
ERROR - 2018-04-23 05:05:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:05:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:05:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:05:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:05:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:05:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:10:21 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 89
ERROR - 2018-04-23 05:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:10:32 --> Severity: Notice --> Undefined variable: accounts_list D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 122
ERROR - 2018-04-23 05:10:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 122
ERROR - 2018-04-23 05:10:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:10:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:28:33 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:33 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:33 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:33 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:33 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:33 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:28:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:28:46 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:46 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:46 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:46 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:46 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:46 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:28:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:28:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:31:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:31:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:31:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:07 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:07 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:07 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:07 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:08 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:08 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:08 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:08 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:08 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:09 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:15 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:15 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:15 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:15 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:15 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:19 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:33:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:33:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:35:36 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:35:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:35:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Undefined property: stdClass::$user_ckecklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:36:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:36:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:38:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:38:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:38:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:38:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:39:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:39:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:39:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:39:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:39:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:39:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:22 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:31 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:32 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:32 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:33 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:33 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:33 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:33 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:33 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:34 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:34 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:34 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:46 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:46 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:46 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:46 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:40:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:40:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:41:53 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:41:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:41:53 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:41:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:41:53 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:41:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:41:53 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:41:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:41:53 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:41:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:41:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:41:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:44:38 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:44:38 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:44:38 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:44:38 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:44:38 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:44:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:44:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:45:22 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:45:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:45:23 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:45:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:45:23 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:45:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:45:23 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:45:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:45:23 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:45:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:45:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:45:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:58:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:58:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:58:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:58:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:58:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:58:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:59:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:59:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:59:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:59:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:59:35 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:59:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:59:35 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:59:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:59:35 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:59:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 05:59:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 05:59:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:34 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 06:00:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 06:00:34 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 06:00:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 06:00:34 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 06:00:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 06:00:34 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 06:00:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 06:00:34 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 06:00:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 06:00:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 06:00:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:06:42 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 07:06:42 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 07:06:42 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 07:06:42 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 07:06:42 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 124
ERROR - 2018-04-23 07:06:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:06:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:06:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:06:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:08:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:08:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:08:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:08:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:09:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:09:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:09:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:09:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:09:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:09:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:09:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:09:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:09:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:09:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:10:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:10:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:10:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:10:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:10:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:10:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:10:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:10:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:10:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:10:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:11:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:11:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:11:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:11:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:12:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:12:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:12:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:12:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:12:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:12:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:13:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:13:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:13:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:13:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:13:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:18:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 142
ERROR - 2018-04-23 07:18:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 146
ERROR - 2018-04-23 07:18:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 151
ERROR - 2018-04-23 07:18:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:18:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:19:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:19:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:20:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:20:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:20:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:20:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:20:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:25:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:25:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:25:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:25:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:25:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:32:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 07:32:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:32:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:36:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:36:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:37:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:37:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:38:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:38:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:38:54 --> Severity: Notice --> Undefined index: help D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 89
ERROR - 2018-04-23 07:38:54 --> Severity: Notice --> Undefined index: help D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 89
ERROR - 2018-04-23 07:38:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:38:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:38:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:38:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:38:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:39:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:39:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:39:24 --> Severity: Notice --> Undefined index: help D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 89
ERROR - 2018-04-23 07:39:24 --> Severity: Notice --> Undefined index: help D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 89
ERROR - 2018-04-23 07:39:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:39:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:39:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:39:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 07:39:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:00:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 08:00:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 08:00:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:00:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:00:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 08:00:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 08:00:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:00:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:00:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 08:00:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 08:00:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:00:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:02:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 08:02:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 08:02:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:02:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:02:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:02:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:03:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:03:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:04:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 08:04:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 140
ERROR - 2018-04-23 08:04:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:04:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:04:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:04:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:04:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:04:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:05:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:05:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:05:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:05:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:07:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:07:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:07:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:07:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:08:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:12:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:12:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:13:58 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 159
ERROR - 2018-04-23 08:13:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:13:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:14:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:14:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:14:55 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:14:55 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:14:55 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:14:55 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:14:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:14:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:14:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:14:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:14:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:14:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:14:55 --> The path to the image is not correct.
ERROR - 2018-04-23 08:14:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:17:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:17:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:17:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:17:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:17:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:17:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:17:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:17:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:17:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:17:03 --> The path to the image is not correct.
ERROR - 2018-04-23 08:17:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:17:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:17:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:17:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:17:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:17:04 --> The path to the image is not correct.
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:17:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:17:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:17:04 --> The path to the image is not correct.
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:17:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:17:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:17:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:17:04 --> The path to the image is not correct.
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:17:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:17:04 --> The path to the image is not correct.
ERROR - 2018-04-23 08:17:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:20:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:20:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:20:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:20:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:20:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:20:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:20:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:20:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:20:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:20:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:20:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:20:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:20:58 --> The path to the image is not correct.
ERROR - 2018-04-23 08:20:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:21:08 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:21:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:21:08 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:21:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:21:08 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:21:08 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:21:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:21:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:21:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:21:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:21:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:21:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:21:08 --> The path to the image is not correct.
ERROR - 2018-04-23 08:21:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:21:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:21:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:21:43 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:21:43 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:21:43 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:21:43 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:21:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:21:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:21:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:21:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:21:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:21:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:21:43 --> The path to the image is not correct.
ERROR - 2018-04-23 08:21:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:21:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:21:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:21:56 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:21:56 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:21:56 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:21:56 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:21:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:21:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:21:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:21:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:21:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:21:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:21:56 --> The path to the image is not correct.
ERROR - 2018-04-23 08:21:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:22:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:22:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:26:56 --> Query error: Unknown column 'u2.updated_by' in 'field list' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`updated_by`
FROM `report` `r`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:27:05 --> Query error: Unknown column 'u2.updated_by' in 'field list' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `rs`.`user_id` as `updated_by`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`updated_by`
FROM `report` `r`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:27:30 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `rs`.`user_id` as `updated_by`, `c`.`checklist_name`, `u`.`display_name`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:27:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:27:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:27:37 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:27:37 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:27:37 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:27:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:27:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:27:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:27:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:27:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:27:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:27:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:27:38 --> The path to the image is not correct.
ERROR - 2018-04-23 08:27:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:27:40 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `rs`.`user_id` as `updated_by`, `c`.`checklist_name`, `u`.`display_name`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:48 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:48 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:49 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:49 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:49 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:49 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:49 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:50 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:50 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:50 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:50 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:51 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:51 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:51 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:51 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:51 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:52 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:52 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:52 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:52 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:52 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:53 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:53 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:53 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:28:53 --> Query error: Unknown column 'rs.user_id' in 'on clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`
FROM `report` `r`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-23 08:31:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:31:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:32:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:32:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:32:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:33:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:33:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:33:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:33:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:33:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:33:47 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:33:47 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:33:47 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:33:47 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:33:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:33:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:33:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:33:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:33:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:33:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:33:47 --> The path to the image is not correct.
ERROR - 2018-04-23 08:33:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:35:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:35:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:35:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:35:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:35:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:35:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:35:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:35:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:35:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:35:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:35:03 --> The path to the image is not correct.
ERROR - 2018-04-23 08:35:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:35:14 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:35:14 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:35:14 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:35:14 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:35:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:35:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:35:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:35:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:35:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:35:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:35:14 --> The path to the image is not correct.
ERROR - 2018-04-23 08:35:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:38:06 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:06 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:06 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:06 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:38:06 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:06 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:06 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:06 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:06 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:38:06 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:38:06 --> The path to the image is not correct.
ERROR - 2018-04-23 08:38:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:38:06 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:38:07 --> The path to the image is not correct.
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:38:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:38:07 --> The path to the image is not correct.
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:38:07 --> The path to the image is not correct.
ERROR - 2018-04-23 08:38:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:38:08 --> The path to the image is not correct.
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:38:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:38:08 --> The path to the image is not correct.
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:38:08 --> The path to the image is not correct.
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:38:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:38:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:38:08 --> The path to the image is not correct.
ERROR - 2018-04-23 08:38:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:38:09 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:09 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:09 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:38:09 --> The path to the image is not correct.
ERROR - 2018-04-23 08:38:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:38:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:38:09 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:09 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:09 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:38:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:38:09 --> The path to the image is not correct.
ERROR - 2018-04-23 08:38:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:39:35 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:39:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:39:35 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:39:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:39:35 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:39:35 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:39:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:39:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:39:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:39:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:39:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:39:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:39:35 --> The path to the image is not correct.
ERROR - 2018-04-23 08:39:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:39:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:39:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:39:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:39:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:39:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:39:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:39:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:39:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:39:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:39:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:39:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:39:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:39:58 --> The path to the image is not correct.
ERROR - 2018-04-23 08:39:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:40:36 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:40:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:40:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:40:36 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:40:36 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 08:40:36 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 08:40:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:40:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 08:40:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:40:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 08:40:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-23 08:40:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 08:40:36 --> The path to the image is not correct.
ERROR - 2018-04-23 08:40:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 08:40:51 --> Severity: Notice --> Undefined index: help D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 89
ERROR - 2018-04-23 08:40:51 --> Severity: Notice --> Undefined index: help D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 89
ERROR - 2018-04-23 08:40:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:40:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:40:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:40:55 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:40:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:40:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:40:55 --> The provided image is not valid.
ERROR - 2018-04-23 08:40:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:40:55 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:40:55 --> The provided image is not valid.
ERROR - 2018-04-23 08:40:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:42:12 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:42:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:42:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:42:12 --> The provided image is not valid.
ERROR - 2018-04-23 08:42:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:42:12 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:42:12 --> The provided image is not valid.
ERROR - 2018-04-23 08:42:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:42:24 --> Severity: Notice --> Undefined index: help D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 89
ERROR - 2018-04-23 08:42:24 --> Severity: Notice --> Undefined index: help D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 89
ERROR - 2018-04-23 08:42:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:42:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:42:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:42:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:42:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:42:27 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:42:27 --> The provided image is not valid.
ERROR - 2018-04-23 08:42:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:42:27 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:42:27 --> The provided image is not valid.
ERROR - 2018-04-23 08:42:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:00 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:00 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:00 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:00 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:00 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:00 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:00 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:00 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:01 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:01 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:01 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:01 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:01 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:01 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:01 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:01 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:01 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:01 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:01 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:01 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:02 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:02 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:43:02 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:02 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:43:02 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 08:43:02 --> The provided image is not valid.
ERROR - 2018-04-23 08:43:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 08:44:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:44:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:46:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:46:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:46:35 --> Severity: Notice --> Undefined index: help D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 89
ERROR - 2018-04-23 08:46:35 --> Severity: Notice --> Undefined index: help D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 89
ERROR - 2018-04-23 08:46:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:46:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:46:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:46:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:46:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:46:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:48:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:48:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:49:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:49:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:52:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:52:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:52:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:52:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:57:43 --> Severity: Parsing Error --> syntax error, unexpected ']' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 158
ERROR - 2018-04-23 08:57:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:57:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:57:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:57:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 08:59:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:00:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:00:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:12:26 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 89
ERROR - 2018-04-23 09:12:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 89
ERROR - 2018-04-23 09:14:06 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 89
ERROR - 2018-04-23 09:22:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:22:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:22:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:25:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:25:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:25:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:25:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:25:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:25:05 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:25:05 --> The provided image is not valid.
ERROR - 2018-04-23 09:25:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:25:06 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:25:06 --> The provided image is not valid.
ERROR - 2018-04-23 09:25:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:25:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:26:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:26:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:26:48 --> The path to the image is not correct.
ERROR - 2018-04-23 09:26:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:26:49 --> The path to the image is not correct.
ERROR - 2018-04-23 09:26:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:26:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:27:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:27:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:27:06 --> The path to the image is not correct.
ERROR - 2018-04-23 09:27:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:27:06 --> The path to the image is not correct.
ERROR - 2018-04-23 09:27:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:27:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:27:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:27:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:27:18 --> The path to the image is not correct.
ERROR - 2018-04-23 09:27:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:27:18 --> The path to the image is not correct.
ERROR - 2018-04-23 09:27:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:27:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:27:35 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:27:35 --> The provided image is not valid.
ERROR - 2018-04-23 09:27:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:27:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:27:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:27:35 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:27:35 --> The provided image is not valid.
ERROR - 2018-04-23 09:27:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:27:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:31:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:31:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:31:10 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:31:10 --> The provided image is not valid.
ERROR - 2018-04-23 09:31:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:31:10 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:31:10 --> The provided image is not valid.
ERROR - 2018-04-23 09:31:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:31:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:31:11 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:31:11 --> The provided image is not valid.
ERROR - 2018-04-23 09:31:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:31:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:31:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:31:11 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:31:11 --> The provided image is not valid.
ERROR - 2018-04-23 09:31:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:31:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:31:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:31:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:31:12 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:31:12 --> The provided image is not valid.
ERROR - 2018-04-23 09:31:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:31:12 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:31:12 --> The provided image is not valid.
ERROR - 2018-04-23 09:31:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:31:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:40:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:40:13 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:40:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:40:13 --> The provided image is not valid.
ERROR - 2018-04-23 09:40:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:40:13 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:40:13 --> The provided image is not valid.
ERROR - 2018-04-23 09:40:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:40:13 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:40:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:40:13 --> The provided image is not valid.
ERROR - 2018-04-23 09:40:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:40:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:40:14 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:40:14 --> The provided image is not valid.
ERROR - 2018-04-23 09:40:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:40:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:40:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:40:14 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:40:14 --> The provided image is not valid.
ERROR - 2018-04-23 09:40:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:40:14 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:40:14 --> The provided image is not valid.
ERROR - 2018-04-23 09:40:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:40:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:46:21 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:46:21 --> The provided image is not valid.
ERROR - 2018-04-23 09:46:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:46:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:46:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:46:21 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:46:21 --> The provided image is not valid.
ERROR - 2018-04-23 09:46:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:46:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:46:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:46:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:46:21 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:46:21 --> The provided image is not valid.
ERROR - 2018-04-23 09:46:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:46:21 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:46:21 --> The provided image is not valid.
ERROR - 2018-04-23 09:46:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:46:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:46:51 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:46:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:46:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:46:51 --> The provided image is not valid.
ERROR - 2018-04-23 09:46:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:46:51 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:46:51 --> The provided image is not valid.
ERROR - 2018-04-23 09:46:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:46:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:48:39 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:48:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:48:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:48:39 --> The provided image is not valid.
ERROR - 2018-04-23 09:48:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:48:39 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:48:39 --> The provided image is not valid.
ERROR - 2018-04-23 09:48:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:48:39 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:48:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:48:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:48:39 --> The provided image is not valid.
ERROR - 2018-04-23 09:48:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:48:39 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:48:39 --> The provided image is not valid.
ERROR - 2018-04-23 09:48:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:48:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:49:14 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-23 09:49:46 --> 404 Page Not Found: Images/checklist
ERROR - 2018-04-23 09:49:55 --> 404 Page Not Found: Thumbnail/images
ERROR - 2018-04-23 09:50:03 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:50:03 --> The provided image is not valid.
ERROR - 2018-04-23 09:50:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:50:15 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 09:50:15 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-23 09:50:15 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-23 09:50:15 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-23 09:50:15 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-23 09:50:15 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-23 09:50:15 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:50:15 --> The provided image is not valid.
ERROR - 2018-04-23 09:50:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-23 09:50:36 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:50:36 --> The provided image is not valid.
ERROR - 2018-04-23 09:50:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:50:36 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:50:36 --> The provided image is not valid.
ERROR - 2018-04-23 09:50:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:52:26 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:52:26 --> The provided image is not valid.
ERROR - 2018-04-23 09:52:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:52:54 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-23 09:52:54 --> The provided image is not valid.
ERROR - 2018-04-23 09:52:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-23 09:53:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:53:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:53:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:53:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:53:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:53:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:57:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:57:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 09:57:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:06:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:06:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:06:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:07:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:07:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:07:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:07:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:07:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:07:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:07:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:07:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:07:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:17:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:17:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:17:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:17:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:17:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:17:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:18:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:18:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:18:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:18:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:18:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:18:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:18:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:18:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:18:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:20:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:20:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:20:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:20:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:20:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:20:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:22:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:22:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:22:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:23:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:23:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:23:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:23:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:23:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:23:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:25:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:25:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:25:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:29:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:29:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:29:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:29:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:29:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:29:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:29:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:29:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:29:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 10:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 11:11:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 11:11:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 11:11:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 11:11:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 11:11:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 11:11:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 11:11:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-23 11:11:47 --> 404 Page Not Found: Public/lib

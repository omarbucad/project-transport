<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-10 03:57:42 --> The path to the image is not correct.
ERROR - 2018-05-10 03:57:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 03:59:06 --> The path to the image is not correct.
ERROR - 2018-05-10 03:59:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 03:59:15 --> The path to the image is not correct.
ERROR - 2018-05-10 03:59:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:03:33 --> The path to the image is not correct.
ERROR - 2018-05-10 04:03:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:03:35 --> 404 Page Not Found: app/Report/index
ERROR - 2018-05-10 04:03:37 --> The path to the image is not correct.
ERROR - 2018-05-10 04:03:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:24:59 --> The path to the image is not correct.
ERROR - 2018-05-10 04:24:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:25:05 --> The path to the image is not correct.
ERROR - 2018-05-10 04:25:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:25:22 --> The path to the image is not correct.
ERROR - 2018-05-10 04:25:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:25:48 --> The path to the image is not correct.
ERROR - 2018-05-10 04:25:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:25:50 --> The path to the image is not correct.
ERROR - 2018-05-10 04:25:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:34:29 --> The path to the image is not correct.
ERROR - 2018-05-10 04:34:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:34:29 --> The path to the image is not correct.
ERROR - 2018-05-10 04:34:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:34:31 --> 404 Page Not Found: app/Users/view_user_info
ERROR - 2018-05-10 04:34:35 --> The path to the image is not correct.
ERROR - 2018-05-10 04:34:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 04:34:35 --> The path to the image is not correct.
ERROR - 2018-05-10 04:34:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 07:15:02 --> The path to the image is not correct.
ERROR - 2018-05-10 07:15:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-10 07:21:58 --> The path to the image is not correct.
ERROR - 2018-05-10 07:21:58 --> Your server does not support the GD function required to process this type of image.

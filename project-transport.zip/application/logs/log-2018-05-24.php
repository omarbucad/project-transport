<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-24 05:24:47 --> The path to the image is not correct.
ERROR - 2018-05-24 05:24:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-24 05:25:03 --> The path to the image is not correct.
ERROR - 2018-05-24 05:25:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-24 05:25:03 --> The path to the image is not correct.
ERROR - 2018-05-24 05:25:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-24 05:25:05 --> The path to the image is not correct.
ERROR - 2018-05-24 05:25:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-24 05:38:43 --> The path to the image is not correct.
ERROR - 2018-05-24 05:38:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-24 05:38:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-24 05:38:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-24 07:45:31 --> The path to the image is not correct.
ERROR - 2018-05-24 07:45:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-24 07:45:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-24 07:45:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-24 07:55:20 --> The path to the image is not correct.
ERROR - 2018-05-24 07:55:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-24 07:55:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-24 07:55:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-24 07:55:22 --> 404 Page Not Found: Paypal/index
ERROR - 2018-05-24 07:55:48 --> 404 Page Not Found: Paypal/index
ERROR - 2018-05-24 07:55:54 --> Severity: Warning --> require_once(D:\xampp\htdocs\project-transport\application\libraries/paypal-php-sdk/paypal/rest-api-sdk-php/sample/bootstrap.php): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\app\Paypal.php 3
ERROR - 2018-05-24 07:55:54 --> Severity: Compile Error --> require_once(): Failed opening required 'D:\xampp\htdocs\project-transport\application\libraries/paypal-php-sdk/paypal/rest-api-sdk-php/sample/bootstrap.php' (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\project-transport\application\controllers\app\Paypal.php 3
ERROR - 2018-05-24 07:58:43 --> Severity: Error --> Class 'PayPal\Rest\ApiContext' not found D:\xampp\htdocs\project-transport\application\controllers\app\Paypal.php 21

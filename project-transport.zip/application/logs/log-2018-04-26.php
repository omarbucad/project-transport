<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-26 02:01:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 02:02:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 02:02:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 02:18:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 02:18:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 02:18:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:23:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:23:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:23:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:23:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:23:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:23:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 03:23:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:23:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:23:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:23:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:23:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 03:23:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 03:23:00 --> The path to the image is not correct.
ERROR - 2018-04-26 03:23:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 03:23:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:23:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:23:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:23:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:23:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:23:35 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:23:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:23:35 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:23:35 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:23:35 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 03:23:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:23:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:23:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:23:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:23:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 03:23:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 03:23:35 --> The path to the image is not correct.
ERROR - 2018-04-26 03:23:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 03:23:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:26:51 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 167
ERROR - 2018-04-26 03:26:51 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 173
ERROR - 2018-04-26 03:26:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:26:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:26:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:28:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:28:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:28:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:40:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:40:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:40:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:40:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:40:08 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:40:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:40:08 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:40:08 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:40:08 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 03:40:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:40:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:40:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:40:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:40:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 03:40:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 03:40:08 --> The path to the image is not correct.
ERROR - 2018-04-26 03:40:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 03:40:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:42:26 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:42:26 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:42:26 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:42:26 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 03:42:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:42:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:42:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:42:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:42:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 03:42:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 03:42:26 --> The path to the image is not correct.
ERROR - 2018-04-26 03:42:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 03:42:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:43:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:43:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:43:37 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:43:37 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:43:37 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:43:37 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 03:43:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:43:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:43:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:43:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:43:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 03:43:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 03:43:37 --> The path to the image is not correct.
ERROR - 2018-04-26 03:43:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 03:43:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:43:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:43:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:43:40 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:43:40 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:43:40 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 03:43:40 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 03:43:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:43:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 03:43:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:43:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 03:43:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 03:43:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 03:43:40 --> The path to the image is not correct.
ERROR - 2018-04-26 03:43:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 03:43:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:48:06 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 241
ERROR - 2018-04-26 03:48:33 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 144
ERROR - 2018-04-26 03:48:33 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 03:48:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:48:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:48:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:48:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:48:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:48:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:49:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 144
ERROR - 2018-04-26 03:49:24 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 03:49:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 144
ERROR - 2018-04-26 03:49:24 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 03:49:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 100
ERROR - 2018-04-26 03:49:24 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2018-04-26 03:49:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-04-26 03:49:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 100
ERROR - 2018-04-26 03:49:49 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2018-04-26 03:50:25 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2018-04-26 03:58:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:58:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:58:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:58:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:58:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:58:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:58:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:58:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:59:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:59:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 03:59:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:01:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:01:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:01:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:01:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:01:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:01:44 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-26 04:01:44 --> The provided image is not valid.
ERROR - 2018-04-26 04:01:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 04:01:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:08:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:08:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:08:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:09:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:09:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:09:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:09:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:09:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:09:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:10:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:10:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:10:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:11:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:11:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:11:20 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:11:20 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:11:20 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:11:20 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 04:11:20 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 04:11:20 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 04:11:20 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 04:11:20 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 04:11:20 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 04:11:20 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 04:11:20 --> The path to the image is not correct.
ERROR - 2018-04-26 04:11:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 04:11:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:19:16 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 146
ERROR - 2018-04-26 04:19:16 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 04:19:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:19:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:19:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:20:07 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:20:07 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:20:07 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:20:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 04:20:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 04:20:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 04:20:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 04:20:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 04:20:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 04:20:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 04:20:07 --> The path to the image is not correct.
ERROR - 2018-04-26 04:20:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 04:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:20:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:20:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:20:10 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:20:10 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:20:10 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:20:10 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 04:20:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 04:20:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 04:20:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 04:20:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 04:20:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 04:20:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 04:20:10 --> The path to the image is not correct.
ERROR - 2018-04-26 04:20:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 04:20:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:21:21 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 146
ERROR - 2018-04-26 04:21:21 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 04:30:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:30:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:30:12 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:30:12 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:30:12 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:30:12 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 04:30:12 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 04:30:12 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 04:30:12 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 04:30:12 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 04:30:12 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 04:30:12 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 04:30:12 --> The path to the image is not correct.
ERROR - 2018-04-26 04:30:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 04:30:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:30:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:30:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:30:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:30:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:30:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:30:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:31:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:31:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:31:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:32:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:32:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:32:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:33:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:33:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 04:33:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:33:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:33:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 04:33:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 04:33:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 04:33:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 04:33:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 04:33:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 04:33:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 04:33:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 04:33:00 --> The path to the image is not correct.
ERROR - 2018-04-26 04:33:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 04:33:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:09:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:09:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:09:25 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:09:25 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:09:25 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:09:25 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 05:09:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 05:09:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 05:09:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 05:09:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 05:09:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 05:09:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 05:09:25 --> The path to the image is not correct.
ERROR - 2018-04-26 05:09:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 05:09:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:09:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:09:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:09:27 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:09:27 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:09:27 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:09:27 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 05:09:27 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 05:09:27 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 05:09:27 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 05:09:27 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 05:09:27 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 05:09:27 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 05:09:27 --> The path to the image is not correct.
ERROR - 2018-04-26 05:09:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 05:09:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:10:38 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 05:14:09 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 05:17:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:17:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:17:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:17:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:17:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:17:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:17:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:17:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:17:24 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:17:24 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:17:24 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:17:24 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 05:17:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 05:17:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 05:17:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 05:17:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 05:17:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 05:17:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 05:17:24 --> The path to the image is not correct.
ERROR - 2018-04-26 05:17:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 05:17:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:23:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:23:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:23:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:23:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:23:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:23:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:23:25 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:23:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:23:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:23:25 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:23:25 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:23:25 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 05:23:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 05:23:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 05:23:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 05:23:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 05:23:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 05:23:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 05:23:25 --> The path to the image is not correct.
ERROR - 2018-04-26 05:23:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 05:23:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:23:56 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 05:24:57 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 05:27:32 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 05:32:56 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 182
ERROR - 2018-04-26 05:33:14 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 05:35:36 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 05:43:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:43:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:43:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:43:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:43:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:43:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:43:24 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:43:24 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:43:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:43:24 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 05:43:24 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 05:43:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 05:43:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 05:43:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 05:43:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 05:43:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 05:43:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 05:43:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 05:43:24 --> The path to the image is not correct.
ERROR - 2018-04-26 05:43:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 05:43:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:04:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:04:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:04:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:04:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:04:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:04:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:04:47 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:04:47 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:04:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:04:47 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:04:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:04:47 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:04:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:04:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:04:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:04:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:04:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:04:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:04:47 --> The path to the image is not correct.
ERROR - 2018-04-26 06:04:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:04:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:05:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:05:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:05:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:05:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:05:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:05:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:05:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:05:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:05:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:05:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:05:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:05:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:05:58 --> The path to the image is not correct.
ERROR - 2018-04-26 06:05:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:05:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:06:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:06:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:06:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:06:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:06:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:06:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:06:00 --> The path to the image is not correct.
ERROR - 2018-04-26 06:06:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:06:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:01 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:01 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:01 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:06:01 --> The path to the image is not correct.
ERROR - 2018-04-26 06:06:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:06:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:01 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:01 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:01 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:06:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:06:01 --> The path to the image is not correct.
ERROR - 2018-04-26 06:06:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:06:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:06:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:04 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:06:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:06:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:06:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:06:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:06:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:06:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:06:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:06:04 --> The path to the image is not correct.
ERROR - 2018-04-26 06:06:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:06:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:09:30 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 270
ERROR - 2018-04-26 06:10:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:16 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:16 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:16 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:16 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:10:16 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:10:16 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:10:16 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:10:16 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:10:16 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:10:16 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:10:16 --> The path to the image is not correct.
ERROR - 2018-04-26 06:10:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:10:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:18 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:18 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:18 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:10:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:10:18 --> The path to the image is not correct.
ERROR - 2018-04-26 06:10:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:10:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:18 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:18 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:18 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:10:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:10:18 --> The path to the image is not correct.
ERROR - 2018-04-26 06:10:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:10:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:10:24 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:24 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:24 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:10:24 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:10:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:10:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:10:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:10:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:10:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:10:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:10:24 --> The path to the image is not correct.
ERROR - 2018-04-26 06:10:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:10:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:13:07 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 172
ERROR - 2018-04-26 06:17:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:17:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:17:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:17:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:17:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:17:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:17:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:17:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:17:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:17:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:17:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:17:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:17:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:17:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:17:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:17:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:17:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:17:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:17:58 --> The path to the image is not correct.
ERROR - 2018-04-26 06:17:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:17:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:18:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:18:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:18:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:19:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:19:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:19:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:19:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:19:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:19:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:20:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:20:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:20:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:20:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:20:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:20:40 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:20:40 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:20:40 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:20:40 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:20:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:20:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:20:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:20:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:20:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:20:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:20:40 --> The path to the image is not correct.
ERROR - 2018-04-26 06:20:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:20:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:21:36 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:21:36 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:21:36 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:21:36 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:21:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:21:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:21:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:21:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:21:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:21:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:21:36 --> The path to the image is not correct.
ERROR - 2018-04-26 06:21:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:21:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:28:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:28:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:28:40 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:28:40 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:28:40 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:28:40 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:28:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:28:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:28:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:28:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:28:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:28:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:28:40 --> The path to the image is not correct.
ERROR - 2018-04-26 06:28:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:28:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:28:43 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:28:43 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:28:43 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 06:28:43 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 06:28:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:28:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 06:28:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:28:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 06:28:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 06:28:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 06:28:43 --> The path to the image is not correct.
ERROR - 2018-04-26 06:28:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 06:29:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:29:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:29:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:29:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:29:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:29:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:30:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:30:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:30:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:31:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:31:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 06:31:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:37:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:37:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:37:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:43:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:43:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:43:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:43:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:43:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:43:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:44:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:44:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:44:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:45:45 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 07:45:45 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 07:45:45 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 07:45:45 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 07:45:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:45:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:45:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 07:45:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 07:45:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 07:45:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 07:45:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 07:45:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 07:45:45 --> The path to the image is not correct.
ERROR - 2018-04-26 07:45:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 07:45:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:46:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:46:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:46:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:46:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:46:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:46:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:47:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:47:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:47:01 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 07:47:01 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 07:47:01 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 07:47:01 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 07:47:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 07:47:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 07:47:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 07:47:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 07:47:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 07:47:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 07:47:01 --> The path to the image is not correct.
ERROR - 2018-04-26 07:47:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:47:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 07:47:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:47:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:47:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:47:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:47:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:47:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:49:59 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 07:49:59 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 07:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:49:59 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 07:49:59 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 07:49:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 07:49:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 07:49:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 07:49:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 07:49:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 07:49:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 07:49:59 --> The path to the image is not correct.
ERROR - 2018-04-26 07:49:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 07:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:51:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:51:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:51:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:51:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:51:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:51:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:57:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:57:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 07:57:47 --> The path to the image is not correct.
ERROR - 2018-04-26 07:57:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 07:57:47 --> The path to the image is not correct.
ERROR - 2018-04-26 07:57:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 07:57:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:20:11 --> The path to the image is not correct.
ERROR - 2018-04-26 08:20:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 08:20:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:20:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:20:11 --> The path to the image is not correct.
ERROR - 2018-04-26 08:20:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 08:20:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:20:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:20:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:20:42 --> The path to the image is not correct.
ERROR - 2018-04-26 08:20:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 08:20:42 --> The path to the image is not correct.
ERROR - 2018-04-26 08:20:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 08:20:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:20:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:20:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:20:55 --> The path to the image is not correct.
ERROR - 2018-04-26 08:20:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 08:20:55 --> The path to the image is not correct.
ERROR - 2018-04-26 08:20:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 08:20:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:04 --> The path to the image is not correct.
ERROR - 2018-04-26 08:21:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 08:21:04 --> The path to the image is not correct.
ERROR - 2018-04-26 08:21:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 08:21:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:19 --> The path to the image is not correct.
ERROR - 2018-04-26 08:21:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 08:21:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:21:19 --> The path to the image is not correct.
ERROR - 2018-04-26 08:21:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-26 08:21:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:22:39 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:22:39 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:22:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:22:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:22:39 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:22:39 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:22:39 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:22:39 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:22:39 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:22:39 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:22:39 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:22:39 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:22:39 --> The path to the image is not correct.
ERROR - 2018-04-26 08:22:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:22:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:22:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:22:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:22:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:22:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:22:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:22:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:23:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:23:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:23:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:23:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:23:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:23:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:23:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:23:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:23:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:24:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:24:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:24:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:24:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:24:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:24:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:24:39 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:24:39 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:24:39 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:24:39 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:24:39 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:24:39 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:24:39 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:24:39 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:24:39 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:24:39 --> The path to the image is not correct.
ERROR - 2018-04-26 08:24:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:24:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:25:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:25:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:25:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:29:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:29:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:29:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:29:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:29:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:29:28 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:29:28 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:29:28 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:29:28 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:29:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:29:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:29:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:29:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:29:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:29:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:29:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:29:29 --> The path to the image is not correct.
ERROR - 2018-04-26 08:29:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:30:09 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:30:09 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:30:09 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:30:09 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:30:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:30:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:30:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:30:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:30:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:30:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:30:09 --> The path to the image is not correct.
ERROR - 2018-04-26 08:30:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:33:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:33:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:33:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:14 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:14 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:14 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:14 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:35:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:35:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:35:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:35:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:35:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:35:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:35:14 --> The path to the image is not correct.
ERROR - 2018-04-26 08:35:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:35:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:36 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:36 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:36 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:35:36 --> The path to the image is not correct.
ERROR - 2018-04-26 08:35:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:35:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:36 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:36 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:36 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:35:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:35:36 --> The path to the image is not correct.
ERROR - 2018-04-26 08:35:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:35:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:59 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:35:59 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:59 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:35:59 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:35:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:35:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:35:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:35:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:35:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:35:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:35:59 --> The path to the image is not correct.
ERROR - 2018-04-26 08:35:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:35:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:36:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:36:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:36:56 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:36:56 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:36:57 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:36:57 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:36:57 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:36:57 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:36:57 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:36:57 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:36:57 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:36:57 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:36:57 --> The path to the image is not correct.
ERROR - 2018-04-26 08:36:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:36:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:37:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:37:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:37:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:37:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:37:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:37:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:37:45 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:37:45 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:37:45 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:37:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:37:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:37:45 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:37:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:37:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:37:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:37:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:37:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:37:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:37:46 --> The path to the image is not correct.
ERROR - 2018-04-26 08:37:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:37:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:38:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:38:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:38:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:38:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:38:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:38:04 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:38:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:38:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:38:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:38:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:38:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:38:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:38:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:38:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:38:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:38:04 --> The path to the image is not correct.
ERROR - 2018-04-26 08:38:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:38:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:39:18 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:39:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:39:18 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:39:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:39:18 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:39:18 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:39:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:39:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:39:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:39:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:39:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:39:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:39:18 --> The path to the image is not correct.
ERROR - 2018-04-26 08:39:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:39:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:40:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:40:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:40:58 --> The path to the image is not correct.
ERROR - 2018-04-26 08:40:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:40:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:40:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:40:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:40:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:40:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:58 --> The path to the image is not correct.
ERROR - 2018-04-26 08:40:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:40:59 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:40:59 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:40:59 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:40:59 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:40:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:40:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:40:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:40:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:40:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:40:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:40:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:40:59 --> The path to the image is not correct.
ERROR - 2018-04-26 08:40:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:41:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:41:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:41:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:41:38 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:41:38 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:41:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:41:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:41:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:41:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:41:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:41:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:41:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:41:38 --> The path to the image is not correct.
ERROR - 2018-04-26 08:41:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:41:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:45:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:45:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:45:30 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:45:31 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:45:31 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:45:31 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:45:31 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:45:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:45:31 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:45:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:45:31 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:45:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:45:31 --> The path to the image is not correct.
ERROR - 2018-04-26 08:45:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:45:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:45:35 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:45:35 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:45:35 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:45:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:45:35 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:45:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:45:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:45:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:45:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:45:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:45:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:45:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:45:35 --> The path to the image is not correct.
ERROR - 2018-04-26 08:45:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:45:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:46:36 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:46:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:46:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:46:36 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:46:36 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:46:36 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:46:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:46:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:46:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:46:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:46:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:46:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:46:36 --> The path to the image is not correct.
ERROR - 2018-04-26 08:46:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:46:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:46:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:46:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:46:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:46:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:46:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:46:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:47:43 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:47:43 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:47:43 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:47:43 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:47:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:47:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:47:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:47:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:47:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:47:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:47:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:47:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:47:43 --> The path to the image is not correct.
ERROR - 2018-04-26 08:47:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:47:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:13 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:48:13 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:48:13 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:48:13 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:48:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:48:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:48:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:48:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:48:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:48:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:48:13 --> The path to the image is not correct.
ERROR - 2018-04-26 08:48:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:48:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:48:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:48:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:48:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:48:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:48:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:48:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:48:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:48:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:48:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:48:58 --> The path to the image is not correct.
ERROR - 2018-04-26 08:48:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:48:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:48:59 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:48:59 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:48:59 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:48:59 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:48:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:48:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:48:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:48:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:48:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:48:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:48:59 --> The path to the image is not correct.
ERROR - 2018-04-26 08:48:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:49:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:49:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:49:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:49:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:49:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:49:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:50:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:50:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:50:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:50:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:50:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:50:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:52:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:52:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:52:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:52:22 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:52:22 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:52:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:52:22 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:52:22 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:52:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:52:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:52:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:52:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:52:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:52:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:52:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:52:22 --> The path to the image is not correct.
ERROR - 2018-04-26 08:52:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:52:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:52:28 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:52:28 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:52:28 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:52:28 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:52:28 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:52:28 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:52:28 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:52:28 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:52:28 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:52:28 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:52:28 --> The path to the image is not correct.
ERROR - 2018-04-26 08:52:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:52:35 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 197
ERROR - 2018-04-26 08:52:35 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 08:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:53:22 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:53:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:53:22 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:53:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:53:22 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:53:22 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:53:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:53:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:53:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:53:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:53:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:53:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:53:22 --> The path to the image is not correct.
ERROR - 2018-04-26 08:53:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:53:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:53:28 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 197
ERROR - 2018-04-26 08:53:28 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-26 08:58:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:58:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:58:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:58:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:58:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:58:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:58:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:58:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:58:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 08:58:18 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:58:18 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:58:18 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 08:58:18 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 08:58:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:58:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 08:58:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:58:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 08:58:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 08:58:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 08:58:18 --> The path to the image is not correct.
ERROR - 2018-04-26 08:58:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 08:58:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:01:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:01:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:01:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:01:31 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 09:01:31 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 09:01:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:01:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:01:31 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 09:01:31 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 09:01:31 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 09:01:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 09:01:31 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 09:01:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 09:01:31 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 09:01:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 09:01:31 --> The path to the image is not correct.
ERROR - 2018-04-26 09:01:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 09:01:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:29 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 09:04:30 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 09:04:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:30 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-26 09:04:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:30 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-26 09:04:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 09:04:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-26 09:04:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 09:04:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-26 09:04:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-26 09:04:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-26 09:04:30 --> The path to the image is not correct.
ERROR - 2018-04-26 09:04:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-26 09:04:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:04:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:05:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:05:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:05:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:05:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:05:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:05:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:06:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:06:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:06:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:06:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:06:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:06:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:07:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:07:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:07:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:07:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:07:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:07:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:10:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:10:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:10:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:11:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:11:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:11:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:12:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:12:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:12:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:14:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:14:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:14:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:18:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:18:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:18:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:18:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:18:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:18:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:19:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:19:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:19:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:34:27 --> Query error: Unknown column 'vehicle' in 'field list' - Invalid query: UPDATE `checklist` SET `checklist_name` = '12', `description` = '<p>12</p>', `vehicle` = 'BOTH', `status` = '1', `checklist_for` = 'MECHANIC', `reminder_every` = '2 MONTHS'
WHERE `checklist_id` = '42'
ERROR - 2018-04-26 09:34:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:34:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:34:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:34:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:34:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:34:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:35:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:35:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 09:35:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:39:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:39:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:39:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-26 10:53:42 --> 404 Page Not Found: Public/lib

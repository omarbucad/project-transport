<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-07 04:05:30 --> Severity: Notice --> Undefined property: stdClass::$user D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 67
ERROR - 2018-08-07 04:05:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 73
ERROR - 2018-08-07 04:05:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 86
ERROR - 2018-08-07 04:05:30 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 89
ERROR - 2018-08-07 04:05:30 --> Severity: Notice --> Undefined property: stdClass::$start_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 90
ERROR - 2018-08-07 04:05:30 --> Severity: Notice --> Undefined property: stdClass::$end_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 91
ERROR - 2018-08-07 04:05:30 --> Query error: Column 'report_by' cannot be null - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES (NULL, '', '', NULL, NULL, NULL, '', 1533607530, NULL, 0)
ERROR - 2018-08-07 04:05:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-08-07 04:05:40 --> The path to the image is not correct.
ERROR - 2018-08-07 04:05:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:05:42 --> The path to the image is not correct.
ERROR - 2018-08-07 04:05:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:06:03 --> The path to the image is not correct.
ERROR - 2018-08-07 04:06:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:06:07 --> The path to the image is not correct.
ERROR - 2018-08-07 04:06:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:13 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:15 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:17 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:19 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:19 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:22 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:23 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:24 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:48 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:51 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:07:55 --> The path to the image is not correct.
ERROR - 2018-08-07 04:07:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:08:04 --> The path to the image is not correct.
ERROR - 2018-08-07 04:08:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:08:10 --> The path to the image is not correct.
ERROR - 2018-08-07 04:08:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:10:28 --> The path to the image is not correct.
ERROR - 2018-08-07 04:10:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:10:31 --> The path to the image is not correct.
ERROR - 2018-08-07 04:10:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:10:42 --> The path to the image is not correct.
ERROR - 2018-08-07 04:10:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:54:25 --> The path to the image is not correct.
ERROR - 2018-08-07 04:54:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:54:29 --> The path to the image is not correct.
ERROR - 2018-08-07 04:54:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:56:03 --> The path to the image is not correct.
ERROR - 2018-08-07 04:56:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 04:56:06 --> The path to the image is not correct.
ERROR - 2018-08-07 04:56:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 05:38:59 --> The path to the image is not correct.
ERROR - 2018-08-07 05:38:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 05:39:02 --> The path to the image is not correct.
ERROR - 2018-08-07 05:39:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 05:39:09 --> The path to the image is not correct.
ERROR - 2018-08-07 05:39:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 05:40:17 --> The path to the image is not correct.
ERROR - 2018-08-07 05:40:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 05:40:19 --> The path to the image is not correct.
ERROR - 2018-08-07 05:40:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 05:40:34 --> The path to the image is not correct.
ERROR - 2018-08-07 05:40:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 05:40:37 --> The path to the image is not correct.
ERROR - 2018-08-07 05:40:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-07 05:40:40 --> The path to the image is not correct.
ERROR - 2018-08-07 05:40:40 --> Your server does not support the GD function required to process this type of image.

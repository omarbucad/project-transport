<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-30 08:07:45 --> The path to the image is not correct.
ERROR - 2018-05-30 08:07:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-30 08:07:48 --> The path to the image is not correct.
ERROR - 2018-05-30 08:07:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-30 08:07:49 --> The path to the image is not correct.
ERROR - 2018-05-30 08:07:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-30 08:20:42 --> The path to the image is not correct.
ERROR - 2018-05-30 08:20:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-30 08:21:00 --> The path to the image is not correct.
ERROR - 2018-05-30 08:21:00 --> Your server does not support the GD function required to process this type of image.

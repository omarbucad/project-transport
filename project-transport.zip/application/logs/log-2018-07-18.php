<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-18 08:44:39 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-18 08:44:39 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-18 08:44:39 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-18 08:44:40 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-18 08:44:40 --> 404 Page Not Found: Public/upload

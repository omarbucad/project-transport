<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-25 03:54:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:55:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:55:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:55:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:55:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:55:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:55:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:55:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:55:11 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 03:55:11 --> The provided image is not valid.
ERROR - 2018-04-25 03:55:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 03:55:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:56:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:56:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:56:53 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 03:56:53 --> The provided image is not valid.
ERROR - 2018-04-25 03:56:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 03:56:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:59:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:59:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:59:32 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 03:59:32 --> The provided image is not valid.
ERROR - 2018-04-25 03:59:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 03:59:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:59:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:59:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:59:51 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 03:59:51 --> The provided image is not valid.
ERROR - 2018-04-25 03:59:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 03:59:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 03:59:57 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 181
ERROR - 2018-04-25 03:59:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 197
ERROR - 2018-04-25 03:59:57 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 228
ERROR - 2018-04-25 03:59:57 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 229
ERROR - 2018-04-25 03:59:57 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 228
ERROR - 2018-04-25 03:59:57 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 229
ERROR - 2018-04-25 03:59:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-25 04:02:43 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 225
ERROR - 2018-04-25 04:02:43 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 226
ERROR - 2018-04-25 04:02:43 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 225
ERROR - 2018-04-25 04:02:43 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 226
ERROR - 2018-04-25 04:02:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:02:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:02:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:02:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:02:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:02:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:04:21 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-25 04:04:21 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 202
ERROR - 2018-04-25 04:04:21 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 203
ERROR - 2018-04-25 04:04:21 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 204
ERROR - 2018-04-25 04:04:21 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 205
ERROR - 2018-04-25 04:05:15 --> Severity: Warning --> Illegal string offset 'name' D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 04:06:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:28 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 04:06:28 --> The provided image is not valid.
ERROR - 2018-04-25 04:06:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 04:06:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:06:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:07:28 --> Severity: Notice --> Undefined variable: l D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 04:08:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:08:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:09:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:09:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:09:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:09:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:09:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:09:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:09:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:15:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:15:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:15:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:15:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:15:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:15:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:16:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:16:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:16:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:21:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:21:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:21:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:23:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:23:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:23:11 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 04:23:11 --> The provided image is not valid.
ERROR - 2018-04-25 04:23:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 04:23:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:23:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:23:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:23:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:24:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:24:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:24:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:24:09 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 04:24:09 --> The provided image is not valid.
ERROR - 2018-04-25 04:24:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:24:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 04:24:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:24:09 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 04:24:09 --> The provided image is not valid.
ERROR - 2018-04-25 04:24:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 04:24:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:00 --> 404 Page Not Found: Images/checklist
ERROR - 2018-04-25 04:25:00 --> 404 Page Not Found: Images/checklist
ERROR - 2018-04-25 04:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:17 --> 404 Page Not Found: Publi/upload
ERROR - 2018-04-25 04:25:17 --> 404 Page Not Found: Publi/upload
ERROR - 2018-04-25 04:25:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:24 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-25 04:25:24 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-25 04:25:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:47 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-25 04:25:47 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-25 04:25:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:25:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:26:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:26:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:26:35 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 04:26:35 --> The provided image is not valid.
ERROR - 2018-04-25 04:26:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 04:26:35 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 04:26:35 --> The provided image is not valid.
ERROR - 2018-04-25 04:26:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 04:26:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:46:15 --> The path to the image is not correct.
ERROR - 2018-04-25 04:46:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 04:46:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:46:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:46:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:46:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:46:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:46:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:50:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:50:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:50:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:52:47 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 192
ERROR - 2018-04-25 04:52:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:52:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:53:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:53:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:53:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:54:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:54:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:54:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:55:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:55:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:55:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:55:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:55:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 04:55:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:10:29 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 05:10:29 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 05:10:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:10:29 --> The path to the image is not correct.
ERROR - 2018-04-25 05:10:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:10:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 05:10:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:10:30 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 05:10:30 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 05:10:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:10:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:10:30 --> The path to the image is not correct.
ERROR - 2018-04-25 05:10:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 05:10:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:10:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:10:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:10:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:11:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:11:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:11:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:12:13 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 143
ERROR - 2018-04-25 05:12:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 236
ERROR - 2018-04-25 05:12:13 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 237
ERROR - 2018-04-25 05:12:13 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 236
ERROR - 2018-04-25 05:12:13 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 237
ERROR - 2018-04-25 05:12:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 154
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 155
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 156
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: error D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 157
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: size D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 158
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 160
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 160
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 154
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 155
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 156
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: error D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 157
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: size D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 158
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 160
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 160
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 231
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 232
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 231
ERROR - 2018-04-25 05:14:06 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 232
ERROR - 2018-04-25 05:14:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 161
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 161
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 155
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 156
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 157
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 158
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 159
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 161
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 161
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 232
ERROR - 2018-04-25 05:16:42 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 233
ERROR - 2018-04-25 05:16:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-25 05:17:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 155
ERROR - 2018-04-25 05:17:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 156
ERROR - 2018-04-25 05:17:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 157
ERROR - 2018-04-25 05:17:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 158
ERROR - 2018-04-25 05:17:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 159
ERROR - 2018-04-25 05:17:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 161
ERROR - 2018-04-25 05:17:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 232
ERROR - 2018-04-25 05:17:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 233
ERROR - 2018-04-25 05:17:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-25 05:20:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:20:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:20:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:20:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:20:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:20:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:21:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:21:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:21:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:26:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:26:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:26:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:26:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:26:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:27:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:27:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:27:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:31:14 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 151
ERROR - 2018-04-25 05:31:14 --> Severity: Notice --> Undefined index: type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 152
ERROR - 2018-04-25 05:31:14 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 153
ERROR - 2018-04-25 05:31:14 --> Severity: Notice --> Undefined index: error D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 154
ERROR - 2018-04-25 05:31:14 --> Severity: Notice --> Undefined index: size D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 155
ERROR - 2018-04-25 05:31:14 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 157
ERROR - 2018-04-25 05:31:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 228
ERROR - 2018-04-25 05:31:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 229
ERROR - 2018-04-25 05:31:14 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 228
ERROR - 2018-04-25 05:31:14 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 229
ERROR - 2018-04-25 05:31:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-25 05:31:26 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 151
ERROR - 2018-04-25 05:53:15 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 150
ERROR - 2018-04-25 05:53:15 --> Severity: Notice --> Undefined index: type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 151
ERROR - 2018-04-25 05:53:15 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 152
ERROR - 2018-04-25 05:53:15 --> Severity: Notice --> Undefined index: error D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 153
ERROR - 2018-04-25 05:53:15 --> Severity: Notice --> Undefined index: size D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 154
ERROR - 2018-04-25 05:53:15 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 156
ERROR - 2018-04-25 05:53:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 227
ERROR - 2018-04-25 05:53:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 228
ERROR - 2018-04-25 05:53:15 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 227
ERROR - 2018-04-25 05:53:15 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 228
ERROR - 2018-04-25 05:53:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-25 05:54:46 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 150
ERROR - 2018-04-25 05:54:46 --> Severity: Notice --> Undefined index: type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 151
ERROR - 2018-04-25 05:54:46 --> Severity: Notice --> Undefined index: tmp_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 152
ERROR - 2018-04-25 05:54:46 --> Severity: Notice --> Undefined index: error D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 153
ERROR - 2018-04-25 05:54:46 --> Severity: Notice --> Undefined index: size D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 154
ERROR - 2018-04-25 05:54:46 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 156
ERROR - 2018-04-25 05:54:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 227
ERROR - 2018-04-25 05:54:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 228
ERROR - 2018-04-25 05:54:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 227
ERROR - 2018-04-25 05:54:46 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 228
ERROR - 2018-04-25 05:54:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-25 05:58:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:58:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:58:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:58:45 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 05:58:45 --> The provided image is not valid.
ERROR - 2018-04-25 05:58:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 05:58:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:58:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:58:45 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 05:58:45 --> The provided image is not valid.
ERROR - 2018-04-25 05:58:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 05:58:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:58:47 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 05:58:47 --> The provided image is not valid.
ERROR - 2018-04-25 05:58:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 05:58:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:58:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 05:58:47 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 05:58:47 --> The provided image is not valid.
ERROR - 2018-04-25 05:58:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 05:58:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:00:22 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-25 06:00:22 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-25 06:00:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:00:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:00:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:39:28 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 06:39:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:39:28 --> The provided image is not valid.
ERROR - 2018-04-25 06:39:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 06:39:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:39:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:39:53 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 231
ERROR - 2018-04-25 06:39:53 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 232
ERROR - 2018-04-25 06:39:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:39:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:39:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:40:15 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 06:40:15 --> The provided image is not valid.
ERROR - 2018-04-25 06:40:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:40:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 06:40:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:40:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:40:16 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 06:40:16 --> The provided image is not valid.
ERROR - 2018-04-25 06:40:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:40:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 06:40:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 06:40:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:11:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:11:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:11:01 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 07:11:01 --> The provided image is not valid.
ERROR - 2018-04-25 07:11:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 07:11:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:11:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:11:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:11:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 200
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 202
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 203
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 204
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 200
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 202
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 203
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 204
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 200
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 202
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 203
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 204
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 200
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 202
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 203
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 204
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 200
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 202
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 203
ERROR - 2018-04-25 07:11:16 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 204
ERROR - 2018-04-25 07:12:37 --> Severity: Warning --> Illegal string offset 'name' D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 07:13:06 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 07:14:08 --> Severity: Warning --> Illegal string offset 'name' D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 07:14:52 --> Severity: Notice --> Undefined index: ghost.png D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 07:15:20 --> Severity: Notice --> Undefined index: ghost.png D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 07:15:21 --> Severity: Notice --> Undefined index: ghost.png D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 07:15:22 --> Severity: Notice --> Undefined index: ghost.png D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 07:15:22 --> Severity: Notice --> Undefined index: ghost.png D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 07:16:03 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-25 07:16:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:16:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:16:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:16:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:16:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:16:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:16:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:16:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:16:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:21:45 --> Severity: Parsing Error --> syntax error, unexpected '{' D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 217
ERROR - 2018-04-25 07:26:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:26:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:26:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:27:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:27:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:27:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:27:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:27:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:27:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:37:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:37:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:37:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:44:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:45:46 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 07:45:46 --> The provided image is not valid.
ERROR - 2018-04-25 07:45:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 07:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:52:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:52:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:52:03 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 07:52:03 --> The provided image is not valid.
ERROR - 2018-04-25 07:52:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 07:52:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:52:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:52:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:52:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:24 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 219
ERROR - 2018-04-25 07:53:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:51 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 219
ERROR - 2018-04-25 07:53:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:53:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:54:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:54:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:54:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:54:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:54:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:54:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:54:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:54:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:54:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 07:54:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 219
ERROR - 2018-04-25 07:56:40 --> Severity: Notice --> Undefined index: image_path D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 220
ERROR - 2018-04-25 07:56:40 --> Severity: Notice --> Undefined index: image_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 221
ERROR - 2018-04-25 07:56:40 --> Severity: Notice --> Undefined index: image_path D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 220
ERROR - 2018-04-25 07:56:40 --> Severity: Notice --> Undefined index: image_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 221
ERROR - 2018-04-25 08:05:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:06:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:06:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:06:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:06:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:06:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:06:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:06:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:06:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:07:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:07:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:07:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:07:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:07:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:07:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:08:48 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 194
ERROR - 2018-04-25 08:09:22 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 194
ERROR - 2018-04-25 08:09:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:09:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:11:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:11:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:11:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:11:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:11:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:11:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:11:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:12:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:12:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:12:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:12:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:12:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:12:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:13:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:13:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:13:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:13:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:13:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:13:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:13:51 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 08:13:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:13:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:13:51 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 08:13:51 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 08:13:51 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 08:13:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 08:13:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 08:13:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 08:13:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 08:13:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 08:13:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 08:13:51 --> The path to the image is not correct.
ERROR - 2018-04-25 08:13:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 08:13:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:13:51 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 08:13:51 --> The provided image is not valid.
ERROR - 2018-04-25 08:13:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 08:15:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:15:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:15:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:15:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:15:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:15:31 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 08:15:31 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 08:15:31 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 08:15:31 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 08:15:31 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 08:15:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 08:15:31 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 08:15:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 08:15:31 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 08:15:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 08:15:31 --> The path to the image is not correct.
ERROR - 2018-04-25 08:15:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 08:15:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:15:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:15:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:15:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:18:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:18:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:18:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:20:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:20:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:20:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:21:16 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 217
ERROR - 2018-04-25 08:23:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:20 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 08:23:20 --> The provided image is not valid.
ERROR - 2018-04-25 08:23:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 08:23:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:21 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 08:23:21 --> The provided image is not valid.
ERROR - 2018-04-25 08:23:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 08:23:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:23:25 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 08:23:25 --> The provided image is not valid.
ERROR - 2018-04-25 08:23:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 08:23:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:55 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 08:39:55 --> The provided image is not valid.
ERROR - 2018-04-25 08:39:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 08:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:57 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 08:39:57 --> The provided image is not valid.
ERROR - 2018-04-25 08:39:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 08:39:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:57 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 08:39:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:57 --> The provided image is not valid.
ERROR - 2018-04-25 08:39:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 08:39:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:58 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 08:39:58 --> The provided image is not valid.
ERROR - 2018-04-25 08:39:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 08:39:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:39:58 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 08:39:58 --> The provided image is not valid.
ERROR - 2018-04-25 08:39:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 08:39:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 08:42:01 --> Severity: Notice --> Undefined index: image_path D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 253
ERROR - 2018-04-25 08:42:01 --> Severity: Notice --> Undefined index: image_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 254
ERROR - 2018-04-25 08:45:02 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 216
ERROR - 2018-04-25 08:45:02 --> Severity: Notice --> Undefined index: image_path D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 253
ERROR - 2018-04-25 08:45:02 --> Severity: Notice --> Undefined index: image_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 254
ERROR - 2018-04-25 08:47:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 216
ERROR - 2018-04-25 08:49:21 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 217
ERROR - 2018-04-25 08:49:22 --> Severity: Notice --> Undefined index: image_path D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 254
ERROR - 2018-04-25 08:49:22 --> Severity: Notice --> Undefined index: image_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 255
ERROR - 2018-04-25 08:49:41 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 217
ERROR - 2018-04-25 08:49:41 --> Severity: Notice --> Undefined index: image_path D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 254
ERROR - 2018-04-25 08:49:41 --> Severity: Notice --> Undefined index: image_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 255
ERROR - 2018-04-25 08:51:11 --> Severity: Notice --> Undefined index: image_path D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 254
ERROR - 2018-04-25 08:51:11 --> Severity: Notice --> Undefined index: image_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 255
ERROR - 2018-04-25 08:56:46 --> Severity: Notice --> Undefined index: image_path D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 261
ERROR - 2018-04-25 08:56:46 --> Severity: Notice --> Undefined index: image_name D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 262
ERROR - 2018-04-25 09:11:19 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 193
ERROR - 2018-04-25 09:29:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:30:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:32:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:40:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:40:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:40:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:40:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:40:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:40:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:40:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:40:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:41:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:41:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:41:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:41:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:41:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:44:12 --> Severity: Parsing Error --> syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 189
ERROR - 2018-04-25 09:44:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:44:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:44:13 --> Severity: Parsing Error --> syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 189
ERROR - 2018-04-25 09:44:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:44:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:45:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:45:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:45:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:45:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:45:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:45:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 09:45:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:45:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:45:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:45:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:45:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 09:45:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 09:45:03 --> The path to the image is not correct.
ERROR - 2018-04-25 09:45:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 09:45:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:46:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:46:34 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:46:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:46:34 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:46:34 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:46:34 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 09:46:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:46:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:46:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:46:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:46:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 09:46:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 09:46:34 --> The path to the image is not correct.
ERROR - 2018-04-25 09:46:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 09:46:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 09:47:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:47:04 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:47:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:47:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 09:47:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:47:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:47:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:47:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:47:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 09:47:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 09:47:04 --> The path to the image is not correct.
ERROR - 2018-04-25 09:47:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 09:47:35 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:47:35 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:47:35 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:47:35 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 09:47:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:47:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:47:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:47:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:47:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 09:47:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 09:47:35 --> The path to the image is not correct.
ERROR - 2018-04-25 09:47:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 09:54:56 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:54:56 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:54:56 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 09:54:56 --> The path to the image is not correct.
ERROR - 2018-04-25 09:54:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 09:54:56 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:54:56 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:54:56 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:54:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 09:54:57 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 09:54:57 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 09:54:57 --> The path to the image is not correct.
ERROR - 2018-04-25 09:54:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:13:56 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:13:56 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:13:56 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:13:56 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:13:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:13:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:13:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:13:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:13:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:13:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:13:56 --> The path to the image is not correct.
ERROR - 2018-04-25 10:13:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:13:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:13:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:13:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:13:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:13:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:13:59 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:13:59 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:13:59 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:13:59 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:13:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:13:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:13:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:13:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:13:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:13:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:13:59 --> The path to the image is not correct.
ERROR - 2018-04-25 10:13:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:14:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:14:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:14:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:14:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:14:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:14:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:14:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:14:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:14:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:14:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:14:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:14:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:14:00 --> The path to the image is not correct.
ERROR - 2018-04-25 10:14:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:14:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:14:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:14:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:14:26 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:14:26 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:14:26 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:14:26 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:14:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:14:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:14:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:14:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:14:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:14:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:14:26 --> The path to the image is not correct.
ERROR - 2018-04-25 10:14:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:14:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:14:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:14:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:14:48 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:14:48 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:14:48 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:14:48 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:14:48 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:14:48 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:14:48 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:14:48 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:14:48 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:14:48 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:14:48 --> The path to the image is not correct.
ERROR - 2018-04-25 10:14:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:14:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:15:02 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:15:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:15:02 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:02 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:02 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:15:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:15:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:15:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:15:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:15:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:15:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:15:02 --> The path to the image is not correct.
ERROR - 2018-04-25 10:15:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:15:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:15:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:15:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:15:03 --> The path to the image is not correct.
ERROR - 2018-04-25 10:15:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:15:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:15:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:15:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:15:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:15:03 --> The path to the image is not correct.
ERROR - 2018-04-25 10:15:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:15:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:15:23 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:15:23 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:15:23 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:15:23 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:15:23 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:15:23 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:15:23 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:15:23 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:15:23 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:15:23 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:15:23 --> The path to the image is not correct.
ERROR - 2018-04-25 10:15:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:15:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:20:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:20:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:20:46 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:20:46 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:20:46 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:20:46 --> The path to the image is not correct.
ERROR - 2018-04-25 10:20:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:20:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:20:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:20:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:20:46 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:20:46 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:20:46 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:20:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:20:46 --> The path to the image is not correct.
ERROR - 2018-04-25 10:20:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:20:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:21:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:21:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:21:09 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:21:09 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:21:09 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:21:09 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:21:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:21:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:21:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:21:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:21:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:21:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:21:09 --> The path to the image is not correct.
ERROR - 2018-04-25 10:21:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:21:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:21:11 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:21:11 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:21:11 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:21:11 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:21:11 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:21:11 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:21:11 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:21:11 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:21:11 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:21:11 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:21:11 --> The path to the image is not correct.
ERROR - 2018-04-25 10:21:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:24 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:22:24 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:22:24 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:22:24 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:22:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:22:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:22:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:22:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:22:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:22:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:22:24 --> The path to the image is not correct.
ERROR - 2018-04-25 10:22:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:22:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:26 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:22:26 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:22:26 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:22:26 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:22:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:22:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:22:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:22:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:22:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:22:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:22:26 --> The path to the image is not correct.
ERROR - 2018-04-25 10:22:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:22:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:30 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:22:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:22:30 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:22:30 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:22:30 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:22:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:22:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:22:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:22:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:22:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:22:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:22:30 --> The path to the image is not correct.
ERROR - 2018-04-25 10:22:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:22:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:23:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:23:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:23:13 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:23:13 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:23:13 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:23:13 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:23:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:23:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:23:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:23:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:23:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:23:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:23:14 --> The path to the image is not correct.
ERROR - 2018-04-25 10:23:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:23:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:23:33 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:23:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:23:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:23:33 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:23:33 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:23:33 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:23:33 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:23:33 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:23:33 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:23:33 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:23:33 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:23:33 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:23:33 --> The path to the image is not correct.
ERROR - 2018-04-25 10:23:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:23:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:24:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:24:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:24:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:24:24 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:24:24 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:24:24 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:24:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:24:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:24:24 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:24:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:24:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:24:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:24:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:24:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:24:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:24:24 --> The path to the image is not correct.
ERROR - 2018-04-25 10:24:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:24:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:24:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:24:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:24:35 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:24:35 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:24:35 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:24:35 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:24:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:24:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:24:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:24:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:24:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:24:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:24:36 --> The path to the image is not correct.
ERROR - 2018-04-25 10:24:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:24:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:24:46 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:24:46 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:24:46 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:24:46 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:24:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:24:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:24:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:24:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:24:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:24:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:24:46 --> The path to the image is not correct.
ERROR - 2018-04-25 10:24:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:25:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:40 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:40 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:40 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:40 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:25:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:25:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:25:40 --> The path to the image is not correct.
ERROR - 2018-04-25 10:25:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:25:45 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:45 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:45 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:45 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:25:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:25:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:25:45 --> The path to the image is not correct.
ERROR - 2018-04-25 10:25:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:25:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:25:50 --> The path to the image is not correct.
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:25:50 --> The path to the image is not correct.
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:25:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:25:50 --> The path to the image is not correct.
ERROR - 2018-04-25 10:25:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:25:51 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:51 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:25:51 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:25:51 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:25:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:25:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:25:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:25:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:25:51 --> The path to the image is not correct.
ERROR - 2018-04-25 10:25:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:25:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:30:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:30:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:30:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:30:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:30:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:30:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:30:00 --> The path to the image is not correct.
ERROR - 2018-04-25 10:30:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:30:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:02 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:02 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:02 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:30:02 --> The path to the image is not correct.
ERROR - 2018-04-25 10:30:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:30:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:02 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:02 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:02 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:30:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:30:03 --> The path to the image is not correct.
ERROR - 2018-04-25 10:30:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:30:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:30:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:30:03 --> The path to the image is not correct.
ERROR - 2018-04-25 10:30:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:30:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:30:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:30:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:30:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:30:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:30:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:30:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:30:04 --> The path to the image is not correct.
ERROR - 2018-04-25 10:30:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:30:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:31:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:31:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:31:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:31:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:31:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:31:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:31:03 --> The path to the image is not correct.
ERROR - 2018-04-25 10:31:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:31:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:31:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:31:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:31:04 --> The path to the image is not correct.
ERROR - 2018-04-25 10:31:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:31:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:04 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:31:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:31:04 --> The path to the image is not correct.
ERROR - 2018-04-25 10:31:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:31:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:05 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:05 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:05 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:31:05 --> The path to the image is not correct.
ERROR - 2018-04-25 10:31:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:31:05 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:05 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:05 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:31:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:31:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:31:05 --> The path to the image is not correct.
ERROR - 2018-04-25 10:31:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:31:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:32:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:32:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:32:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:32:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:32:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:32:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:40:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:40:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:40:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:40:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:40:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:40:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:40:05 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:40:05 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:40:05 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:40:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:40:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:40:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:40:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:40:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:40:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:40:05 --> The path to the image is not correct.
ERROR - 2018-04-25 10:40:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:40:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:44:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:44:21 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:44:21 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:44:21 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:44:21 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:44:21 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:44:21 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:44:21 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:44:21 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:44:21 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:44:21 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:44:21 --> The path to the image is not correct.
ERROR - 2018-04-25 10:44:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:44:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:44:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:44:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:44:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:44:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:44:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:44:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:44:36 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:44:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:44:36 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:44:36 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:44:36 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:44:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:44:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:44:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:44:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:44:36 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:44:36 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:44:36 --> The path to the image is not correct.
ERROR - 2018-04-25 10:44:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:44:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:45:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:45:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:45:15 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:45:15 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:45:15 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:45:15 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:45:15 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:45:15 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:45:15 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:45:15 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:45:15 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:45:15 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:45:15 --> The path to the image is not correct.
ERROR - 2018-04-25 10:45:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:45:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:45:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:45:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:45:22 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:45:22 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:45:22 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:45:22 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:45:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:45:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:45:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:45:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:45:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:45:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:45:22 --> The path to the image is not correct.
ERROR - 2018-04-25 10:45:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:45:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:45:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:45:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:45:23 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:45:23 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:45:23 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:45:23 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:45:23 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:45:23 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:45:23 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:45:23 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:45:23 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:45:23 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:45:23 --> The path to the image is not correct.
ERROR - 2018-04-25 10:45:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:45:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:46:07 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:46:07 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:46:07 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:46:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:46:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:46:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:46:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:46:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:46:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:46:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:46:07 --> The path to the image is not correct.
ERROR - 2018-04-25 10:46:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:46:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:46:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:46:26 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:46:26 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:46:26 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:46:26 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:46:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:46:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:46:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:46:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:46:26 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:46:26 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:46:26 --> The path to the image is not correct.
ERROR - 2018-04-25 10:46:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:46:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:46:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:46:57 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:46:57 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:46:57 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:46:57 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:46:57 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:46:57 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:46:57 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:46:57 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:46:57 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:46:57 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:46:57 --> The path to the image is not correct.
ERROR - 2018-04-25 10:46:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:47:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:47:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:47:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:47:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:47:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:47:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:47:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:47:03 --> The path to the image is not correct.
ERROR - 2018-04-25 10:47:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:47:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:51 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:51 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:51 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:51 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:47:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:47:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:47:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:47:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:47:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:47:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:47:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:51 --> The path to the image is not correct.
ERROR - 2018-04-25 10:47:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:47:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:53 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:53 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:53 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:47:53 --> The path to the image is not correct.
ERROR - 2018-04-25 10:47:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:47:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 10:47:53 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:53 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:53 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 10:47:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 10:47:53 --> The path to the image is not correct.
ERROR - 2018-04-25 10:47:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 10:47:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:41:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:41:56 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:41:56 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:41:56 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:41:56 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:41:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:41:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:41:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:41:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:41:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:41:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:41:56 --> The path to the image is not correct.
ERROR - 2018-04-25 11:41:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:41:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:07 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:07 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:07 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:42:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:42:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:42:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:42:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:42:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:42:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:42:07 --> The path to the image is not correct.
ERROR - 2018-04-25 11:42:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:42:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:41 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:41 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:41 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:41 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:42:41 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:42:41 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:42:41 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:42:41 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:42:41 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:42:41 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:42:41 --> The path to the image is not correct.
ERROR - 2018-04-25 11:42:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:42:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:43 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:43 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:43 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:43 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:42:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:42:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:42:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:42:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:42:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:42:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:42:43 --> The path to the image is not correct.
ERROR - 2018-04-25 11:42:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:42:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:44 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:44 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:44 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:44 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:42:44 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:42:44 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:42:44 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:42:44 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:42:44 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:42:44 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:42:44 --> The path to the image is not correct.
ERROR - 2018-04-25 11:42:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:42:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:47 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:42:47 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:47 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:42:47 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:42:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:42:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:42:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:42:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:42:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:42:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:42:47 --> The path to the image is not correct.
ERROR - 2018-04-25 11:42:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:42:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:43:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:43:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:43:45 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:43:45 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:43:45 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:43:45 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:43:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:43:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:43:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:43:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:43:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:43:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:43:45 --> The path to the image is not correct.
ERROR - 2018-04-25 11:43:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:43:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:43:46 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:43:46 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:43:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:43:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:43:46 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:43:46 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:43:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:43:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:43:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:43:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:43:46 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:43:46 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:43:46 --> The path to the image is not correct.
ERROR - 2018-04-25 11:43:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:43:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:45:01 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:45:01 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:45:01 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:45:01 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:45:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:45:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:45:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:45:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:45:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:45:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:45:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:45:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:45:01 --> The path to the image is not correct.
ERROR - 2018-04-25 11:45:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:45:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:45:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:45:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:45:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:45:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:45:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:45:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:45:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:45:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:45:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:45:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:45:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:45:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:45:03 --> The path to the image is not correct.
ERROR - 2018-04-25 11:45:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:45:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:24 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:46:24 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:46:24 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:46:24 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:46:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:46:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:46:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:46:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:46:24 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:46:24 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:46:24 --> The path to the image is not correct.
ERROR - 2018-04-25 11:46:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:46:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:29 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:46:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:46:29 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:46:29 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:46:29 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:46:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:46:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:46:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:46:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:46:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:46:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:46:30 --> The path to the image is not correct.
ERROR - 2018-04-25 11:46:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:46:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:49:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:49:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:49:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:49:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:49:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:49:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:49:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:49:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:49:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:49:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:49:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:49:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:49:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:49:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:49:58 --> The path to the image is not correct.
ERROR - 2018-04-25 11:49:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:50:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:50:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:50:27 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:50:27 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:50:27 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:50:27 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:50:27 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:50:27 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:50:27 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:50:27 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:50:27 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:50:27 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:50:27 --> The path to the image is not correct.
ERROR - 2018-04-25 11:50:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:50:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:50:29 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:50:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:50:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:50:29 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:50:29 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:50:29 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:50:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:50:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:50:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:50:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:50:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:50:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:50:29 --> The path to the image is not correct.
ERROR - 2018-04-25 11:50:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:50:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:50:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:50:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 11:50:29 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:50:30 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:50:30 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 11:50:30 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 11:50:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:50:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 11:50:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:50:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 11:50:30 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 11:50:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 11:50:30 --> The path to the image is not correct.
ERROR - 2018-04-25 11:50:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 11:50:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:02:25 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:02:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:02:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:02:25 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:02:25 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:02:25 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:02:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:02:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:02:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:02:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:02:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:02:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:02:25 --> The path to the image is not correct.
ERROR - 2018-04-25 12:02:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:02:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:03:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:03:56 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:03:56 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:03:56 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:03:56 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:03:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:03:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:03:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:03:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:03:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:03:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:03:56 --> The path to the image is not correct.
ERROR - 2018-04-25 12:03:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:03:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:03:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:05 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:04:05 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:04:05 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:04:05 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:04:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:04:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:04:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:04:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:04:06 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:04:06 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:04:06 --> The path to the image is not correct.
ERROR - 2018-04-25 12:04:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:04:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:32 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:04:32 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:04:32 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:04:32 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:04:32 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:04:32 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:04:32 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:04:32 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:04:32 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:04:32 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:04:32 --> The path to the image is not correct.
ERROR - 2018-04-25 12:04:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:04:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:04:40 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:04:40 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:04:40 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:04:40 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:04:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:04:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:04:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:04:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:04:40 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:04:40 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:04:40 --> The path to the image is not correct.
ERROR - 2018-04-25 12:04:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:04:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:32 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:32 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:32 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:32 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:05:32 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:05:32 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:05:32 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:05:32 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:05:32 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:05:32 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:05:32 --> The path to the image is not correct.
ERROR - 2018-04-25 12:05:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:05:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:38 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:38 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:05:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:05:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:05:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:05:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:05:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:05:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:05:38 --> The path to the image is not correct.
ERROR - 2018-04-25 12:05:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:05:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:05:51 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:51 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:51 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:51 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:05:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:05:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:05:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:05:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:05:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:05:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:05:51 --> The path to the image is not correct.
ERROR - 2018-04-25 12:05:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:05:52 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:52 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:52 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:05:52 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:05:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:05:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:05:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:05:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:05:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:05:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:05:53 --> The path to the image is not correct.
ERROR - 2018-04-25 12:05:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:06:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:06:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:06:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:06:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:06:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:06:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:06:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:06:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:06:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:06:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:06:00 --> The path to the image is not correct.
ERROR - 2018-04-25 12:06:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:06:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:06:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:06:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:06:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:06:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:06:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:06:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:06:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:06:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:06:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:06:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:06:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:06:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:06:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:06:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:06:03 --> The path to the image is not correct.
ERROR - 2018-04-25 12:06:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:06:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:10:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:10:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:10:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:10:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:10:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:10:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:11:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:11:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:11:10 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:11:10 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:11:10 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:11:10 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:11:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:11:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:11:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:11:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:11:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:11:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:11:10 --> The path to the image is not correct.
ERROR - 2018-04-25 12:11:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:11:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:25:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:25:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:25:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:25:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:25:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:25:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:25:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:25:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:25:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:25:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:25:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:25:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:25:03 --> The path to the image is not correct.
ERROR - 2018-04-25 12:25:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:25:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 12:25:13 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:25:13 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:25:13 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:25:13 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:25:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:25:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:25:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:25:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:25:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:25:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:25:13 --> The path to the image is not correct.
ERROR - 2018-04-25 12:25:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:29:10 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:29:10 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:29:10 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:29:10 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:29:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:29:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:29:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:29:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:29:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:29:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:29:10 --> The path to the image is not correct.
ERROR - 2018-04-25 12:29:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:30:07 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:30:07 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:30:07 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:30:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:30:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:30:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:30:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:30:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:30:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:30:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:30:08 --> The path to the image is not correct.
ERROR - 2018-04-25 12:30:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:30:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:30:38 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:30:38 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:30:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:30:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:30:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:30:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:30:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:30:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:30:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:30:38 --> The path to the image is not correct.
ERROR - 2018-04-25 12:30:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:30:42 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:30:42 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:30:42 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:30:42 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:30:42 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:30:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:30:42 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:30:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:30:42 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:30:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:30:42 --> The path to the image is not correct.
ERROR - 2018-04-25 12:30:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:31:18 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:31:18 --> The provided image is not valid.
ERROR - 2018-04-25 12:31:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:31:18 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:31:18 --> The provided image is not valid.
ERROR - 2018-04-25 12:31:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:31:21 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:31:21 --> The provided image is not valid.
ERROR - 2018-04-25 12:31:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:31:21 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:31:21 --> The provided image is not valid.
ERROR - 2018-04-25 12:31:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:32:58 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:32:58 --> The provided image is not valid.
ERROR - 2018-04-25 12:32:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:32:58 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:32:58 --> The provided image is not valid.
ERROR - 2018-04-25 12:32:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:33:42 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:33:42 --> The provided image is not valid.
ERROR - 2018-04-25 12:33:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:33:42 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:33:42 --> The provided image is not valid.
ERROR - 2018-04-25 12:33:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:33:45 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:33:45 --> The provided image is not valid.
ERROR - 2018-04-25 12:33:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:33:45 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:45 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:45 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:45 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:33:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:33:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:33:45 --> The path to the image is not correct.
ERROR - 2018-04-25 12:33:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:33:46 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:33:47 --> The provided image is not valid.
ERROR - 2018-04-25 12:33:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:33:47 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:47 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:47 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:47 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:33:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:47 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:33:47 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:33:47 --> The path to the image is not correct.
ERROR - 2018-04-25 12:33:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:33:49 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:49 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:49 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:49 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:33:49 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:49 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:49 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:49 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:49 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:33:49 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:33:49 --> The path to the image is not correct.
ERROR - 2018-04-25 12:33:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:33:49 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:49 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:50 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:33:50 --> The path to the image is not correct.
ERROR - 2018-04-25 12:33:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:33:50 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:50 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:50 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:33:50 --> The path to the image is not correct.
ERROR - 2018-04-25 12:33:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:33:50 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:50 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:50 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:33:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:33:50 --> The path to the image is not correct.
ERROR - 2018-04-25 12:33:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:33:53 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:53 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:53 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:33:53 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:33:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:33:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:33:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:33:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:33:53 --> The path to the image is not correct.
ERROR - 2018-04-25 12:33:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:34:04 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:34:04 --> The provided image is not valid.
ERROR - 2018-04-25 12:34:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:35:01 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:35:01 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:35:01 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:35:01 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:35:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:35:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:35:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:35:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:35:01 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:35:01 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:35:01 --> The path to the image is not correct.
ERROR - 2018-04-25 12:35:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:35:25 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:35:25 --> The provided image is not valid.
ERROR - 2018-04-25 12:35:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:35:25 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:35:25 --> The provided image is not valid.
ERROR - 2018-04-25 12:35:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:35:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:35:38 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:35:38 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:35:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:35:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:35:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:35:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:35:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:35:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:35:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:35:38 --> The path to the image is not correct.
ERROR - 2018-04-25 12:35:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:35:53 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:35:53 --> The provided image is not valid.
ERROR - 2018-04-25 12:35:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:43:06 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:43:06 --> The provided image is not valid.
ERROR - 2018-04-25 12:43:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:43:06 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:43:06 --> The provided image is not valid.
ERROR - 2018-04-25 12:43:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:43:37 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:43:37 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:43:37 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:43:37 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:43:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:43:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:43:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:43:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:43:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:43:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:43:37 --> The path to the image is not correct.
ERROR - 2018-04-25 12:43:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:43:52 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:43:52 --> The provided image is not valid.
ERROR - 2018-04-25 12:43:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:43:54 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:43:55 --> The provided image is not valid.
ERROR - 2018-04-25 12:43:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:43:55 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:43:55 --> The provided image is not valid.
ERROR - 2018-04-25 12:43:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:43:55 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:43:55 --> The provided image is not valid.
ERROR - 2018-04-25 12:43:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:43:55 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:43:55 --> The provided image is not valid.
ERROR - 2018-04-25 12:43:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:43:56 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:43:56 --> The provided image is not valid.
ERROR - 2018-04-25 12:43:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:43:56 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:43:56 --> The provided image is not valid.
ERROR - 2018-04-25 12:43:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:44:23 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 12:44:23 --> The provided image is not valid.
ERROR - 2018-04-25 12:44:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 12:46:52 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:46:52 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:46:52 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:46:52 --> The path to the image is not correct.
ERROR - 2018-04-25 12:46:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 12:46:52 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:46:52 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:46:52 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 12:46:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 12:46:52 --> The path to the image is not correct.
ERROR - 2018-04-25 12:46:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 13:00:23 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 161
ERROR - 2018-04-25 13:02:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:02:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:02:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:12:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:12:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:12:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:12:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:12:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:12:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:16:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:16:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:16:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:18:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:18:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:18:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:19:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:19:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:19:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:22:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:22:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:22:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:23:18 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 155
ERROR - 2018-04-25 13:23:18 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 155
ERROR - 2018-04-25 13:23:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 100
ERROR - 2018-04-25 13:23:18 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2018-04-25 13:24:00 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 155
ERROR - 2018-04-25 13:24:00 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 155
ERROR - 2018-04-25 13:24:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 100
ERROR - 2018-04-25 13:24:00 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2018-04-25 13:24:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:25:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:25:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:25:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:25:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:25:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:25:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:25:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:25:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:27:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:27:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:27:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:28:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:28:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:28:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:28:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:28:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:28:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:28:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:28:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:28:59 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:28:59 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:28:59 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:28:59 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 13:28:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 13:28:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 13:28:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 13:28:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 13:28:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 13:28:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 13:28:59 --> The path to the image is not correct.
ERROR - 2018-04-25 13:28:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 13:28:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 13:29:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 249
ERROR - 2018-04-25 13:29:12 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2018-04-25 13:55:44 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:55:44 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:55:44 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:55:44 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 13:55:44 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 13:55:44 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 13:55:44 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 13:55:44 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 13:55:44 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 13:55:44 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 13:55:44 --> The path to the image is not correct.
ERROR - 2018-04-25 13:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 13:56:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:56:04 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:56:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:56:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 13:56:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 13:56:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 13:56:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 13:56:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 13:56:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 13:56:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 13:56:04 --> The path to the image is not correct.
ERROR - 2018-04-25 13:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 13:56:13 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:56:13 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:56:13 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 13:56:13 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 13:56:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 13:56:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 13:56:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 13:56:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 13:56:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 13:56:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 13:56:13 --> The path to the image is not correct.
ERROR - 2018-04-25 13:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 14:00:07 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:00:07 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:00:07 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:00:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 14:00:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:00:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:00:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:00:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:00:07 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 14:00:07 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 14:00:07 --> The path to the image is not correct.
ERROR - 2018-04-25 14:00:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 14:00:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:00:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:00:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:00:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 14:00:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:00:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:00:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:00:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:00:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 14:00:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 14:00:58 --> The path to the image is not correct.
ERROR - 2018-04-25 14:00:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 14:01:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:01:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:01:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:02:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:02:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:02:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:03:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:03:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:03:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:03:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:03:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:03:04 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:03:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:03:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:03:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 14:03:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:03:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:03:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:03:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:03:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 14:03:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 14:03:04 --> The path to the image is not correct.
ERROR - 2018-04-25 14:03:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 14:03:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:03:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:03:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:03:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:16:00 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 160
ERROR - 2018-04-25 14:16:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:16:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:16:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:16:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:16:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:16:13 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-25 14:16:13 --> The provided image is not valid.
ERROR - 2018-04-25 14:16:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-25 14:16:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:17:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:17:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:17:15 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:17:15 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:17:15 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:17:15 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 14:17:15 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:17:15 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:17:15 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:17:15 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:17:15 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 14:17:15 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 14:17:15 --> The path to the image is not correct.
ERROR - 2018-04-25 14:17:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 14:17:18 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:17:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:17:18 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:17:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:17:18 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:17:18 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 14:17:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:17:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:17:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:17:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:17:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 14:17:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 14:17:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:17:18 --> The path to the image is not correct.
ERROR - 2018-04-25 14:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 14:18:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:18:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:18:13 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:18:13 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:18:13 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:18:13 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 14:18:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:18:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:18:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:18:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:18:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 14:18:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 14:18:13 --> The path to the image is not correct.
ERROR - 2018-04-25 14:18:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 14:18:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:18:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:18:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:18:16 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:18:16 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:18:16 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:18:16 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 14:18:16 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:18:16 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:18:16 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:18:16 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:18:16 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 14:18:16 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 14:18:16 --> The path to the image is not correct.
ERROR - 2018-04-25 14:18:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 14:18:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:23:15 --> Severity: Notice --> Undefined variable: config D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 143
ERROR - 2018-04-25 14:23:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 149
ERROR - 2018-04-25 14:24:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:24:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:24:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:24:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:24:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:24:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:24:55 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:24:55 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:24:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:24:55 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:24:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:24:55 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 14:24:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:24:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:24:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:24:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:24:56 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 14:24:56 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 14:24:56 --> The path to the image is not correct.
ERROR - 2018-04-25 14:24:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 14:24:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:25:10 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 152
ERROR - 2018-04-25 14:25:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:25:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-25 14:25:35 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:25:35 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:25:35 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-25 14:25:35 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-25 14:25:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:25:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-25 14:25:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:25:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-25 14:25:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-25 14:25:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-25 14:25:35 --> The path to the image is not correct.
ERROR - 2018-04-25 14:25:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-25 14:25:35 --> 404 Page Not Found: Public/lib

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-28 02:55:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Invoice.php 13
ERROR - 2018-06-28 02:55:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-28 02:55:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-28 02:55:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-28 02:55:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-28 02:55:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-28 02:55:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-28 02:55:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-28 02:55:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-28 02:55:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-28 02:55:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-28 02:55:09 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 04:13:17 --> The path to the image is not correct.
ERROR - 2018-06-28 04:13:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:33:05 --> The path to the image is not correct.
ERROR - 2018-06-28 08:33:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:33:05 --> The path to the image is not correct.
ERROR - 2018-06-28 08:33:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:36:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 08:36:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 08:36:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 08:36:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 08:36:30 --> The path to the image is not correct.
ERROR - 2018-06-28 08:36:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:36:30 --> The path to the image is not correct.
ERROR - 2018-06-28 08:36:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:36:30 --> The path to the image is not correct.
ERROR - 2018-06-28 08:36:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:38:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 08:38:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 08:38:24 --> The path to the image is not correct.
ERROR - 2018-06-28 08:38:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:38:24 --> The path to the image is not correct.
ERROR - 2018-06-28 08:38:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 08:38:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 08:38:25 --> The path to the image is not correct.
ERROR - 2018-06-28 08:38:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:38:25 --> The path to the image is not correct.
ERROR - 2018-06-28 08:38:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:38:25 --> The path to the image is not correct.
ERROR - 2018-06-28 08:38:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:38:44 --> The path to the image is not correct.
ERROR - 2018-06-28 08:38:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:38:44 --> The path to the image is not correct.
ERROR - 2018-06-28 08:38:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:38:44 --> The path to the image is not correct.
ERROR - 2018-06-28 08:38:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:53 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:54 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:55 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:38:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:01 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:05 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:06 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:11 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:39:12 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:15 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:16 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:17 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:18 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:39:26 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 08:39:26 --> The path to the image is not correct.
ERROR - 2018-06-28 08:39:26 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 08:39:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:40:41 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 35
ERROR - 2018-06-28 08:40:41 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 37
ERROR - 2018-06-28 08:40:41 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:40:41 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 39
ERROR - 2018-06-28 08:40:41 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:41 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:41 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:41 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:41 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:42 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:43 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 146
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 149
ERROR - 2018-06-28 08:40:45 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 08:40:45 --> The path to the image is not correct.
ERROR - 2018-06-28 08:40:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:40:45 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 08:40:46 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:47 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:48 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:48 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-28 08:41:48 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:48 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:41:48 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:41:48 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:41:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:41:48 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 08:41:48 --> The path to the image is not correct.
ERROR - 2018-06-28 08:41:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:41:48 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 08:41:48 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:18 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:19 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:20 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:21 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:23 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 143
ERROR - 2018-06-28 08:44:25 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 08:44:25 --> The path to the image is not correct.
ERROR - 2018-06-28 08:44:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:44:25 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:38 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 131
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 137
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 140
ERROR - 2018-06-28 08:44:40 --> The path to the image is not correct.
ERROR - 2018-06-28 08:44:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:57 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:44:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:45:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:00 --> Severity: Notice --> Undefined property: stdClass::$updated_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-28 08:45:00 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:00 --> The path to the image is not correct.
ERROR - 2018-06-28 08:45:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:45:27 --> The path to the image is not correct.
ERROR - 2018-06-28 08:45:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 133
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 136
ERROR - 2018-06-28 08:49:10 --> The path to the image is not correct.
ERROR - 2018-06-28 08:49:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:17 --> The path to the image is not correct.
ERROR - 2018-06-28 08:50:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:33 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:33 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:33 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:33 --> The path to the image is not correct.
ERROR - 2018-06-28 08:50:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:50:41 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:41 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:41 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:41 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:42 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:43 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:43 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:43 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:43 --> Severity: Notice --> Undefined variable: ow D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:43 --> The path to the image is not correct.
ERROR - 2018-06-28 08:50:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:50:49 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting ',' or ';' D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-28 08:50:49 --> The path to the image is not correct.
ERROR - 2018-06-28 08:50:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:50:55 --> The path to the image is not correct.
ERROR - 2018-06-28 08:50:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:51:36 --> The path to the image is not correct.
ERROR - 2018-06-28 08:51:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:53:33 --> The path to the image is not correct.
ERROR - 2018-06-28 08:53:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:54:22 --> The path to the image is not correct.
ERROR - 2018-06-28 08:54:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:54:41 --> The path to the image is not correct.
ERROR - 2018-06-28 08:54:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:55:01 --> The path to the image is not correct.
ERROR - 2018-06-28 08:55:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:55:01 --> The path to the image is not correct.
ERROR - 2018-06-28 08:55:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:55:01 --> The path to the image is not correct.
ERROR - 2018-06-28 08:55:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:55:13 --> The path to the image is not correct.
ERROR - 2018-06-28 08:55:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:55:19 --> The path to the image is not correct.
ERROR - 2018-06-28 08:55:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:55:41 --> The path to the image is not correct.
ERROR - 2018-06-28 08:55:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:55:47 --> The path to the image is not correct.
ERROR - 2018-06-28 08:55:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:55:53 --> The path to the image is not correct.
ERROR - 2018-06-28 08:55:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:56:04 --> The path to the image is not correct.
ERROR - 2018-06-28 08:56:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:56:11 --> The path to the image is not correct.
ERROR - 2018-06-28 08:56:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:56:16 --> The path to the image is not correct.
ERROR - 2018-06-28 08:56:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:56:50 --> The path to the image is not correct.
ERROR - 2018-06-28 08:56:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:56:51 --> The path to the image is not correct.
ERROR - 2018-06-28 08:56:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:57:37 --> The path to the image is not correct.
ERROR - 2018-06-28 08:57:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:57:37 --> The path to the image is not correct.
ERROR - 2018-06-28 08:57:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:57:46 --> The path to the image is not correct.
ERROR - 2018-06-28 08:57:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:58:31 --> The path to the image is not correct.
ERROR - 2018-06-28 08:58:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:58:53 --> The path to the image is not correct.
ERROR - 2018-06-28 08:58:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:58:53 --> The path to the image is not correct.
ERROR - 2018-06-28 08:58:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:59:01 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 94
ERROR - 2018-06-28 08:59:02 --> The path to the image is not correct.
ERROR - 2018-06-28 08:59:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:59:02 --> The path to the image is not correct.
ERROR - 2018-06-28 08:59:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:59:03 --> The path to the image is not correct.
ERROR - 2018-06-28 08:59:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 08:59:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 08:59:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 09:01:39 --> The path to the image is not correct.
ERROR - 2018-06-28 09:01:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:01:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 09:01:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 09:02:26 --> The path to the image is not correct.
ERROR - 2018-06-28 09:02:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:02:27 --> The path to the image is not correct.
ERROR - 2018-06-28 09:02:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:02:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 09:02:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 09:03:13 --> The path to the image is not correct.
ERROR - 2018-06-28 09:03:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:03:15 --> The path to the image is not correct.
ERROR - 2018-06-28 09:03:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:03:15 --> The path to the image is not correct.
ERROR - 2018-06-28 09:03:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:03:19 --> The path to the image is not correct.
ERROR - 2018-06-28 09:03:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:03:19 --> The path to the image is not correct.
ERROR - 2018-06-28 09:03:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:03:19 --> The path to the image is not correct.
ERROR - 2018-06-28 09:03:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:03:19 --> The path to the image is not correct.
ERROR - 2018-06-28 09:03:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:10:02 --> The path to the image is not correct.
ERROR - 2018-06-28 09:10:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:10:02 --> The path to the image is not correct.
ERROR - 2018-06-28 09:10:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:10:02 --> The path to the image is not correct.
ERROR - 2018-06-28 09:10:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:13:26 --> The path to the image is not correct.
ERROR - 2018-06-28 09:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:13:26 --> The path to the image is not correct.
ERROR - 2018-06-28 09:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:13:26 --> The path to the image is not correct.
ERROR - 2018-06-28 09:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:14:53 --> Severity: Error --> Call to undefined function is_empty() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:14:54 --> The path to the image is not correct.
ERROR - 2018-06-28 09:14:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:14:54 --> The path to the image is not correct.
ERROR - 2018-06-28 09:14:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:07 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:07 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:11 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:11 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:11 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:11 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:38 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:38 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:59 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:59 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:59 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:15:59 --> The path to the image is not correct.
ERROR - 2018-06-28 09:15:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:16:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:16:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:16:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:16:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:16:39 --> The path to the image is not correct.
ERROR - 2018-06-28 09:16:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:16:40 --> The path to the image is not correct.
ERROR - 2018-06-28 09:16:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:16:40 --> The path to the image is not correct.
ERROR - 2018-06-28 09:16:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:17:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:17:06 --> The path to the image is not correct.
ERROR - 2018-06-28 09:17:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:17:07 --> The path to the image is not correct.
ERROR - 2018-06-28 09:17:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:17:07 --> The path to the image is not correct.
ERROR - 2018-06-28 09:17:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:18:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:18:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:18:46 --> The path to the image is not correct.
ERROR - 2018-06-28 09:18:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:18:46 --> The path to the image is not correct.
ERROR - 2018-06-28 09:18:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:18:46 --> The path to the image is not correct.
ERROR - 2018-06-28 09:18:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:19:04 --> Severity: Notice --> Undefined property: stdClass::$invoice_id D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 159
ERROR - 2018-06-28 09:19:04 --> The path to the image is not correct.
ERROR - 2018-06-28 09:19:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:19:04 --> The path to the image is not correct.
ERROR - 2018-06-28 09:19:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:19:04 --> The path to the image is not correct.
ERROR - 2018-06-28 09:19:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:19:47 --> Severity: Notice --> Undefined property: stdClass::$invoice_pdf D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:19:47 --> Severity: Notice --> Undefined property: stdClass::$invoice_pdf D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 158
ERROR - 2018-06-28 09:19:47 --> The path to the image is not correct.
ERROR - 2018-06-28 09:19:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:19:47 --> The path to the image is not correct.
ERROR - 2018-06-28 09:19:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:19:47 --> The path to the image is not correct.
ERROR - 2018-06-28 09:19:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:20:15 --> Severity: Notice --> Undefined property: stdClass::$invoice_pdf D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 159
ERROR - 2018-06-28 09:20:15 --> Severity: Notice --> Undefined property: stdClass::$invoice_id D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 159
ERROR - 2018-06-28 09:20:15 --> Severity: Notice --> Undefined property: stdClass::$invoice_pdf D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 159
ERROR - 2018-06-28 09:20:15 --> Severity: Notice --> Undefined property: stdClass::$invoice_id D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 159
ERROR - 2018-06-28 09:20:15 --> The path to the image is not correct.
ERROR - 2018-06-28 09:20:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:20:15 --> The path to the image is not correct.
ERROR - 2018-06-28 09:20:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:20:15 --> The path to the image is not correct.
ERROR - 2018-06-28 09:20:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:20:42 --> The path to the image is not correct.
ERROR - 2018-06-28 09:20:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:20:42 --> The path to the image is not correct.
ERROR - 2018-06-28 09:20:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:23:17 --> The path to the image is not correct.
ERROR - 2018-06-28 09:23:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:23:17 --> The path to the image is not correct.
ERROR - 2018-06-28 09:23:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:23:18 --> The path to the image is not correct.
ERROR - 2018-06-28 09:23:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:54:00 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT `plan_expiration`
FROM `user_plan`
WHERE `user_id` = '6'
AND `active` = 1
ERROR - 2018-06-28 09:56:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 113
ERROR - 2018-06-28 09:56:24 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 126
ERROR - 2018-06-28 09:56:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 113
ERROR - 2018-06-28 09:56:24 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 126
ERROR - 2018-06-28 09:56:24 --> The path to the image is not correct.
ERROR - 2018-06-28 09:56:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:56:24 --> The path to the image is not correct.
ERROR - 2018-06-28 09:56:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:56:24 --> The path to the image is not correct.
ERROR - 2018-06-28 09:56:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:56:44 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 126
ERROR - 2018-06-28 09:56:44 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 126
ERROR - 2018-06-28 09:56:44 --> The path to the image is not correct.
ERROR - 2018-06-28 09:56:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:56:45 --> The path to the image is not correct.
ERROR - 2018-06-28 09:56:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:56:45 --> The path to the image is not correct.
ERROR - 2018-06-28 09:56:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:57:07 --> The path to the image is not correct.
ERROR - 2018-06-28 09:57:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:57:07 --> The path to the image is not correct.
ERROR - 2018-06-28 09:57:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:57:07 --> The path to the image is not correct.
ERROR - 2018-06-28 09:57:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:57:48 --> The path to the image is not correct.
ERROR - 2018-06-28 09:57:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:57:48 --> The path to the image is not correct.
ERROR - 2018-06-28 09:57:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:57:48 --> The path to the image is not correct.
ERROR - 2018-06-28 09:57:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:58:06 --> The path to the image is not correct.
ERROR - 2018-06-28 09:58:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:58:06 --> The path to the image is not correct.
ERROR - 2018-06-28 09:58:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:58:06 --> The path to the image is not correct.
ERROR - 2018-06-28 09:58:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:59:13 --> The path to the image is not correct.
ERROR - 2018-06-28 09:59:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:59:13 --> The path to the image is not correct.
ERROR - 2018-06-28 09:59:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 09:59:13 --> The path to the image is not correct.
ERROR - 2018-06-28 09:59:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 10:01:51 --> The path to the image is not correct.
ERROR - 2018-06-28 10:01:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 10:01:51 --> The path to the image is not correct.
ERROR - 2018-06-28 10:01:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 10:01:51 --> The path to the image is not correct.
ERROR - 2018-06-28 10:01:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:30:35 --> The path to the image is not correct.
ERROR - 2018-06-28 11:30:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:30:36 --> The path to the image is not correct.
ERROR - 2018-06-28 11:30:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:30:36 --> The path to the image is not correct.
ERROR - 2018-06-28 11:30:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:31:48 --> The path to the image is not correct.
ERROR - 2018-06-28 11:31:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:31:48 --> The path to the image is not correct.
ERROR - 2018-06-28 11:31:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:31:48 --> The path to the image is not correct.
ERROR - 2018-06-28 11:31:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:31:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:31:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:32:24 --> The path to the image is not correct.
ERROR - 2018-06-28 11:32:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:32:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:32:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:32:24 --> The path to the image is not correct.
ERROR - 2018-06-28 11:32:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:32:24 --> The path to the image is not correct.
ERROR - 2018-06-28 11:32:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:32:34 --> The path to the image is not correct.
ERROR - 2018-06-28 11:32:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:32:34 --> The path to the image is not correct.
ERROR - 2018-06-28 11:32:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:32:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:32:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:32:34 --> The path to the image is not correct.
ERROR - 2018-06-28 11:32:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:33:26 --> The path to the image is not correct.
ERROR - 2018-06-28 11:33:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:33:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:33:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:33:26 --> The path to the image is not correct.
ERROR - 2018-06-28 11:33:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:33:26 --> The path to the image is not correct.
ERROR - 2018-06-28 11:33:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:34:03 --> The path to the image is not correct.
ERROR - 2018-06-28 11:34:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:34:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:34:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:34:03 --> The path to the image is not correct.
ERROR - 2018-06-28 11:34:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:36:34 --> The path to the image is not correct.
ERROR - 2018-06-28 11:36:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:36:34 --> The path to the image is not correct.
ERROR - 2018-06-28 11:36:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:36:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:36:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:36:34 --> The path to the image is not correct.
ERROR - 2018-06-28 11:36:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:37:48 --> The path to the image is not correct.
ERROR - 2018-06-28 11:37:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:37:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:37:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:37:48 --> The path to the image is not correct.
ERROR - 2018-06-28 11:37:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:37:48 --> The path to the image is not correct.
ERROR - 2018-06-28 11:37:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:39:47 --> The path to the image is not correct.
ERROR - 2018-06-28 11:39:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:39:47 --> The path to the image is not correct.
ERROR - 2018-06-28 11:39:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:39:47 --> The path to the image is not correct.
ERROR - 2018-06-28 11:39:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:39:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:39:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:39:47 --> The path to the image is not correct.
ERROR - 2018-06-28 11:39:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:39:47 --> The path to the image is not correct.
ERROR - 2018-06-28 11:39:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:40:45 --> The path to the image is not correct.
ERROR - 2018-06-28 11:40:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:40:45 --> The path to the image is not correct.
ERROR - 2018-06-28 11:40:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:40:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:40:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:40:45 --> The path to the image is not correct.
ERROR - 2018-06-28 11:40:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:42:43 --> The path to the image is not correct.
ERROR - 2018-06-28 11:42:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:42:43 --> The path to the image is not correct.
ERROR - 2018-06-28 11:42:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:42:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:42:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:42:43 --> The path to the image is not correct.
ERROR - 2018-06-28 11:42:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:43:31 --> The path to the image is not correct.
ERROR - 2018-06-28 11:43:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:43:31 --> The path to the image is not correct.
ERROR - 2018-06-28 11:43:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:43:31 --> The path to the image is not correct.
ERROR - 2018-06-28 11:43:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:43:31 --> The path to the image is not correct.
ERROR - 2018-06-28 11:43:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:43:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:43:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:45:06 --> The path to the image is not correct.
ERROR - 2018-06-28 11:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:45:06 --> The path to the image is not correct.
ERROR - 2018-06-28 11:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:45:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:45:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:45:06 --> The path to the image is not correct.
ERROR - 2018-06-28 11:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:16 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:51:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:51:16 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:17 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:35 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:51:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:51:35 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:35 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:35 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:36 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:36 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:51:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:51:36 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:36 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:54 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:54 --> The path to the image is not correct.
ERROR - 2018-06-28 11:51:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 11:51:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 11:51:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:23:19 --> The path to the image is not correct.
ERROR - 2018-06-28 12:23:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:23:19 --> The path to the image is not correct.
ERROR - 2018-06-28 12:23:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:23:19 --> The path to the image is not correct.
ERROR - 2018-06-28 12:23:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:23:23 --> 404 Page Not Found: admin/Accounts/send_plan_notice
ERROR - 2018-06-28 12:23:58 --> The path to the image is not correct.
ERROR - 2018-06-28 12:23:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:23:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:23:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:23:58 --> The path to the image is not correct.
ERROR - 2018-06-28 12:23:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:23:58 --> The path to the image is not correct.
ERROR - 2018-06-28 12:23:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:24:02 --> Query error: Unknown column 'u.email_address*' in 'field list' - Invalid query: SELECT `u`.`email_address*`, `up`.`plan_expiration`, `up`.`user_plan_id`
FROM `user` `u`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
JOIN `user` `u2` ON `u2`.`user_id` = `up`.`who_updated`
WHERE `up`.`active` = 1
AND `u`.`user_id` = '6'
AND `u`.`role` = 'SUPER ADMIN'
ERROR - 2018-06-28 12:24:50 --> The path to the image is not correct.
ERROR - 2018-06-28 12:24:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:24:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:24:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:24:50 --> The path to the image is not correct.
ERROR - 2018-06-28 12:24:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:24:50 --> The path to the image is not correct.
ERROR - 2018-06-28 12:24:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$email D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 162
ERROR - 2018-06-28 12:24:53 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\project-transport\application\views\backend\page\admin\email\plan_notification.php 8
ERROR - 2018-06-28 12:24:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\email\plan_notification.php 8
ERROR - 2018-06-28 12:24:53 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\project-transport\application\views\backend\page\admin\email\plan_notification.php 9
ERROR - 2018-06-28 12:24:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\email\plan_notification.php 9
ERROR - 2018-06-28 12:25:09 --> The path to the image is not correct.
ERROR - 2018-06-28 12:25:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:25:09 --> The path to the image is not correct.
ERROR - 2018-06-28 12:25:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:25:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:25:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:25:10 --> The path to the image is not correct.
ERROR - 2018-06-28 12:25:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:25:13 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\project-transport\application\views\backend\page\admin\email\plan_notification.php 8
ERROR - 2018-06-28 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\email\plan_notification.php 8
ERROR - 2018-06-28 12:25:13 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\project-transport\application\views\backend\page\admin\email\plan_notification.php 9
ERROR - 2018-06-28 12:25:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\email\plan_notification.php 9
ERROR - 2018-06-28 12:26:07 --> The path to the image is not correct.
ERROR - 2018-06-28 12:26:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:26:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:26:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-28 12:26:07 --> The path to the image is not correct.
ERROR - 2018-06-28 12:26:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-28 12:26:07 --> The path to the image is not correct.
ERROR - 2018-06-28 12:26:07 --> Your server does not support the GD function required to process this type of image.

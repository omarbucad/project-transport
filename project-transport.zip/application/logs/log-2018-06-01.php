<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-01 07:08:36 --> The path to the image is not correct.
ERROR - 2018-06-01 07:08:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 07:41:46 --> The path to the image is not correct.
ERROR - 2018-06-01 07:41:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 07:43:08 --> The path to the image is not correct.
ERROR - 2018-06-01 07:43:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 07:43:17 --> The path to the image is not correct.
ERROR - 2018-06-01 07:43:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 07:43:23 --> The path to the image is not correct.
ERROR - 2018-06-01 07:43:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 07:53:28 --> The path to the image is not correct.
ERROR - 2018-06-01 07:53:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:03:46 --> The path to the image is not correct.
ERROR - 2018-06-01 08:03:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:03:49 --> The path to the image is not correct.
ERROR - 2018-06-01 08:03:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:04:51 --> Query error: Unknown column 'deletes' in 'where clause' - Invalid query: SELECT *
FROM `user_checklist`
WHERE `checklist_id` = '8'
AND `deletes` IS NULL
ERROR - 2018-06-01 08:05:04 --> Query error: Unknown column 'deleted' in 'where clause' - Invalid query: SELECT *
FROM `user_checklist`
WHERE `checklist_id` = '8'
AND `deleted` IS NULL
ERROR - 2018-06-01 08:05:07 --> Query error: Unknown column 'deleted' in 'where clause' - Invalid query: SELECT *
FROM `user_checklist`
WHERE `checklist_id` = '8'
AND `deleted` IS NULL
ERROR - 2018-06-01 08:08:16 --> The path to the image is not correct.
ERROR - 2018-06-01 08:08:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:09:18 --> The path to the image is not correct.
ERROR - 2018-06-01 08:09:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:13:08 --> The path to the image is not correct.
ERROR - 2018-06-01 08:13:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:14:03 --> The path to the image is not correct.
ERROR - 2018-06-01 08:14:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:14:06 --> The path to the image is not correct.
ERROR - 2018-06-01 08:14:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:14:07 --> The path to the image is not correct.
ERROR - 2018-06-01 08:14:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:17:43 --> The path to the image is not correct.
ERROR - 2018-06-01 08:17:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:17:54 --> The path to the image is not correct.
ERROR - 2018-06-01 08:17:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:18:06 --> The path to the image is not correct.
ERROR - 2018-06-01 08:18:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 08:51:05 --> The path to the image is not correct.
ERROR - 2018-06-01 08:51:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 09:31:22 --> The path to the image is not correct.
ERROR - 2018-06-01 09:31:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 09:31:25 --> The path to the image is not correct.
ERROR - 2018-06-01 09:31:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 09:31:51 --> The path to the image is not correct.
ERROR - 2018-06-01 09:31:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 09:31:52 --> The path to the image is not correct.
ERROR - 2018-06-01 09:31:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 09:31:52 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-06-01 09:31:52 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-06-01 09:31:52 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-06-01 09:31:52 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-06-01 09:31:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-06-01 09:31:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-06-01 09:31:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-06-01 09:31:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-06-01 09:31:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-06-01 09:31:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-06-01 09:31:52 --> The path to the image is not correct.
ERROR - 2018-06-01 09:31:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-06-01 09:32:04 --> The path to the image is not correct.
ERROR - 2018-06-01 09:32:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 09:32:05 --> The path to the image is not correct.
ERROR - 2018-06-01 09:32:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 10:55:14 --> The path to the image is not correct.
ERROR - 2018-06-01 10:55:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 10:59:56 --> The path to the image is not correct.
ERROR - 2018-06-01 10:59:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:00:04 --> The path to the image is not correct.
ERROR - 2018-06-01 11:00:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:00:24 --> The path to the image is not correct.
ERROR - 2018-06-01 11:00:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:00:35 --> The path to the image is not correct.
ERROR - 2018-06-01 11:00:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:10:02 --> The path to the image is not correct.
ERROR - 2018-06-01 11:10:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:10:33 --> The path to the image is not correct.
ERROR - 2018-06-01 11:10:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:10:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:10:46 --> The path to the image is not correct.
ERROR - 2018-06-01 11:10:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:10:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:10:52 --> The path to the image is not correct.
ERROR - 2018-06-01 11:10:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:10:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:10:56 --> The path to the image is not correct.
ERROR - 2018-06-01 11:10:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 174
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 174
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 177
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 177
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 180
ERROR - 2018-06-01 11:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 180
ERROR - 2018-06-01 11:12:34 --> The path to the image is not correct.
ERROR - 2018-06-01 11:12:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:12:47 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:12:47 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:12:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:12:47 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:12:47 --> The path to the image is not correct.
ERROR - 2018-06-01 11:12:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:13:31 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:31 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:31 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:31 --> The path to the image is not correct.
ERROR - 2018-06-01 11:13:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:13:42 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:42 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:42 --> The path to the image is not correct.
ERROR - 2018-06-01 11:13:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:13:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:13:50 --> The path to the image is not correct.
ERROR - 2018-06-01 11:13:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 171
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 172
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 173
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 176
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:13:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 179
ERROR - 2018-06-01 11:13:51 --> The path to the image is not correct.
ERROR - 2018-06-01 11:13:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:14:09 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:14:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 223
ERROR - 2018-06-01 11:14:09 --> Severity: Notice --> Undefined variable: count_items D:\xampp\htdocs\project-transport\application\models\Report_model.php 219
ERROR - 2018-06-01 11:14:09 --> The path to the image is not correct.
ERROR - 2018-06-01 11:14:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:17:50 --> The path to the image is not correct.
ERROR - 2018-06-01 11:17:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:18:02 --> The path to the image is not correct.
ERROR - 2018-06-01 11:18:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:18:30 --> The path to the image is not correct.
ERROR - 2018-06-01 11:18:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:18:39 --> The path to the image is not correct.
ERROR - 2018-06-01 11:18:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:18:45 --> The path to the image is not correct.
ERROR - 2018-06-01 11:18:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:19:43 --> The path to the image is not correct.
ERROR - 2018-06-01 11:19:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:19:47 --> The path to the image is not correct.
ERROR - 2018-06-01 11:19:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:19:47 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-06-01 11:19:47 --> The provided image is not valid.
ERROR - 2018-06-01 11:19:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:19:59 --> The path to the image is not correct.
ERROR - 2018-06-01 11:19:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:20:01 --> The path to the image is not correct.
ERROR - 2018-06-01 11:20:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:20:01 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-06-01 11:20:01 --> The provided image is not valid.
ERROR - 2018-06-01 11:20:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:20:34 --> The path to the image is not correct.
ERROR - 2018-06-01 11:20:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:20:35 --> The path to the image is not correct.
ERROR - 2018-06-01 11:20:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:21:14 --> The path to the image is not correct.
ERROR - 2018-06-01 11:21:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:21:42 --> 404 Page Not Found: app/Report/index
ERROR - 2018-06-01 11:22:38 --> The path to the image is not correct.
ERROR - 2018-06-01 11:22:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:23:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:23:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:25:26 --> 404 Page Not Found: app/Report/index
ERROR - 2018-06-01 11:27:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:27:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:27:12 --> The path to the image is not correct.
ERROR - 2018-06-01 11:27:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:27:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:27:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:27:18 --> The path to the image is not correct.
ERROR - 2018-06-01 11:27:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:27:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:27:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:44 --> The path to the image is not correct.
ERROR - 2018-06-01 11:28:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:28:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:45 --> The path to the image is not correct.
ERROR - 2018-06-01 11:28:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:28:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:46 --> The path to the image is not correct.
ERROR - 2018-06-01 11:28:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:28:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:46 --> The path to the image is not correct.
ERROR - 2018-06-01 11:28:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:28:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:46 --> The path to the image is not correct.
ERROR - 2018-06-01 11:28:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:28:46 --> The path to the image is not correct.
ERROR - 2018-06-01 11:28:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:28:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:59 --> The path to the image is not correct.
ERROR - 2018-06-01 11:28:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:28:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:28:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:00 --> The path to the image is not correct.
ERROR - 2018-06-01 11:29:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:00 --> The path to the image is not correct.
ERROR - 2018-06-01 11:29:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:00 --> The path to the image is not correct.
ERROR - 2018-06-01 11:29:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:00 --> The path to the image is not correct.
ERROR - 2018-06-01 11:29:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:29:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:26 --> The path to the image is not correct.
ERROR - 2018-06-01 11:29:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:29:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:34 --> The path to the image is not correct.
ERROR - 2018-06-01 11:29:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:29:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:51 --> The path to the image is not correct.
ERROR - 2018-06-01 11:29:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-01 11:29:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-01 11:29:51 --> 404 Page Not Found: Public/lib

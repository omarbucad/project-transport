<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-23 05:06:27 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-23 05:06:27 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-23 05:06:27 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-23 05:06:27 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-23 05:06:27 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-23 05:08:13 --> The path to the image is not correct.
ERROR - 2018-07-23 05:08:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:08:24 --> The path to the image is not correct.
ERROR - 2018-07-23 05:08:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:08:37 --> The path to the image is not correct.
ERROR - 2018-07-23 05:08:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:08:44 --> The path to the image is not correct.
ERROR - 2018-07-23 05:08:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:08:49 --> The path to the image is not correct.
ERROR - 2018-07-23 05:08:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:08:56 --> The path to the image is not correct.
ERROR - 2018-07-23 05:08:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:08:57 --> The path to the image is not correct.
ERROR - 2018-07-23 05:08:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:09:09 --> The path to the image is not correct.
ERROR - 2018-07-23 05:09:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:09:40 --> The path to the image is not correct.
ERROR - 2018-07-23 05:09:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:10:12 --> The path to the image is not correct.
ERROR - 2018-07-23 05:10:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:10:22 --> The path to the image is not correct.
ERROR - 2018-07-23 05:10:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:10:27 --> The path to the image is not correct.
ERROR - 2018-07-23 05:10:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:11:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-23 05:11:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-23 05:11:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-23 05:17:00 --> The path to the image is not correct.
ERROR - 2018-07-23 05:17:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:17:00 --> The path to the image is not correct.
ERROR - 2018-07-23 05:17:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:17:03 --> The path to the image is not correct.
ERROR - 2018-07-23 05:17:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:18:47 --> Severity: Error --> Call to undefined method stdClass::no_accounts() D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 336
ERROR - 2018-07-23 05:18:55 --> The path to the image is not correct.
ERROR - 2018-07-23 05:18:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:19:14 --> The path to the image is not correct.
ERROR - 2018-07-23 05:19:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:19:20 --> The path to the image is not correct.
ERROR - 2018-07-23 05:19:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:20:22 --> The path to the image is not correct.
ERROR - 2018-07-23 05:20:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:23:14 --> The path to the image is not correct.
ERROR - 2018-07-23 05:23:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:23:18 --> The path to the image is not correct.
ERROR - 2018-07-23 05:23:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:23:18 --> The path to the image is not correct.
ERROR - 2018-07-23 05:23:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:23:30 --> The path to the image is not correct.
ERROR - 2018-07-23 05:23:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:24:15 --> Severity: Error --> Call to undefined method stdClass::no_accounts() D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 336
ERROR - 2018-07-23 05:24:21 --> The path to the image is not correct.
ERROR - 2018-07-23 05:24:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:24:28 --> The path to the image is not correct.
ERROR - 2018-07-23 05:24:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:24:28 --> The path to the image is not correct.
ERROR - 2018-07-23 05:24:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:24:31 --> The path to the image is not correct.
ERROR - 2018-07-23 05:24:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:24:31 --> The path to the image is not correct.
ERROR - 2018-07-23 05:24:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:24:41 --> The path to the image is not correct.
ERROR - 2018-07-23 05:24:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:24:41 --> The path to the image is not correct.
ERROR - 2018-07-23 05:24:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:35:44 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-23 05:35:44 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-23 05:35:44 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/07): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-07-23 05:35:44 --> The provided image is not valid.
ERROR - 2018-07-23 05:35:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:35:48 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-23 05:35:48 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-23 05:35:48 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-23 05:35:48 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-23 05:35:48 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-23 05:35:48 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-07-23 05:35:48 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/07): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-07-23 05:35:48 --> The provided image is not valid.
ERROR - 2018-07-23 05:35:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:35:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-07-23 05:35:51 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-23 05:35:51 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-23 05:35:51 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-23 05:35:51 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-23 05:35:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-23 05:35:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-23 05:35:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-23 05:35:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-23 05:35:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-07-23 05:35:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-07-23 05:35:51 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/07): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-07-23 05:35:51 --> The provided image is not valid.
ERROR - 2018-07-23 05:35:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-07-23 05:36:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-23 05:36:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-23 05:36:00 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/07): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-07-23 05:36:00 --> The provided image is not valid.
ERROR - 2018-07-23 05:36:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:57:21 --> The path to the image is not correct.
ERROR - 2018-07-23 05:57:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:57:30 --> The path to the image is not correct.
ERROR - 2018-07-23 05:57:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 05:57:43 --> The path to the image is not correct.
ERROR - 2018-07-23 05:57:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:00:57 --> The path to the image is not correct.
ERROR - 2018-07-23 06:00:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:01:08 --> The path to the image is not correct.
ERROR - 2018-07-23 06:01:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:01:08 --> The path to the image is not correct.
ERROR - 2018-07-23 06:01:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:01:13 --> The path to the image is not correct.
ERROR - 2018-07-23 06:01:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:01:13 --> The path to the image is not correct.
ERROR - 2018-07-23 06:01:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:01:30 --> The path to the image is not correct.
ERROR - 2018-07-23 06:01:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:01:30 --> The path to the image is not correct.
ERROR - 2018-07-23 06:01:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:01:34 --> The path to the image is not correct.
ERROR - 2018-07-23 06:01:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:02:02 --> The path to the image is not correct.
ERROR - 2018-07-23 06:02:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:02:02 --> The path to the image is not correct.
ERROR - 2018-07-23 06:02:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:02:08 --> The path to the image is not correct.
ERROR - 2018-07-23 06:02:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:02:10 --> The path to the image is not correct.
ERROR - 2018-07-23 06:02:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:02:10 --> The path to the image is not correct.
ERROR - 2018-07-23 06:02:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:02:18 --> The path to the image is not correct.
ERROR - 2018-07-23 06:02:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:02:23 --> The path to the image is not correct.
ERROR - 2018-07-23 06:02:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:02:23 --> The path to the image is not correct.
ERROR - 2018-07-23 06:02:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:02:26 --> The path to the image is not correct.
ERROR - 2018-07-23 06:02:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:02:31 --> 404 Page Not Found: app/Users/index
ERROR - 2018-07-23 06:02:40 --> The path to the image is not correct.
ERROR - 2018-07-23 06:02:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:03:10 --> Severity: Error --> Call to undefined method stdClass::no_accounts() D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 336
ERROR - 2018-07-23 06:04:31 --> The path to the image is not correct.
ERROR - 2018-07-23 06:04:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:04:50 --> The path to the image is not correct.
ERROR - 2018-07-23 06:04:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:04:50 --> The path to the image is not correct.
ERROR - 2018-07-23 06:04:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:04:54 --> The path to the image is not correct.
ERROR - 2018-07-23 06:04:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:04:59 --> The path to the image is not correct.
ERROR - 2018-07-23 06:04:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:05:11 --> The path to the image is not correct.
ERROR - 2018-07-23 06:05:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:05:31 --> The path to the image is not correct.
ERROR - 2018-07-23 06:05:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:05:34 --> The path to the image is not correct.
ERROR - 2018-07-23 06:05:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:05:38 --> The path to the image is not correct.
ERROR - 2018-07-23 06:05:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:05:38 --> The path to the image is not correct.
ERROR - 2018-07-23 06:05:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:05:40 --> The path to the image is not correct.
ERROR - 2018-07-23 06:05:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:05:40 --> The path to the image is not correct.
ERROR - 2018-07-23 06:05:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:05:43 --> The path to the image is not correct.
ERROR - 2018-07-23 06:05:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:06:50 --> Severity: Error --> Call to undefined method stdClass::no_accounts() D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 336
ERROR - 2018-07-23 06:07:54 --> Query error: Table 'project_transport.accounts' doesn't exist - Invalid query: SELECT *
FROM `accounts`
WHERE `store_id` = 'Trial'
ERROR - 2018-07-23 06:09:05 --> Query error: Table 'project_transport.accounts' doesn't exist - Invalid query: SELECT *
FROM `accounts`
WHERE `store_id` = '4'
ERROR - 2018-07-23 06:10:11 --> Query error: Table 'project_transport.accounts' doesn't exist - Invalid query: SELECT *
FROM `accounts`
WHERE `store_id` = '1'
ERROR - 2018-07-23 06:10:15 --> Query error: Table 'project_transport.accounts' doesn't exist - Invalid query: SELECT *
FROM `accounts`
WHERE `store_id` = '1'
ERROR - 2018-07-23 06:11:20 --> The path to the image is not correct.
ERROR - 2018-07-23 06:11:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:11:22 --> The path to the image is not correct.
ERROR - 2018-07-23 06:11:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:11:23 --> The path to the image is not correct.
ERROR - 2018-07-23 06:11:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:11:26 --> The path to the image is not correct.
ERROR - 2018-07-23 06:11:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:15:32 --> The path to the image is not correct.
ERROR - 2018-07-23 06:15:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:15:58 --> The path to the image is not correct.
ERROR - 2018-07-23 06:15:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:15:58 --> The path to the image is not correct.
ERROR - 2018-07-23 06:15:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:16:45 --> The path to the image is not correct.
ERROR - 2018-07-23 06:16:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:18:04 --> The path to the image is not correct.
ERROR - 2018-07-23 06:18:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-23 06:18:05 --> The path to the image is not correct.
ERROR - 2018-07-23 06:18:05 --> Your server does not support the GD function required to process this type of image.

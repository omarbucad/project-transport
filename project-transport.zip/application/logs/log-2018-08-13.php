<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-13 08:11:33 --> The provided image is not valid.
ERROR - 2018-08-13 08:11:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:11:33 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_205_1281_1_1533883622.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:12:01 --> The provided image is not valid.
ERROR - 2018-08-13 08:12:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:12:01 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_205_1281_1_1533883622.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:12:04 --> The provided image is not valid.
ERROR - 2018-08-13 08:12:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:12:04 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_205_1281_1_1533883622.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:12:04 --> The provided image is not valid.
ERROR - 2018-08-13 08:12:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:12:04 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_205_1281_2_1533883622.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:12:05 --> The provided image is not valid.
ERROR - 2018-08-13 08:12:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:12:05 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_205_1281_1_1533883622.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:12:05 --> The provided image is not valid.
ERROR - 2018-08-13 08:12:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:12:05 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_205_1281_2_1533883622.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:12:59 --> The provided image is not valid.
ERROR - 2018-08-13 08:12:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:12:59 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_205_1281_1_1533883622.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:15 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:15 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:15 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_1_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:15 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:15 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:16 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_2_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:16 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:16 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:16 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_3_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:16 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:16 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:16 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_1_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:25 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:25 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:25 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_1_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:26 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:26 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:26 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_2_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:26 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:26 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:26 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_3_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:26 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:26 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:26 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_1_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:27 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:27 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:27 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_2_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:27 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:27 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:27 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_3_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:38 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:38 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:38 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1263_1_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:55 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:55 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:55 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:13:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:55 --> The provided image is not valid.
ERROR - 2018-08-13 08:13:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:13:55 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1263_1_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:13:55 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_194_1262_3_1533879640.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:14:49 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:14:49 --> The provided image is not valid.
ERROR - 2018-08-13 08:14:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:14:49 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_195_1267_1_1533879720.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:14:57 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:14:57 --> The provided image is not valid.
ERROR - 2018-08-13 08:14:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:14:57 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_195_1267_2_1533879720.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:15:05 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-13 08:15:05 --> The provided image is not valid.
ERROR - 2018-08-13 08:15:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:15:05 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_195_1267_3_1533879720.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-13 08:26:03 --> The path to the image is not correct.
ERROR - 2018-08-13 08:26:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:27:07 --> The path to the image is not correct.
ERROR - 2018-08-13 08:27:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:28:25 --> The path to the image is not correct.
ERROR - 2018-08-13 08:28:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:28:27 --> The path to the image is not correct.
ERROR - 2018-08-13 08:28:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:28:27 --> The path to the image is not correct.
ERROR - 2018-08-13 08:28:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:29:15 --> The path to the image is not correct.
ERROR - 2018-08-13 08:29:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:29:24 --> The path to the image is not correct.
ERROR - 2018-08-13 08:29:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:29:28 --> The path to the image is not correct.
ERROR - 2018-08-13 08:29:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:29:31 --> The path to the image is not correct.
ERROR - 2018-08-13 08:29:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:30:21 --> The path to the image is not correct.
ERROR - 2018-08-13 08:30:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:30:21 --> The path to the image is not correct.
ERROR - 2018-08-13 08:30:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:30:31 --> The path to the image is not correct.
ERROR - 2018-08-13 08:30:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:30:47 --> The path to the image is not correct.
ERROR - 2018-08-13 08:30:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:33:02 --> The path to the image is not correct.
ERROR - 2018-08-13 08:33:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:33:07 --> The path to the image is not correct.
ERROR - 2018-08-13 08:33:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:35:28 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\project-transport\application\controllers\apimobile\Report.php 63
ERROR - 2018-08-13 08:53:33 --> The path to the image is not correct.
ERROR - 2018-08-13 08:53:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:53:40 --> The path to the image is not correct.
ERROR - 2018-08-13 08:53:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:53:46 --> The path to the image is not correct.
ERROR - 2018-08-13 08:53:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:53:46 --> The path to the image is not correct.
ERROR - 2018-08-13 08:53:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:54:05 --> The path to the image is not correct.
ERROR - 2018-08-13 08:54:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:54:07 --> The path to the image is not correct.
ERROR - 2018-08-13 08:54:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:54:07 --> The path to the image is not correct.
ERROR - 2018-08-13 08:54:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:54:11 --> The path to the image is not correct.
ERROR - 2018-08-13 08:54:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:54:11 --> The path to the image is not correct.
ERROR - 2018-08-13 08:54:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:54:13 --> The path to the image is not correct.
ERROR - 2018-08-13 08:54:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:54:47 --> The path to the image is not correct.
ERROR - 2018-08-13 08:54:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:54:47 --> The path to the image is not correct.
ERROR - 2018-08-13 08:54:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 08:58:39 --> The path to the image is not correct.
ERROR - 2018-08-13 08:58:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:07:45 --> The path to the image is not correct.
ERROR - 2018-08-13 09:07:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:07:45 --> The path to the image is not correct.
ERROR - 2018-08-13 09:07:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:07:47 --> The path to the image is not correct.
ERROR - 2018-08-13 09:07:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:07:49 --> The path to the image is not correct.
ERROR - 2018-08-13 09:07:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:07:56 --> The path to the image is not correct.
ERROR - 2018-08-13 09:07:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:08:58 --> The path to the image is not correct.
ERROR - 2018-08-13 09:08:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:09:01 --> The path to the image is not correct.
ERROR - 2018-08-13 09:09:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:09:01 --> The path to the image is not correct.
ERROR - 2018-08-13 09:09:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:09:03 --> The path to the image is not correct.
ERROR - 2018-08-13 09:09:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:10:07 --> The path to the image is not correct.
ERROR - 2018-08-13 09:10:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:11:14 --> The path to the image is not correct.
ERROR - 2018-08-13 09:11:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:11:32 --> The path to the image is not correct.
ERROR - 2018-08-13 09:11:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:11:32 --> The path to the image is not correct.
ERROR - 2018-08-13 09:11:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:11:56 --> The path to the image is not correct.
ERROR - 2018-08-13 09:11:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:12:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:12:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:13:43 --> The path to the image is not correct.
ERROR - 2018-08-13 09:13:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:13:43 --> The path to the image is not correct.
ERROR - 2018-08-13 09:13:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:13:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:13:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:13:44 --> The path to the image is not correct.
ERROR - 2018-08-13 09:13:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:13:46 --> Severity: Notice --> Undefined variable: report_id D:\xampp\htdocs\project-transport\application\controllers\app\Accounts.php 127
ERROR - 2018-08-13 09:13:46 --> Severity: Notice --> Undefined property: Accounts::$reports D:\xampp\htdocs\project-transport\application\controllers\app\Accounts.php 129
ERROR - 2018-08-13 09:13:46 --> Severity: Error --> Call to a member function delete_report() on null D:\xampp\htdocs\project-transport\application\controllers\app\Accounts.php 129
ERROR - 2018-08-13 09:13:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:13:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:15:28 --> The path to the image is not correct.
ERROR - 2018-08-13 09:15:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:15:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:15:28 --> The path to the image is not correct.
ERROR - 2018-08-13 09:15:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:15:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:16:31 --> The path to the image is not correct.
ERROR - 2018-08-13 09:16:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:16:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:16:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:16:32 --> The path to the image is not correct.
ERROR - 2018-08-13 09:16:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:16:34 --> The path to the image is not correct.
ERROR - 2018-08-13 09:16:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:16:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:16:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:16:34 --> The path to the image is not correct.
ERROR - 2018-08-13 09:16:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:17:34 --> The path to the image is not correct.
ERROR - 2018-08-13 09:17:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:17:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:17:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:17:34 --> The path to the image is not correct.
ERROR - 2018-08-13 09:17:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:17:34 --> The path to the image is not correct.
ERROR - 2018-08-13 09:17:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:18:44 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 221
ERROR - 2018-08-13 09:18:56 --> The path to the image is not correct.
ERROR - 2018-08-13 09:18:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:18:56 --> The path to the image is not correct.
ERROR - 2018-08-13 09:18:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:18:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:18:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:18:56 --> The path to the image is not correct.
ERROR - 2018-08-13 09:18:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:19:00 --> The path to the image is not correct.
ERROR - 2018-08-13 09:19:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:19:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:19:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:20:22 --> The path to the image is not correct.
ERROR - 2018-08-13 09:20:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:20:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:20:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:20:22 --> The path to the image is not correct.
ERROR - 2018-08-13 09:20:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:20:31 --> The path to the image is not correct.
ERROR - 2018-08-13 09:20:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:20:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:20:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:11 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:13 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:19 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:19 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:42 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:42 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:45 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:45 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:50 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:50 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:54 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:54 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:55 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:55 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:56 --> The path to the image is not correct.
ERROR - 2018-08-13 09:21:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:21:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:21:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:22:30 --> Severity: Notice --> Undefined index: total_rows D:\xampp\htdocs\project-transport\application\views\backend\page\users\view.php 125
ERROR - 2018-08-13 09:22:30 --> Severity: Notice --> Undefined variable: links D:\xampp\htdocs\project-transport\application\views\backend\page\users\view.php 129
ERROR - 2018-08-13 09:22:30 --> The path to the image is not correct.
ERROR - 2018-08-13 09:22:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:22:30 --> The path to the image is not correct.
ERROR - 2018-08-13 09:22:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:22:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:22:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:22:43 --> The path to the image is not correct.
ERROR - 2018-08-13 09:22:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:22:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:22:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:22:43 --> The path to the image is not correct.
ERROR - 2018-08-13 09:22:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:23:54 --> The path to the image is not correct.
ERROR - 2018-08-13 09:23:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:23:54 --> The path to the image is not correct.
ERROR - 2018-08-13 09:23:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-13 09:23:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-13 09:23:54 --> 404 Page Not Found: Public/lib

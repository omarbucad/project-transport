<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-14 03:45:44 --> Unable to load the requested class: Paypal_adaptive
ERROR - 2018-06-14 03:45:45 --> Unable to load the requested class: Paypal_adaptive
ERROR - 2018-06-14 03:45:48 --> Unable to load the requested class: Paypal_adaptive
ERROR - 2018-06-14 03:46:02 --> Unable to load the requested class: Paypal_adaptive
ERROR - 2018-06-14 03:46:06 --> Unable to load the requested class: Paypal_adaptive
ERROR - 2018-06-14 03:46:09 --> 404 Page Not Found: L/index
ERROR - 2018-06-14 03:46:14 --> Unable to load the requested class: Paypal_adaptive
ERROR - 2018-06-14 03:46:36 --> Unable to load the requested class: Paypal_adaptive
ERROR - 2018-06-14 03:46:39 --> Unable to load the requested class: Paypal_adaptive
ERROR - 2018-06-14 03:46:49 --> Unable to load the requested class: Paypal_adaptive
ERROR - 2018-06-14 03:47:20 --> The path to the image is not correct.
ERROR - 2018-06-14 03:47:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 03:47:29 --> The path to the image is not correct.
ERROR - 2018-06-14 03:47:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 03:50:03 --> The path to the image is not correct.
ERROR - 2018-06-14 03:50:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 03:50:06 --> The path to the image is not correct.
ERROR - 2018-06-14 03:50:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 03:51:40 --> The path to the image is not correct.
ERROR - 2018-06-14 03:51:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 03:51:40 --> The path to the image is not correct.
ERROR - 2018-06-14 03:51:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 03:52:29 --> The path to the image is not correct.
ERROR - 2018-06-14 03:52:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 03:52:33 --> The path to the image is not correct.
ERROR - 2018-06-14 03:52:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 03:59:22 --> The path to the image is not correct.
ERROR - 2018-06-14 03:59:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:05:30 --> The path to the image is not correct.
ERROR - 2018-06-14 04:05:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:06:41 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 95
ERROR - 2018-06-14 04:06:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 95
ERROR - 2018-06-14 04:06:42 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 04:07:50 --> 404 Page Not Found: Dashboard/index
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 95
ERROR - 2018-06-14 04:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 95
ERROR - 2018-06-14 04:08:00 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 04:11:13 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\controllers\Login.php 18
ERROR - 2018-06-14 04:11:36 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\controllers\Login.php 18
ERROR - 2018-06-14 04:11:37 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\controllers\Login.php 18
ERROR - 2018-06-14 04:11:38 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:11:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 95
ERROR - 2018-06-14 04:11:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 95
ERROR - 2018-06-14 04:11:42 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\controllers\Login.php 18
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:12:51 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:12:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:12:52 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:12:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:12:52 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 95
ERROR - 2018-06-14 04:12:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 95
ERROR - 2018-06-14 04:12:52 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:14:08 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:14:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:14:10 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:14:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:14:10 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:16:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:16:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:16:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:16:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:16:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:16:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 116
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 45
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 6
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 39
ERROR - 2018-06-14 04:16:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:16:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:17:32 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:17:32 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:17:32 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 110
ERROR - 2018-06-14 04:17:32 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 118
ERROR - 2018-06-14 04:17:32 --> The path to the image is not correct.
ERROR - 2018-06-14 04:17:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:19:53 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:19:53 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:19:53 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 110
ERROR - 2018-06-14 04:19:53 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 118
ERROR - 2018-06-14 04:19:53 --> The path to the image is not correct.
ERROR - 2018-06-14 04:19:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 110
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 118
ERROR - 2018-06-14 04:20:15 --> The path to the image is not correct.
ERROR - 2018-06-14 04:20:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 110
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 118
ERROR - 2018-06-14 04:20:15 --> The path to the image is not correct.
ERROR - 2018-06-14 04:20:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 110
ERROR - 2018-06-14 04:20:15 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 118
ERROR - 2018-06-14 04:20:15 --> The path to the image is not correct.
ERROR - 2018-06-14 04:20:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:20:16 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:20:16 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 98
ERROR - 2018-06-14 04:20:16 --> Severity: Notice --> Undefined variable: trucks D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 110
ERROR - 2018-06-14 04:20:16 --> Severity: Notice --> Undefined variable: drivers D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 118
ERROR - 2018-06-14 04:20:16 --> The path to the image is not correct.
ERROR - 2018-06-14 04:20:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:20:31 --> The path to the image is not correct.
ERROR - 2018-06-14 04:20:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:27:10 --> The path to the image is not correct.
ERROR - 2018-06-14 04:27:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:27:12 --> The path to the image is not correct.
ERROR - 2018-06-14 04:27:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:27:28 --> The path to the image is not correct.
ERROR - 2018-06-14 04:27:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:27:29 --> The path to the image is not correct.
ERROR - 2018-06-14 04:27:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:30:40 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 92
ERROR - 2018-06-14 04:30:40 --> The path to the image is not correct.
ERROR - 2018-06-14 04:30:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:31:02 --> The path to the image is not correct.
ERROR - 2018-06-14 04:31:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:33:40 --> The path to the image is not correct.
ERROR - 2018-06-14 04:33:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:34:19 --> The path to the image is not correct.
ERROR - 2018-06-14 04:34:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:34:27 --> The path to the image is not correct.
ERROR - 2018-06-14 04:34:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:34:47 --> The path to the image is not correct.
ERROR - 2018-06-14 04:34:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:38:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:38:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:38:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:38:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:38:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:38:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:38:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 19
ERROR - 2018-06-14 04:38:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 31
ERROR - 2018-06-14 04:38:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 73
ERROR - 2018-06-14 04:38:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\dashboard.php 95
ERROR - 2018-06-14 04:38:41 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 04:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:39:19 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 04:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:39:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:39:20 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:39:20 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:39:20 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:39:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:39:20 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 04:39:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Dashboard.php 19
ERROR - 2018-06-14 04:39:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Dashboard.php 19
ERROR - 2018-06-14 04:39:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Dashboard.php 19
ERROR - 2018-06-14 04:39:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Dashboard.php 19
ERROR - 2018-06-14 04:39:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Dashboard.php 19
ERROR - 2018-06-14 04:39:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Dashboard.php 19
ERROR - 2018-06-14 04:39:58 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\controllers\admin\Dashboard.php 19
ERROR - 2018-06-14 04:40:46 --> The path to the image is not correct.
ERROR - 2018-06-14 04:40:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:40:53 --> The path to the image is not correct.
ERROR - 2018-06-14 04:40:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:40:58 --> 404 Page Not Found: admin/Accounts/index
ERROR - 2018-06-14 04:40:59 --> 404 Page Not Found: admin/Invoice/index
ERROR - 2018-06-14 04:42:43 --> The path to the image is not correct.
ERROR - 2018-06-14 04:42:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 6
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 6
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 6
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 6
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 24
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 37
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 37
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 49
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 49
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 28
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 28
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 19
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 19
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 31
ERROR - 2018-06-14 04:42:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 31
ERROR - 2018-06-14 04:42:44 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 04:54:56 --> The path to the image is not correct.
ERROR - 2018-06-14 04:54:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:54:56 --> The path to the image is not correct.
ERROR - 2018-06-14 04:54:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 04:55:15 --> 404 Page Not Found: admin/Invoice/index
ERROR - 2018-06-14 05:05:24 --> The path to the image is not correct.
ERROR - 2018-06-14 05:05:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:05:24 --> The path to the image is not correct.
ERROR - 2018-06-14 05:05:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:05:54 --> Severity: Notice --> Undefined variable: count D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 9
ERROR - 2018-06-14 05:05:54 --> Severity: Error --> Unsupported operand types D:\xampp\htdocs\project-transport\system\libraries\Pagination.php 412
ERROR - 2018-06-14 05:06:10 --> The path to the image is not correct.
ERROR - 2018-06-14 05:06:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:06:10 --> The path to the image is not correct.
ERROR - 2018-06-14 05:06:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:06:44 --> The path to the image is not correct.
ERROR - 2018-06-14 05:06:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:06:46 --> The path to the image is not correct.
ERROR - 2018-06-14 05:06:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:06:46 --> The path to the image is not correct.
ERROR - 2018-06-14 05:06:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:06:46 --> The path to the image is not correct.
ERROR - 2018-06-14 05:06:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:06:46 --> The path to the image is not correct.
ERROR - 2018-06-14 05:06:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:12:50 --> The path to the image is not correct.
ERROR - 2018-06-14 05:12:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:12:51 --> The path to the image is not correct.
ERROR - 2018-06-14 05:12:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:12:53 --> The path to the image is not correct.
ERROR - 2018-06-14 05:12:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:13:08 --> The path to the image is not correct.
ERROR - 2018-06-14 05:13:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 13
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 41
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 54
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 66
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 28
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-14 05:15:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-14 05:15:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 19
ERROR - 2018-06-14 05:15:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 31
ERROR - 2018-06-14 05:15:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 73
ERROR - 2018-06-14 05:15:01 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-14 05:15:01 --> The path to the image is not correct.
ERROR - 2018-06-14 05:15:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:15:12 --> The path to the image is not correct.
ERROR - 2018-06-14 05:15:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:15:18 --> The path to the image is not correct.
ERROR - 2018-06-14 05:15:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:15:19 --> The path to the image is not correct.
ERROR - 2018-06-14 05:15:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:18:14 --> The path to the image is not correct.
ERROR - 2018-06-14 05:18:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:18:15 --> The path to the image is not correct.
ERROR - 2018-06-14 05:18:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:18:21 --> The path to the image is not correct.
ERROR - 2018-06-14 05:18:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:18:25 --> 404 Page Not Found: admin/Invoice/index
ERROR - 2018-06-14 05:18:27 --> The path to the image is not correct.
ERROR - 2018-06-14 05:18:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:22:35 --> The path to the image is not correct.
ERROR - 2018-06-14 05:22:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:22:49 --> The path to the image is not correct.
ERROR - 2018-06-14 05:22:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:23:22 --> The path to the image is not correct.
ERROR - 2018-06-14 05:23:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:23:47 --> The path to the image is not correct.
ERROR - 2018-06-14 05:23:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:23:48 --> The path to the image is not correct.
ERROR - 2018-06-14 05:23:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:24:08 --> The path to the image is not correct.
ERROR - 2018-06-14 05:24:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:24:40 --> The path to the image is not correct.
ERROR - 2018-06-14 05:24:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:26:18 --> The path to the image is not correct.
ERROR - 2018-06-14 05:26:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:26:37 --> The path to the image is not correct.
ERROR - 2018-06-14 05:26:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:27:01 --> The path to the image is not correct.
ERROR - 2018-06-14 05:27:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:27:44 --> The path to the image is not correct.
ERROR - 2018-06-14 05:27:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:27:55 --> The path to the image is not correct.
ERROR - 2018-06-14 05:27:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:28:13 --> The path to the image is not correct.
ERROR - 2018-06-14 05:28:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:28:22 --> The path to the image is not correct.
ERROR - 2018-06-14 05:28:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:28:52 --> The path to the image is not correct.
ERROR - 2018-06-14 05:28:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:45:24 --> The path to the image is not correct.
ERROR - 2018-06-14 05:45:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:45:41 --> The path to the image is not correct.
ERROR - 2018-06-14 05:45:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:45:44 --> The path to the image is not correct.
ERROR - 2018-06-14 05:45:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 05:45:45 --> The path to the image is not correct.
ERROR - 2018-06-14 05:45:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 09:40:13 --> The path to the image is not correct.
ERROR - 2018-06-14 09:40:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-14 09:40:15 --> The path to the image is not correct.
ERROR - 2018-06-14 09:40:15 --> Your server does not support the GD function required to process this type of image.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-15 03:25:43 --> The path to the image is not correct.
ERROR - 2018-08-15 03:25:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:25:50 --> The path to the image is not correct.
ERROR - 2018-08-15 03:25:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:26:45 --> The path to the image is not correct.
ERROR - 2018-08-15 03:26:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:27:26 --> The path to the image is not correct.
ERROR - 2018-08-15 03:27:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:27:46 --> The path to the image is not correct.
ERROR - 2018-08-15 03:27:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:36:22 --> The path to the image is not correct.
ERROR - 2018-08-15 03:36:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:36:43 --> The path to the image is not correct.
ERROR - 2018-08-15 03:36:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:36:43 --> The path to the image is not correct.
ERROR - 2018-08-15 03:36:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:41:48 --> The path to the image is not correct.
ERROR - 2018-08-15 03:41:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:41:48 --> The path to the image is not correct.
ERROR - 2018-08-15 03:41:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:41:53 --> The path to the image is not correct.
ERROR - 2018-08-15 03:41:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:42:01 --> The path to the image is not correct.
ERROR - 2018-08-15 03:42:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:42:04 --> The path to the image is not correct.
ERROR - 2018-08-15 03:42:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:42:06 --> The path to the image is not correct.
ERROR - 2018-08-15 03:42:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:42:07 --> The path to the image is not correct.
ERROR - 2018-08-15 03:42:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:42:09 --> The path to the image is not correct.
ERROR - 2018-08-15 03:42:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:42:11 --> The path to the image is not correct.
ERROR - 2018-08-15 03:42:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:42:43 --> The path to the image is not correct.
ERROR - 2018-08-15 03:42:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:42:43 --> The path to the image is not correct.
ERROR - 2018-08-15 03:42:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:42:53 --> The path to the image is not correct.
ERROR - 2018-08-15 03:42:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:42:53 --> The path to the image is not correct.
ERROR - 2018-08-15 03:42:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:43:02 --> The path to the image is not correct.
ERROR - 2018-08-15 03:43:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 03:45:30 --> The path to the image is not correct.
ERROR - 2018-08-15 03:45:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 08:04:34 --> Severity: Parsing Error --> syntax error, unexpected '$result' (T_VARIABLE) D:\xampp\htdocs\project-transport\application\models\Report_model.php 20
ERROR - 2018-08-15 08:05:34 --> Severity: Parsing Error --> syntax error, unexpected '$result' (T_VARIABLE) D:\xampp\htdocs\project-transport\application\models\Report_model.php 20
ERROR - 2018-08-15 09:00:24 --> The path to the image is not correct.
ERROR - 2018-08-15 09:00:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 09:00:28 --> The path to the image is not correct.
ERROR - 2018-08-15 09:00:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 09:01:26 --> The path to the image is not correct.
ERROR - 2018-08-15 09:01:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 09:01:45 --> The path to the image is not correct.
ERROR - 2018-08-15 09:01:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 13:31:00 --> The path to the image is not correct.
ERROR - 2018-08-15 13:31:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-15 13:31:03 --> The path to the image is not correct.
ERROR - 2018-08-15 13:31:03 --> Your server does not support the GD function required to process this type of image.

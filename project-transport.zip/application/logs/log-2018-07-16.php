<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-16 03:14:08 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 52

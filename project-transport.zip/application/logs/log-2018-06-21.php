<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-21 03:04:53 --> The path to the image is not correct.
ERROR - 2018-06-21 03:04:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:05:31 --> The path to the image is not correct.
ERROR - 2018-06-21 03:05:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:05:31 --> The path to the image is not correct.
ERROR - 2018-06-21 03:05:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:05:31 --> The path to the image is not correct.
ERROR - 2018-06-21 03:05:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:27:19 --> The path to the image is not correct.
ERROR - 2018-06-21 03:27:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:27:19 --> The path to the image is not correct.
ERROR - 2018-06-21 03:27:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:36:43 --> The path to the image is not correct.
ERROR - 2018-06-21 03:36:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:36:43 --> The path to the image is not correct.
ERROR - 2018-06-21 03:36:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:36:54 --> The path to the image is not correct.
ERROR - 2018-06-21 03:36:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:36:54 --> The path to the image is not correct.
ERROR - 2018-06-21 03:36:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:37:07 --> The path to the image is not correct.
ERROR - 2018-06-21 03:37:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:37:07 --> The path to the image is not correct.
ERROR - 2018-06-21 03:37:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:38:28 --> The path to the image is not correct.
ERROR - 2018-06-21 03:38:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:38:29 --> The path to the image is not correct.
ERROR - 2018-06-21 03:38:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:38:51 --> The path to the image is not correct.
ERROR - 2018-06-21 03:38:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:38:51 --> The path to the image is not correct.
ERROR - 2018-06-21 03:38:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:39:01 --> The path to the image is not correct.
ERROR - 2018-06-21 03:39:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:39:01 --> The path to the image is not correct.
ERROR - 2018-06-21 03:39:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:39:33 --> The path to the image is not correct.
ERROR - 2018-06-21 03:39:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:39:33 --> The path to the image is not correct.
ERROR - 2018-06-21 03:39:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:39:39 --> The path to the image is not correct.
ERROR - 2018-06-21 03:39:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:39:39 --> The path to the image is not correct.
ERROR - 2018-06-21 03:39:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:39:49 --> The path to the image is not correct.
ERROR - 2018-06-21 03:39:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:39:49 --> The path to the image is not correct.
ERROR - 2018-06-21 03:39:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:41:15 --> The path to the image is not correct.
ERROR - 2018-06-21 03:41:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:41:15 --> The path to the image is not correct.
ERROR - 2018-06-21 03:41:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:42:03 --> The path to the image is not correct.
ERROR - 2018-06-21 03:42:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:42:03 --> The path to the image is not correct.
ERROR - 2018-06-21 03:42:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:42:24 --> The path to the image is not correct.
ERROR - 2018-06-21 03:42:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:42:24 --> The path to the image is not correct.
ERROR - 2018-06-21 03:42:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:42:46 --> The path to the image is not correct.
ERROR - 2018-06-21 03:42:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:42:46 --> The path to the image is not correct.
ERROR - 2018-06-21 03:42:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:43:03 --> The path to the image is not correct.
ERROR - 2018-06-21 03:43:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:43:03 --> The path to the image is not correct.
ERROR - 2018-06-21 03:43:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:43:13 --> The path to the image is not correct.
ERROR - 2018-06-21 03:43:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:43:13 --> The path to the image is not correct.
ERROR - 2018-06-21 03:43:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:43:14 --> The path to the image is not correct.
ERROR - 2018-06-21 03:43:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:43:14 --> The path to the image is not correct.
ERROR - 2018-06-21 03:43:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:43:53 --> The path to the image is not correct.
ERROR - 2018-06-21 03:43:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:43:53 --> The path to the image is not correct.
ERROR - 2018-06-21 03:43:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:44:05 --> The path to the image is not correct.
ERROR - 2018-06-21 03:44:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:44:05 --> The path to the image is not correct.
ERROR - 2018-06-21 03:44:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:44:14 --> The path to the image is not correct.
ERROR - 2018-06-21 03:44:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:44:14 --> The path to the image is not correct.
ERROR - 2018-06-21 03:44:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:44:55 --> The path to the image is not correct.
ERROR - 2018-06-21 03:44:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:44:55 --> The path to the image is not correct.
ERROR - 2018-06-21 03:44:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:45:01 --> The path to the image is not correct.
ERROR - 2018-06-21 03:45:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:45:01 --> The path to the image is not correct.
ERROR - 2018-06-21 03:45:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:45:06 --> The path to the image is not correct.
ERROR - 2018-06-21 03:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:45:06 --> The path to the image is not correct.
ERROR - 2018-06-21 03:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:45:14 --> The path to the image is not correct.
ERROR - 2018-06-21 03:45:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:45:14 --> The path to the image is not correct.
ERROR - 2018-06-21 03:45:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:45:23 --> The path to the image is not correct.
ERROR - 2018-06-21 03:45:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:45:23 --> The path to the image is not correct.
ERROR - 2018-06-21 03:45:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:45:41 --> The path to the image is not correct.
ERROR - 2018-06-21 03:45:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:45:41 --> The path to the image is not correct.
ERROR - 2018-06-21 03:45:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:46:10 --> The path to the image is not correct.
ERROR - 2018-06-21 03:46:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:46:10 --> The path to the image is not correct.
ERROR - 2018-06-21 03:46:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:46:27 --> The path to the image is not correct.
ERROR - 2018-06-21 03:46:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:46:27 --> The path to the image is not correct.
ERROR - 2018-06-21 03:46:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:47:07 --> The path to the image is not correct.
ERROR - 2018-06-21 03:47:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 03:47:07 --> The path to the image is not correct.
ERROR - 2018-06-21 03:47:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:00:55 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 416
ERROR - 2018-06-21 04:00:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 416
ERROR - 2018-06-21 04:00:55 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-21 04:00:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-21 04:00:55 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:55 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-21 04:00:56 --> The path to the image is not correct.
ERROR - 2018-06-21 04:00:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:00:56 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 91
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined index: session_data D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 416
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 416
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 36
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 47
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 51
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 55
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 62
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 62
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 79
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 80
ERROR - 2018-06-21 04:00:56 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 81
ERROR - 2018-06-21 04:01:32 --> The path to the image is not correct.
ERROR - 2018-06-21 04:01:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:01:32 --> The path to the image is not correct.
ERROR - 2018-06-21 04:01:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:24:15 --> The path to the image is not correct.
ERROR - 2018-06-21 04:24:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:24:15 --> The path to the image is not correct.
ERROR - 2018-06-21 04:24:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:27:47 --> The path to the image is not correct.
ERROR - 2018-06-21 04:27:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:27:47 --> The path to the image is not correct.
ERROR - 2018-06-21 04:27:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:31:34 --> The path to the image is not correct.
ERROR - 2018-06-21 04:31:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:31:34 --> The path to the image is not correct.
ERROR - 2018-06-21 04:31:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:31:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 04:31:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 04:31:55 --> The path to the image is not correct.
ERROR - 2018-06-21 04:31:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:31:55 --> The path to the image is not correct.
ERROR - 2018-06-21 04:31:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:31:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 04:31:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 04:33:34 --> The path to the image is not correct.
ERROR - 2018-06-21 04:33:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:33:34 --> The path to the image is not correct.
ERROR - 2018-06-21 04:33:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:35:04 --> The path to the image is not correct.
ERROR - 2018-06-21 04:35:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:35:04 --> The path to the image is not correct.
ERROR - 2018-06-21 04:35:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:35:30 --> The path to the image is not correct.
ERROR - 2018-06-21 04:35:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:35:30 --> The path to the image is not correct.
ERROR - 2018-06-21 04:35:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:37:41 --> The path to the image is not correct.
ERROR - 2018-06-21 04:37:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 04:37:41 --> The path to the image is not correct.
ERROR - 2018-06-21 04:37:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:07 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:07 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:07 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:07 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:08 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:08 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:08 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:08 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:08 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:08 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:08 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:08 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:08 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:10 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:10 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:10 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:10 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:11 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:11 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:12 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:30:12 --> The path to the image is not correct.
ERROR - 2018-06-21 05:30:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:31:00 --> The path to the image is not correct.
ERROR - 2018-06-21 05:31:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:31:00 --> The path to the image is not correct.
ERROR - 2018-06-21 05:31:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:35:34 --> The path to the image is not correct.
ERROR - 2018-06-21 05:35:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:35:34 --> The path to the image is not correct.
ERROR - 2018-06-21 05:35:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:35:37 --> 404 Page Not Found: admin/Users/view_user_info
ERROR - 2018-06-21 05:36:31 --> The path to the image is not correct.
ERROR - 2018-06-21 05:36:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:36:31 --> The path to the image is not correct.
ERROR - 2018-06-21 05:36:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:36:44 --> The path to the image is not correct.
ERROR - 2018-06-21 05:36:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:36:44 --> The path to the image is not correct.
ERROR - 2018-06-21 05:36:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:36:51 --> The path to the image is not correct.
ERROR - 2018-06-21 05:36:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:36:51 --> The path to the image is not correct.
ERROR - 2018-06-21 05:36:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:04 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:04 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:04 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:11 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:11 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:19 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:19 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:36 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:37 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:37 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:37:37 --> The path to the image is not correct.
ERROR - 2018-06-21 05:37:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:43:32 --> The path to the image is not correct.
ERROR - 2018-06-21 05:43:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:43:32 --> The path to the image is not correct.
ERROR - 2018-06-21 05:43:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:45:23 --> The path to the image is not correct.
ERROR - 2018-06-21 05:45:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:45:23 --> The path to the image is not correct.
ERROR - 2018-06-21 05:45:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:45:23 --> The path to the image is not correct.
ERROR - 2018-06-21 05:45:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:45:24 --> The path to the image is not correct.
ERROR - 2018-06-21 05:45:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:45:24 --> The path to the image is not correct.
ERROR - 2018-06-21 05:45:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:45:24 --> The path to the image is not correct.
ERROR - 2018-06-21 05:45:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 05:54:59 --> Query error: Unknown column 'up.plan_type' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `up`.`plan_type` = 'BASIC'
AND `u`.`status` = 'ACTIVE'
AND `role` = 'SUPER ADMIN'
ERROR - 2018-06-21 05:56:48 --> Query error: Unknown table 'project_transport.u' - Invalid query: SELECT `u`.*, `up`.`plan_type`, `up`.`billing_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`updated`, `up`.`active`
FROM `user`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
WHERE `up`.`plan_type` = 'BASIC'
AND `u`.`status` = 'ACTIVE'
AND `role` = 'SUPER ADMIN'
ERROR - 2018-06-21 06:00:52 --> Query error: Unknown column 'up.plan_type' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `up`.`plan_type` = 'BASIC'
AND `u`.`status` = 'ACTIVE'
AND `role` = 'SUPER ADMIN'
ERROR - 2018-06-21 07:46:18 --> Query error: Unknown column 'up.plan_type' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `up`.`plan_type` = 'BASIC'
AND `u`.`status` = 'ACTIVE'
AND `role` = 'SUPER ADMIN'
ERROR - 2018-06-21 07:46:18 --> Query error: Unknown column 'up.plan_type' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `up`.`plan_type` = 'BASIC'
AND `u`.`status` = 'ACTIVE'
AND `role` = 'SUPER ADMIN'
ERROR - 2018-06-21 07:46:18 --> Query error: Unknown column 'up.plan_type' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `up`.`plan_type` = 'BASIC'
AND `u`.`status` = 'ACTIVE'
AND `role` = 'SUPER ADMIN'
ERROR - 2018-06-21 07:46:18 --> Query error: Unknown column 'up.plan_type' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `up`.`plan_type` = 'BASIC'
AND `u`.`status` = 'ACTIVE'
AND `role` = 'SUPER ADMIN'
ERROR - 2018-06-21 07:46:18 --> Query error: Unknown column 'up.plan_type' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `up`.`plan_type` = 'BASIC'
AND `u`.`status` = 'ACTIVE'
AND `role` = 'SUPER ADMIN'
ERROR - 2018-06-21 07:48:38 --> The path to the image is not correct.
ERROR - 2018-06-21 07:48:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:48:38 --> The path to the image is not correct.
ERROR - 2018-06-21 07:48:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:48:50 --> Query error: Unknown column 'up.plan_type' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `up`.`plan_type` = 'BASIC'
AND `role` = 'SUPER ADMIN'
ERROR - 2018-06-21 07:49:10 --> Query error: Unknown table 'project_transport.u' - Invalid query: SELECT `u`.*, `up`.`plan_type`, `up`.`billing_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`updated`, `up`.`active`
FROM `user`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
WHERE `up`.`plan_type` = 'BASIC'
AND `role` = 'SUPER ADMIN'
ERROR - 2018-06-21 07:57:24 --> The path to the image is not correct.
ERROR - 2018-06-21 07:57:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:57:25 --> The path to the image is not correct.
ERROR - 2018-06-21 07:57:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:57:26 --> The path to the image is not correct.
ERROR - 2018-06-21 07:57:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:57:26 --> The path to the image is not correct.
ERROR - 2018-06-21 07:57:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:57:26 --> The path to the image is not correct.
ERROR - 2018-06-21 07:57:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:57:27 --> The path to the image is not correct.
ERROR - 2018-06-21 07:57:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:57:27 --> The path to the image is not correct.
ERROR - 2018-06-21 07:57:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:57:27 --> The path to the image is not correct.
ERROR - 2018-06-21 07:57:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:57:42 --> Query error: Unknown column 'u.billing_type' in 'where clause' - Invalid query: SELECT `u`.*, `up`.`plan_type`, `up`.`billing_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`updated`, `up`.`active`
FROM `user` `u`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
WHERE `up`.`plan_type` = 'BASIC'
AND `u`.`billing_type` = 'ANNUAL'
AND `u`.`role` = 'SUPER ADMIN'
ERROR - 2018-06-21 07:58:05 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:11 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:11 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:11 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:12 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:12 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:12 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:13 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:13 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:13 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:14 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:14 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 07:58:14 --> The path to the image is not correct.
ERROR - 2018-06-21 07:58:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:01:34 --> The path to the image is not correct.
ERROR - 2018-06-21 08:01:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:01:48 --> The path to the image is not correct.
ERROR - 2018-06-21 08:01:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:01:48 --> The path to the image is not correct.
ERROR - 2018-06-21 08:01:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:03:06 --> The path to the image is not correct.
ERROR - 2018-06-21 08:03:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:03:09 --> The path to the image is not correct.
ERROR - 2018-06-21 08:03:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:03:09 --> The path to the image is not correct.
ERROR - 2018-06-21 08:03:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:03:12 --> The path to the image is not correct.
ERROR - 2018-06-21 08:03:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:03:12 --> The path to the image is not correct.
ERROR - 2018-06-21 08:03:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:08:05 --> The path to the image is not correct.
ERROR - 2018-06-21 08:08:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:08:05 --> The path to the image is not correct.
ERROR - 2018-06-21 08:08:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:08:10 --> The path to the image is not correct.
ERROR - 2018-06-21 08:08:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:08:10 --> The path to the image is not correct.
ERROR - 2018-06-21 08:08:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:08:11 --> The path to the image is not correct.
ERROR - 2018-06-21 08:08:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:08:12 --> The path to the image is not correct.
ERROR - 2018-06-21 08:08:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:08:35 --> The path to the image is not correct.
ERROR - 2018-06-21 08:08:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:08:35 --> The path to the image is not correct.
ERROR - 2018-06-21 08:08:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:17:19 --> The path to the image is not correct.
ERROR - 2018-06-21 08:17:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:17:20 --> The path to the image is not correct.
ERROR - 2018-06-21 08:17:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:19:44 --> The path to the image is not correct.
ERROR - 2018-06-21 08:19:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:19:44 --> The path to the image is not correct.
ERROR - 2018-06-21 08:19:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:20:46 --> The path to the image is not correct.
ERROR - 2018-06-21 08:20:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:20:46 --> The path to the image is not correct.
ERROR - 2018-06-21 08:20:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:21:05 --> The path to the image is not correct.
ERROR - 2018-06-21 08:21:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:21:05 --> The path to the image is not correct.
ERROR - 2018-06-21 08:21:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:21:05 --> The path to the image is not correct.
ERROR - 2018-06-21 08:21:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:21:05 --> The path to the image is not correct.
ERROR - 2018-06-21 08:21:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:21:45 --> The path to the image is not correct.
ERROR - 2018-06-21 08:21:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:21:46 --> The path to the image is not correct.
ERROR - 2018-06-21 08:21:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:23:20 --> The path to the image is not correct.
ERROR - 2018-06-21 08:23:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:23:20 --> The path to the image is not correct.
ERROR - 2018-06-21 08:23:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:23:39 --> The path to the image is not correct.
ERROR - 2018-06-21 08:23:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:23:39 --> The path to the image is not correct.
ERROR - 2018-06-21 08:23:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:23:40 --> The path to the image is not correct.
ERROR - 2018-06-21 08:23:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:37:59 --> The path to the image is not correct.
ERROR - 2018-06-21 08:37:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:37:59 --> The path to the image is not correct.
ERROR - 2018-06-21 08:37:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:56:59 --> The path to the image is not correct.
ERROR - 2018-06-21 08:56:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 08:56:59 --> The path to the image is not correct.
ERROR - 2018-06-21 08:56:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 09:15:36 --> The path to the image is not correct.
ERROR - 2018-06-21 09:15:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 09:15:36 --> The path to the image is not correct.
ERROR - 2018-06-21 09:15:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 09:57:41 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 276
ERROR - 2018-06-21 09:57:41 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 276
ERROR - 2018-06-21 09:57:41 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 276
ERROR - 2018-06-21 10:00:31 --> The path to the image is not correct.
ERROR - 2018-06-21 10:00:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:00:31 --> The path to the image is not correct.
ERROR - 2018-06-21 10:00:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:00:31 --> The path to the image is not correct.
ERROR - 2018-06-21 10:00:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:00:31 --> The path to the image is not correct.
ERROR - 2018-06-21 10:00:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:20:16 --> The path to the image is not correct.
ERROR - 2018-06-21 10:20:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:20:16 --> The path to the image is not correct.
ERROR - 2018-06-21 10:20:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:20:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:20:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:20:26 --> The path to the image is not correct.
ERROR - 2018-06-21 10:20:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:20:26 --> The path to the image is not correct.
ERROR - 2018-06-21 10:20:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:20:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:20:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:21:05 --> The path to the image is not correct.
ERROR - 2018-06-21 10:21:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:21:05 --> The path to the image is not correct.
ERROR - 2018-06-21 10:21:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:21:05 --> The path to the image is not correct.
ERROR - 2018-06-21 10:21:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:21:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:21:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:23:27 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:27 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:23:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:23:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:27 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:27 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:28 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:28 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:23:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:23:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:28 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:28 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:28 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:28 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:28 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:23:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:23:57 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:57 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:57 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:57 --> The path to the image is not correct.
ERROR - 2018-06-21 10:23:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:23:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:23:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:04 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:04 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:04 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:56 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:56 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:56 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:58 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:58 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:58 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:58 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:58 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:58 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:24:58 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:24:59 --> The path to the image is not correct.
ERROR - 2018-06-21 10:24:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:25:25 --> The path to the image is not correct.
ERROR - 2018-06-21 10:25:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:25:25 --> The path to the image is not correct.
ERROR - 2018-06-21 10:25:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:25:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:25:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:25:27 --> The path to the image is not correct.
ERROR - 2018-06-21 10:25:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:25:27 --> The path to the image is not correct.
ERROR - 2018-06-21 10:25:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:25:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:25:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-21 10:25:27 --> The path to the image is not correct.
ERROR - 2018-06-21 10:25:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:22 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:22 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:22 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:22 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:22 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:23 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:23 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:23 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:32 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:32 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:32 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:32 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:32 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:32 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:47 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:47 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-21 10:27:47 --> The path to the image is not correct.
ERROR - 2018-06-21 10:27:47 --> Your server does not support the GD function required to process this type of image.

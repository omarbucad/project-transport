<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-24 03:24:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:24:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:24:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:25:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:25:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:25:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:27:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:27:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:27:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:29:15 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 84
ERROR - 2018-04-24 03:29:20 --> Severity: Error --> Call to undefined function print_r_dieempty() D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 84
ERROR - 2018-04-24 03:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 197
ERROR - 2018-04-24 03:29:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:29:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:29:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:30:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:30:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:30:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:30:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:30:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:30:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 197
ERROR - 2018-04-24 03:30:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:30:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:30:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:31:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:31:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:31:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:31:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 197
ERROR - 2018-04-24 03:31:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 197
ERROR - 2018-04-24 03:32:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:32:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:35:53 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 184
ERROR - 2018-04-24 03:36:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:36:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:36:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:36:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:36:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:36:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:37:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:37:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:37:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:37:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:37:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:37:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:43:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:43:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:43:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:43:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:43:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:43:59 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 03:43:59 --> The provided image is not valid.
ERROR - 2018-04-24 03:43:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 03:43:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:46:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:46:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:46:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:46:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 198
ERROR - 2018-04-24 03:46:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-24 03:46:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 200
ERROR - 2018-04-24 03:46:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-24 03:46:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 202
ERROR - 2018-04-24 03:46:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-24 03:49:06 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-24 03:54:00 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-24 03:54:07 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-24 03:55:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:55:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:55:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:56:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:56:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:56:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:58:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:58:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:58:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:59:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:59:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:59:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:59:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:59:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:59:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:59:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:59:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 03:59:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:00:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:00:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:00:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:01:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:01:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:01:02 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:01:02 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:01:02 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:01:02 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:01:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:01:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:01:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:01:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:01:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:01:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:01:02 --> The path to the image is not correct.
ERROR - 2018-04-24 04:01:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:01:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:42 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:42 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:42 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:42 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:02:42 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:42 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:42 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:02:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:02:42 --> The path to the image is not correct.
ERROR - 2018-04-24 04:02:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:02:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:48 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:48 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:48 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:48 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:02:48 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:48 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:48 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:48 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:48 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:02:48 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:02:48 --> The path to the image is not correct.
ERROR - 2018-04-24 04:02:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:02:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:53 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:53 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:53 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:02:53 --> The path to the image is not correct.
ERROR - 2018-04-24 04:02:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:02:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:53 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:53 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:53 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:02:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:02:53 --> The path to the image is not correct.
ERROR - 2018-04-24 04:02:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:02:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:02:54 --> The path to the image is not correct.
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:02:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:02:54 --> The path to the image is not correct.
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:02:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:02:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:54 --> The path to the image is not correct.
ERROR - 2018-04-24 04:02:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:02:55 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:55 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:55 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:02:55 --> The path to the image is not correct.
ERROR - 2018-04-24 04:02:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:02:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:02:55 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:55 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:55 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:02:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:02:55 --> The path to the image is not correct.
ERROR - 2018-04-24 04:02:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:02:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:03:52 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:03:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:03:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:03:52 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:03:52 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:03:52 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:03:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:03:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:03:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:03:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:03:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:03:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:03:52 --> The path to the image is not correct.
ERROR - 2018-04-24 04:03:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:03:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:04:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:04:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:04:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:04:38 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:04:38 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:04:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:04:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:04:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:04:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:04:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:04:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:04:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:04:38 --> The path to the image is not correct.
ERROR - 2018-04-24 04:04:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:04:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:04:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:04:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:04:42 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:04:42 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:04:42 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:04:42 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:04:42 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:04:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:04:42 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:04:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:04:42 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:04:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:04:42 --> The path to the image is not correct.
ERROR - 2018-04-24 04:04:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:04:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:10:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:10:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:10:54 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:10:54 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:10:54 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:10:54 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:10:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:10:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:10:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:10:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:10:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:10:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:10:54 --> The path to the image is not correct.
ERROR - 2018-04-24 04:10:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:10:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:11:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:11:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:11:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:11:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:11:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:11:07 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 04:11:07 --> The provided image is not valid.
ERROR - 2018-04-24 04:11:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 04:11:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:18 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:18 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:18 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:18 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:15:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:15:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:15:18 --> The path to the image is not correct.
ERROR - 2018-04-24 04:15:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:15:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:18 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 04:15:18 --> The provided image is not valid.
ERROR - 2018-04-24 04:15:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 04:15:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:19 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:19 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:19 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:19 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:15:19 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:19 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:19 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:19 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:19 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:15:19 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:15:19 --> The path to the image is not correct.
ERROR - 2018-04-24 04:15:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:15:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:19 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 04:15:19 --> The provided image is not valid.
ERROR - 2018-04-24 04:15:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 04:15:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:38 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:38 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:15:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:15:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:15:38 --> The path to the image is not correct.
ERROR - 2018-04-24 04:15:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:15:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:39 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 04:15:39 --> The provided image is not valid.
ERROR - 2018-04-24 04:15:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 04:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:15:52 --> The path to the image is not correct.
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:15:52 --> The path to the image is not correct.
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:52 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:52 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:15:53 --> The path to the image is not correct.
ERROR - 2018-04-24 04:15:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:15:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:15:53 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:53 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:53 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 04:15:53 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 04:15:53 --> The path to the image is not correct.
ERROR - 2018-04-24 04:15:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 04:15:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:16:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:16:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:16:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:16:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:16:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:16:13 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 04:16:13 --> The provided image is not valid.
ERROR - 2018-04-24 04:16:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 04:16:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:46:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:46:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 04:46:39 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 04:46:39 --> The provided image is not valid.
ERROR - 2018-04-24 04:46:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 04:46:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:10:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:10:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:10:36 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:10:36 --> The provided image is not valid.
ERROR - 2018-04-24 05:10:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:10:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:10:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:10:37 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:10:37 --> The provided image is not valid.
ERROR - 2018-04-24 05:10:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:10:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:17:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:17:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:17:04 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:17:04 --> The provided image is not valid.
ERROR - 2018-04-24 05:17:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:17:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:17:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:17:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:17:39 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:17:39 --> The provided image is not valid.
ERROR - 2018-04-24 05:17:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:17:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:17:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:17:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:17:50 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:17:50 --> The provided image is not valid.
ERROR - 2018-04-24 05:17:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:17:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:18:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:18:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:18:07 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:18:07 --> The provided image is not valid.
ERROR - 2018-04-24 05:18:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:18:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:18:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:18:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:18:35 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:18:35 --> The provided image is not valid.
ERROR - 2018-04-24 05:18:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:18:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:19:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:19:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:19:12 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:19:12 --> The provided image is not valid.
ERROR - 2018-04-24 05:19:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:19:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:19:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:19:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:19:13 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:19:13 --> The provided image is not valid.
ERROR - 2018-04-24 05:19:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:19:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:19:36 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:19:36 --> The provided image is not valid.
ERROR - 2018-04-24 05:19:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:19:44 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:19:44 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:19:44 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:19:44 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 05:19:44 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 05:19:44 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 05:19:44 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 05:19:44 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 05:19:44 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 05:19:44 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 05:19:44 --> The path to the image is not correct.
ERROR - 2018-04-24 05:19:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 05:19:44 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:19:44 --> The provided image is not valid.
ERROR - 2018-04-24 05:19:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:25:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:25:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:25:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:41:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:41:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:41:00 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 05:41:00 --> The provided image is not valid.
ERROR - 2018-04-24 05:41:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 05:41:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:41:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:41:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:41:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 05:41:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 05:41:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:41:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 05:41:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 05:41:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 05:41:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 05:41:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 05:41:00 --> The path to the image is not correct.
ERROR - 2018-04-24 05:41:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 05:41:05 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:41:05 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:41:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:41:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:41:05 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:41:05 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 05:41:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 05:41:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 05:41:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 05:41:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 05:41:05 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 05:41:05 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 05:41:05 --> The path to the image is not correct.
ERROR - 2018-04-24 05:41:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 05:41:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:41:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:41:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:41:06 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:41:06 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:41:06 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 05:41:06 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 05:41:06 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 05:41:06 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 05:41:06 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 05:41:06 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 05:41:06 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 05:41:06 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 05:41:06 --> The path to the image is not correct.
ERROR - 2018-04-24 05:41:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 05:41:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:39:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:39:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:39:37 --> The path to the image is not correct.
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:39:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:39:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:39:37 --> The path to the image is not correct.
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:39:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:39:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:39:37 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:39:37 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:39:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:39:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:39:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:39:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:39:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:39:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:39:38 --> The path to the image is not correct.
ERROR - 2018-04-24 07:39:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:39:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:16 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:16 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:16 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:16 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:40:16 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:40:16 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:40:16 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:40:16 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:40:16 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:40:16 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:40:16 --> The path to the image is not correct.
ERROR - 2018-04-24 07:40:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:40:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:18 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:18 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:18 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:18 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:40:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:40:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:40:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:40:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:40:18 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:40:18 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:40:18 --> The path to the image is not correct.
ERROR - 2018-04-24 07:40:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:40:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:19 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:19 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:19 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:40:19 --> The path to the image is not correct.
ERROR - 2018-04-24 07:40:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:40:19 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:19 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:19 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:40:19 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:40:19 --> The path to the image is not correct.
ERROR - 2018-04-24 07:40:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:40:20 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:20 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:20 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:40:20 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:40:20 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:40:20 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:40:20 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:40:20 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:40:20 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:40:20 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:40:20 --> The path to the image is not correct.
ERROR - 2018-04-24 07:40:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:49:45 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:49:45 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:49:45 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:49:45 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:49:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:49:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:49:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:49:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:49:45 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:49:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:49:45 --> The path to the image is not correct.
ERROR - 2018-04-24 07:49:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:49:59 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:49:59 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:49:59 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:49:59 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:49:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:49:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:49:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:49:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:49:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:49:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:49:59 --> The path to the image is not correct.
ERROR - 2018-04-24 07:49:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:50:00 --> The path to the image is not correct.
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:50:00 --> The path to the image is not correct.
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:50:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:50:00 --> The path to the image is not correct.
ERROR - 2018-04-24 07:50:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:50:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:56:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:56:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:56:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:57:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:57:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:57:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:57:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:57:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:57:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:57:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 07:57:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 07:57:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 07:57:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:57:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 07:57:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:57:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 07:57:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 07:57:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 07:57:03 --> The path to the image is not correct.
ERROR - 2018-04-24 07:57:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 07:57:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:07:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:07:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:07:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:07:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:07:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:07:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:07:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:07:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:07:14 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:07:14 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:07:14 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:07:14 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:07:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:07:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:07:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:07:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:07:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:07:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:07:14 --> The path to the image is not correct.
ERROR - 2018-04-24 08:07:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:07:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:20:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:20:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:20:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:04 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:21:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:04 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:21:04 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:21:04 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:21:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:21:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:21:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:21:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:21:04 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:21:04 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:21:04 --> The path to the image is not correct.
ERROR - 2018-04-24 08:21:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:21:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:22 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:21:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:22 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:21:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:21:22 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:21:22 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:21:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:21:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:21:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:21:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:21:22 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:21:22 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:21:22 --> The path to the image is not correct.
ERROR - 2018-04-24 08:21:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:21:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:24:13 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:24:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:24:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:24:13 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:24:13 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:24:13 --> The path to the image is not correct.
ERROR - 2018-04-24 08:24:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:24:13 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:24:13 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:24:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:24:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:24:13 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:24:13 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:24:13 --> The path to the image is not correct.
ERROR - 2018-04-24 08:24:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:24:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:24:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:24:14 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:24:14 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:24:14 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:24:14 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:24:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:24:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:24:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:24:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:24:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:24:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:24:14 --> The path to the image is not correct.
ERROR - 2018-04-24 08:24:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:24:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:25:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:25:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:25:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:25:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:25:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:25:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:25:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:25:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:25:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:25:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:25:00 --> The path to the image is not correct.
ERROR - 2018-04-24 08:25:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:25:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:25:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:25:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:25:43 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:25:43 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:25:43 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:25:43 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:25:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:25:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:25:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:25:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:25:44 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:25:44 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:25:44 --> The path to the image is not correct.
ERROR - 2018-04-24 08:25:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:25:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:26:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:26:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:26:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:26:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:26:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:26:03 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 08:26:03 --> The provided image is not valid.
ERROR - 2018-04-24 08:26:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 08:26:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:30:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:30:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:30:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:31:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:31:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:31:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:38:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:38:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:38:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:38:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:38:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:38:41 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 08:38:41 --> The provided image is not valid.
ERROR - 2018-04-24 08:38:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 08:38:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:46:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:46:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:46:33 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 08:46:33 --> The provided image is not valid.
ERROR - 2018-04-24 08:46:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 08:46:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:46:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:46:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:46:55 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 08:46:55 --> The provided image is not valid.
ERROR - 2018-04-24 08:46:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 08:46:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:54:37 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 08:54:37 --> The provided image is not valid.
ERROR - 2018-04-24 08:54:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 08:54:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:54:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:54:49 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:54:50 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:54:50 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:54:50 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:54:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:54:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:54:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:54:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:54:50 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:54:50 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:54:50 --> The path to the image is not correct.
ERROR - 2018-04-24 08:54:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:54:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:54:54 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:54:54 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:54:54 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:54:54 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:54:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:54:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:54:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:54:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:54:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:54:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:54:54 --> The path to the image is not correct.
ERROR - 2018-04-24 08:54:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:55:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:55:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:55:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:55:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:55:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:55:27 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:55:27 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:55:27 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:55:27 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:55:27 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:55:27 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:55:27 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:55:27 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:55:27 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:55:27 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:55:27 --> The path to the image is not correct.
ERROR - 2018-04-24 08:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:55:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:57:29 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:57:29 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:57:29 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-24 08:57:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:57:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:57:29 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-24 08:57:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:57:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-24 08:57:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:57:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-24 08:57:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-04-24 08:57:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-24 08:57:29 --> The path to the image is not correct.
ERROR - 2018-04-24 08:57:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-24 08:57:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:57:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:57:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 08:57:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:04:26 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:04:26 --> The provided image is not valid.
ERROR - 2018-04-24 09:04:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:04:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:34 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:10:34 --> The provided image is not valid.
ERROR - 2018-04-24 09:10:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:10:34 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:10:34 --> The provided image is not valid.
ERROR - 2018-04-24 09:10:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:10:34 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:10:34 --> The provided image is not valid.
ERROR - 2018-04-24 09:10:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:10:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:38 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:38 --> The provided image is not valid.
ERROR - 2018-04-24 09:10:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:10:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:12:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:12:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:12:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:12:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:12:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:12:42 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:12:42 --> The provided image is not valid.
ERROR - 2018-04-24 09:12:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:12:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:40:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:40:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:40:03 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:40:03 --> The provided image is not valid.
ERROR - 2018-04-24 09:40:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:40:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:47:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:47:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:47:14 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:47:14 --> The provided image is not valid.
ERROR - 2018-04-24 09:47:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:47:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:47:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:47:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:47:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:47:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:47:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:47:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:47:25 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 142
ERROR - 2018-04-24 09:47:25 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given D:\xampp\htdocs\project-transport\system\libraries\Upload.php 412
ERROR - 2018-04-24 09:47:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 198
ERROR - 2018-04-24 09:47:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-24 09:47:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 200
ERROR - 2018-04-24 09:47:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-24 09:47:25 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 202
ERROR - 2018-04-24 09:47:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-24 09:47:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 199
ERROR - 2018-04-24 09:47:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 200
ERROR - 2018-04-24 09:47:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-24 09:47:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 202
ERROR - 2018-04-24 09:47:48 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 203
ERROR - 2018-04-24 09:47:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-24 09:48:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:48:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:48:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:49:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:50:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:50:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:50:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:51:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:51:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:51:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:51:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:51:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:51:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:51:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:51:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:51:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:53:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:53:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:53:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:53:13 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 181
ERROR - 2018-04-24 09:55:17 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 225
ERROR - 2018-04-24 09:55:17 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 226
ERROR - 2018-04-24 09:55:17 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 225
ERROR - 2018-04-24 09:55:17 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 226
ERROR - 2018-04-24 09:55:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:55:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:55:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:55:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:55:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:55:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:55:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:55:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:55:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:56:17 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:56:17 --> The provided image is not valid.
ERROR - 2018-04-24 09:56:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:56:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:56:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:56:17 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:56:17 --> The provided image is not valid.
ERROR - 2018-04-24 09:56:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:56:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:56:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:56:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:56:21 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:56:21 --> The provided image is not valid.
ERROR - 2018-04-24 09:56:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:56:21 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:56:21 --> The provided image is not valid.
ERROR - 2018-04-24 09:56:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:56:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:58:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:58:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:58:41 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:58:41 --> The provided image is not valid.
ERROR - 2018-04-24 09:58:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:58:42 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:58:42 --> The provided image is not valid.
ERROR - 2018-04-24 09:58:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:58:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:58:49 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:58:49 --> The provided image is not valid.
ERROR - 2018-04-24 09:58:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:58:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:58:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:58:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:58:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:58:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:58:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:08 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:59:08 --> The provided image is not valid.
ERROR - 2018-04-24 09:59:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:59:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:08 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:59:08 --> The provided image is not valid.
ERROR - 2018-04-24 09:59:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:59:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:09 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:59:09 --> The provided image is not valid.
ERROR - 2018-04-24 09:59:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:59:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:09 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 09:59:09 --> The provided image is not valid.
ERROR - 2018-04-24 09:59:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 09:59:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 09:59:55 --> Severity: Notice --> Undefined variable: images D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-24 09:59:55 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 226
ERROR - 2018-04-24 09:59:55 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 227
ERROR - 2018-04-24 09:59:55 --> Severity: Notice --> Undefined variable: images D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-24 09:59:55 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 226
ERROR - 2018-04-24 09:59:55 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 227
ERROR - 2018-04-24 09:59:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-24 10:40:23 --> Severity: Notice --> Undefined variable: images D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-24 10:40:23 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 226
ERROR - 2018-04-24 10:40:23 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 227
ERROR - 2018-04-24 10:40:23 --> Severity: Notice --> Undefined variable: images D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 201
ERROR - 2018-04-24 10:40:23 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 226
ERROR - 2018-04-24 10:40:23 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 227
ERROR - 2018-04-24 10:40:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-24 10:40:39 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 182
ERROR - 2018-04-24 10:40:39 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 225
ERROR - 2018-04-24 10:40:39 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 226
ERROR - 2018-04-24 10:40:39 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 225
ERROR - 2018-04-24 10:40:39 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 226
ERROR - 2018-04-24 10:40:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-24 10:42:07 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 181
ERROR - 2018-04-24 10:42:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 223
ERROR - 2018-04-24 10:42:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 224
ERROR - 2018-04-24 10:42:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 223
ERROR - 2018-04-24 10:42:07 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 224
ERROR - 2018-04-24 10:42:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-04-24 10:42:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:42:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:42:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:44:54 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 10:44:54 --> The provided image is not valid.
ERROR - 2018-04-24 10:44:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 10:44:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:03 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 10:47:03 --> The provided image is not valid.
ERROR - 2018-04-24 10:47:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 10:47:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:04 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 10:47:04 --> The provided image is not valid.
ERROR - 2018-04-24 10:47:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 10:47:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:55 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 10:47:55 --> The provided image is not valid.
ERROR - 2018-04-24 10:47:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 10:47:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:55 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 10:47:55 --> The provided image is not valid.
ERROR - 2018-04-24 10:47:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 10:47:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-24 10:47:56 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-24 10:47:56 --> The provided image is not valid.
ERROR - 2018-04-24 10:47:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-24 10:47:56 --> 404 Page Not Found: Public/lib

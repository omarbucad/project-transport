<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-17 07:27:53 --> The path to the image is not correct.
ERROR - 2018-05-17 07:27:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 07:28:17 --> The path to the image is not correct.
ERROR - 2018-05-17 07:28:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 07:47:21 --> The path to the image is not correct.
ERROR - 2018-05-17 07:47:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 07:49:58 --> The path to the image is not correct.
ERROR - 2018-05-17 07:49:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 07:49:58 --> The path to the image is not correct.
ERROR - 2018-05-17 07:49:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 07:50:04 --> The path to the image is not correct.
ERROR - 2018-05-17 07:50:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 07:50:06 --> The path to the image is not correct.
ERROR - 2018-05-17 07:50:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 07:52:57 --> The path to the image is not correct.
ERROR - 2018-05-17 07:52:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 07:52:58 --> The path to the image is not correct.
ERROR - 2018-05-17 07:52:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 07:52:58 --> The path to the image is not correct.
ERROR - 2018-05-17 07:52:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 07:56:23 --> The path to the image is not correct.
ERROR - 2018-05-17 07:56:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:02:25 --> The path to the image is not correct.
ERROR - 2018-05-17 08:02:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:02:25 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:02:25 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:02:25 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:02:25 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:02:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:02:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:02:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:02:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:02:25 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:02:25 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:02:25 --> The path to the image is not correct.
ERROR - 2018-05-17 08:02:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:05:38 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 131
ERROR - 2018-05-17 08:05:38 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 131
ERROR - 2018-05-17 08:05:38 --> The path to the image is not correct.
ERROR - 2018-05-17 08:05:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:05:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:05:38 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:05:38 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:05:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:05:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:05:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:05:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:05:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:05:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:05:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:05:38 --> The path to the image is not correct.
ERROR - 2018-05-17 08:05:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:06:11 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 131
ERROR - 2018-05-17 08:06:11 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 131
ERROR - 2018-05-17 08:06:11 --> The path to the image is not correct.
ERROR - 2018-05-17 08:06:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:06:11 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:06:11 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:06:11 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:06:11 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:06:11 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:06:11 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:06:11 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:06:11 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:06:11 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:06:11 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:06:11 --> The path to the image is not correct.
ERROR - 2018-05-17 08:06:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:06:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:06:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:06:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:27:02 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 131
ERROR - 2018-05-17 08:27:02 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 131
ERROR - 2018-05-17 08:27:02 --> The path to the image is not correct.
ERROR - 2018-05-17 08:27:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:27:02 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:27:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:27:02 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:27:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:27:02 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:27:02 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:27:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:27:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:27:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:27:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:27:02 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:27:02 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:27:02 --> The path to the image is not correct.
ERROR - 2018-05-17 08:27:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:27:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:27:11 --> The path to the image is not correct.
ERROR - 2018-05-17 08:27:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:27:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:27:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:27:11 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:27:11 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:27:11 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:27:11 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:27:11 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:27:11 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:27:11 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:27:11 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:27:11 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:27:11 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:27:11 --> The path to the image is not correct.
ERROR - 2018-05-17 08:27:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:27:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:27:52 --> The path to the image is not correct.
ERROR - 2018-05-17 08:27:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:27:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:27:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:27:52 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:27:52 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:27:52 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:27:52 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:27:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:27:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:27:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:27:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:27:52 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:27:52 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:27:52 --> The path to the image is not correct.
ERROR - 2018-05-17 08:27:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:27:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:31:16 --> The path to the image is not correct.
ERROR - 2018-05-17 08:31:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:31:17 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:31:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:31:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:31:17 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:31:17 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:31:17 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:31:17 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:31:17 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:31:17 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:31:17 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:31:17 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:31:17 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:31:17 --> The path to the image is not correct.
ERROR - 2018-05-17 08:31:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:32:03 --> The path to the image is not correct.
ERROR - 2018-05-17 08:32:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:32:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:32:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:32:03 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:32:03 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:32:03 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:32:03 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:32:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:32:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:32:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:32:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:32:03 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:32:03 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:32:03 --> The path to the image is not correct.
ERROR - 2018-05-17 08:32:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:37:07 --> The path to the image is not correct.
ERROR - 2018-05-17 08:37:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:37:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:37:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:37:08 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:37:08 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:37:08 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:37:08 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:37:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:37:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:37:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:37:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:37:08 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:37:08 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:37:08 --> The path to the image is not correct.
ERROR - 2018-05-17 08:37:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:37:13 --> The path to the image is not correct.
ERROR - 2018-05-17 08:37:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:37:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:37:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:37:13 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:37:13 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:37:13 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:37:13 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:37:13 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:37:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:37:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:37:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:37:14 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:37:14 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:37:14 --> The path to the image is not correct.
ERROR - 2018-05-17 08:37:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:41:10 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:41:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:10 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:10 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:10 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:10 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:41:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:41:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:41:10 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:41:27 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:41:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:28 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:28 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:28 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:28 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:41:28 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:28 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:28 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:28 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:28 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:41:28 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:41:28 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:41:32 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:41:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:32 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:32 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:32 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:32 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:41:32 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:32 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:32 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:32 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:32 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:41:32 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:41:32 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:41:33 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:41:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:33 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:33 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:33 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:33 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:41:33 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:33 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:33 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:33 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:33 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:41:33 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:41:33 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:41:33 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:41:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:41:34 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:41:34 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:41:34 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:41:34 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:41:34 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:41:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:41:34 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:41:34 --> The path to the image is not correct.
ERROR - 2018-05-17 08:41:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:42:03 --> The path to the image is not correct.
ERROR - 2018-05-17 08:42:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:42:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:42:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:42:15 --> The path to the image is not correct.
ERROR - 2018-05-17 08:42:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:42:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:42:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:43:00 --> The path to the image is not correct.
ERROR - 2018-05-17 08:43:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:43:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:43:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:43:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:43:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:43:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:43:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:43:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:43:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:43:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:43:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:43:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:43:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:43:00 --> The path to the image is not correct.
ERROR - 2018-05-17 08:43:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:43:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:43:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:43:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:43:09 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 131
ERROR - 2018-05-17 08:43:09 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 135
ERROR - 2018-05-17 08:43:09 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 135
ERROR - 2018-05-17 08:43:09 --> The path to the image is not correct.
ERROR - 2018-05-17 08:43:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:43:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:43:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:43:09 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:43:09 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:43:09 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:43:09 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:43:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:43:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:43:09 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:43:09 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:43:10 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:43:10 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:43:10 --> The path to the image is not correct.
ERROR - 2018-05-17 08:43:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:43:43 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 135
ERROR - 2018-05-17 08:43:43 --> The path to the image is not correct.
ERROR - 2018-05-17 08:43:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:43:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:43:43 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:43:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:43:43 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:43:43 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:43:43 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:43:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:43:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:43:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:43:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:43:43 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:43:43 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:43:43 --> The path to the image is not correct.
ERROR - 2018-05-17 08:43:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:43:59 --> The path to the image is not correct.
ERROR - 2018-05-17 08:43:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:44:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:44:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:44:00 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:44:00 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:44:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:44:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:44:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:44:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:44:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:44:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:44:00 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:44:00 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:44:00 --> The path to the image is not correct.
ERROR - 2018-05-17 08:44:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:45:29 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 236
ERROR - 2018-05-17 08:45:29 --> The path to the image is not correct.
ERROR - 2018-05-17 08:45:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:45:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:45:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:45:37 --> The path to the image is not correct.
ERROR - 2018-05-17 08:45:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:45:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:45:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:45:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:45:38 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:45:38 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:45:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:45:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:45:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:45:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:45:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:45:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:45:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:45:38 --> The path to the image is not correct.
ERROR - 2018-05-17 08:45:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:46:57 --> The path to the image is not correct.
ERROR - 2018-05-17 08:46:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:46:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:46:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:46:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:46:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:46:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:46:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:46:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:46:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:46:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:46:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:46:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:46:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:46:58 --> The path to the image is not correct.
ERROR - 2018-05-17 08:46:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:47:21 --> The path to the image is not correct.
ERROR - 2018-05-17 08:47:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:47:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:47:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:47:21 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:47:21 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:47:21 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:47:21 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:47:21 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:47:21 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:47:21 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:47:21 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:47:21 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:47:21 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:47:21 --> The path to the image is not correct.
ERROR - 2018-05-17 08:47:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:48:38 --> The path to the image is not correct.
ERROR - 2018-05-17 08:48:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:48:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:48:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:48:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:48:38 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:48:38 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:48:38 --> The path to the image is not correct.
ERROR - 2018-05-17 08:48:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:48:38 --> The path to the image is not correct.
ERROR - 2018-05-17 08:48:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:48:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:48:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:48:38 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:48:38 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:48:38 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:48:38 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:48:38 --> The path to the image is not correct.
ERROR - 2018-05-17 08:48:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:58:54 --> The path to the image is not correct.
ERROR - 2018-05-17 08:58:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:58:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:58:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:58:54 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:58:54 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:58:54 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-17 08:58:54 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-17 08:58:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:58:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-17 08:58:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:58:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-17 08:58:54 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-17 08:58:54 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-17 08:58:54 --> The path to the image is not correct.
ERROR - 2018-05-17 08:58:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-17 08:58:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:19 --> The path to the image is not correct.
ERROR - 2018-05-17 08:59:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:59:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:33 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:33 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:33 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:33 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:33 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:33 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:33 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:33 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:33 --> The path to the image is not correct.
ERROR - 2018-05-17 08:59:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:59:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> The path to the image is not correct.
ERROR - 2018-05-17 08:59:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:59:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> The path to the image is not correct.
ERROR - 2018-05-17 08:59:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:59:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:34 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> The path to the image is not correct.
ERROR - 2018-05-17 08:59:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:59:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> The path to the image is not correct.
ERROR - 2018-05-17 08:59:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:59:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> The path to the image is not correct.
ERROR - 2018-05-17 08:59:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:59:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> Severity: Notice --> Undefined property: stdClass::$checklist D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 159
ERROR - 2018-05-17 08:59:35 --> The path to the image is not correct.
ERROR - 2018-05-17 08:59:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:59:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:43 --> The path to the image is not correct.
ERROR - 2018-05-17 08:59:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 08:59:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 08:59:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:28:15 --> The path to the image is not correct.
ERROR - 2018-05-17 09:28:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:28:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:28:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:28:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:51 --> The path to the image is not correct.
ERROR - 2018-05-17 09:29:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:29:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:52 --> The path to the image is not correct.
ERROR - 2018-05-17 09:29:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:29:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:53 --> The path to the image is not correct.
ERROR - 2018-05-17 09:29:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:29:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:54 --> The path to the image is not correct.
ERROR - 2018-05-17 09:29:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:29:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:55 --> The path to the image is not correct.
ERROR - 2018-05-17 09:29:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:29:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:29:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:07 --> The path to the image is not correct.
ERROR - 2018-05-17 09:30:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:30:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:21 --> The path to the image is not correct.
ERROR - 2018-05-17 09:30:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:30:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:44 --> The path to the image is not correct.
ERROR - 2018-05-17 09:30:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:30:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:46 --> The path to the image is not correct.
ERROR - 2018-05-17 09:30:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:30:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:52 --> The path to the image is not correct.
ERROR - 2018-05-17 09:30:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:30:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:59 --> The path to the image is not correct.
ERROR - 2018-05-17 09:30:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:30:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:30:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:33:31 --> The path to the image is not correct.
ERROR - 2018-05-17 09:33:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:33:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:33:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:33:31 --> The path to the image is not correct.
ERROR - 2018-05-17 09:33:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:42:20 --> The path to the image is not correct.
ERROR - 2018-05-17 09:42:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:42:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:42:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:42:20 --> The path to the image is not correct.
ERROR - 2018-05-17 09:42:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:45:16 --> The path to the image is not correct.
ERROR - 2018-05-17 09:45:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:45:16 --> The path to the image is not correct.
ERROR - 2018-05-17 09:45:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:45:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:45:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:45:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:45:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:45:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:46:04 --> The path to the image is not correct.
ERROR - 2018-05-17 09:46:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:46:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:46:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:46:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:46:05 --> The path to the image is not correct.
ERROR - 2018-05-17 09:46:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:46:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:46:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:46:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-17 09:46:54 --> The path to the image is not correct.
ERROR - 2018-05-17 09:46:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:46:54 --> The path to the image is not correct.
ERROR - 2018-05-17 09:46:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:46:58 --> The path to the image is not correct.
ERROR - 2018-05-17 09:46:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:47:03 --> The path to the image is not correct.
ERROR - 2018-05-17 09:47:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:47:03 --> The path to the image is not correct.
ERROR - 2018-05-17 09:47:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:47:48 --> The path to the image is not correct.
ERROR - 2018-05-17 09:47:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:47:48 --> The path to the image is not correct.
ERROR - 2018-05-17 09:47:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:48:03 --> The path to the image is not correct.
ERROR - 2018-05-17 09:48:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:48:03 --> The path to the image is not correct.
ERROR - 2018-05-17 09:48:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:48:03 --> The path to the image is not correct.
ERROR - 2018-05-17 09:48:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:48:03 --> The path to the image is not correct.
ERROR - 2018-05-17 09:48:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:48:04 --> The path to the image is not correct.
ERROR - 2018-05-17 09:48:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:48:04 --> The path to the image is not correct.
ERROR - 2018-05-17 09:48:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:48:04 --> The path to the image is not correct.
ERROR - 2018-05-17 09:48:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:48:04 --> The path to the image is not correct.
ERROR - 2018-05-17 09:48:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:48:14 --> The path to the image is not correct.
ERROR - 2018-05-17 09:48:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:48:14 --> The path to the image is not correct.
ERROR - 2018-05-17 09:48:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:53:41 --> The path to the image is not correct.
ERROR - 2018-05-17 09:53:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:53:41 --> The path to the image is not correct.
ERROR - 2018-05-17 09:53:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:54:27 --> The path to the image is not correct.
ERROR - 2018-05-17 09:54:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:54:27 --> The path to the image is not correct.
ERROR - 2018-05-17 09:54:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 09:54:44 --> The path to the image is not correct.
ERROR - 2018-05-17 09:54:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:02:09 --> The path to the image is not correct.
ERROR - 2018-05-17 10:02:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:02:32 --> The path to the image is not correct.
ERROR - 2018-05-17 10:02:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:04:14 --> The path to the image is not correct.
ERROR - 2018-05-17 10:04:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:05:06 --> The path to the image is not correct.
ERROR - 2018-05-17 10:05:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:21:27 --> The path to the image is not correct.
ERROR - 2018-05-17 10:21:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:21:27 --> The path to the image is not correct.
ERROR - 2018-05-17 10:21:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:21:30 --> The path to the image is not correct.
ERROR - 2018-05-17 10:21:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:22:55 --> The path to the image is not correct.
ERROR - 2018-05-17 10:22:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:33 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:34 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:34 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:35 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:35 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:35 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:35 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:35 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:36 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:36 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:36 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:36 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:36 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:37 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:37 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:39 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:23:40 --> The path to the image is not correct.
ERROR - 2018-05-17 10:23:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:24:57 --> The path to the image is not correct.
ERROR - 2018-05-17 10:24:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 10:25:19 --> The path to the image is not correct.
ERROR - 2018-05-17 10:25:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:25:08 --> The path to the image is not correct.
ERROR - 2018-05-17 11:25:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:25:08 --> The path to the image is not correct.
ERROR - 2018-05-17 11:25:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:25:11 --> The path to the image is not correct.
ERROR - 2018-05-17 11:25:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:25:11 --> The path to the image is not correct.
ERROR - 2018-05-17 11:25:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:32:34 --> The path to the image is not correct.
ERROR - 2018-05-17 11:32:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:32:44 --> The path to the image is not correct.
ERROR - 2018-05-17 11:32:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:33:52 --> The path to the image is not correct.
ERROR - 2018-05-17 11:33:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:33:56 --> The path to the image is not correct.
ERROR - 2018-05-17 11:33:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:36:19 --> The path to the image is not correct.
ERROR - 2018-05-17 11:36:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:36:20 --> The path to the image is not correct.
ERROR - 2018-05-17 11:36:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:36:21 --> The path to the image is not correct.
ERROR - 2018-05-17 11:36:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:36:21 --> The path to the image is not correct.
ERROR - 2018-05-17 11:36:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:36:21 --> The path to the image is not correct.
ERROR - 2018-05-17 11:36:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-17 11:36:35 --> The path to the image is not correct.
ERROR - 2018-05-17 11:36:35 --> Your server does not support the GD function required to process this type of image.

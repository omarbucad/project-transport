<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-01 04:35:31 --> 404 Page Not Found: Public/upload
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-01 04:35:31 --> 404 Page Not Found: Public/upload
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-01 04:35:31 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-01 04:35:31 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-01 04:35:31 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-01 07:14:29 --> Severity: Notice --> Undefined property: stdClass::$user D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 71
ERROR - 2018-08-01 07:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 71
ERROR - 2018-08-01 07:14:29 --> Severity: Notice --> Undefined property: stdClass::$user D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 83
ERROR - 2018-08-01 07:14:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 83
ERROR - 2018-08-01 07:14:29 --> Severity: Notice --> Undefined property: stdClass::$checklist_type D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 86
ERROR - 2018-08-01 07:14:29 --> Severity: Notice --> Undefined property: stdClass::$start_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 87
ERROR - 2018-08-01 07:14:29 --> Severity: Notice --> Undefined property: stdClass::$end_mileage D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 88
ERROR - 2018-08-01 07:14:29 --> Query error: Column 'report_by' cannot be null - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES (NULL, '', '', NULL, NULL, NULL, '', 1533100469, NULL, 0)
ERROR - 2018-08-01 07:14:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570

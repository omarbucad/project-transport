<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-10 05:15:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:15:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:15:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:15:42 --> The path to the image is not correct.
ERROR - 2018-04-10 05:15:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:15:45 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 88
ERROR - 2018-04-10 05:16:14 --> The path to the image is not correct.
ERROR - 2018-04-10 05:16:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:16:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:16:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:16:16 --> The path to the image is not correct.
ERROR - 2018-04-10 05:16:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:16:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:16:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:16:22 --> The path to the image is not correct.
ERROR - 2018-04-10 05:16:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:16:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:16:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:17:02 --> The path to the image is not correct.
ERROR - 2018-04-10 05:17:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:17:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:17:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:17:31 --> The path to the image is not correct.
ERROR - 2018-04-10 05:17:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:17:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:17:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:17:46 --> The path to the image is not correct.
ERROR - 2018-04-10 05:17:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:17:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:17:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:19:45 --> The path to the image is not correct.
ERROR - 2018-04-10 05:19:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:19:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:19:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:19:54 --> The path to the image is not correct.
ERROR - 2018-04-10 05:19:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:19:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:19:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:20:18 --> The path to the image is not correct.
ERROR - 2018-04-10 05:20:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:20:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:20:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:20:53 --> The path to the image is not correct.
ERROR - 2018-04-10 05:20:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:20:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:20:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:21:41 --> The path to the image is not correct.
ERROR - 2018-04-10 05:21:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:21:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:21:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:13 --> The path to the image is not correct.
ERROR - 2018-04-10 05:22:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:22:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:15 --> The path to the image is not correct.
ERROR - 2018-04-10 05:22:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:22:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:18 --> The path to the image is not correct.
ERROR - 2018-04-10 05:22:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:22:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:20 --> The path to the image is not correct.
ERROR - 2018-04-10 05:22:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:22:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:24 --> The path to the image is not correct.
ERROR - 2018-04-10 05:22:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:22:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:22:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:23:37 --> The path to the image is not correct.
ERROR - 2018-04-10 05:23:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:23:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:23:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:23:38 --> The path to the image is not correct.
ERROR - 2018-04-10 05:23:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:23:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:23:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:23:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:24:15 --> The path to the image is not correct.
ERROR - 2018-04-10 05:24:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:24:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:24:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:24:16 --> The path to the image is not correct.
ERROR - 2018-04-10 05:24:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:24:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:24:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:24:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:25:56 --> The path to the image is not correct.
ERROR - 2018-04-10 05:25:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:25:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:25:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:25:57 --> The path to the image is not correct.
ERROR - 2018-04-10 05:25:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:25:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:25:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:25:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:27 --> The path to the image is not correct.
ERROR - 2018-04-10 05:26:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:26:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:28 --> The path to the image is not correct.
ERROR - 2018-04-10 05:26:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:26:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:30 --> The path to the image is not correct.
ERROR - 2018-04-10 05:26:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:26:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:45 --> The path to the image is not correct.
ERROR - 2018-04-10 05:26:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:26:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:26:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:27:44 --> The path to the image is not correct.
ERROR - 2018-04-10 05:27:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:27:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:27:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:27:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:27:59 --> The path to the image is not correct.
ERROR - 2018-04-10 05:27:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:27:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:27:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:27:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:28:09 --> The path to the image is not correct.
ERROR - 2018-04-10 05:28:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:28:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:28:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:28:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:28:23 --> The path to the image is not correct.
ERROR - 2018-04-10 05:28:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:28:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:28:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:28:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:28:51 --> The path to the image is not correct.
ERROR - 2018-04-10 05:28:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:28:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:28:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:28:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:29:06 --> The path to the image is not correct.
ERROR - 2018-04-10 05:29:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:29:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:29:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:29:20 --> 404 Page Not Found: app/Report/view
ERROR - 2018-04-10 05:29:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:29:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:29:27 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-10 05:29:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:29:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:30:01 --> The path to the image is not correct.
ERROR - 2018-04-10 05:30:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:30:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:30:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:33:03 --> The path to the image is not correct.
ERROR - 2018-04-10 05:33:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:33:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:33:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:33:25 --> The path to the image is not correct.
ERROR - 2018-04-10 05:33:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:33:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:33:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:33:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:33:32 --> The path to the image is not correct.
ERROR - 2018-04-10 05:33:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:33:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:33:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:33:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:34:02 --> The path to the image is not correct.
ERROR - 2018-04-10 05:34:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:34:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:34:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:34:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:22 --> The path to the image is not correct.
ERROR - 2018-04-10 05:36:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:36:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:28 --> The path to the image is not correct.
ERROR - 2018-04-10 05:36:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:36:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:48 --> The path to the image is not correct.
ERROR - 2018-04-10 05:36:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:36:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:54 --> The path to the image is not correct.
ERROR - 2018-04-10 05:36:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:36:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:36:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:43 --> The path to the image is not correct.
ERROR - 2018-04-10 05:37:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:37:45 --> The path to the image is not correct.
ERROR - 2018-04-10 05:37:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:37:46 --> The path to the image is not correct.
ERROR - 2018-04-10 05:37:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:37:46 --> The path to the image is not correct.
ERROR - 2018-04-10 05:37:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:37:47 --> The path to the image is not correct.
ERROR - 2018-04-10 05:37:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:37:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:57 --> The path to the image is not correct.
ERROR - 2018-04-10 05:37:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:37:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:57 --> The path to the image is not correct.
ERROR - 2018-04-10 05:37:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:37:58 --> The path to the image is not correct.
ERROR - 2018-04-10 05:37:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:37:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:58 --> The path to the image is not correct.
ERROR - 2018-04-10 05:37:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:37:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:37:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:38:04 --> The path to the image is not correct.
ERROR - 2018-04-10 05:38:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:38:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:38:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:38:09 --> The path to the image is not correct.
ERROR - 2018-04-10 05:38:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:38:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:38:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:38:21 --> The path to the image is not correct.
ERROR - 2018-04-10 05:38:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:38:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:38:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:40:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:40:35 --> The path to the image is not correct.
ERROR - 2018-04-10 05:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:40:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:40:37 --> The path to the image is not correct.
ERROR - 2018-04-10 05:40:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:40:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:40:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:40:39 --> The path to the image is not correct.
ERROR - 2018-04-10 05:40:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:40:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:40:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:40:42 --> The path to the image is not correct.
ERROR - 2018-04-10 05:40:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:40:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:40:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:40:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:43:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:43:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:43:12 --> The path to the image is not correct.
ERROR - 2018-04-10 05:43:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:43:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:44:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:44:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:44:11 --> The path to the image is not correct.
ERROR - 2018-04-10 05:44:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:44:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:44:28 --> The path to the image is not correct.
ERROR - 2018-04-10 05:44:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:44:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:44:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:44:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:44:33 --> The path to the image is not correct.
ERROR - 2018-04-10 05:44:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:44:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:44:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:37 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:38 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:39 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:39 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:39 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:39 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:40 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:40 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:40 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:40 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:41 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:41 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:41 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:46 --> The path to the image is not correct.
ERROR - 2018-04-10 05:45:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:01 --> The path to the image is not correct.
ERROR - 2018-04-10 05:46:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:46:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:05 --> The path to the image is not correct.
ERROR - 2018-04-10 05:46:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:46:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:11 --> The path to the image is not correct.
ERROR - 2018-04-10 05:46:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:46:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:12 --> The path to the image is not correct.
ERROR - 2018-04-10 05:46:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:46:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:19 --> The path to the image is not correct.
ERROR - 2018-04-10 05:46:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:46:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:46:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:48:14 --> The path to the image is not correct.
ERROR - 2018-04-10 05:48:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:48:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:48:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:09 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:18 --> Severity: Notice --> Undefined property: Vehicle::$category D:\xampp\htdocs\project-transport\application\controllers\app\Vehicle.php 108
ERROR - 2018-04-10 05:55:18 --> Severity: Error --> Call to a member function delete_trailer() on null D:\xampp\htdocs\project-transport\application\controllers\app\Vehicle.php 108
ERROR - 2018-04-10 05:55:46 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:48 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:49 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:49 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:50 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:50 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:50 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:50 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:51 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:51 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:51 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:51 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:52 --> The path to the image is not correct.
ERROR - 2018-04-10 05:55:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:55:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:55:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:56:26 --> The path to the image is not correct.
ERROR - 2018-04-10 05:56:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:56:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:56:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:56:33 --> The path to the image is not correct.
ERROR - 2018-04-10 05:56:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 05:56:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 05:56:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:13:50 --> The path to the image is not correct.
ERROR - 2018-04-10 06:13:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:13:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:13:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:14:41 --> The path to the image is not correct.
ERROR - 2018-04-10 06:14:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:14:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:14:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:14:44 --> The path to the image is not correct.
ERROR - 2018-04-10 06:14:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:14:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:14:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:14:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:14:47 --> The path to the image is not correct.
ERROR - 2018-04-10 06:14:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:14:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:14:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:20:18 --> The path to the image is not correct.
ERROR - 2018-04-10 06:20:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:20:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:20:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:20:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:20:20 --> The path to the image is not correct.
ERROR - 2018-04-10 06:20:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:20:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:20:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:20:24 --> The path to the image is not correct.
ERROR - 2018-04-10 06:20:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:20:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:20:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:20:25 --> The path to the image is not correct.
ERROR - 2018-04-10 06:20:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:20:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:20:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:21:35 --> 404 Page Not Found: app/Product/tags
ERROR - 2018-04-10 06:21:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:21:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:21:46 --> The path to the image is not correct.
ERROR - 2018-04-10 06:21:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:21:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:21:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:21:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:22:05 --> The path to the image is not correct.
ERROR - 2018-04-10 06:22:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:22:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:22:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:22:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:22:39 --> The path to the image is not correct.
ERROR - 2018-04-10 06:22:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:22:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:22:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:22:44 --> The path to the image is not correct.
ERROR - 2018-04-10 06:22:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:22:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:22:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:23:36 --> The path to the image is not correct.
ERROR - 2018-04-10 06:23:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:23:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:23:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:14 --> The path to the image is not correct.
ERROR - 2018-04-10 06:24:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:24:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:14 --> The path to the image is not correct.
ERROR - 2018-04-10 06:24:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:24:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:15 --> The path to the image is not correct.
ERROR - 2018-04-10 06:24:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:24:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:17 --> The path to the image is not correct.
ERROR - 2018-04-10 06:24:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:24:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:27 --> The path to the image is not correct.
ERROR - 2018-04-10 06:24:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:24:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:30 --> The path to the image is not correct.
ERROR - 2018-04-10 06:24:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:24:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:24:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:25:12 --> The path to the image is not correct.
ERROR - 2018-04-10 06:25:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:25:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:25:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:25:13 --> The path to the image is not correct.
ERROR - 2018-04-10 06:25:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:25:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:25:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:25:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:25:16 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:29:45 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:29:46 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:30:58 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:00 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:00 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:00 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:00 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:01 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:01 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:02 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:02 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:02 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:03 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:03 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:04 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:04 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:04 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:05 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:05 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:05 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:06 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:06 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:31:12 --> The path to the image is not correct.
ERROR - 2018-04-10 06:31:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:31:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:14 --> The path to the image is not correct.
ERROR - 2018-04-10 06:31:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:31:30 --> The path to the image is not correct.
ERROR - 2018-04-10 06:31:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:31:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:36 --> The path to the image is not correct.
ERROR - 2018-04-10 06:31:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:31:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:38 --> The path to the image is not correct.
ERROR - 2018-04-10 06:31:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:31:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:31:42 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:32:41 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:32:42 --> Query error: Unknown column 'vahicle_registration_number' in 'field list' - Invalid query: UPDATE `vehicle` SET `vahicle_registration_number` = NULL, `status` = '1', `description` = '<p>Test 22</p>'
WHERE `vehicle_id` = '2'
ERROR - 2018-04-10 06:33:25 --> The path to the image is not correct.
ERROR - 2018-04-10 06:33:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:33:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:33:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:33:28 --> The path to the image is not correct.
ERROR - 2018-04-10 06:33:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:33:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:33:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:33:32 --> The path to the image is not correct.
ERROR - 2018-04-10 06:33:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:33:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:33:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:37:17 --> Severity: Error --> Call to undefined method MY_Input::pot() D:\xampp\htdocs\project-transport\application\models\Vehicle_model.php 11
ERROR - 2018-04-10 06:37:26 --> The path to the image is not correct.
ERROR - 2018-04-10 06:37:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:37:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:37:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:38:23 --> The path to the image is not correct.
ERROR - 2018-04-10 06:38:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:38:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:38:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:41:32 --> The path to the image is not correct.
ERROR - 2018-04-10 06:41:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:41:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:41:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:41:36 --> The path to the image is not correct.
ERROR - 2018-04-10 06:41:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:42:03 --> The path to the image is not correct.
ERROR - 2018-04-10 06:42:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:42:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:42:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:42:07 --> The path to the image is not correct.
ERROR - 2018-04-10 06:42:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:42:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:42:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:42:11 --> The path to the image is not correct.
ERROR - 2018-04-10 06:42:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:42:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:42:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:42:16 --> The path to the image is not correct.
ERROR - 2018-04-10 06:42:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:42:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:42:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:42:44 --> The path to the image is not correct.
ERROR - 2018-04-10 06:42:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:42:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:42:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:43:59 --> The path to the image is not correct.
ERROR - 2018-04-10 06:43:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:43:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:43:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:43:59 --> The path to the image is not correct.
ERROR - 2018-04-10 06:43:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:43:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:43:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:44:02 --> The path to the image is not correct.
ERROR - 2018-04-10 06:44:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:44:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:44:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:44:05 --> The path to the image is not correct.
ERROR - 2018-04-10 06:44:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:44:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:44:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:45:25 --> The path to the image is not correct.
ERROR - 2018-04-10 06:45:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:45:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:45:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:46:33 --> The path to the image is not correct.
ERROR - 2018-04-10 06:46:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:46:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:46:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:48:44 --> The path to the image is not correct.
ERROR - 2018-04-10 06:48:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:48:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:48:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:48:51 --> The path to the image is not correct.
ERROR - 2018-04-10 06:48:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:48:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:48:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:49:11 --> The path to the image is not correct.
ERROR - 2018-04-10 06:49:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:49:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:49:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:49:33 --> The path to the image is not correct.
ERROR - 2018-04-10 06:49:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:49:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:49:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:49:40 --> The path to the image is not correct.
ERROR - 2018-04-10 06:49:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:49:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:49:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:49:50 --> The path to the image is not correct.
ERROR - 2018-04-10 06:49:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:49:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:49:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:49:54 --> The path to the image is not correct.
ERROR - 2018-04-10 06:49:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:50:15 --> The path to the image is not correct.
ERROR - 2018-04-10 06:50:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:50:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:50:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:50:17 --> The path to the image is not correct.
ERROR - 2018-04-10 06:50:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:50:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:50:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:50:21 --> The path to the image is not correct.
ERROR - 2018-04-10 06:50:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:50:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:50:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:50:24 --> The path to the image is not correct.
ERROR - 2018-04-10 06:50:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:50:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:50:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:50:28 --> The path to the image is not correct.
ERROR - 2018-04-10 06:50:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:50:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:50:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:06 --> The path to the image is not correct.
ERROR - 2018-04-10 06:53:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:53:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:12 --> The path to the image is not correct.
ERROR - 2018-04-10 06:53:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:53:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:18 --> The path to the image is not correct.
ERROR - 2018-04-10 06:53:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:53:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:23 --> The path to the image is not correct.
ERROR - 2018-04-10 06:53:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:53:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:40 --> The path to the image is not correct.
ERROR - 2018-04-10 06:53:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:53:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:42 --> The path to the image is not correct.
ERROR - 2018-04-10 06:53:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:53:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:47 --> The path to the image is not correct.
ERROR - 2018-04-10 06:53:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:53:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:49 --> The path to the image is not correct.
ERROR - 2018-04-10 06:53:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:53:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:53 --> The path to the image is not correct.
ERROR - 2018-04-10 06:53:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:53:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:53:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:54:09 --> The path to the image is not correct.
ERROR - 2018-04-10 06:54:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:54:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:54:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:54:16 --> The path to the image is not correct.
ERROR - 2018-04-10 06:54:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:54:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:54:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:57:38 --> The path to the image is not correct.
ERROR - 2018-04-10 06:57:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:57:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:57:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:57:44 --> The path to the image is not correct.
ERROR - 2018-04-10 06:57:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:57:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:57:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:18 --> The path to the image is not correct.
ERROR - 2018-04-10 06:58:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:58:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:20 --> The path to the image is not correct.
ERROR - 2018-04-10 06:58:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:58:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:20 --> The path to the image is not correct.
ERROR - 2018-04-10 06:58:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:58:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:20 --> The path to the image is not correct.
ERROR - 2018-04-10 06:58:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:58:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:36 --> The path to the image is not correct.
ERROR - 2018-04-10 06:58:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:58:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:37 --> The path to the image is not correct.
ERROR - 2018-04-10 06:58:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:58:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:39 --> The path to the image is not correct.
ERROR - 2018-04-10 06:58:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:58:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:39 --> The path to the image is not correct.
ERROR - 2018-04-10 06:58:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:58:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:42 --> The path to the image is not correct.
ERROR - 2018-04-10 06:58:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 06:58:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 06:58:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:18:15 --> The path to the image is not correct.
ERROR - 2018-04-10 07:18:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 07:18:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:18:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:18:21 --> 404 Page Not Found: app/Setup/profile
ERROR - 2018-04-10 07:25:34 --> The path to the image is not correct.
ERROR - 2018-04-10 07:25:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 07:25:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:25:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:25:38 --> The path to the image is not correct.
ERROR - 2018-04-10 07:25:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:25:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:25:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 07:46:39 --> 404 Page Not Found: app/Setup/profile
ERROR - 2018-04-10 07:47:19 --> The path to the image is not correct.
ERROR - 2018-04-10 07:47:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 07:47:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:47:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:47:22 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:08 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:09 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:09 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:09 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:09 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:10 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:10 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:10 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:10 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:46 --> The path to the image is not correct.
ERROR - 2018-04-10 07:50:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 07:50:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:50:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:50:51 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:50:54 --> 404 Page Not Found: app/Checklist/index
ERROR - 2018-04-10 07:52:58 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:53:03 --> The path to the image is not correct.
ERROR - 2018-04-10 07:53:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 07:53:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:53:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:53:05 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:53:32 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:54:42 --> Severity: Notice --> Undefined property: Setup::$vehicle D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 14
ERROR - 2018-04-10 07:54:42 --> Severity: Error --> Call to a member function get_checklist_list() on null D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 14
ERROR - 2018-04-10 07:55:02 --> The path to the image is not correct.
ERROR - 2018-04-10 07:55:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 07:55:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:55:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:55:29 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:55:30 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:55:31 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:55:47 --> 404 Page Not Found: app/Setup/checklist
ERROR - 2018-04-10 07:56:16 --> The path to the image is not correct.
ERROR - 2018-04-10 07:56:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 07:56:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 07:56:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:17:58 --> The path to the image is not correct.
ERROR - 2018-04-10 08:17:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:17:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:17:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:20:17 --> The path to the image is not correct.
ERROR - 2018-04-10 08:20:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:20:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:20:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:23:00 --> The path to the image is not correct.
ERROR - 2018-04-10 08:23:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:23:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:23:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:26:57 --> The path to the image is not correct.
ERROR - 2018-04-10 08:26:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:26:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:26:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:27:57 --> The path to the image is not correct.
ERROR - 2018-04-10 08:27:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:27:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 08:27:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:29:19 --> The path to the image is not correct.
ERROR - 2018-04-10 08:29:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:29:22 --> The path to the image is not correct.
ERROR - 2018-04-10 08:29:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:31:43 --> The path to the image is not correct.
ERROR - 2018-04-10 08:31:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:34:43 --> The path to the image is not correct.
ERROR - 2018-04-10 08:34:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:37:03 --> The path to the image is not correct.
ERROR - 2018-04-10 08:37:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:37:42 --> The path to the image is not correct.
ERROR - 2018-04-10 08:37:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:37:44 --> The path to the image is not correct.
ERROR - 2018-04-10 08:37:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:38:40 --> The path to the image is not correct.
ERROR - 2018-04-10 08:38:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:39:47 --> The path to the image is not correct.
ERROR - 2018-04-10 08:39:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:40:15 --> The path to the image is not correct.
ERROR - 2018-04-10 08:40:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:44:06 --> The path to the image is not correct.
ERROR - 2018-04-10 08:44:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:44:42 --> The path to the image is not correct.
ERROR - 2018-04-10 08:44:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:44:54 --> The path to the image is not correct.
ERROR - 2018-04-10 08:44:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:48:53 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 13
ERROR - 2018-04-10 08:48:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 13
ERROR - 2018-04-10 08:48:53 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 13
ERROR - 2018-04-10 08:48:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 13
ERROR - 2018-04-10 08:48:53 --> The path to the image is not correct.
ERROR - 2018-04-10 08:48:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 13
ERROR - 2018-04-10 08:50:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 13
ERROR - 2018-04-10 08:50:31 --> The path to the image is not correct.
ERROR - 2018-04-10 08:50:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:51:08 --> The path to the image is not correct.
ERROR - 2018-04-10 08:51:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:52:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 35
ERROR - 2018-04-10 08:52:06 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 35
ERROR - 2018-04-10 08:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 35
ERROR - 2018-04-10 08:56:47 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 35
ERROR - 2018-04-10 08:56:47 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 13
ERROR - 2018-04-10 08:56:47 --> The path to the image is not correct.
ERROR - 2018-04-10 08:56:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 08:57:03 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 33
ERROR - 2018-04-10 08:58:35 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 33
ERROR - 2018-04-10 09:00:57 --> The path to the image is not correct.
ERROR - 2018-04-10 09:00:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:01:19 --> The path to the image is not correct.
ERROR - 2018-04-10 09:01:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:02:28 --> The path to the image is not correct.
ERROR - 2018-04-10 09:02:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:02:41 --> The path to the image is not correct.
ERROR - 2018-04-10 09:02:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:02:54 --> The path to the image is not correct.
ERROR - 2018-04-10 09:02:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:03:02 --> The path to the image is not correct.
ERROR - 2018-04-10 09:03:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:03:25 --> The path to the image is not correct.
ERROR - 2018-04-10 09:03:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:03:31 --> The path to the image is not correct.
ERROR - 2018-04-10 09:03:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:03:40 --> The path to the image is not correct.
ERROR - 2018-04-10 09:03:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:03:51 --> The path to the image is not correct.
ERROR - 2018-04-10 09:03:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:04:51 --> The path to the image is not correct.
ERROR - 2018-04-10 09:04:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:05:05 --> The path to the image is not correct.
ERROR - 2018-04-10 09:05:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:05:12 --> The path to the image is not correct.
ERROR - 2018-04-10 09:05:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:05:23 --> The path to the image is not correct.
ERROR - 2018-04-10 09:05:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:05:35 --> The path to the image is not correct.
ERROR - 2018-04-10 09:05:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:05:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:05:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:05:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:06:38 --> The path to the image is not correct.
ERROR - 2018-04-10 09:06:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:06:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:06:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:06:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:07:04 --> The path to the image is not correct.
ERROR - 2018-04-10 09:07:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:07:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:07:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:07:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:07:31 --> The path to the image is not correct.
ERROR - 2018-04-10 09:07:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:07:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:07:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:07:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:10:59 --> The path to the image is not correct.
ERROR - 2018-04-10 09:10:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:11:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:11:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:11:17 --> The path to the image is not correct.
ERROR - 2018-04-10 09:11:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:11:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:11:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:13:31 --> The path to the image is not correct.
ERROR - 2018-04-10 09:13:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:13:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:13:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:14:01 --> The path to the image is not correct.
ERROR - 2018-04-10 09:14:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:14:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:14:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:15:05 --> The path to the image is not correct.
ERROR - 2018-04-10 09:15:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:15:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:15:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:15:40 --> The path to the image is not correct.
ERROR - 2018-04-10 09:15:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:15:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:15:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:16:16 --> The path to the image is not correct.
ERROR - 2018-04-10 09:16:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:16:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:16:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:16:32 --> The path to the image is not correct.
ERROR - 2018-04-10 09:16:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:16:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:16:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:17:48 --> 404 Page Not Found: app/Products/index
ERROR - 2018-04-10 09:17:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:17:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:18:37 --> The path to the image is not correct.
ERROR - 2018-04-10 09:18:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:18:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:18:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:18:46 --> The path to the image is not correct.
ERROR - 2018-04-10 09:18:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:18:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:18:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:20:04 --> The path to the image is not correct.
ERROR - 2018-04-10 09:20:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:20:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:20:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:20:08 --> The path to the image is not correct.
ERROR - 2018-04-10 09:20:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:20:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:20:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:20:54 --> The path to the image is not correct.
ERROR - 2018-04-10 09:20:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:20:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:20:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:21:48 --> The path to the image is not correct.
ERROR - 2018-04-10 09:21:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:21:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:21:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:22:02 --> The path to the image is not correct.
ERROR - 2018-04-10 09:22:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:22:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:22:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:22:48 --> The path to the image is not correct.
ERROR - 2018-04-10 09:22:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:22:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:22:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:23:19 --> The path to the image is not correct.
ERROR - 2018-04-10 09:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:23:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:23:36 --> The path to the image is not correct.
ERROR - 2018-04-10 09:23:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:23:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:23:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:23:51 --> The path to the image is not correct.
ERROR - 2018-04-10 09:23:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:23:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:23:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:24:09 --> The path to the image is not correct.
ERROR - 2018-04-10 09:24:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:24:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:24:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:27:26 --> The path to the image is not correct.
ERROR - 2018-04-10 09:27:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:27:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:27:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:27:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:27:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:27:55 --> The path to the image is not correct.
ERROR - 2018-04-10 09:27:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:37:47 --> The path to the image is not correct.
ERROR - 2018-04-10 09:37:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:37:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:37:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:39:22 --> The path to the image is not correct.
ERROR - 2018-04-10 09:39:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:39:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:39:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:39:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:39:52 --> The path to the image is not correct.
ERROR - 2018-04-10 09:39:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:39:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:49:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:49:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:51:15 --> Query error: Unknown column 'item' in 'field list' - Invalid query: INSERT INTO `checklist_items` (`checklist_id`, `item_name`, `item`) VALUES ('3', 'item1', 1)
ERROR - 2018-04-10 09:52:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 38
ERROR - 2018-04-10 09:52:20 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 38
ERROR - 2018-04-10 09:52:20 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 26
ERROR - 2018-04-10 09:52:20 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 28
ERROR - 2018-04-10 09:52:20 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 33
ERROR - 2018-04-10 09:52:20 --> The path to the image is not correct.
ERROR - 2018-04-10 09:52:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:52:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:52:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:53:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 38
ERROR - 2018-04-10 09:53:36 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 38
ERROR - 2018-04-10 09:53:36 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 26
ERROR - 2018-04-10 09:53:36 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 28
ERROR - 2018-04-10 09:53:36 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\add_item.php 33
ERROR - 2018-04-10 09:53:36 --> The path to the image is not correct.
ERROR - 2018-04-10 09:53:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:53:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:53:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:53:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:53:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:54:11 --> The path to the image is not correct.
ERROR - 2018-04-10 09:54:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:54:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:54:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:54:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:54:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:54:11 --> The path to the image is not correct.
ERROR - 2018-04-10 09:54:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:55:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:55:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:55:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:55:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:55:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:55:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:55:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:55:15 --> The path to the image is not correct.
ERROR - 2018-04-10 09:55:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:55:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:55:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:56:04 --> The path to the image is not correct.
ERROR - 2018-04-10 09:56:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:56:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:56:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:56:24 --> The path to the image is not correct.
ERROR - 2018-04-10 09:56:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:56:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:56:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:56:50 --> The path to the image is not correct.
ERROR - 2018-04-10 09:56:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:56:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:56:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:57:22 --> The path to the image is not correct.
ERROR - 2018-04-10 09:57:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:57:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:57:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:57:53 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 38
ERROR - 2018-04-10 09:59:36 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:38 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:38 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:39 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:39 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:39 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:39 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:39 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:40 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:41 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:42 --> The path to the image is not correct.
ERROR - 2018-04-10 09:59:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 09:59:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 09:59:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:00:27 --> The path to the image is not correct.
ERROR - 2018-04-10 10:00:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:00:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:00:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:00:28 --> The path to the image is not correct.
ERROR - 2018-04-10 10:00:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:00:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:00:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:00:28 --> The path to the image is not correct.
ERROR - 2018-04-10 10:00:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:00:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:00:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:00:28 --> The path to the image is not correct.
ERROR - 2018-04-10 10:00:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:00:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:00:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:00:39 --> The path to the image is not correct.
ERROR - 2018-04-10 10:00:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:00:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:00:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:01:28 --> The path to the image is not correct.
ERROR - 2018-04-10 10:01:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:01:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:01:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:01:55 --> The path to the image is not correct.
ERROR - 2018-04-10 10:01:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:01:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:01:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:03:51 --> The path to the image is not correct.
ERROR - 2018-04-10 10:03:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:03:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:03:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:03:58 --> The path to the image is not correct.
ERROR - 2018-04-10 10:03:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:03:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:03:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:06:34 --> The path to the image is not correct.
ERROR - 2018-04-10 10:06:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:06:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:06:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:07:30 --> The path to the image is not correct.
ERROR - 2018-04-10 10:07:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:07:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:07:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:09:54 --> The path to the image is not correct.
ERROR - 2018-04-10 10:09:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:09:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:09:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:09:58 --> The path to the image is not correct.
ERROR - 2018-04-10 10:09:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:09:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:09:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:10:05 --> The path to the image is not correct.
ERROR - 2018-04-10 10:10:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:10:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:10:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:10:09 --> The path to the image is not correct.
ERROR - 2018-04-10 10:10:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:10:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:10:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:11:23 --> The path to the image is not correct.
ERROR - 2018-04-10 10:11:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:11:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:11:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:11:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:11:37 --> The path to the image is not correct.
ERROR - 2018-04-10 10:11:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:11:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:11:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:11:53 --> The path to the image is not correct.
ERROR - 2018-04-10 10:11:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:11:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:11:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:12:06 --> The path to the image is not correct.
ERROR - 2018-04-10 10:12:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:12:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:12:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:13:39 --> The path to the image is not correct.
ERROR - 2018-04-10 10:13:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:13:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:13:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:13:56 --> The path to the image is not correct.
ERROR - 2018-04-10 10:13:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:13:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:13:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:14:07 --> The path to the image is not correct.
ERROR - 2018-04-10 10:14:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:14:25 --> The path to the image is not correct.
ERROR - 2018-04-10 10:14:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:14:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:14:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:14:51 --> The path to the image is not correct.
ERROR - 2018-04-10 10:14:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:14:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:14:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:15:10 --> The path to the image is not correct.
ERROR - 2018-04-10 10:15:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:15:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:15:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:15:16 --> The path to the image is not correct.
ERROR - 2018-04-10 10:15:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:15:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:15:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:15:25 --> The path to the image is not correct.
ERROR - 2018-04-10 10:15:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:15:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:15:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:17:30 --> The path to the image is not correct.
ERROR - 2018-04-10 10:17:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:17:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:17:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:20:00 --> The path to the image is not correct.
ERROR - 2018-04-10 10:20:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:20:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:20:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:20:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:20:13 --> The path to the image is not correct.
ERROR - 2018-04-10 10:20:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:20:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:20:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:20:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:20:17 --> The path to the image is not correct.
ERROR - 2018-04-10 10:20:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:20:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:20:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:20:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:23:15 --> The path to the image is not correct.
ERROR - 2018-04-10 10:23:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:23:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:23:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:23:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:24:48 --> The path to the image is not correct.
ERROR - 2018-04-10 10:24:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:24:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:24:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:24:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:24:54 --> The path to the image is not correct.
ERROR - 2018-04-10 10:24:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:24:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:24:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:24:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:25:16 --> The path to the image is not correct.
ERROR - 2018-04-10 10:25:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:25:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:25:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:25:48 --> The path to the image is not correct.
ERROR - 2018-04-10 10:25:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:25:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:25:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:26:04 --> The path to the image is not correct.
ERROR - 2018-04-10 10:26:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:26:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:26:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:27:20 --> The path to the image is not correct.
ERROR - 2018-04-10 10:27:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:27:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:27:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:27:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:36:29 --> The path to the image is not correct.
ERROR - 2018-04-10 10:36:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:36:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:36:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:38:31 --> The path to the image is not correct.
ERROR - 2018-04-10 10:38:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:38:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:38:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:39:09 --> The path to the image is not correct.
ERROR - 2018-04-10 10:39:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:39:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:39:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:39:42 --> The path to the image is not correct.
ERROR - 2018-04-10 10:39:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:39:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:39:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:40:04 --> The path to the image is not correct.
ERROR - 2018-04-10 10:40:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:40:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:40:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:40:45 --> The path to the image is not correct.
ERROR - 2018-04-10 10:40:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:40:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:40:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:41:33 --> The path to the image is not correct.
ERROR - 2018-04-10 10:41:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:41:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:41:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:41:49 --> The path to the image is not correct.
ERROR - 2018-04-10 10:41:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:41:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:41:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:42:50 --> The path to the image is not correct.
ERROR - 2018-04-10 10:42:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:42:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:42:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:43:04 --> The path to the image is not correct.
ERROR - 2018-04-10 10:43:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:43:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:43:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:43:48 --> The path to the image is not correct.
ERROR - 2018-04-10 10:43:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:43:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:43:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:44:16 --> The path to the image is not correct.
ERROR - 2018-04-10 10:44:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:44:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:44:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:45:23 --> The path to the image is not correct.
ERROR - 2018-04-10 10:45:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:45:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:45:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:45:49 --> The path to the image is not correct.
ERROR - 2018-04-10 10:45:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:45:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:45:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:46:24 --> The path to the image is not correct.
ERROR - 2018-04-10 10:46:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:46:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:46:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:46:31 --> The path to the image is not correct.
ERROR - 2018-04-10 10:46:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:46:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:46:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:46:51 --> The path to the image is not correct.
ERROR - 2018-04-10 10:46:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:46:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:46:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:48:05 --> The path to the image is not correct.
ERROR - 2018-04-10 10:48:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:48:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:48:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:48:30 --> The path to the image is not correct.
ERROR - 2018-04-10 10:48:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:48:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:48:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:49:04 --> The path to the image is not correct.
ERROR - 2018-04-10 10:49:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:49:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:49:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:49:13 --> The path to the image is not correct.
ERROR - 2018-04-10 10:49:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:49:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:49:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:49:27 --> The path to the image is not correct.
ERROR - 2018-04-10 10:49:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:49:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:49:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:50:07 --> The path to the image is not correct.
ERROR - 2018-04-10 10:50:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:50:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:50:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:50:58 --> The path to the image is not correct.
ERROR - 2018-04-10 10:50:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:50:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:50:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:51:03 --> The path to the image is not correct.
ERROR - 2018-04-10 10:51:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:51:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:51:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:51:37 --> The path to the image is not correct.
ERROR - 2018-04-10 10:51:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:51:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:51:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:52:11 --> The path to the image is not correct.
ERROR - 2018-04-10 10:52:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:52:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:52:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:52:39 --> The path to the image is not correct.
ERROR - 2018-04-10 10:52:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:52:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:52:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:53:04 --> The path to the image is not correct.
ERROR - 2018-04-10 10:53:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:53:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:53:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:53:11 --> The path to the image is not correct.
ERROR - 2018-04-10 10:53:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:53:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:53:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:53:24 --> The path to the image is not correct.
ERROR - 2018-04-10 10:53:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:53:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:53:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:53:32 --> The path to the image is not correct.
ERROR - 2018-04-10 10:53:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:53:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:53:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:53:41 --> The path to the image is not correct.
ERROR - 2018-04-10 10:53:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:53:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:53:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:54:08 --> The path to the image is not correct.
ERROR - 2018-04-10 10:54:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:54:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:54:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:54:20 --> The path to the image is not correct.
ERROR - 2018-04-10 10:54:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:54:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:54:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:54:37 --> The path to the image is not correct.
ERROR - 2018-04-10 10:54:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:54:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:54:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:55:45 --> The path to the image is not correct.
ERROR - 2018-04-10 10:55:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:55:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:55:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:56:12 --> The path to the image is not correct.
ERROR - 2018-04-10 10:56:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 10:56:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 10:56:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:00:57 --> The path to the image is not correct.
ERROR - 2018-04-10 11:00:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:00:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:00:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:03:05 --> The path to the image is not correct.
ERROR - 2018-04-10 11:03:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:03:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:03:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:03:27 --> The path to the image is not correct.
ERROR - 2018-04-10 11:03:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:03:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:03:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:03:52 --> The path to the image is not correct.
ERROR - 2018-04-10 11:03:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:03:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:03:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:04:37 --> The path to the image is not correct.
ERROR - 2018-04-10 11:04:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:04:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:04:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:07:09 --> The path to the image is not correct.
ERROR - 2018-04-10 11:07:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:07:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:07:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:07:22 --> The path to the image is not correct.
ERROR - 2018-04-10 11:07:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:07:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:07:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:07:49 --> The path to the image is not correct.
ERROR - 2018-04-10 11:07:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:07:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:07:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:08:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:08:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:13:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:13:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:13:04 --> The path to the image is not correct.
ERROR - 2018-04-10 11:13:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:13:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:13:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:13:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:13:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:13:36 --> The path to the image is not correct.
ERROR - 2018-04-10 11:13:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:13:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:13:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:22:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:22:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:22:56 --> The path to the image is not correct.
ERROR - 2018-04-10 11:22:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:22:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:22:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:23:00 --> The path to the image is not correct.
ERROR - 2018-04-10 11:23:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:23:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:23:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:23:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:23:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:23:51 --> The path to the image is not correct.
ERROR - 2018-04-10 11:23:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:23:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:23:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:24:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:24:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:24:40 --> The path to the image is not correct.
ERROR - 2018-04-10 11:24:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:24:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:24:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:24:41 --> The path to the image is not correct.
ERROR - 2018-04-10 11:24:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:24:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:24:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:24:41 --> The path to the image is not correct.
ERROR - 2018-04-10 11:24:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:24:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:24:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:24:42 --> The path to the image is not correct.
ERROR - 2018-04-10 11:24:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:24:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:24:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:25:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:25:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:25:27 --> The path to the image is not correct.
ERROR - 2018-04-10 11:25:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:25:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:25:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:33:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:33:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:33:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:33:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:33:24 --> The path to the image is not correct.
ERROR - 2018-04-10 11:33:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:33:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:33:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:33:24 --> The path to the image is not correct.
ERROR - 2018-04-10 11:33:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:33:24 --> The path to the image is not correct.
ERROR - 2018-04-10 11:33:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:33:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:33:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:38:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:38:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:39:02 --> The path to the image is not correct.
ERROR - 2018-04-10 11:39:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:39:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:39:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:47:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:47:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:47:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:47:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:47:12 --> The path to the image is not correct.
ERROR - 2018-04-10 11:47:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:48:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:48:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:49:19 --> The path to the image is not correct.
ERROR - 2018-04-10 11:49:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:49:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:49:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:49:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 69
ERROR - 2018-04-10 11:49:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 70
ERROR - 2018-04-10 11:49:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 69
ERROR - 2018-04-10 11:49:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 70
ERROR - 2018-04-10 11:49:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 69
ERROR - 2018-04-10 11:49:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 70
ERROR - 2018-04-10 11:49:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 69
ERROR - 2018-04-10 11:49:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 70
ERROR - 2018-04-10 11:50:41 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 69
ERROR - 2018-04-10 11:50:58 --> The path to the image is not correct.
ERROR - 2018-04-10 11:50:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:50:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:50:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:51:03 --> The path to the image is not correct.
ERROR - 2018-04-10 11:51:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:51:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:51:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:51:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:51:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:52:02 --> The path to the image is not correct.
ERROR - 2018-04-10 11:52:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 11:52:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 11:52:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:06:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:06:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:06:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:06:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:06:54 --> The path to the image is not correct.
ERROR - 2018-04-10 12:06:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:09:23 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 69
ERROR - 2018-04-10 12:24:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:24:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:24:27 --> The path to the image is not correct.
ERROR - 2018-04-10 12:24:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:24:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:24:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:29:58 --> The path to the image is not correct.
ERROR - 2018-04-10 12:29:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:29:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:29:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:30:44 --> The path to the image is not correct.
ERROR - 2018-04-10 12:30:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:30:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:30:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:31:16 --> The path to the image is not correct.
ERROR - 2018-04-10 12:31:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:31:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:31:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:31:55 --> The path to the image is not correct.
ERROR - 2018-04-10 12:31:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:31:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:31:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:32:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:32:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:32:28 --> The path to the image is not correct.
ERROR - 2018-04-10 12:32:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:32:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:32:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:33:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:33:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:33:39 --> The path to the image is not correct.
ERROR - 2018-04-10 12:33:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:33:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:33:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:33:57 --> The path to the image is not correct.
ERROR - 2018-04-10 12:33:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:33:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:33:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:33:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:34:34 --> The path to the image is not correct.
ERROR - 2018-04-10 12:34:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:34:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:34:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:35:09 --> The path to the image is not correct.
ERROR - 2018-04-10 12:35:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:35:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:35:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:35:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:43:01 --> The path to the image is not correct.
ERROR - 2018-04-10 12:43:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:43:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:43:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:43:02 --> The path to the image is not correct.
ERROR - 2018-04-10 12:43:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:43:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:43:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:43:02 --> The path to the image is not correct.
ERROR - 2018-04-10 12:43:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:43:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:43:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:43:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:58:50 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ']' D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 120
ERROR - 2018-04-10 12:59:03 --> The path to the image is not correct.
ERROR - 2018-04-10 12:59:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:59:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:59:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:59:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:59:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 39
ERROR - 2018-04-10 12:59:06 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 39
ERROR - 2018-04-10 12:59:06 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 31
ERROR - 2018-04-10 12:59:06 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 33
ERROR - 2018-04-10 12:59:06 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 38
ERROR - 2018-04-10 12:59:06 --> The path to the image is not correct.
ERROR - 2018-04-10 12:59:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 12:59:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 12:59:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:00:51 --> The path to the image is not correct.
ERROR - 2018-04-10 13:00:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:00:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:00:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:00:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:01:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 39
ERROR - 2018-04-10 13:01:52 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 39
ERROR - 2018-04-10 13:01:52 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 31
ERROR - 2018-04-10 13:01:52 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 33
ERROR - 2018-04-10 13:01:52 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 38
ERROR - 2018-04-10 13:01:52 --> The path to the image is not correct.
ERROR - 2018-04-10 13:01:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:01:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:01:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:03:15 --> The path to the image is not correct.
ERROR - 2018-04-10 13:03:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:03:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:03:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:07:54 --> The path to the image is not correct.
ERROR - 2018-04-10 13:07:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:07:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:07:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:08:19 --> The path to the image is not correct.
ERROR - 2018-04-10 13:08:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:08:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:08:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:08:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:08:35 --> The path to the image is not correct.
ERROR - 2018-04-10 13:08:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:08:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:08:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:08:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:08:57 --> The path to the image is not correct.
ERROR - 2018-04-10 13:08:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:08:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:08:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:08:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:09:58 --> The path to the image is not correct.
ERROR - 2018-04-10 13:09:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:09:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:09:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:09:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:10:40 --> The path to the image is not correct.
ERROR - 2018-04-10 13:10:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:10:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:10:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:10:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:11:27 --> The path to the image is not correct.
ERROR - 2018-04-10 13:11:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:11:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:11:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:11:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:12:57 --> The path to the image is not correct.
ERROR - 2018-04-10 13:12:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:12:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:12:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:12:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:08 --> The path to the image is not correct.
ERROR - 2018-04-10 13:13:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:13:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:17 --> The path to the image is not correct.
ERROR - 2018-04-10 13:13:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:13:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:38 --> The path to the image is not correct.
ERROR - 2018-04-10 13:13:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:13:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:53 --> The path to the image is not correct.
ERROR - 2018-04-10 13:13:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:13:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:13:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:15:21 --> The path to the image is not correct.
ERROR - 2018-04-10 13:15:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:15:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:15:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:15:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:15:46 --> The path to the image is not correct.
ERROR - 2018-04-10 13:15:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:15:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:15:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:15:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:32:43 --> The path to the image is not correct.
ERROR - 2018-04-10 13:32:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:32:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:32:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:32:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:33:28 --> The path to the image is not correct.
ERROR - 2018-04-10 13:33:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:33:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:33:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:33:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:34:05 --> The path to the image is not correct.
ERROR - 2018-04-10 13:34:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:34:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:34:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:34:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:34:19 --> The path to the image is not correct.
ERROR - 2018-04-10 13:34:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:34:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:34:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:34:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:34:39 --> The path to the image is not correct.
ERROR - 2018-04-10 13:34:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:34:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:34:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:34:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:35:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:35:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:35:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:35:42 --> The path to the image is not correct.
ERROR - 2018-04-10 13:35:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:35:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:35:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:35:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:38:02 --> The path to the image is not correct.
ERROR - 2018-04-10 13:38:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:38:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:38:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:38:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:39:52 --> The path to the image is not correct.
ERROR - 2018-04-10 13:39:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:39:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:39:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:39:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:40:34 --> The path to the image is not correct.
ERROR - 2018-04-10 13:40:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:47:26 --> The path to the image is not correct.
ERROR - 2018-04-10 13:47:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:47:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:47:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:47:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:48:36 --> The path to the image is not correct.
ERROR - 2018-04-10 13:48:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:51:31 --> The path to the image is not correct.
ERROR - 2018-04-10 13:51:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:51:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:51:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:51:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:53:15 --> The path to the image is not correct.
ERROR - 2018-04-10 13:53:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:53:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:53:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:53:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:53:33 --> The path to the image is not correct.
ERROR - 2018-04-10 13:53:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:53:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:53:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:53:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:55:54 --> The path to the image is not correct.
ERROR - 2018-04-10 13:55:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:55:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:55:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:55:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:57:07 --> Severity: Notice --> Undefined variable: ctr D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 72
ERROR - 2018-04-10 13:57:07 --> Severity: Notice --> Undefined variable: ctr D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 76
ERROR - 2018-04-10 13:57:07 --> Severity: Notice --> Undefined variable: ctr D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 81
ERROR - 2018-04-10 13:57:07 --> Severity: Notice --> Undefined variable: ctr D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\edit.php 90
ERROR - 2018-04-10 13:57:07 --> The path to the image is not correct.
ERROR - 2018-04-10 13:57:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:57:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:57:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:57:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:57:31 --> The path to the image is not correct.
ERROR - 2018-04-10 13:57:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 13:57:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:57:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 13:57:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 14:00:01 --> The path to the image is not correct.
ERROR - 2018-04-10 14:00:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-10 14:00:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 14:00:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-10 14:00:01 --> 404 Page Not Found: Public/lib

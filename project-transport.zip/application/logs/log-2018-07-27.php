<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-27 11:19:14 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:19:17 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:19:21 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:19:28 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:19:37 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:19:41 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:20:00 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-27 11:20:00 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-27 11:20:00 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/07): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-07-27 11:20:00 --> The provided image is not valid.
ERROR - 2018-07-27 11:20:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:20:26 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:20:27 --> The path to the image is not correct.
ERROR - 2018-07-27 11:20:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:20:39 --> The path to the image is not correct.
ERROR - 2018-07-27 11:20:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:20:39 --> The path to the image is not correct.
ERROR - 2018-07-27 11:20:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:20:46 --> The path to the image is not correct.
ERROR - 2018-07-27 11:20:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:20:46 --> The path to the image is not correct.
ERROR - 2018-07-27 11:20:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:20:57 --> The path to the image is not correct.
ERROR - 2018-07-27 11:20:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:20:57 --> The path to the image is not correct.
ERROR - 2018-07-27 11:20:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:21:08 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:21:29 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:21:45 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:23:03 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:25:12 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:25:26 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:26:15 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:26:16 --> The path to the image is not correct.
ERROR - 2018-07-27 11:26:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:26:41 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:26:42 --> The path to the image is not correct.
ERROR - 2018-07-27 11:26:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:26:53 --> The path to the image is not correct.
ERROR - 2018-07-27 11:26:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:27:40 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:27:41 --> The path to the image is not correct.
ERROR - 2018-07-27 11:27:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:27:44 --> The path to the image is not correct.
ERROR - 2018-07-27 11:27:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:27:50 --> The path to the image is not correct.
ERROR - 2018-07-27 11:27:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:28:00 --> The path to the image is not correct.
ERROR - 2018-07-27 11:28:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:28:00 --> The path to the image is not correct.
ERROR - 2018-07-27 11:28:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:28:14 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:28:14 --> The path to the image is not correct.
ERROR - 2018-07-27 11:28:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-27 11:28:37 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:29:12 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\apimobile\login.php 29
ERROR - 2018-07-27 11:29:12 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\apimobile\login.php 30
ERROR - 2018-07-27 11:29:49 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:31:07 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:34:48 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:36:01 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101
ERROR - 2018-07-27 11:39:10 --> Severity: Notice --> Undefined property: stdClass::$qr_id D:\xampp\htdocs\project-transport\application\models\Register_model.php 101

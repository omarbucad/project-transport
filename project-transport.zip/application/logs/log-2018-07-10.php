<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-10 03:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-10 03:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-10 03:15:38 --> The path to the image is not correct.
ERROR - 2018-07-10 03:15:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:45:46 --> The path to the image is not correct.
ERROR - 2018-07-10 03:45:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:47:49 --> The path to the image is not correct.
ERROR - 2018-07-10 03:47:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:47:53 --> The path to the image is not correct.
ERROR - 2018-07-10 03:47:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:48:04 --> The path to the image is not correct.
ERROR - 2018-07-10 03:48:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:50:48 --> The path to the image is not correct.
ERROR - 2018-07-10 03:50:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:51:42 --> The path to the image is not correct.
ERROR - 2018-07-10 03:51:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:51:43 --> The path to the image is not correct.
ERROR - 2018-07-10 03:51:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:51:44 --> The path to the image is not correct.
ERROR - 2018-07-10 03:51:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:51:44 --> The path to the image is not correct.
ERROR - 2018-07-10 03:51:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:51:44 --> The path to the image is not correct.
ERROR - 2018-07-10 03:51:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:51:45 --> The path to the image is not correct.
ERROR - 2018-07-10 03:51:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:57:04 --> The path to the image is not correct.
ERROR - 2018-07-10 03:57:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:57:06 --> The path to the image is not correct.
ERROR - 2018-07-10 03:57:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:57:49 --> The path to the image is not correct.
ERROR - 2018-07-10 03:57:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:58:10 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 03:58:10 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 03:58:10 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 03:58:10 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 03:58:10 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 03:59:27 --> The path to the image is not correct.
ERROR - 2018-07-10 03:59:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 03:59:44 --> The path to the image is not correct.
ERROR - 2018-07-10 03:59:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:00:06 --> The path to the image is not correct.
ERROR - 2018-07-10 04:00:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:02:55 --> The path to the image is not correct.
ERROR - 2018-07-10 04:02:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:04:43 --> The path to the image is not correct.
ERROR - 2018-07-10 04:04:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:05:45 --> The path to the image is not correct.
ERROR - 2018-07-10 04:05:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:06:18 --> The path to the image is not correct.
ERROR - 2018-07-10 04:06:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:06:52 --> The path to the image is not correct.
ERROR - 2018-07-10 04:06:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:07:36 --> The path to the image is not correct.
ERROR - 2018-07-10 04:07:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:07:42 --> The path to the image is not correct.
ERROR - 2018-07-10 04:07:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:07:47 --> The path to the image is not correct.
ERROR - 2018-07-10 04:07:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:08:00 --> The path to the image is not correct.
ERROR - 2018-07-10 04:08:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:08:24 --> The path to the image is not correct.
ERROR - 2018-07-10 04:08:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:08:47 --> The path to the image is not correct.
ERROR - 2018-07-10 04:08:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:09:35 --> The path to the image is not correct.
ERROR - 2018-07-10 04:09:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:09:39 --> The path to the image is not correct.
ERROR - 2018-07-10 04:09:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:17 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:18 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:18 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:18 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:19 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:19 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:19 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:19 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:30 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:30 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:36 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:47 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:48 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:48 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:49 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:12:49 --> The path to the image is not correct.
ERROR - 2018-07-10 04:12:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:21:36 --> Severity: Notice --> Undefined property: stdClass::$price D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 293
ERROR - 2018-07-10 04:21:36 --> The path to the image is not correct.
ERROR - 2018-07-10 04:21:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:21:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:21:56 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:21:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:21:56 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:21:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:21:56 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:21:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:21:56 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:21:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:13 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:13 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:14 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 122
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 124
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 125
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 126
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 127
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 145
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 147
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 148
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 149
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 150
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 168
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Undefined variable: user_plans D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\frontend\index.php 173
ERROR - 2018-07-10 04:22:20 --> Severity: Notice --> Undefined property: stdClass::$price D:\xampp\htdocs\project-transport\application\views\frontend\index.php 140
ERROR - 2018-07-10 04:22:20 --> Severity: Notice --> Undefined property: stdClass::$price D:\xampp\htdocs\project-transport\application\views\frontend\index.php 163
ERROR - 2018-07-10 04:23:18 --> The path to the image is not correct.
ERROR - 2018-07-10 04:23:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:23:18 --> The path to the image is not correct.
ERROR - 2018-07-10 04:23:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:23:19 --> The path to the image is not correct.
ERROR - 2018-07-10 04:23:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:23:19 --> The path to the image is not correct.
ERROR - 2018-07-10 04:23:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:23:19 --> The path to the image is not correct.
ERROR - 2018-07-10 04:23:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:30:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-10 04:30:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-10 04:30:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-10 04:30:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-10 04:30:40 --> The path to the image is not correct.
ERROR - 2018-07-10 04:30:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:43:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:44:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:45:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:45:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:45:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:46:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:46:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:49:01 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 04:49:01 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 04:49:01 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 04:49:01 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 04:49:01 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 04:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:53:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:54:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:54:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:54:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:54:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:54:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:54:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:54:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:54:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:55:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:55:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:55:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:55:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:55:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:55:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:56:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 04:57:12 --> The path to the image is not correct.
ERROR - 2018-07-10 04:57:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:57:23 --> The path to the image is not correct.
ERROR - 2018-07-10 04:57:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:57:26 --> The path to the image is not correct.
ERROR - 2018-07-10 04:57:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:57:28 --> The path to the image is not correct.
ERROR - 2018-07-10 04:57:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:57:28 --> The path to the image is not correct.
ERROR - 2018-07-10 04:57:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:57:39 --> The path to the image is not correct.
ERROR - 2018-07-10 04:57:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:57:41 --> The path to the image is not correct.
ERROR - 2018-07-10 04:57:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:57:41 --> The path to the image is not correct.
ERROR - 2018-07-10 04:57:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:57:55 --> The path to the image is not correct.
ERROR - 2018-07-10 04:57:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:57:55 --> The path to the image is not correct.
ERROR - 2018-07-10 04:57:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:58:03 --> The path to the image is not correct.
ERROR - 2018-07-10 04:58:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:58:10 --> The path to the image is not correct.
ERROR - 2018-07-10 04:58:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:58:12 --> The path to the image is not correct.
ERROR - 2018-07-10 04:58:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:58:12 --> The path to the image is not correct.
ERROR - 2018-07-10 04:58:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:58:14 --> The path to the image is not correct.
ERROR - 2018-07-10 04:58:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:58:25 --> The path to the image is not correct.
ERROR - 2018-07-10 04:58:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:58:41 --> The path to the image is not correct.
ERROR - 2018-07-10 04:58:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:58:41 --> The path to the image is not correct.
ERROR - 2018-07-10 04:58:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:58:49 --> The path to the image is not correct.
ERROR - 2018-07-10 04:58:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 04:58:49 --> The path to the image is not correct.
ERROR - 2018-07-10 04:58:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:00:13 --> The path to the image is not correct.
ERROR - 2018-07-10 05:00:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:00:13 --> The path to the image is not correct.
ERROR - 2018-07-10 05:00:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:00:44 --> The path to the image is not correct.
ERROR - 2018-07-10 05:00:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:00:44 --> The path to the image is not correct.
ERROR - 2018-07-10 05:00:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:00:52 --> The path to the image is not correct.
ERROR - 2018-07-10 05:00:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:01:02 --> The path to the image is not correct.
ERROR - 2018-07-10 05:01:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:01:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:01:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:04:34 --> The path to the image is not correct.
ERROR - 2018-07-10 05:04:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:04:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:04:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:04:59 --> The path to the image is not correct.
ERROR - 2018-07-10 05:04:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:04:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:04:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:05:15 --> The path to the image is not correct.
ERROR - 2018-07-10 05:05:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:05:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:05:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:05:57 --> The path to the image is not correct.
ERROR - 2018-07-10 05:05:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:05:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:05:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:06:05 --> The path to the image is not correct.
ERROR - 2018-07-10 05:06:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:06:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:06:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:06:13 --> The path to the image is not correct.
ERROR - 2018-07-10 05:06:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:06:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:06:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:06:28 --> The path to the image is not correct.
ERROR - 2018-07-10 05:06:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:06:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:06:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:06:35 --> The path to the image is not correct.
ERROR - 2018-07-10 05:06:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:06:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:06:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:07:10 --> The path to the image is not correct.
ERROR - 2018-07-10 05:07:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:07:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:07:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:14 --> The path to the image is not correct.
ERROR - 2018-07-10 05:08:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:08:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:15 --> The path to the image is not correct.
ERROR - 2018-07-10 05:08:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:08:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:16 --> The path to the image is not correct.
ERROR - 2018-07-10 05:08:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:08:16 --> The path to the image is not correct.
ERROR - 2018-07-10 05:08:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:08:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:16 --> The path to the image is not correct.
ERROR - 2018-07-10 05:08:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:08:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:16 --> The path to the image is not correct.
ERROR - 2018-07-10 05:08:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:08:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:26 --> The path to the image is not correct.
ERROR - 2018-07-10 05:08:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:08:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:35 --> The path to the image is not correct.
ERROR - 2018-07-10 05:08:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:08:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:40 --> The path to the image is not correct.
ERROR - 2018-07-10 05:08:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:08:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:46 --> The path to the image is not correct.
ERROR - 2018-07-10 05:08:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:08:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:08:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:09:14 --> The path to the image is not correct.
ERROR - 2018-07-10 05:09:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:09:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:09:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:09:48 --> The path to the image is not correct.
ERROR - 2018-07-10 05:09:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:09:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:09:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:02 --> The path to the image is not correct.
ERROR - 2018-07-10 05:10:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:10:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:06 --> The path to the image is not correct.
ERROR - 2018-07-10 05:10:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:10:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:10 --> The path to the image is not correct.
ERROR - 2018-07-10 05:10:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:10:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:14 --> The path to the image is not correct.
ERROR - 2018-07-10 05:10:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:10:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:27 --> The path to the image is not correct.
ERROR - 2018-07-10 05:10:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:10:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:59 --> The path to the image is not correct.
ERROR - 2018-07-10 05:10:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:10:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:10:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:01 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:05 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:08 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:12 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:14 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:21 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:24 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:28 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:36 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:53 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:59 --> The path to the image is not correct.
ERROR - 2018-07-10 05:11:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:11:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:11:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:13:11 --> The path to the image is not correct.
ERROR - 2018-07-10 05:13:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:13:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:13:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:13:46 --> The path to the image is not correct.
ERROR - 2018-07-10 05:13:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:13:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:13:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:15:08 --> The path to the image is not correct.
ERROR - 2018-07-10 05:15:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:15:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:15:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:15:15 --> The path to the image is not correct.
ERROR - 2018-07-10 05:15:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:15:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:15:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:16:54 --> The path to the image is not correct.
ERROR - 2018-07-10 05:16:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:16:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:16:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:16:54 --> The path to the image is not correct.
ERROR - 2018-07-10 05:16:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:16:54 --> The path to the image is not correct.
ERROR - 2018-07-10 05:16:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:16:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:16:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:19:34 --> The path to the image is not correct.
ERROR - 2018-07-10 05:19:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:19:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:19:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:19:44 --> The path to the image is not correct.
ERROR - 2018-07-10 05:19:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:19:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:19:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:21:53 --> The path to the image is not correct.
ERROR - 2018-07-10 05:21:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:21:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:21:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:21:54 --> The path to the image is not correct.
ERROR - 2018-07-10 05:21:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:21:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:21:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:22:05 --> The path to the image is not correct.
ERROR - 2018-07-10 05:22:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:22:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:22:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:22:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:22:08 --> Severity: Error --> Call to undefined method Checklist_model::get_meech_and_driver_list() D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 92
ERROR - 2018-07-10 05:22:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:22:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:22:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:08 --> The path to the image is not correct.
ERROR - 2018-07-10 05:23:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:09 --> The path to the image is not correct.
ERROR - 2018-07-10 05:23:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:16 --> The path to the image is not correct.
ERROR - 2018-07-10 05:23:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:20 --> The path to the image is not correct.
ERROR - 2018-07-10 05:23:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:30 --> The path to the image is not correct.
ERROR - 2018-07-10 05:23:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:32 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-07-10 05:23:32 --> The provided image is not valid.
ERROR - 2018-07-10 05:23:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:32 --> The path to the image is not correct.
ERROR - 2018-07-10 05:23:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:32 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-07-10 05:23:32 --> The provided image is not valid.
ERROR - 2018-07-10 05:23:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:40 --> The path to the image is not correct.
ERROR - 2018-07-10 05:23:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:50 --> The path to the image is not correct.
ERROR - 2018-07-10 05:23:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:53 --> The path to the image is not correct.
ERROR - 2018-07-10 05:23:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:58 --> The path to the image is not correct.
ERROR - 2018-07-10 05:23:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:23:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:23:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:02 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:04 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:11 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:15 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:17 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:25 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:27 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:35 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:36 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:36 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:46 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:46 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:52 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:53 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:55 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:55 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:59 --> The path to the image is not correct.
ERROR - 2018-07-10 05:24:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:25:03 --> The path to the image is not correct.
ERROR - 2018-07-10 05:25:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:25:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:25:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:25:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:25:09 --> The path to the image is not correct.
ERROR - 2018-07-10 05:25:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:25:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:25:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:25:11 --> The path to the image is not correct.
ERROR - 2018-07-10 05:25:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:25:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:25:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:25:23 --> The path to the image is not correct.
ERROR - 2018-07-10 05:25:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:25:23 --> The path to the image is not correct.
ERROR - 2018-07-10 05:25:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:25:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:25:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:26:34 --> The path to the image is not correct.
ERROR - 2018-07-10 05:26:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:26:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:26:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:26:35 --> The path to the image is not correct.
ERROR - 2018-07-10 05:26:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:26:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:26:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:26:43 --> The path to the image is not correct.
ERROR - 2018-07-10 05:26:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:26:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:26:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:28:26 --> The path to the image is not correct.
ERROR - 2018-07-10 05:28:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:28:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:28:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:28:36 --> The path to the image is not correct.
ERROR - 2018-07-10 05:28:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:28:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:28:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:29:36 --> The path to the image is not correct.
ERROR - 2018-07-10 05:29:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:29:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:29:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:29:57 --> The path to the image is not correct.
ERROR - 2018-07-10 05:29:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:29:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:29:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:30:33 --> The path to the image is not correct.
ERROR - 2018-07-10 05:30:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:30:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:30:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:30:58 --> The path to the image is not correct.
ERROR - 2018-07-10 05:30:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:30:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:30:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:31:15 --> The path to the image is not correct.
ERROR - 2018-07-10 05:31:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:31:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:31:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:31:34 --> The path to the image is not correct.
ERROR - 2018-07-10 05:31:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:31:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:31:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:32:28 --> The path to the image is not correct.
ERROR - 2018-07-10 05:32:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 05:32:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 05:32:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 06:02:41 --> The path to the image is not correct.
ERROR - 2018-07-10 06:02:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 06:02:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 06:02:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 06:02:43 --> The path to the image is not correct.
ERROR - 2018-07-10 06:02:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 06:02:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 06:02:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-10 08:10:25 --> 404 Page Not Found: app/Vehicle/index
ERROR - 2018-07-10 09:24:28 --> The path to the image is not correct.
ERROR - 2018-07-10 09:24:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:24:53 --> The path to the image is not correct.
ERROR - 2018-07-10 09:24:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:24:57 --> The path to the image is not correct.
ERROR - 2018-07-10 09:24:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:24:57 --> The path to the image is not correct.
ERROR - 2018-07-10 09:24:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:25:04 --> The path to the image is not correct.
ERROR - 2018-07-10 09:25:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:25:04 --> The path to the image is not correct.
ERROR - 2018-07-10 09:25:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:25:13 --> The path to the image is not correct.
ERROR - 2018-07-10 09:25:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:25:13 --> The path to the image is not correct.
ERROR - 2018-07-10 09:25:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:25:17 --> The path to the image is not correct.
ERROR - 2018-07-10 09:25:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:25:18 --> The path to the image is not correct.
ERROR - 2018-07-10 09:25:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:25:18 --> The path to the image is not correct.
ERROR - 2018-07-10 09:25:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:25:21 --> The path to the image is not correct.
ERROR - 2018-07-10 09:25:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:25:21 --> The path to the image is not correct.
ERROR - 2018-07-10 09:25:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 09:25:23 --> The path to the image is not correct.
ERROR - 2018-07-10 09:25:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 10:06:40 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\controllers\apimobile\Report.php 25
ERROR - 2018-07-10 10:06:40 --> Severity: Notice --> Undefined property: stdClass::$store_id D:\xampp\htdocs\project-transport\application\controllers\apimobile\Report.php 26
ERROR - 2018-07-10 11:03:58 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 11:03:58 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 11:03:58 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 11:03:58 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 11:04:00 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-10 12:54:26 --> The path to the image is not correct.
ERROR - 2018-07-10 12:54:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:01:57 --> Query error: Unknown column 'p.plan_expiration' in 'field list' - Invalid query: SELECT `u`.`user_id`, `u`.`display_name`, `u`.`email_address`, `u`.`role`, `u`.`store_id`, `u`.`image_path`, `u`.`image_name`, `p`.`plan_id`, `p`.`title`, `p`.`no_accounts`, `p`.`no_vehicle`, `p`.`plan_expiration`, `a1`.`country`
FROM `user` `u`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `a1` ON `a1`.`store_address_id` = `s`.`address_id`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
JOIN `plan` `p` ON `p`.`plan_id` = `up`.`plan_id`
WHERE `u`.`username` = 'admin'
AND `u`.`password` = '21232f297a57a5a743894a0e4a801fc3'
AND `up`.`active` = 1
ERROR - 2018-07-10 13:02:27 --> The path to the image is not correct.
ERROR - 2018-07-10 13:02:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:04:56 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 115
ERROR - 2018-07-10 13:04:56 --> The path to the image is not correct.
ERROR - 2018-07-10 13:04:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:05:17 --> The path to the image is not correct.
ERROR - 2018-07-10 13:05:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:06:17 --> The path to the image is not correct.
ERROR - 2018-07-10 13:06:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:09:12 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 120
ERROR - 2018-07-10 13:09:12 --> The path to the image is not correct.
ERROR - 2018-07-10 13:09:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:10:39 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 120
ERROR - 2018-07-10 13:10:39 --> The path to the image is not correct.
ERROR - 2018-07-10 13:10:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:10:39 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 120
ERROR - 2018-07-10 13:10:39 --> The path to the image is not correct.
ERROR - 2018-07-10 13:10:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:10:39 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 120
ERROR - 2018-07-10 13:10:39 --> The path to the image is not correct.
ERROR - 2018-07-10 13:10:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:10:39 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 120
ERROR - 2018-07-10 13:10:39 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 120
ERROR - 2018-07-10 13:10:39 --> The path to the image is not correct.
ERROR - 2018-07-10 13:10:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:10:40 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 120
ERROR - 2018-07-10 13:10:40 --> The path to the image is not correct.
ERROR - 2018-07-10 13:10:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:48 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:48 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:49 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:49 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:49 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:49 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:49 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:50 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:50 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:50 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:50 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:50 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:50 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:51 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:51 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:51 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:51 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:51 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:51 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:51 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:51 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:51 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:52 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:52 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:52 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:52 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:52 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:52 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:43:52 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 119
ERROR - 2018-07-10 13:43:52 --> The path to the image is not correct.
ERROR - 2018-07-10 13:43:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:47:02 --> The path to the image is not correct.
ERROR - 2018-07-10 13:47:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:48:59 --> The path to the image is not correct.
ERROR - 2018-07-10 13:48:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:54:51 --> The path to the image is not correct.
ERROR - 2018-07-10 13:54:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:54:51 --> The path to the image is not correct.
ERROR - 2018-07-10 13:54:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:54:51 --> The path to the image is not correct.
ERROR - 2018-07-10 13:54:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:54:51 --> The path to the image is not correct.
ERROR - 2018-07-10 13:54:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:54:51 --> The path to the image is not correct.
ERROR - 2018-07-10 13:54:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:54:52 --> The path to the image is not correct.
ERROR - 2018-07-10 13:54:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:54:52 --> The path to the image is not correct.
ERROR - 2018-07-10 13:54:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:54:52 --> The path to the image is not correct.
ERROR - 2018-07-10 13:54:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-10 13:54:52 --> The path to the image is not correct.
ERROR - 2018-07-10 13:54:52 --> Your server does not support the GD function required to process this type of image.

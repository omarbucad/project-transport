<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-26 02:55:31 --> The path to the image is not correct.
ERROR - 2018-06-26 02:55:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 02:57:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 02:57:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 03:18:40 --> The path to the image is not correct.
ERROR - 2018-06-26 03:18:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 03:18:40 --> The path to the image is not correct.
ERROR - 2018-06-26 03:18:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 13
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 68
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 81
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 93
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 28
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-26 04:04:59 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-26 04:04:59 --> The path to the image is not correct.
ERROR - 2018-06-26 04:04:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 13
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 68
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 81
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 93
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 28
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-26 04:04:59 --> The path to the image is not correct.
ERROR - 2018-06-26 04:04:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 13
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 68
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 81
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 93
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 28
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:04:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:05:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-26 04:05:00 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-26 04:05:00 --> The path to the image is not correct.
ERROR - 2018-06-26 04:05:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-26 04:05:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\dashboard.php 95
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-26 04:06:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\dashboard.php 95
ERROR - 2018-06-26 04:06:11 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-26 04:06:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\dashboard.php 95
ERROR - 2018-06-26 04:06:13 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-26 04:06:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\dashboard.php 95
ERROR - 2018-06-26 04:06:21 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\dashboard.php 95
ERROR - 2018-06-26 04:06:22 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\dashboard.php 95
ERROR - 2018-06-26 04:06:22 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-26 04:06:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\dashboard.php 95
ERROR - 2018-06-26 04:06:22 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-26 04:06:26 --> The path to the image is not correct.
ERROR - 2018-06-26 04:06:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:06:40 --> The path to the image is not correct.
ERROR - 2018-06-26 04:06:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:06:40 --> The path to the image is not correct.
ERROR - 2018-06-26 04:06:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:08:01 --> The path to the image is not correct.
ERROR - 2018-06-26 04:08:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:08:01 --> The path to the image is not correct.
ERROR - 2018-06-26 04:08:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:19:53 --> The path to the image is not correct.
ERROR - 2018-06-26 04:19:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:19:53 --> The path to the image is not correct.
ERROR - 2018-06-26 04:19:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: limit D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: skip D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 36
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 47
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 51
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 55
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 79
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 80
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 81
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:22:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: limit D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: skip D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Undefined variable: session_data D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 36
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 47
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 51
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 55
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:22:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 79
ERROR - 2018-06-26 04:22:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 80
ERROR - 2018-06-26 04:22:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 81
ERROR - 2018-06-26 04:22:49 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:22:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:22:50 --> The path to the image is not correct.
ERROR - 2018-06-26 04:22:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:22:50 --> The path to the image is not correct.
ERROR - 2018-06-26 04:22:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:23:38 --> The path to the image is not correct.
ERROR - 2018-06-26 04:23:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:23:38 --> The path to the image is not correct.
ERROR - 2018-06-26 04:23:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Undefined variable: limit D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Undefined variable: skip D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 36
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 47
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 51
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 55
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 79
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 80
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 81
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:23:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:23:40 --> The path to the image is not correct.
ERROR - 2018-06-26 04:23:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Undefined variable: limit D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Undefined variable: skip D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 36
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 47
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 51
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 55
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 79
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 80
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 81
ERROR - 2018-06-26 04:23:40 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:23:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:23:55 --> The path to the image is not correct.
ERROR - 2018-06-26 04:23:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:23:55 --> The path to the image is not correct.
ERROR - 2018-06-26 04:23:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:26:55 --> The path to the image is not correct.
ERROR - 2018-06-26 04:26:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:26:55 --> The path to the image is not correct.
ERROR - 2018-06-26 04:26:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:26:59 --> Severity: Notice --> Undefined variable: limit D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:26:59 --> Severity: Notice --> Undefined variable: skip D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:27:36 --> The path to the image is not correct.
ERROR - 2018-06-26 04:27:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:27:36 --> The path to the image is not correct.
ERROR - 2018-06-26 04:27:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:27:36 --> The path to the image is not correct.
ERROR - 2018-06-26 04:27:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:27:36 --> The path to the image is not correct.
ERROR - 2018-06-26 04:27:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:27:41 --> Severity: Notice --> Undefined variable: limit D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:27:41 --> Severity: Notice --> Undefined variable: skip D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 59
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 36
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 47
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 51
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 55
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 79
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 80
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 81
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:28:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 36
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 47
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 51
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 55
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 79
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 80
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 81
ERROR - 2018-06-26 04:28:58 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:28:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 96
ERROR - 2018-06-26 04:28:58 --> The path to the image is not correct.
ERROR - 2018-06-26 04:28:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:36:26 --> The path to the image is not correct.
ERROR - 2018-06-26 04:36:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:36:26 --> The path to the image is not correct.
ERROR - 2018-06-26 04:36:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:36:28 --> The path to the image is not correct.
ERROR - 2018-06-26 04:36:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:36:28 --> The path to the image is not correct.
ERROR - 2018-06-26 04:36:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 36
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 47
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 51
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 55
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 78
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 92
ERROR - 2018-06-26 04:37:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 92
ERROR - 2018-06-26 04:37:05 --> The path to the image is not correct.
ERROR - 2018-06-26 04:37:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 36
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 47
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 51
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 55
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 78
ERROR - 2018-06-26 04:37:05 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 92
ERROR - 2018-06-26 04:37:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 92
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 36
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 47
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 51
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 55
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 78
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 92
ERROR - 2018-06-26 04:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 92
ERROR - 2018-06-26 04:37:37 --> The path to the image is not correct.
ERROR - 2018-06-26 04:37:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 36
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 47
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 51
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 55
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 62
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 78
ERROR - 2018-06-26 04:37:37 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 92
ERROR - 2018-06-26 04:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 92
ERROR - 2018-06-26 04:38:41 --> The path to the image is not correct.
ERROR - 2018-06-26 04:38:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:38:41 --> The path to the image is not correct.
ERROR - 2018-06-26 04:38:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:39:43 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 92
ERROR - 2018-06-26 04:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\view_info.php 92
ERROR - 2018-06-26 04:39:43 --> The path to the image is not correct.
ERROR - 2018-06-26 04:39:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:39:43 --> The path to the image is not correct.
ERROR - 2018-06-26 04:39:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:41:13 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 92
ERROR - 2018-06-26 04:41:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 92
ERROR - 2018-06-26 04:41:13 --> The path to the image is not correct.
ERROR - 2018-06-26 04:41:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:41:13 --> The path to the image is not correct.
ERROR - 2018-06-26 04:41:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:48:23 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `user_plan`
WHERE `active` = 1
AND `user_id` = '6'
ERROR - 2018-06-26 04:49:35 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 92
ERROR - 2018-06-26 04:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 92
ERROR - 2018-06-26 04:49:35 --> The path to the image is not correct.
ERROR - 2018-06-26 04:49:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:49:35 --> The path to the image is not correct.
ERROR - 2018-06-26 04:49:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:50:57 --> The path to the image is not correct.
ERROR - 2018-06-26 04:50:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:50:58 --> The path to the image is not correct.
ERROR - 2018-06-26 04:50:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:50:58 --> The path to the image is not correct.
ERROR - 2018-06-26 04:50:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:53:42 --> Severity: Notice --> Undefined variable: subscription D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 98
ERROR - 2018-06-26 04:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 98
ERROR - 2018-06-26 04:53:42 --> The path to the image is not correct.
ERROR - 2018-06-26 04:53:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:53:42 --> The path to the image is not correct.
ERROR - 2018-06-26 04:53:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:53:53 --> The path to the image is not correct.
ERROR - 2018-06-26 04:53:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:53:53 --> The path to the image is not correct.
ERROR - 2018-06-26 04:53:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:54:20 --> The path to the image is not correct.
ERROR - 2018-06-26 04:54:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:54:20 --> The path to the image is not correct.
ERROR - 2018-06-26 04:54:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:55:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 71
ERROR - 2018-06-26 04:55:04 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 71
ERROR - 2018-06-26 04:55:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 72
ERROR - 2018-06-26 04:55:04 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 72
ERROR - 2018-06-26 04:55:04 --> The path to the image is not correct.
ERROR - 2018-06-26 04:55:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:55:04 --> The path to the image is not correct.
ERROR - 2018-06-26 04:55:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:55:31 --> The path to the image is not correct.
ERROR - 2018-06-26 04:55:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:55:31 --> The path to the image is not correct.
ERROR - 2018-06-26 04:55:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:57:11 --> The path to the image is not correct.
ERROR - 2018-06-26 04:57:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:57:11 --> The path to the image is not correct.
ERROR - 2018-06-26 04:57:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:57:26 --> The path to the image is not correct.
ERROR - 2018-06-26 04:57:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:57:26 --> The path to the image is not correct.
ERROR - 2018-06-26 04:57:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:57:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 04:57:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 04:58:05 --> The path to the image is not correct.
ERROR - 2018-06-26 04:58:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:58:05 --> The path to the image is not correct.
ERROR - 2018-06-26 04:58:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:59:59 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 144
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 36
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 47
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 51
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 55
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 62
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 62
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 79
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 80
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 81
ERROR - 2018-06-26 04:59:59 --> The path to the image is not correct.
ERROR - 2018-06-26 04:59:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:59:59 --> The path to the image is not correct.
ERROR - 2018-06-26 04:59:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 61
ERROR - 2018-06-26 04:59:59 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 61
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 62
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$plan_created D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 63
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$plan_expiration D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 64
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 36
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 47
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 51
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 55
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 59
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 66
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 66
ERROR - 2018-06-26 04:59:59 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 144
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 36
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 47
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 51
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 55
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 62
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 62
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 79
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 80
ERROR - 2018-06-26 04:59:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 81
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 61
ERROR - 2018-06-26 05:02:39 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 61
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 62
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$plan_created D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 63
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$plan_expiration D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 64
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 36
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 47
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 51
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 55
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 59
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 66
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 66
ERROR - 2018-06-26 05:02:39 --> The path to the image is not correct.
ERROR - 2018-06-26 05:02:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 61
ERROR - 2018-06-26 05:02:39 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 61
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 62
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$plan_created D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 63
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$plan_expiration D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 64
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 36
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 47
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 51
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 55
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 59
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 66
ERROR - 2018-06-26 05:02:39 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 66
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 61
ERROR - 2018-06-26 05:04:02 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 61
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 62
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$plan_created D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 63
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$plan_expiration D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 64
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 36
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 47
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 51
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 55
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 59
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 66
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 66
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 61
ERROR - 2018-06-26 05:04:02 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 61
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 62
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$plan_created D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 63
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$plan_expiration D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 64
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 36
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 47
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 51
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 55
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 59
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 66
ERROR - 2018-06-26 05:04:02 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\edit_info.php 66
ERROR - 2018-06-26 05:04:02 --> The path to the image is not correct.
ERROR - 2018-06-26 05:04:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:04:57 --> The path to the image is not correct.
ERROR - 2018-06-26 05:04:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:04:57 --> The path to the image is not correct.
ERROR - 2018-06-26 05:04:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:05:48 --> The path to the image is not correct.
ERROR - 2018-06-26 05:05:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:05:48 --> The path to the image is not correct.
ERROR - 2018-06-26 05:05:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:05:56 --> The path to the image is not correct.
ERROR - 2018-06-26 05:05:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:05:56 --> The path to the image is not correct.
ERROR - 2018-06-26 05:05:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:06:38 --> The path to the image is not correct.
ERROR - 2018-06-26 05:06:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:06:38 --> The path to the image is not correct.
ERROR - 2018-06-26 05:06:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:07:53 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::order_by() D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 70
ERROR - 2018-06-26 05:08:09 --> The path to the image is not correct.
ERROR - 2018-06-26 05:08:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:08:09 --> The path to the image is not correct.
ERROR - 2018-06-26 05:08:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:09:19 --> The path to the image is not correct.
ERROR - 2018-06-26 05:09:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:09:20 --> The path to the image is not correct.
ERROR - 2018-06-26 05:09:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:11:14 --> The path to the image is not correct.
ERROR - 2018-06-26 05:11:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:11:14 --> The path to the image is not correct.
ERROR - 2018-06-26 05:11:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:13:54 --> The path to the image is not correct.
ERROR - 2018-06-26 05:13:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:13:54 --> The path to the image is not correct.
ERROR - 2018-06-26 05:13:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:14:36 --> The path to the image is not correct.
ERROR - 2018-06-26 05:14:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:14:36 --> The path to the image is not correct.
ERROR - 2018-06-26 05:14:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:14:44 --> The path to the image is not correct.
ERROR - 2018-06-26 05:14:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:14:44 --> The path to the image is not correct.
ERROR - 2018-06-26 05:14:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:14:48 --> The path to the image is not correct.
ERROR - 2018-06-26 05:14:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:14:48 --> The path to the image is not correct.
ERROR - 2018-06-26 05:14:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:14:51 --> The path to the image is not correct.
ERROR - 2018-06-26 05:14:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:14:52 --> The path to the image is not correct.
ERROR - 2018-06-26 05:14:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:22:03 --> The path to the image is not correct.
ERROR - 2018-06-26 05:22:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:22:03 --> The path to the image is not correct.
ERROR - 2018-06-26 05:22:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:24:25 --> Severity: Compile Error --> Cannot redeclare Accounts_model::edit_user() D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 222
ERROR - 2018-06-26 05:24:53 --> The path to the image is not correct.
ERROR - 2018-06-26 05:24:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:24:53 --> The path to the image is not correct.
ERROR - 2018-06-26 05:24:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:25:03 --> Severity: Notice --> Undefined variable: role D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 87
ERROR - 2018-06-26 05:25:03 --> The path to the image is not correct.
ERROR - 2018-06-26 05:25:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:25:04 --> The path to the image is not correct.
ERROR - 2018-06-26 05:25:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:25:45 --> The path to the image is not correct.
ERROR - 2018-06-26 05:25:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:25:45 --> The path to the image is not correct.
ERROR - 2018-06-26 05:25:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:28:46 --> The path to the image is not correct.
ERROR - 2018-06-26 05:28:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:28:47 --> The path to the image is not correct.
ERROR - 2018-06-26 05:28:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:31 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:31 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:38 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:38 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:40 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:40 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:40 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:40 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:41 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:41 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:41 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:41 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:41 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:41 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:41 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:42 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:42 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:42 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:42 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:42 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:42 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:42 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:43 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:43 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:43 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:43 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:43 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:43 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:43 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:43 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:44 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:44 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:44 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:44 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:45 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:45 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:46 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:46 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:53 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:29:53 --> The path to the image is not correct.
ERROR - 2018-06-26 05:29:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:30:22 --> The path to the image is not correct.
ERROR - 2018-06-26 05:30:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:30:23 --> The path to the image is not correct.
ERROR - 2018-06-26 05:30:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:30:54 --> The path to the image is not correct.
ERROR - 2018-06-26 05:30:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:30:54 --> The path to the image is not correct.
ERROR - 2018-06-26 05:30:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:31:05 --> The path to the image is not correct.
ERROR - 2018-06-26 05:31:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:31:11 --> The path to the image is not correct.
ERROR - 2018-06-26 05:31:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:31:13 --> The path to the image is not correct.
ERROR - 2018-06-26 05:31:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:31:13 --> The path to the image is not correct.
ERROR - 2018-06-26 05:31:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:31:17 --> The path to the image is not correct.
ERROR - 2018-06-26 05:31:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:31:17 --> The path to the image is not correct.
ERROR - 2018-06-26 05:31:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:31:24 --> The path to the image is not correct.
ERROR - 2018-06-26 05:31:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:31:24 --> The path to the image is not correct.
ERROR - 2018-06-26 05:31:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:33:21 --> The path to the image is not correct.
ERROR - 2018-06-26 05:33:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:33:21 --> The path to the image is not correct.
ERROR - 2018-06-26 05:33:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:33:26 --> The path to the image is not correct.
ERROR - 2018-06-26 05:33:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:33:31 --> The path to the image is not correct.
ERROR - 2018-06-26 05:33:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:33:31 --> The path to the image is not correct.
ERROR - 2018-06-26 05:33:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:33:45 --> The path to the image is not correct.
ERROR - 2018-06-26 05:33:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:33:46 --> The path to the image is not correct.
ERROR - 2018-06-26 05:33:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:33:46 --> The path to the image is not correct.
ERROR - 2018-06-26 05:33:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:34:42 --> The path to the image is not correct.
ERROR - 2018-06-26 05:34:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:34:42 --> The path to the image is not correct.
ERROR - 2018-06-26 05:34:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:34:45 --> The path to the image is not correct.
ERROR - 2018-06-26 05:34:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:34:45 --> The path to the image is not correct.
ERROR - 2018-06-26 05:34:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:36:35 --> The path to the image is not correct.
ERROR - 2018-06-26 05:36:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:36:35 --> The path to the image is not correct.
ERROR - 2018-06-26 05:36:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:52:09 --> The path to the image is not correct.
ERROR - 2018-06-26 05:52:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 05:52:09 --> The path to the image is not correct.
ERROR - 2018-06-26 05:52:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:10:53 --> The path to the image is not correct.
ERROR - 2018-06-26 07:10:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:10:53 --> The path to the image is not correct.
ERROR - 2018-06-26 07:10:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:16:16 --> The path to the image is not correct.
ERROR - 2018-06-26 07:16:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:16:17 --> The path to the image is not correct.
ERROR - 2018-06-26 07:16:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 48
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 48
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 52
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 52
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 56
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 56
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 60
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 60
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 64
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 64
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 65
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 65
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 66
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 66
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 74
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 74
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 74
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 74
ERROR - 2018-06-26 07:16:18 --> Severity: Notice --> Undefined variable: subscriptions D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 96
ERROR - 2018-06-26 07:16:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 96
ERROR - 2018-06-26 07:16:18 --> 404 Page Not Found: admin/Accounts/%3Cdiv%20style=
ERROR - 2018-06-26 07:16:18 --> The path to the image is not correct.
ERROR - 2018-06-26 07:16:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:16:23 --> The path to the image is not correct.
ERROR - 2018-06-26 07:16:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:31:09 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:31:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:31:09 --> The path to the image is not correct.
ERROR - 2018-06-26 07:31:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:32:02 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:32:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:32:02 --> The path to the image is not correct.
ERROR - 2018-06-26 07:32:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:34:49 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:34:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:34:49 --> The path to the image is not correct.
ERROR - 2018-06-26 07:34:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:35:27 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:35:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:35:28 --> The path to the image is not correct.
ERROR - 2018-06-26 07:35:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:35:35 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:35:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:35:35 --> The path to the image is not correct.
ERROR - 2018-06-26 07:35:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:35:48 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:35:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\add.php 37
ERROR - 2018-06-26 07:35:48 --> The path to the image is not correct.
ERROR - 2018-06-26 07:35:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:36:44 --> The path to the image is not correct.
ERROR - 2018-06-26 07:36:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:41:09 --> The path to the image is not correct.
ERROR - 2018-06-26 07:41:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:43:24 --> The path to the image is not correct.
ERROR - 2018-06-26 07:43:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:43:25 --> The path to the image is not correct.
ERROR - 2018-06-26 07:43:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:43:25 --> The path to the image is not correct.
ERROR - 2018-06-26 07:43:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:43:25 --> The path to the image is not correct.
ERROR - 2018-06-26 07:43:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 07:43:25 --> The path to the image is not correct.
ERROR - 2018-06-26 07:43:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 08:14:01 --> The path to the image is not correct.
ERROR - 2018-06-26 08:14:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 08:14:01 --> The path to the image is not correct.
ERROR - 2018-06-26 08:14:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 08:14:01 --> The path to the image is not correct.
ERROR - 2018-06-26 08:14:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:27:35 --> The path to the image is not correct.
ERROR - 2018-06-26 10:27:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:27:43 --> The path to the image is not correct.
ERROR - 2018-06-26 10:27:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:28:34 --> The path to the image is not correct.
ERROR - 2018-06-26 10:28:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:31:54 --> The path to the image is not correct.
ERROR - 2018-06-26 10:31:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:32:11 --> The path to the image is not correct.
ERROR - 2018-06-26 10:32:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:32:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:32:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:32:53 --> The path to the image is not correct.
ERROR - 2018-06-26 10:32:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:32:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:32:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:33:02 --> The path to the image is not correct.
ERROR - 2018-06-26 10:33:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:33:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:33:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:33:36 --> The path to the image is not correct.
ERROR - 2018-06-26 10:33:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:33:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:33:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:33:58 --> The path to the image is not correct.
ERROR - 2018-06-26 10:33:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:33:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:33:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:34:43 --> The path to the image is not correct.
ERROR - 2018-06-26 10:34:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:34:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:34:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:35:16 --> The path to the image is not correct.
ERROR - 2018-06-26 10:35:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:35:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:35:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:37:00 --> The path to the image is not correct.
ERROR - 2018-06-26 10:37:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:37:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:37:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:37:15 --> The path to the image is not correct.
ERROR - 2018-06-26 10:37:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:37:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:37:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:37:25 --> The path to the image is not correct.
ERROR - 2018-06-26 10:37:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:37:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:37:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:37:40 --> The path to the image is not correct.
ERROR - 2018-06-26 10:37:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:37:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:37:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:37:55 --> The path to the image is not correct.
ERROR - 2018-06-26 10:37:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:37:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:37:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:38:27 --> The path to the image is not correct.
ERROR - 2018-06-26 10:38:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:38:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:38:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:39:08 --> The path to the image is not correct.
ERROR - 2018-06-26 10:39:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:39:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:39:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:39:14 --> The path to the image is not correct.
ERROR - 2018-06-26 10:39:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:39:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:39:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:39:54 --> The path to the image is not correct.
ERROR - 2018-06-26 10:39:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:39:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:39:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:39:55 --> The path to the image is not correct.
ERROR - 2018-06-26 10:39:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:39:55 --> The path to the image is not correct.
ERROR - 2018-06-26 10:39:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:45:16 --> The path to the image is not correct.
ERROR - 2018-06-26 10:45:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:45:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:45:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:45:40 --> The path to the image is not correct.
ERROR - 2018-06-26 10:45:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:45:49 --> The path to the image is not correct.
ERROR - 2018-06-26 10:45:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:45:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:45:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:52:00 --> The path to the image is not correct.
ERROR - 2018-06-26 10:52:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:52:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:52:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:58:02 --> The path to the image is not correct.
ERROR - 2018-06-26 10:58:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:58:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:58:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:59:15 --> The path to the image is not correct.
ERROR - 2018-06-26 10:59:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 10:59:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 10:59:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:04:55 --> The path to the image is not correct.
ERROR - 2018-06-26 11:04:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 11:04:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:04:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:05:10 --> The path to the image is not correct.
ERROR - 2018-06-26 11:05:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 11:05:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:05:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:05:56 --> The path to the image is not correct.
ERROR - 2018-06-26 11:05:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 11:05:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:05:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:06:31 --> The path to the image is not correct.
ERROR - 2018-06-26 11:06:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 11:06:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:06:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:06:31 --> The path to the image is not correct.
ERROR - 2018-06-26 11:06:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 11:06:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:06:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:28:19 --> The path to the image is not correct.
ERROR - 2018-06-26 11:28:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 11:28:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:28:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:39:12 --> The path to the image is not correct.
ERROR - 2018-06-26 11:39:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-26 11:39:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:39:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-26 11:49:39 --> 404 Page Not Found: Public/lib

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-18 03:32:05 --> The path to the image is not correct.
ERROR - 2018-05-18 03:32:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-18 04:38:36 --> The path to the image is not correct.
ERROR - 2018-05-18 04:38:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-18 05:12:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-18 05:12:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-18 05:42:19 --> The path to the image is not correct.
ERROR - 2018-05-18 05:42:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-18 05:42:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-18 05:42:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-18 05:42:19 --> The path to the image is not correct.
ERROR - 2018-05-18 05:42:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-18 05:42:21 --> The path to the image is not correct.
ERROR - 2018-05-18 05:42:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-18 05:42:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-18 05:42:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-18 05:42:22 --> The path to the image is not correct.
ERROR - 2018-05-18 05:42:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-18 05:42:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-18 05:42:22 --> 404 Page Not Found: Public/lib

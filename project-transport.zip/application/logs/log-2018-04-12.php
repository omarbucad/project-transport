<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-12 03:31:34 --> The path to the image is not correct.
ERROR - 2018-04-12 03:31:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 03:31:45 --> The path to the image is not correct.
ERROR - 2018-04-12 03:31:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:43:11 --> Severity: Notice --> Undefined index: username D:\xampp\htdocs\project-transport\application\models\Register_model.php 91
ERROR - 2018-04-12 05:43:11 --> Severity: Notice --> Undefined index: password D:\xampp\htdocs\project-transport\application\models\Register_model.php 92
ERROR - 2018-04-12 05:43:24 --> The path to the image is not correct.
ERROR - 2018-04-12 05:43:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:43:36 --> The path to the image is not correct.
ERROR - 2018-04-12 05:43:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:43:40 --> Severity: Error --> Call to undefined method Hash::ecrypt() D:\xampp\htdocs\project-transport\application\views\backend\page\checklist\view.php 126
ERROR - 2018-04-12 05:43:41 --> The path to the image is not correct.
ERROR - 2018-04-12 05:43:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:43:56 --> The path to the image is not correct.
ERROR - 2018-04-12 05:43:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:44:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:44:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:44:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:44:39 --> The path to the image is not correct.
ERROR - 2018-04-12 05:44:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:44:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:44:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:44:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:46:52 --> The path to the image is not correct.
ERROR - 2018-04-12 05:46:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:46:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:46:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:46:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:47:18 --> The path to the image is not correct.
ERROR - 2018-04-12 05:47:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:47:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:47:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:47:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:47:40 --> The path to the image is not correct.
ERROR - 2018-04-12 05:47:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:47:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:47:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:47:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:47:58 --> The path to the image is not correct.
ERROR - 2018-04-12 05:47:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:47:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:47:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:47:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:48:10 --> The path to the image is not correct.
ERROR - 2018-04-12 05:48:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:48:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:48:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:48:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:05 --> The path to the image is not correct.
ERROR - 2018-04-12 05:49:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:49:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:25 --> The path to the image is not correct.
ERROR - 2018-04-12 05:49:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:49:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:54 --> The path to the image is not correct.
ERROR - 2018-04-12 05:49:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:55 --> The path to the image is not correct.
ERROR - 2018-04-12 05:49:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:49:55 --> The path to the image is not correct.
ERROR - 2018-04-12 05:49:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:30 --> The path to the image is not correct.
ERROR - 2018-04-12 05:50:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:50:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:36 --> The path to the image is not correct.
ERROR - 2018-04-12 05:50:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:50:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:41 --> The path to the image is not correct.
ERROR - 2018-04-12 05:50:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:50:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:46 --> The path to the image is not correct.
ERROR - 2018-04-12 05:50:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:50:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:53 --> 404 Page Not Found: app/Setup/profile
ERROR - 2018-04-12 05:50:56 --> The path to the image is not correct.
ERROR - 2018-04-12 05:50:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:50:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:50:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:51:01 --> 404 Page Not Found: app/Setup/settings
ERROR - 2018-04-12 05:51:05 --> The path to the image is not correct.
ERROR - 2018-04-12 05:51:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:51:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:51:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:51:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:51:07 --> The path to the image is not correct.
ERROR - 2018-04-12 05:51:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:51:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:51:07 --> The path to the image is not correct.
ERROR - 2018-04-12 05:51:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:51:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:51:11 --> 404 Page Not Found: app/Users/view_user_info
ERROR - 2018-04-12 05:51:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:51:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:51:15 --> 404 Page Not Found: app/Users/edit
ERROR - 2018-04-12 05:51:17 --> The path to the image is not correct.
ERROR - 2018-04-12 05:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:51:17 --> The path to the image is not correct.
ERROR - 2018-04-12 05:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 05:51:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 05:51:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 06:55:42 --> 404 Page Not Found: app/Setup/profile
ERROR - 2018-04-12 06:56:34 --> The path to the image is not correct.
ERROR - 2018-04-12 06:56:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 06:56:37 --> The path to the image is not correct.
ERROR - 2018-04-12 06:56:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:34:47 --> The path to the image is not correct.
ERROR - 2018-04-12 09:34:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:34:50 --> Severity: Notice --> Undefined property: Setup::$profile D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 119
ERROR - 2018-04-12 09:34:50 --> Severity: Error --> Call to a member function get_profile() on null D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 119
ERROR - 2018-04-12 09:35:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Profile_model D:\xampp\htdocs\project-transport\system\core\Loader.php 348
ERROR - 2018-04-12 09:36:53 --> The path to the image is not correct.
ERROR - 2018-04-12 09:36:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:36:59 --> The path to the image is not correct.
ERROR - 2018-04-12 09:36:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:14 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:14 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:51 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:51 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:52 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:52 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:52 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:52 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:52 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:52 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:52 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:52 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:53 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:53 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:53 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:53 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:53 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:53 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:53 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:53 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:45:53 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 56
ERROR - 2018-04-12 09:45:53 --> The path to the image is not correct.
ERROR - 2018-04-12 09:45:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:46:52 --> Severity: Notice --> Undefined variable: general_information D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 24
ERROR - 2018-04-12 09:46:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 24
ERROR - 2018-04-12 09:46:52 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 205
ERROR - 2018-04-12 09:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 205
ERROR - 2018-04-12 09:46:52 --> The path to the image is not correct.
ERROR - 2018-04-12 09:46:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:46:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 09:46:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 09:47:06 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 205
ERROR - 2018-04-12 09:47:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 205
ERROR - 2018-04-12 09:47:06 --> The path to the image is not correct.
ERROR - 2018-04-12 09:47:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:47:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 09:47:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 09:47:52 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 205
ERROR - 2018-04-12 09:47:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 205
ERROR - 2018-04-12 09:47:52 --> The path to the image is not correct.
ERROR - 2018-04-12 09:47:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:47:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 09:47:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 09:48:36 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 205
ERROR - 2018-04-12 09:48:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 205
ERROR - 2018-04-12 09:48:36 --> The path to the image is not correct.
ERROR - 2018-04-12 09:48:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 09:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 09:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:24:56 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\models\Profile_model.php 35
ERROR - 2018-04-12 10:25:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`first_name`, `sc`.`last_name`, `sc`.`contact_id`, `sc`.`email`, `sc`.`phone`, ' at line 1 - Invalid query: SELECT `u`.`user_id`, `u`.`display_name`, `u`.`email_address`, `u`.`username`, `u`.`image_path`, `u`.`image_name`, `u`.`role`, `u`.`status`, `s`.`store_id`, `s`.`store_name`, `s`.`address_id` `sc`.`first_name`, `sc`.`last_name`, `sc`.`contact_id`, `sc`.`email`, `sc`.`phone`, `sa`.`street1`, `sa`.`street2`, `sa`.`suburb`, `sa`.`city`, `sa`.`postcode`, `sa`.`state`, `sa`.`country`
FROM `user` `u`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_contact` `sc` ON `sc`.`contact_id` = `s`.`contact_id`
JOIN `store_address` `sa` ON `sa`.`store_address_id` = `s`.`address_id`
WHERE `deleted` IS NULL
AND `user_id` = '2'
ERROR - 2018-04-12 10:25:36 --> Query error: Column 'deleted' in where clause is ambiguous - Invalid query: SELECT `u`.`user_id`, `u`.`display_name`, `u`.`email_address`, `u`.`username`, `u`.`image_path`, `u`.`image_name`, `u`.`role`, `u`.`status`, `s`.`store_id`, `s`.`store_name`, `s`.`address_id`, `sc`.`first_name`, `sc`.`last_name`, `sc`.`contact_id`, `sc`.`email`, `sc`.`phone`, `sa`.`street1`, `sa`.`street2`, `sa`.`suburb`, `sa`.`city`, `sa`.`postcode`, `sa`.`state`, `sa`.`country`
FROM `user` `u`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_contact` `sc` ON `sc`.`contact_id` = `s`.`contact_id`
JOIN `store_address` `sa` ON `sa`.`store_address_id` = `s`.`address_id`
WHERE `deleted` IS NULL
AND `user_id` = '2'
ERROR - 2018-04-12 10:27:08 --> 404 Page Not Found: app/Users/view_user_info
ERROR - 2018-04-12 10:27:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:27:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:31:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:31:27 --> The path to the image is not correct.
ERROR - 2018-04-12 10:31:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:31:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:31:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:31:53 --> The path to the image is not correct.
ERROR - 2018-04-12 10:31:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:31:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:31:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:31:55 --> The path to the image is not correct.
ERROR - 2018-04-12 10:31:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:31:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:31:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:31:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:31:57 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 213
ERROR - 2018-04-12 10:31:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 213
ERROR - 2018-04-12 10:31:57 --> The path to the image is not correct.
ERROR - 2018-04-12 10:31:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:31:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:31:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:33:25 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 205
ERROR - 2018-04-12 10:33:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 205
ERROR - 2018-04-12 10:33:25 --> The path to the image is not correct.
ERROR - 2018-04-12 10:33:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:33:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:33:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:45:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:45:40 --> The path to the image is not correct.
ERROR - 2018-04-12 10:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:45:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 10
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 11
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 26
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 34
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 42
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 51
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 52
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 62
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 63
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 75
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 75
ERROR - 2018-04-12 10:45:43 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 245
ERROR - 2018-04-12 10:45:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 245
ERROR - 2018-04-12 10:45:43 --> 404 Page Not Found: app/Setup/%3Cdiv%20style=
ERROR - 2018-04-12 10:45:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:45:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:45:43 --> The path to the image is not correct.
ERROR - 2018-04-12 10:45:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 10
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 11
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 26
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 34
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 42
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 51
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 52
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 62
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 63
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 75
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 75
ERROR - 2018-04-12 10:46:06 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 245
ERROR - 2018-04-12 10:46:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 245
ERROR - 2018-04-12 10:46:06 --> The path to the image is not correct.
ERROR - 2018-04-12 10:46:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:46:06 --> 404 Page Not Found: app/Setup/%3Cdiv%20style=
ERROR - 2018-04-12 10:46:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:46:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 10
ERROR - 2018-04-12 10:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 11
ERROR - 2018-04-12 10:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 26
ERROR - 2018-04-12 10:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 34
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 42
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 51
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 52
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 62
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 63
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 75
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 75
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 245
ERROR - 2018-04-12 10:46:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 245
ERROR - 2018-04-12 10:46:08 --> The path to the image is not correct.
ERROR - 2018-04-12 10:46:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:46:08 --> 404 Page Not Found: app/Setup/%3Cdiv%20style=
ERROR - 2018-04-12 10:46:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:46:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 10
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 11
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 26
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 34
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 42
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 51
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 52
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 62
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 63
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 75
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 75
ERROR - 2018-04-12 10:46:08 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 245
ERROR - 2018-04-12 10:46:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 245
ERROR - 2018-04-12 10:46:08 --> The path to the image is not correct.
ERROR - 2018-04-12 10:46:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:46:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:46:08 --> 404 Page Not Found: app/Setup/%3Cdiv%20style=
ERROR - 2018-04-12 10:46:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:46:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 40
ERROR - 2018-04-12 10:46:55 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Profile_model.php 40
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 13
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 14
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 29
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 37
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 45
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 54
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 55
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 65
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 66
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 78
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 78
ERROR - 2018-04-12 10:49:59 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:49:59 --> The path to the image is not correct.
ERROR - 2018-04-12 10:49:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:49:59 --> 404 Page Not Found: app/Setup/%3Cdiv%20style=
ERROR - 2018-04-12 10:50:26 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:50:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:50:26 --> The path to the image is not correct.
ERROR - 2018-04-12 10:50:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:50:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:50:26 --> The path to the image is not correct.
ERROR - 2018-04-12 10:50:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:50:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:52:56 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 249
ERROR - 2018-04-12 10:52:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 249
ERROR - 2018-04-12 10:52:56 --> The path to the image is not correct.
ERROR - 2018-04-12 10:52:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:52:56 --> The path to the image is not correct.
ERROR - 2018-04-12 10:52:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:53:02 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:53:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:53:02 --> The path to the image is not correct.
ERROR - 2018-04-12 10:53:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:53:02 --> The path to the image is not correct.
ERROR - 2018-04-12 10:53:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:53:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:53:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:54:25 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:54:25 --> The path to the image is not correct.
ERROR - 2018-04-12 10:54:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:54:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:54:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:54:26 --> The path to the image is not correct.
ERROR - 2018-04-12 10:54:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:54:45 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:54:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:54:45 --> The path to the image is not correct.
ERROR - 2018-04-12 10:54:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:54:45 --> The path to the image is not correct.
ERROR - 2018-04-12 10:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:54:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:54:50 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:54:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:54:50 --> The path to the image is not correct.
ERROR - 2018-04-12 10:54:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:54:50 --> The path to the image is not correct.
ERROR - 2018-04-12 10:54:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:54:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:54:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:55:01 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:55:01 --> The path to the image is not correct.
ERROR - 2018-04-12 10:55:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:55:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:55:01 --> The path to the image is not correct.
ERROR - 2018-04-12 10:55:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:55:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:55:07 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:55:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:55:07 --> The path to the image is not correct.
ERROR - 2018-04-12 10:55:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:55:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:55:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:55:07 --> The path to the image is not correct.
ERROR - 2018-04-12 10:55:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:55:11 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:55:11 --> The path to the image is not correct.
ERROR - 2018-04-12 10:55:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:55:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:55:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:55:12 --> The path to the image is not correct.
ERROR - 2018-04-12 10:55:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:56:21 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:56:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:56:21 --> The path to the image is not correct.
ERROR - 2018-04-12 10:56:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:56:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:56:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:56:21 --> The path to the image is not correct.
ERROR - 2018-04-12 10:56:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:56:35 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:56:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:56:35 --> The path to the image is not correct.
ERROR - 2018-04-12 10:56:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:56:35 --> The path to the image is not correct.
ERROR - 2018-04-12 10:56:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:56:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:56:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:56:48 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:56:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:56:48 --> The path to the image is not correct.
ERROR - 2018-04-12 10:56:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:56:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:56:48 --> The path to the image is not correct.
ERROR - 2018-04-12 10:56:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:56:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:56:59 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:56:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:56:59 --> The path to the image is not correct.
ERROR - 2018-04-12 10:56:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:56:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:56:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:56:59 --> The path to the image is not correct.
ERROR - 2018-04-12 10:56:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:57:56 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:57:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:57:56 --> The path to the image is not correct.
ERROR - 2018-04-12 10:57:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:57:56 --> The path to the image is not correct.
ERROR - 2018-04-12 10:57:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:57:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:57:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:58:22 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:58:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 10:58:22 --> The path to the image is not correct.
ERROR - 2018-04-12 10:58:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:58:22 --> The path to the image is not correct.
ERROR - 2018-04-12 10:58:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 10:58:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 10:58:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:02:07 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 11:02:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 11:02:08 --> The path to the image is not correct.
ERROR - 2018-04-12 11:02:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:02:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:02:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:02:08 --> The path to the image is not correct.
ERROR - 2018-04-12 11:02:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:02:24 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 246
ERROR - 2018-04-12 11:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 246
ERROR - 2018-04-12 11:02:25 --> The path to the image is not correct.
ERROR - 2018-04-12 11:02:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:02:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:02:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:02:25 --> The path to the image is not correct.
ERROR - 2018-04-12 11:02:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:02:34 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 246
ERROR - 2018-04-12 11:02:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 246
ERROR - 2018-04-12 11:02:34 --> The path to the image is not correct.
ERROR - 2018-04-12 11:02:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:02:34 --> The path to the image is not correct.
ERROR - 2018-04-12 11:02:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:02:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:02:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:03:01 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 11:03:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 11:03:01 --> The path to the image is not correct.
ERROR - 2018-04-12 11:03:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:03:01 --> The path to the image is not correct.
ERROR - 2018-04-12 11:03:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:03:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:03:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:03:17 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 11:03:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 11:03:17 --> The path to the image is not correct.
ERROR - 2018-04-12 11:03:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:03:17 --> The path to the image is not correct.
ERROR - 2018-04-12 11:03:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:03:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:03:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:03:38 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 11:03:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 248
ERROR - 2018-04-12 11:03:38 --> The path to the image is not correct.
ERROR - 2018-04-12 11:03:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:03:38 --> The path to the image is not correct.
ERROR - 2018-04-12 11:03:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:03:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:03:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:08:12 --> Severity: Notice --> Undefined property: stdClass::$_last_name D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 118
ERROR - 2018-04-12 11:08:12 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 246
ERROR - 2018-04-12 11:08:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 246
ERROR - 2018-04-12 11:08:12 --> The path to the image is not correct.
ERROR - 2018-04-12 11:08:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:08:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:08:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:08:12 --> The path to the image is not correct.
ERROR - 2018-04-12 11:08:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:08:24 --> Severity: Notice --> Undefined variable: countries_list D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 246
ERROR - 2018-04-12 11:08:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\profile\view.php 246
ERROR - 2018-04-12 11:08:24 --> The path to the image is not correct.
ERROR - 2018-04-12 11:08:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:08:24 --> The path to the image is not correct.
ERROR - 2018-04-12 11:08:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:08:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:08:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:12:56 --> The path to the image is not correct.
ERROR - 2018-04-12 11:12:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:12:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:12:57 --> The path to the image is not correct.
ERROR - 2018-04-12 11:12:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:12:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:13:10 --> The path to the image is not correct.
ERROR - 2018-04-12 11:13:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:13:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:13:10 --> The path to the image is not correct.
ERROR - 2018-04-12 11:13:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:13:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:13:21 --> The path to the image is not correct.
ERROR - 2018-04-12 11:13:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:13:21 --> The path to the image is not correct.
ERROR - 2018-04-12 11:13:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:13:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:13:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:14:31 --> The path to the image is not correct.
ERROR - 2018-04-12 11:14:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:14:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:14:31 --> The path to the image is not correct.
ERROR - 2018-04-12 11:14:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:14:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:15:20 --> The path to the image is not correct.
ERROR - 2018-04-12 11:15:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:15:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:15:20 --> The path to the image is not correct.
ERROR - 2018-04-12 11:15:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:15:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:15:29 --> The path to the image is not correct.
ERROR - 2018-04-12 11:15:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:15:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:15:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:15:29 --> The path to the image is not correct.
ERROR - 2018-04-12 11:15:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:15:38 --> The path to the image is not correct.
ERROR - 2018-04-12 11:15:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:15:38 --> The path to the image is not correct.
ERROR - 2018-04-12 11:15:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:15:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:15:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:16:14 --> The path to the image is not correct.
ERROR - 2018-04-12 11:16:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:16:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:16:15 --> The path to the image is not correct.
ERROR - 2018-04-12 11:16:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:16:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:16:38 --> The path to the image is not correct.
ERROR - 2018-04-12 11:16:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:16:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:16:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:16:38 --> The path to the image is not correct.
ERROR - 2018-04-12 11:16:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:19:01 --> The path to the image is not correct.
ERROR - 2018-04-12 11:19:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:19:01 --> The path to the image is not correct.
ERROR - 2018-04-12 11:19:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:19:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:19:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:20:20 --> The path to the image is not correct.
ERROR - 2018-04-12 11:20:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:20:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:20:20 --> The path to the image is not correct.
ERROR - 2018-04-12 11:20:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:20:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:20:47 --> The path to the image is not correct.
ERROR - 2018-04-12 11:20:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:20:47 --> The path to the image is not correct.
ERROR - 2018-04-12 11:20:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:20:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:20:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:21:00 --> The path to the image is not correct.
ERROR - 2018-04-12 11:21:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:21:00 --> The path to the image is not correct.
ERROR - 2018-04-12 11:21:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:21:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:21:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:21:27 --> The path to the image is not correct.
ERROR - 2018-04-12 11:21:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:21:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:21:27 --> The path to the image is not correct.
ERROR - 2018-04-12 11:21:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:21:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:21:37 --> The path to the image is not correct.
ERROR - 2018-04-12 11:21:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:21:37 --> The path to the image is not correct.
ERROR - 2018-04-12 11:21:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:21:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:21:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:22 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:22 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:31 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:31 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:37 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:37 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:37 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:37 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:44 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:44 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:58 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:22:58 --> The path to the image is not correct.
ERROR - 2018-04-12 11:22:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:22:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:23:46 --> The path to the image is not correct.
ERROR - 2018-04-12 11:23:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:23:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:23:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:23:46 --> The path to the image is not correct.
ERROR - 2018-04-12 11:23:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:29:53 --> The path to the image is not correct.
ERROR - 2018-04-12 11:29:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:29:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:29:53 --> The path to the image is not correct.
ERROR - 2018-04-12 11:29:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:29:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:30:15 --> The path to the image is not correct.
ERROR - 2018-04-12 11:30:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:30:15 --> The path to the image is not correct.
ERROR - 2018-04-12 11:30:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:30:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:30:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:30:29 --> The path to the image is not correct.
ERROR - 2018-04-12 11:30:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:30:29 --> The path to the image is not correct.
ERROR - 2018-04-12 11:30:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:30:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:30:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:30:45 --> The path to the image is not correct.
ERROR - 2018-04-12 11:30:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:30:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:30:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:30:45 --> The path to the image is not correct.
ERROR - 2018-04-12 11:30:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:32:39 --> The path to the image is not correct.
ERROR - 2018-04-12 11:32:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:32:39 --> The path to the image is not correct.
ERROR - 2018-04-12 11:32:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:32:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:32:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:33:10 --> The path to the image is not correct.
ERROR - 2018-04-12 11:33:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:33:10 --> The path to the image is not correct.
ERROR - 2018-04-12 11:33:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:33:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:33:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:36:11 --> The path to the image is not correct.
ERROR - 2018-04-12 11:36:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:36:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:36:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:36:11 --> The path to the image is not correct.
ERROR - 2018-04-12 11:36:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:36:25 --> The path to the image is not correct.
ERROR - 2018-04-12 11:36:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-12 11:36:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:36:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-12 11:36:25 --> The path to the image is not correct.
ERROR - 2018-04-12 11:36:25 --> Your server does not support the GD function required to process this type of image.

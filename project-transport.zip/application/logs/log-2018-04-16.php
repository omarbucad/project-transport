<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-16 04:13:56 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-16 04:46:53 --> 404 Page Not Found: app/Setup/settings
ERROR - 2018-04-16 06:23:42 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\models\Profile_model.php 123
ERROR - 2018-04-16 06:23:49 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\models\Profile_model.php 123
ERROR - 2018-04-16 07:43:59 --> Severity: Notice --> Undefined variable: expiry D:\xampp\htdocs\project-transport\application\models\Profile_model.php 120
ERROR - 2018-04-16 07:52:20 --> Severity: Notice --> Undefined property: stdClass::$trial_left D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 54
ERROR - 2018-04-16 09:31:48 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 65
ERROR - 2018-04-16 10:07:08 --> 404 Page Not Found: app/Users/edit
ERROR - 2018-04-16 10:07:35 --> 404 Page Not Found: app/Users/edit
ERROR - 2018-04-16 10:08:12 --> 404 Page Not Found: app/Users/edit
ERROR - 2018-04-16 10:09:02 --> 404 Page Not Found: app/Users/edit
ERROR - 2018-04-16 10:26:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:26:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:26:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:26:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:26:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:26:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:26:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:26:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:27:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:27:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:28:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:28:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:28:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:28:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:29:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:29:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:29:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:29:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:39:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:39:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:39:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:39:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 10:40:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:03:23 --> The path to the image is not correct.
ERROR - 2018-04-16 11:03:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:04:27 --> The path to the image is not correct.
ERROR - 2018-04-16 11:04:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:04:57 --> The path to the image is not correct.
ERROR - 2018-04-16 11:04:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:07:15 --> The path to the image is not correct.
ERROR - 2018-04-16 11:07:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:08:00 --> The path to the image is not correct.
ERROR - 2018-04-16 11:08:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:08:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:08:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:10:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:10:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:10:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:10:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:10:36 --> The path to the image is not correct.
ERROR - 2018-04-16 11:10:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:11:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:11:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:11:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:11:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:11:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:11:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:15:57 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 42
ERROR - 2018-04-16 11:18:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:18:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:18:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:18:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:18:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:18:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:18:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:18:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:15 --> The path to the image is not correct.
ERROR - 2018-04-16 11:19:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:19:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 42
ERROR - 2018-04-16 11:19:44 --> The path to the image is not correct.
ERROR - 2018-04-16 11:19:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:19:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:52 --> 404 Page Not Found: app/Users/edit
ERROR - 2018-04-16 11:19:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:19:54 --> The path to the image is not correct.
ERROR - 2018-04-16 11:19:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:20:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:20:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:22:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 44
ERROR - 2018-04-16 11:22:13 --> The path to the image is not correct.
ERROR - 2018-04-16 11:22:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:22:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:22:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:22:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:22:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:23:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 44
ERROR - 2018-04-16 11:23:02 --> The path to the image is not correct.
ERROR - 2018-04-16 11:23:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:23:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:23:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:23:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:23:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:23:56 --> The path to the image is not correct.
ERROR - 2018-04-16 11:23:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:23:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:23:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:24:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 44
ERROR - 2018-04-16 11:25:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:25:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:25:20 --> The path to the image is not correct.
ERROR - 2018-04-16 11:25:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:25:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:25:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:39:55 --> The path to the image is not correct.
ERROR - 2018-04-16 11:39:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:39:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:47:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:47:56 --> The path to the image is not correct.
ERROR - 2018-04-16 11:47:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:47:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:47:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:47:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:48:00 --> The path to the image is not correct.
ERROR - 2018-04-16 11:48:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:48:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:48:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:48:16 --> The path to the image is not correct.
ERROR - 2018-04-16 11:48:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:48:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:48:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:48:17 --> Severity: Notice --> Undefined variable: row_status D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 27
ERROR - 2018-04-16 11:50:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:50:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:50:03 --> The path to the image is not correct.
ERROR - 2018-04-16 11:50:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:50:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:50:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:50:41 --> The path to the image is not correct.
ERROR - 2018-04-16 11:50:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:50:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:50:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:54:03 --> Severity: Notice --> Undefined property: stdClass::$email D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 55
ERROR - 2018-04-16 11:54:03 --> The path to the image is not correct.
ERROR - 2018-04-16 11:54:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:54:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:54:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:54:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:54:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:54:37 --> The path to the image is not correct.
ERROR - 2018-04-16 11:54:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:55:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:55:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:58:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:58:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:58:23 --> The path to the image is not correct.
ERROR - 2018-04-16 11:58:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 11:58:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 11:58:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:05:30 --> The path to the image is not correct.
ERROR - 2018-04-16 12:05:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:05:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:05:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:06:05 --> The path to the image is not correct.
ERROR - 2018-04-16 12:06:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:06:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:06:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:06:07 --> The path to the image is not correct.
ERROR - 2018-04-16 12:06:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:06:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:06:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:07:00 --> The path to the image is not correct.
ERROR - 2018-04-16 12:07:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:07:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:07:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:07:01 --> The path to the image is not correct.
ERROR - 2018-04-16 12:07:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:07:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:07:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:07:02 --> The path to the image is not correct.
ERROR - 2018-04-16 12:07:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:07:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:07:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:07:02 --> The path to the image is not correct.
ERROR - 2018-04-16 12:07:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:07:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:07:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:07:02 --> The path to the image is not correct.
ERROR - 2018-04-16 12:07:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:07:57 --> The path to the image is not correct.
ERROR - 2018-04-16 12:07:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:07:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:07:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:10:06 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:10:06 --> The path to the image is not correct.
ERROR - 2018-04-16 12:10:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:10:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:10:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:13:04 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:13:04 --> The path to the image is not correct.
ERROR - 2018-04-16 12:13:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:13:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:13:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:17:29 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:17:29 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:17:29 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:17:29 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:17:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:17:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:17:30 --> The path to the image is not correct.
ERROR - 2018-04-16 12:17:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:18:04 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:18:04 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:18:05 --> The path to the image is not correct.
ERROR - 2018-04-16 12:18:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:18:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:18:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:19:34 --> Severity: Notice --> Undefined property: stdClass::$cehcklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:19:34 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:19:34 --> Severity: Notice --> Undefined property: stdClass::$cehcklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:19:34 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:19:34 --> The path to the image is not correct.
ERROR - 2018-04-16 12:19:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:19:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:19:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:19:43 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:19:43 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:19:43 --> The path to the image is not correct.
ERROR - 2018-04-16 12:19:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:19:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:19:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:22:34 --> The path to the image is not correct.
ERROR - 2018-04-16 12:22:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:22:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:22:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:22:47 --> The path to the image is not correct.
ERROR - 2018-04-16 12:22:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:22:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:22:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:23:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:23:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:23:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:25:04 --> Severity: Parsing Error --> syntax error, unexpected '0' (T_LNUMBER) D:\xampp\htdocs\project-transport\application\models\Checklist_model.php 209
ERROR - 2018-04-16 12:25:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:25:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:25:40 --> The path to the image is not correct.
ERROR - 2018-04-16 12:25:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:25:44 --> Severity: Notice --> Undefined property: stdClass::$user_checklist D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 98
ERROR - 2018-04-16 12:25:44 --> The path to the image is not correct.
ERROR - 2018-04-16 12:25:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:25:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:25:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:27:38 --> Severity: Notice --> Undefined property: stdClass::$user D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 36
ERROR - 2018-04-16 12:27:48 --> The path to the image is not correct.
ERROR - 2018-04-16 12:27:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:27:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:27:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:27:55 --> Severity: Notice --> Undefined property: stdClass::$user_checklist D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 98
ERROR - 2018-04-16 12:27:55 --> The path to the image is not correct.
ERROR - 2018-04-16 12:27:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:27:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:27:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:29:46 --> The path to the image is not correct.
ERROR - 2018-04-16 12:29:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:29:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:29:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:32:16 --> The path to the image is not correct.
ERROR - 2018-04-16 12:32:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:32:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:32:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:34:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:34:30 --> The path to the image is not correct.
ERROR - 2018-04-16 12:34:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:34:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:36:08 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 99
ERROR - 2018-04-16 12:36:08 --> The path to the image is not correct.
ERROR - 2018-04-16 12:36:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:36:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:36:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:37:23 --> The path to the image is not correct.
ERROR - 2018-04-16 12:37:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:37:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:37:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:38:31 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 98
ERROR - 2018-04-16 12:38:31 --> The path to the image is not correct.
ERROR - 2018-04-16 12:38:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:38:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:38:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:39:01 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 98
ERROR - 2018-04-16 12:39:02 --> The path to the image is not correct.
ERROR - 2018-04-16 12:39:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:39:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:39:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:39:13 --> The path to the image is not correct.
ERROR - 2018-04-16 12:39:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:39:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:39:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:39:16 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\views\backend\page\users\edit.php 98
ERROR - 2018-04-16 12:39:16 --> The path to the image is not correct.
ERROR - 2018-04-16 12:39:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:39:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:39:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:34 --> The path to the image is not correct.
ERROR - 2018-04-16 12:41:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:41:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:35 --> The path to the image is not correct.
ERROR - 2018-04-16 12:41:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:41:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:36 --> The path to the image is not correct.
ERROR - 2018-04-16 12:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:36 --> The path to the image is not correct.
ERROR - 2018-04-16 12:41:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:36 --> The path to the image is not correct.
ERROR - 2018-04-16 12:41:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:41:55 --> The path to the image is not correct.
ERROR - 2018-04-16 12:41:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:42:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:42:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:42:29 --> The path to the image is not correct.
ERROR - 2018-04-16 12:42:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:42:58 --> The path to the image is not correct.
ERROR - 2018-04-16 12:42:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:42:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:42:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:50 --> The path to the image is not correct.
ERROR - 2018-04-16 12:45:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:45:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:51 --> The path to the image is not correct.
ERROR - 2018-04-16 12:45:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:45:52 --> The path to the image is not correct.
ERROR - 2018-04-16 12:45:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:45:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:52 --> The path to the image is not correct.
ERROR - 2018-04-16 12:45:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:45:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:52 --> The path to the image is not correct.
ERROR - 2018-04-16 12:45:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:45:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:52 --> The path to the image is not correct.
ERROR - 2018-04-16 12:45:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:45:53 --> The path to the image is not correct.
ERROR - 2018-04-16 12:45:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:45:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:45:53 --> The path to the image is not correct.
ERROR - 2018-04-16 12:45:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:55:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:55:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:55:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:55:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:57:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:57:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:57:47 --> The path to the image is not correct.
ERROR - 2018-04-16 12:57:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:57:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:57:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:57:52 --> The path to the image is not correct.
ERROR - 2018-04-16 12:57:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:57:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:57:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:58:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:58:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:58:15 --> The path to the image is not correct.
ERROR - 2018-04-16 12:58:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:58:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:58:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:58:59 --> The path to the image is not correct.
ERROR - 2018-04-16 12:58:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:59:02 --> The path to the image is not correct.
ERROR - 2018-04-16 12:59:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:59:56 --> The path to the image is not correct.
ERROR - 2018-04-16 12:59:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-16 12:59:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:59:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:59:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:59:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-16 12:59:57 --> The path to the image is not correct.
ERROR - 2018-04-16 12:59:57 --> Your server does not support the GD function required to process this type of image.

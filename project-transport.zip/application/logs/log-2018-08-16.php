<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-16 02:57:16 --> The path to the image is not correct.
ERROR - 2018-08-16 02:57:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 02:57:18 --> The path to the image is not correct.
ERROR - 2018-08-16 02:57:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 02:57:18 --> The path to the image is not correct.
ERROR - 2018-08-16 02:57:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 05:02:08 --> The path to the image is not correct.
ERROR - 2018-08-16 05:02:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 05:02:08 --> The path to the image is not correct.
ERROR - 2018-08-16 05:02:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 05:02:10 --> The path to the image is not correct.
ERROR - 2018-08-16 05:02:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 05:02:14 --> The path to the image is not correct.
ERROR - 2018-08-16 05:02:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 09:46:21 --> The path to the image is not correct.
ERROR - 2018-08-16 09:46:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 09:46:24 --> The path to the image is not correct.
ERROR - 2018-08-16 09:46:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 11:44:36 --> The path to the image is not correct.
ERROR - 2018-08-16 11:44:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 11:44:40 --> The path to the image is not correct.
ERROR - 2018-08-16 11:44:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 11:45:10 --> The path to the image is not correct.
ERROR - 2018-08-16 11:45:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 11:45:13 --> The path to the image is not correct.
ERROR - 2018-08-16 11:45:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 11:45:24 --> The path to the image is not correct.
ERROR - 2018-08-16 11:45:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 11:45:29 --> The path to the image is not correct.
ERROR - 2018-08-16 11:45:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 11:56:55 --> The path to the image is not correct.
ERROR - 2018-08-16 11:56:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 11:56:58 --> The path to the image is not correct.
ERROR - 2018-08-16 11:56:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-16 11:57:00 --> The path to the image is not correct.
ERROR - 2018-08-16 11:57:00 --> Your server does not support the GD function required to process this type of image.

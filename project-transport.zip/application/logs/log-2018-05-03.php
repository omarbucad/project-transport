<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-03 04:16:08 --> 404 Page Not Found: Public/lib
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-03 04:16:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 05:04:04 --> 404 Page Not Found: app/Report/index
ERROR - 2018-05-03 05:04:31 --> 404 Page Not Found: app/Report/index
ERROR - 2018-05-03 05:05:07 --> 404 Page Not Found: app/Report/index
ERROR - 2018-05-03 05:05:19 --> 404 Page Not Found: app/Report/index
ERROR - 2018-05-03 05:07:31 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\models\Report_model.php 158
ERROR - 2018-05-03 05:35:45 --> The path to the image is not correct.
ERROR - 2018-05-03 05:35:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 05:36:56 --> The path to the image is not correct.
ERROR - 2018-05-03 05:36:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 05:38:46 --> Query error: Unknown column 'remind_in' in 'field list' - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES ('14', '', '', '31', '0', '123', 'Sample checklist', 1525318726, NULL, 0)
ERROR - 2018-05-03 05:38:46 --> Query error: Unknown column 'remind_in' in 'field list' - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES ('14', '', '', '31', '0', '123', 'Sample checklist', 1525318726, NULL, 0)
ERROR - 2018-05-03 07:04:09 --> Query error: Unknown column 'remind_in' in 'field list' - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES ('14', '', '', '40', '150', '150', 'Test', 1525323849, NULL, 0)
ERROR - 2018-05-03 07:04:10 --> Query error: Unknown column 'remind_in' in 'field list' - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES ('14', '', '', '40', '150', '150', 'Test', 1525323850, NULL, 0)
ERROR - 2018-05-03 07:07:32 --> Query error: Unknown column 'remind_in' in 'field list' - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES ('14', '', '', '40', '150', '180', 'Hehe', 1525324052, NULL, 0)
ERROR - 2018-05-03 07:07:33 --> Query error: Unknown column 'remind_in' in 'field list' - Invalid query: INSERT INTO `report` (`report_by`, `vehicle_registration_number`, `trailer_number`, `checklist_id`, `start_mileage`, `end_mileage`, `report_notes`, `created`, `remind_in`, `remind_done`) VALUES ('14', '', '', '40', '150', '180', 'Hehe', 1525324053, NULL, 0)
ERROR - 2018-05-03 07:52:00 --> The path to the image is not correct.
ERROR - 2018-05-03 07:52:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 07:53:23 --> The path to the image is not correct.
ERROR - 2018-05-03 07:53:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 07:54:47 --> The path to the image is not correct.
ERROR - 2018-05-03 07:54:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 07:56:16 --> The path to the image is not correct.
ERROR - 2018-05-03 07:56:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:15:16 --> The path to the image is not correct.
ERROR - 2018-05-03 08:15:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:15:42 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 120
ERROR - 2018-05-03 08:15:42 --> The path to the image is not correct.
ERROR - 2018-05-03 08:15:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:16:21 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 120
ERROR - 2018-05-03 08:16:21 --> The path to the image is not correct.
ERROR - 2018-05-03 08:16:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:16:26 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\dashboard\dashboard.php 120
ERROR - 2018-05-03 08:16:26 --> The path to the image is not correct.
ERROR - 2018-05-03 08:16:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:16:38 --> The path to the image is not correct.
ERROR - 2018-05-03 08:16:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:16:45 --> The path to the image is not correct.
ERROR - 2018-05-03 08:16:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:16:51 --> The path to the image is not correct.
ERROR - 2018-05-03 08:16:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:17:07 --> The path to the image is not correct.
ERROR - 2018-05-03 08:17:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:20:22 --> The path to the image is not correct.
ERROR - 2018-05-03 08:20:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:20:23 --> The path to the image is not correct.
ERROR - 2018-05-03 08:20:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:20:24 --> The path to the image is not correct.
ERROR - 2018-05-03 08:20:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:20:28 --> The path to the image is not correct.
ERROR - 2018-05-03 08:20:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:20:28 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-03 08:27:44 --> The path to the image is not correct.
ERROR - 2018-05-03 08:27:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:27:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:27:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:32:45 --> The path to the image is not correct.
ERROR - 2018-05-03 08:32:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:32:46 --> The path to the image is not correct.
ERROR - 2018-05-03 08:32:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:32:47 --> The path to the image is not correct.
ERROR - 2018-05-03 08:32:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:35:19 --> The path to the image is not correct.
ERROR - 2018-05-03 08:35:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:36:40 --> The path to the image is not correct.
ERROR - 2018-05-03 08:36:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:36:49 --> The path to the image is not correct.
ERROR - 2018-05-03 08:36:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:37:27 --> The path to the image is not correct.
ERROR - 2018-05-03 08:37:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:38:12 --> The path to the image is not correct.
ERROR - 2018-05-03 08:38:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:38:18 --> The path to the image is not correct.
ERROR - 2018-05-03 08:38:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:39:16 --> The path to the image is not correct.
ERROR - 2018-05-03 08:39:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:39:22 --> The path to the image is not correct.
ERROR - 2018-05-03 08:39:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:39:55 --> The path to the image is not correct.
ERROR - 2018-05-03 08:39:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:40:22 --> The path to the image is not correct.
ERROR - 2018-05-03 08:40:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:40:53 --> The path to the image is not correct.
ERROR - 2018-05-03 08:40:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:41:06 --> The path to the image is not correct.
ERROR - 2018-05-03 08:41:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:41:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:41:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:41:55 --> The path to the image is not correct.
ERROR - 2018-05-03 08:41:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:41:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:41:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:41:56 --> The path to the image is not correct.
ERROR - 2018-05-03 08:41:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:41:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:41:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:42:13 --> The path to the image is not correct.
ERROR - 2018-05-03 08:42:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:42:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:42:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:42:22 --> The path to the image is not correct.
ERROR - 2018-05-03 08:42:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:42:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:42:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:42:32 --> The path to the image is not correct.
ERROR - 2018-05-03 08:42:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:42:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:42:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:43:18 --> The path to the image is not correct.
ERROR - 2018-05-03 08:43:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:43:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:43:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:43:37 --> The path to the image is not correct.
ERROR - 2018-05-03 08:43:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:43:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:43:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:44:16 --> The path to the image is not correct.
ERROR - 2018-05-03 08:44:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 08:44:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:44:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 08:47:32 --> The path to the image is not correct.
ERROR - 2018-05-03 08:47:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:06:19 --> The path to the image is not correct.
ERROR - 2018-05-03 09:06:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:06:43 --> The path to the image is not correct.
ERROR - 2018-05-03 09:06:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:07:19 --> The path to the image is not correct.
ERROR - 2018-05-03 09:07:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:07:33 --> The path to the image is not correct.
ERROR - 2018-05-03 09:07:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:07:36 --> The path to the image is not correct.
ERROR - 2018-05-03 09:07:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:07:38 --> The path to the image is not correct.
ERROR - 2018-05-03 09:07:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:15:39 --> The path to the image is not correct.
ERROR - 2018-05-03 09:15:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:15:56 --> The path to the image is not correct.
ERROR - 2018-05-03 09:15:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:16:46 --> The path to the image is not correct.
ERROR - 2018-05-03 09:16:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:17:03 --> The path to the image is not correct.
ERROR - 2018-05-03 09:17:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:17:06 --> The path to the image is not correct.
ERROR - 2018-05-03 09:17:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:17:31 --> The path to the image is not correct.
ERROR - 2018-05-03 09:17:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:17:36 --> The path to the image is not correct.
ERROR - 2018-05-03 09:17:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:19:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 30
ERROR - 2018-05-03 09:19:59 --> The path to the image is not correct.
ERROR - 2018-05-03 09:20:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:20:12 --> The path to the image is not correct.
ERROR - 2018-05-03 09:20:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:20:44 --> The path to the image is not correct.
ERROR - 2018-05-03 09:20:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:20:44 --> The path to the image is not correct.
ERROR - 2018-05-03 09:20:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:20:45 --> The path to the image is not correct.
ERROR - 2018-05-03 09:20:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:20:45 --> The path to the image is not correct.
ERROR - 2018-05-03 09:20:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:21:17 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 185
ERROR - 2018-05-03 09:21:17 --> Severity: Notice --> Undefined variable: end_created D:\xampp\htdocs\project-transport\application\models\Report_model.php 186
ERROR - 2018-05-03 09:21:17 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 186
ERROR - 2018-05-03 09:23:18 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\project-transport\application\models\Report_model.php 159
ERROR - 2018-05-03 09:25:41 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\project-transport\application\models\Report_model.php 160
ERROR - 2018-05-03 09:25:53 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\models\Report_model.php 160
ERROR - 2018-05-03 09:26:59 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 188
ERROR - 2018-05-03 09:26:59 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 188
ERROR - 2018-05-03 09:26:59 --> The path to the image is not correct.
ERROR - 2018-05-03 09:26:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 188
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 188
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 190
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 191
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 192
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 198
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 200
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-03 09:33:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-03 09:33:37 --> The path to the image is not correct.
ERROR - 2018-05-03 09:33:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 188
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 188
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 190
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 191
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 192
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 198
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 200
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-03 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-03 09:37:12 --> The path to the image is not correct.
ERROR - 2018-05-03 09:37:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 187
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 187
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 189
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 190
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 191
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 197
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 199
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 207
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 207
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-03 09:39:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-03 09:39:22 --> The path to the image is not correct.
ERROR - 2018-05-03 09:39:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:39:28 --> Severity: Notice --> Undefined index: range D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 163
ERROR - 2018-05-03 09:39:28 --> The path to the image is not correct.
ERROR - 2018-05-03 09:39:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:44:09 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 188
ERROR - 2018-05-03 09:45:41 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 163
ERROR - 2018-05-03 09:45:41 --> The path to the image is not correct.
ERROR - 2018-05-03 09:45:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:46:01 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 163
ERROR - 2018-05-03 09:46:01 --> The path to the image is not correct.
ERROR - 2018-05-03 09:46:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:46:39 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 163
ERROR - 2018-05-03 09:46:39 --> The path to the image is not correct.
ERROR - 2018-05-03 09:46:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:46:44 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 163
ERROR - 2018-05-03 09:46:44 --> The path to the image is not correct.
ERROR - 2018-05-03 09:46:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:47:04 --> The path to the image is not correct.
ERROR - 2018-05-03 09:47:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:47:13 --> The path to the image is not correct.
ERROR - 2018-05-03 09:47:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:47:24 --> The path to the image is not correct.
ERROR - 2018-05-03 09:47:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:47:33 --> The path to the image is not correct.
ERROR - 2018-05-03 09:47:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:47:50 --> The path to the image is not correct.
ERROR - 2018-05-03 09:47:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:51:21 --> The path to the image is not correct.
ERROR - 2018-05-03 09:51:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 09:52:18 --> The path to the image is not correct.
ERROR - 2018-05-03 09:52:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:00:59 --> The path to the image is not correct.
ERROR - 2018-05-03 10:00:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:01:16 --> The path to the image is not correct.
ERROR - 2018-05-03 10:01:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:02:42 --> The path to the image is not correct.
ERROR - 2018-05-03 10:02:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:03:13 --> The path to the image is not correct.
ERROR - 2018-05-03 10:03:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:03:47 --> The path to the image is not correct.
ERROR - 2018-05-03 10:03:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:05:09 --> The path to the image is not correct.
ERROR - 2018-05-03 10:05:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:05:30 --> The path to the image is not correct.
ERROR - 2018-05-03 10:05:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:05:50 --> The path to the image is not correct.
ERROR - 2018-05-03 10:05:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:06:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:06:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:07:32 --> The path to the image is not correct.
ERROR - 2018-05-03 10:07:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:07:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:07:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:07:52 --> The path to the image is not correct.
ERROR - 2018-05-03 10:07:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:07:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:07:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:08:41 --> The path to the image is not correct.
ERROR - 2018-05-03 10:08:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:08:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:08:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:09:03 --> The path to the image is not correct.
ERROR - 2018-05-03 10:09:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:09:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:09:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:09:33 --> The path to the image is not correct.
ERROR - 2018-05-03 10:09:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:09:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:09:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:10:21 --> The path to the image is not correct.
ERROR - 2018-05-03 10:10:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:10:31 --> The path to the image is not correct.
ERROR - 2018-05-03 10:10:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:10:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:10:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:10:47 --> The path to the image is not correct.
ERROR - 2018-05-03 10:10:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:10:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:10:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:11:18 --> The path to the image is not correct.
ERROR - 2018-05-03 10:11:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:11:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:11:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:11:28 --> The path to the image is not correct.
ERROR - 2018-05-03 10:11:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:11:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:11:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:12:12 --> The path to the image is not correct.
ERROR - 2018-05-03 10:12:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:12:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:12:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:05 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:07 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:07 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:07 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:08 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:08 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:08 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:08 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:08 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:08 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:41 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:55 --> The path to the image is not correct.
ERROR - 2018-05-03 10:14:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:14:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:14:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:16:16 --> The path to the image is not correct.
ERROR - 2018-05-03 10:16:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:16:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:16:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:16:39 --> The path to the image is not correct.
ERROR - 2018-05-03 10:16:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:16:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:16:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:16:45 --> The path to the image is not correct.
ERROR - 2018-05-03 10:16:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:16:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:16:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:22:26 --> The path to the image is not correct.
ERROR - 2018-05-03 10:22:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:22:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:22:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:23 --> The path to the image is not correct.
ERROR - 2018-05-03 10:25:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:25:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:26 --> The path to the image is not correct.
ERROR - 2018-05-03 10:25:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:25:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:34 --> The path to the image is not correct.
ERROR - 2018-05-03 10:25:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:25:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:36 --> The path to the image is not correct.
ERROR - 2018-05-03 10:25:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:25:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:37 --> The path to the image is not correct.
ERROR - 2018-05-03 10:25:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:25:37 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-03 10:25:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:25:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:26:39 --> The path to the image is not correct.
ERROR - 2018-05-03 10:26:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:26:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:26:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:26:45 --> The path to the image is not correct.
ERROR - 2018-05-03 10:26:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:26:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:26:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:32:56 --> The path to the image is not correct.
ERROR - 2018-05-03 10:32:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:32:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:32:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:34:25 --> The path to the image is not correct.
ERROR - 2018-05-03 10:34:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:34:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:34:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:34:36 --> The path to the image is not correct.
ERROR - 2018-05-03 10:34:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:34:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:34:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:34:59 --> The path to the image is not correct.
ERROR - 2018-05-03 10:34:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:34:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:34:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:35:14 --> The path to the image is not correct.
ERROR - 2018-05-03 10:35:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:35:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:35:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:35:30 --> The path to the image is not correct.
ERROR - 2018-05-03 10:35:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:35:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:35:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:06 --> The path to the image is not correct.
ERROR - 2018-05-03 10:36:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:36:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:08 --> The path to the image is not correct.
ERROR - 2018-05-03 10:36:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:36:08 --> The path to the image is not correct.
ERROR - 2018-05-03 10:36:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:36:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:10 --> 404 Page Not Found: app/Users/view_user_info
ERROR - 2018-05-03 10:36:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:17 --> The path to the image is not correct.
ERROR - 2018-05-03 10:36:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:36:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:17 --> The path to the image is not correct.
ERROR - 2018-05-03 10:36:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:36:23 --> The path to the image is not correct.
ERROR - 2018-05-03 10:36:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:36:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:25 --> The path to the image is not correct.
ERROR - 2018-05-03 10:36:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:36:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:36:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:38:35 --> The path to the image is not correct.
ERROR - 2018-05-03 10:38:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:38:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:38:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:38:41 --> The path to the image is not correct.
ERROR - 2018-05-03 10:38:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:38:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:38:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:39:01 --> The path to the image is not correct.
ERROR - 2018-05-03 10:39:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:39:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:39:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:40:12 --> The path to the image is not correct.
ERROR - 2018-05-03 10:40:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:40:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:40:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:40:24 --> The path to the image is not correct.
ERROR - 2018-05-03 10:40:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:40:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:40:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:41:35 --> The path to the image is not correct.
ERROR - 2018-05-03 10:41:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:41:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:41:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:41:50 --> The path to the image is not correct.
ERROR - 2018-05-03 10:41:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:41:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:41:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:42:04 --> The path to the image is not correct.
ERROR - 2018-05-03 10:42:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:42:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:42:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:44:19 --> The path to the image is not correct.
ERROR - 2018-05-03 10:44:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:44:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:44:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:49:33 --> The path to the image is not correct.
ERROR - 2018-05-03 10:49:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:49:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:49:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:12 --> The path to the image is not correct.
ERROR - 2018-05-03 10:50:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:50:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:26 --> The path to the image is not correct.
ERROR - 2018-05-03 10:50:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:50:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:28 --> The path to the image is not correct.
ERROR - 2018-05-03 10:50:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:50:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:28 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-03 10:50:28 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-03 10:50:28 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-03 10:50:29 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-03 10:50:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-03 10:50:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-03 10:50:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-03 10:50:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-03 10:50:29 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-05-03 10:50:29 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-03 10:50:29 --> The path to the image is not correct.
ERROR - 2018-05-03 10:50:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-03 10:50:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:50:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:51:45 --> The path to the image is not correct.
ERROR - 2018-05-03 10:51:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:51:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:51:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:52:07 --> The path to the image is not correct.
ERROR - 2018-05-03 10:52:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:52:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:52:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:52:25 --> The path to the image is not correct.
ERROR - 2018-05-03 10:52:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:52:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:52:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:52:41 --> The path to the image is not correct.
ERROR - 2018-05-03 10:52:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:52:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:52:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:52:59 --> The path to the image is not correct.
ERROR - 2018-05-03 10:52:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:53:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:53:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:53:56 --> The path to the image is not correct.
ERROR - 2018-05-03 10:53:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:53:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:53:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:54:17 --> The path to the image is not correct.
ERROR - 2018-05-03 10:54:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:54:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:54:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:55:07 --> The path to the image is not correct.
ERROR - 2018-05-03 10:55:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:55:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:55:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:56:28 --> The path to the image is not correct.
ERROR - 2018-05-03 10:56:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:56:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:56:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:56:39 --> The path to the image is not correct.
ERROR - 2018-05-03 10:56:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:56:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:56:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:58:08 --> The path to the image is not correct.
ERROR - 2018-05-03 10:58:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 10:58:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 10:58:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:03:50 --> The path to the image is not correct.
ERROR - 2018-05-03 11:03:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:03:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:03:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:04:53 --> The path to the image is not correct.
ERROR - 2018-05-03 11:04:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:04:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:04:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:05:13 --> The path to the image is not correct.
ERROR - 2018-05-03 11:05:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:05:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:05:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:05:17 --> The path to the image is not correct.
ERROR - 2018-05-03 11:05:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:05:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:05:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:29:00 --> The path to the image is not correct.
ERROR - 2018-05-03 11:29:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:29:01 --> The path to the image is not correct.
ERROR - 2018-05-03 11:29:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:29:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:29:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:29:05 --> The path to the image is not correct.
ERROR - 2018-05-03 11:29:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:29:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:29:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:29:30 --> The path to the image is not correct.
ERROR - 2018-05-03 11:29:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:29:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:29:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:29:38 --> The path to the image is not correct.
ERROR - 2018-05-03 11:29:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:29:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:29:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:09 --> The path to the image is not correct.
ERROR - 2018-05-03 11:33:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:33:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:20 --> The path to the image is not correct.
ERROR - 2018-05-03 11:33:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:33:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:23 --> The path to the image is not correct.
ERROR - 2018-05-03 11:33:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:33:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:24 --> The path to the image is not correct.
ERROR - 2018-05-03 11:33:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:33:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:25 --> The path to the image is not correct.
ERROR - 2018-05-03 11:33:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:33:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:36 --> The path to the image is not correct.
ERROR - 2018-05-03 11:33:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:33:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:42 --> The path to the image is not correct.
ERROR - 2018-05-03 11:33:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:33:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:33:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:34:45 --> The path to the image is not correct.
ERROR - 2018-05-03 11:34:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:34:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:34:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:34:49 --> The path to the image is not correct.
ERROR - 2018-05-03 11:34:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:34:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:34:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:40:20 --> The path to the image is not correct.
ERROR - 2018-05-03 11:40:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:40:25 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-03 11:41:15 --> The path to the image is not correct.
ERROR - 2018-05-03 11:41:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:41:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:41:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:41:20 --> The path to the image is not correct.
ERROR - 2018-05-03 11:41:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:41:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:41:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:41:42 --> The path to the image is not correct.
ERROR - 2018-05-03 11:41:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:41:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:41:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:41:46 --> The path to the image is not correct.
ERROR - 2018-05-03 11:41:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:41:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:41:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:41:53 --> The path to the image is not correct.
ERROR - 2018-05-03 11:41:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:41:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:41:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:42:39 --> The path to the image is not correct.
ERROR - 2018-05-03 11:42:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:42:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:42:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:42:43 --> The path to the image is not correct.
ERROR - 2018-05-03 11:42:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:42:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:42:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:52:25 --> Severity: Notice --> Undefined index: driver D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 30
ERROR - 2018-05-03 11:55:48 --> The path to the image is not correct.
ERROR - 2018-05-03 11:55:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:55:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:55:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:56:00 --> The path to the image is not correct.
ERROR - 2018-05-03 11:56:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 11:56:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 11:56:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:02:13 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 115
ERROR - 2018-05-03 12:02:13 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 115
ERROR - 2018-05-03 12:02:13 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 115
ERROR - 2018-05-03 12:02:13 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 115
ERROR - 2018-05-03 12:02:13 --> The path to the image is not correct.
ERROR - 2018-05-03 12:02:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:02:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:02:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:02:38 --> The path to the image is not correct.
ERROR - 2018-05-03 12:02:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:02:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:02:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:02:48 --> The path to the image is not correct.
ERROR - 2018-05-03 12:02:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:02:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:02:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:16 --> The path to the image is not correct.
ERROR - 2018-05-03 12:16:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:16:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:18 --> The path to the image is not correct.
ERROR - 2018-05-03 12:16:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:16:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:18 --> The path to the image is not correct.
ERROR - 2018-05-03 12:16:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:16:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:18 --> The path to the image is not correct.
ERROR - 2018-05-03 12:16:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:16:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:27 --> The path to the image is not correct.
ERROR - 2018-05-03 12:16:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:16:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:28 --> The path to the image is not correct.
ERROR - 2018-05-03 12:16:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:16:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:29 --> The path to the image is not correct.
ERROR - 2018-05-03 12:16:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:16:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:37 --> The path to the image is not correct.
ERROR - 2018-05-03 12:16:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:16:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:38 --> The path to the image is not correct.
ERROR - 2018-05-03 12:16:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:16:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:16:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:25:09 --> The path to the image is not correct.
ERROR - 2018-05-03 12:25:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:25:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:25:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:25:09 --> The path to the image is not correct.
ERROR - 2018-05-03 12:25:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:25:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:25:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:27:25 --> Severity: Error --> Call to undefined method CI_Form_validation::set_date() D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 32
ERROR - 2018-05-03 12:27:32 --> The path to the image is not correct.
ERROR - 2018-05-03 12:27:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:27:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:27:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:29:37 --> The path to the image is not correct.
ERROR - 2018-05-03 12:29:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:29:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:29:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:31:41 --> The path to the image is not correct.
ERROR - 2018-05-03 12:31:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:31:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:31:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:32:07 --> The path to the image is not correct.
ERROR - 2018-05-03 12:32:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:32:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:32:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:32:08 --> The path to the image is not correct.
ERROR - 2018-05-03 12:32:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:32:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:32:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:32:50 --> The path to the image is not correct.
ERROR - 2018-05-03 12:32:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:32:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:32:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:34:06 --> The path to the image is not correct.
ERROR - 2018-05-03 12:34:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:34:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:34:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:34:16 --> The path to the image is not correct.
ERROR - 2018-05-03 12:34:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:34:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:34:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:35:17 --> The path to the image is not correct.
ERROR - 2018-05-03 12:35:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:35:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:35:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:35:28 --> The path to the image is not correct.
ERROR - 2018-05-03 12:35:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:35:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:35:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:36:06 --> The path to the image is not correct.
ERROR - 2018-05-03 12:36:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:36:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:36:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:36:11 --> The path to the image is not correct.
ERROR - 2018-05-03 12:36:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:36:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:36:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:40:13 --> The path to the image is not correct.
ERROR - 2018-05-03 12:40:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:40:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:40:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:40:20 --> The path to the image is not correct.
ERROR - 2018-05-03 12:40:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:41:03 --> The path to the image is not correct.
ERROR - 2018-05-03 12:41:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:41:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:41:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:41:10 --> The path to the image is not correct.
ERROR - 2018-05-03 12:41:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:41:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:41:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:41:55 --> The path to the image is not correct.
ERROR - 2018-05-03 12:41:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:41:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:41:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:42:02 --> The path to the image is not correct.
ERROR - 2018-05-03 12:42:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:42:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:42:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:42:51 --> The path to the image is not correct.
ERROR - 2018-05-03 12:42:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:42:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:42:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:42:57 --> The path to the image is not correct.
ERROR - 2018-05-03 12:42:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:42:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:42:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:43:01 --> The path to the image is not correct.
ERROR - 2018-05-03 12:43:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:43:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:43:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:43:07 --> The path to the image is not correct.
ERROR - 2018-05-03 12:43:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:43:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:43:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:44:07 --> The path to the image is not correct.
ERROR - 2018-05-03 12:44:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:44:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:44:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:44:10 --> The path to the image is not correct.
ERROR - 2018-05-03 12:44:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:44:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:44:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:44:16 --> The path to the image is not correct.
ERROR - 2018-05-03 12:44:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:44:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:44:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:46:25 --> The path to the image is not correct.
ERROR - 2018-05-03 12:46:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:46:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:46:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:46:30 --> The path to the image is not correct.
ERROR - 2018-05-03 12:46:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:46:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:46:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:46:38 --> The path to the image is not correct.
ERROR - 2018-05-03 12:46:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:46:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:46:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:46:58 --> The path to the image is not correct.
ERROR - 2018-05-03 12:46:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:46:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:46:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:15 --> The path to the image is not correct.
ERROR - 2018-05-03 12:48:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:48:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:32 --> The path to the image is not correct.
ERROR - 2018-05-03 12:48:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:48:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:40 --> The path to the image is not correct.
ERROR - 2018-05-03 12:48:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:48:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:43 --> The path to the image is not correct.
ERROR - 2018-05-03 12:48:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:48:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:48 --> The path to the image is not correct.
ERROR - 2018-05-03 12:48:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:48:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:50 --> The path to the image is not correct.
ERROR - 2018-05-03 12:48:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:48:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:48:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-03 12:54:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-03 12:54:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-03 12:54:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-03 12:54:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-03 12:54:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-03 12:59:58 --> The path to the image is not correct.
ERROR - 2018-05-03 12:59:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 12:59:59 --> The path to the image is not correct.
ERROR - 2018-05-03 12:59:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 13:00:04 --> The path to the image is not correct.
ERROR - 2018-05-03 13:00:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 13:08:23 --> The path to the image is not correct.
ERROR - 2018-05-03 13:08:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 13:08:26 --> The path to the image is not correct.
ERROR - 2018-05-03 13:08:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-03 13:08:34 --> The path to the image is not correct.
ERROR - 2018-05-03 13:08:34 --> Your server does not support the GD function required to process this type of image.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-26 09:01:42 --> The path to the image is not correct.
ERROR - 2018-07-26 09:01:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 09:01:56 --> The path to the image is not correct.
ERROR - 2018-07-26 09:01:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 09:02:59 --> The path to the image is not correct.
ERROR - 2018-07-26 09:02:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 09:02:59 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:02:59 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:02:59 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:02:59 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-26 09:02:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-26 09:02:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-26 09:02:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-26 09:02:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-26 09:02:59 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-07-26 09:02:59 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-07-26 09:02:59 --> The path to the image is not correct.
ERROR - 2018-07-26 09:02:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-07-26 09:06:05 --> The path to the image is not correct.
ERROR - 2018-07-26 09:06:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 09:06:22 --> The path to the image is not correct.
ERROR - 2018-07-26 09:06:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 09:10:35 --> The path to the image is not correct.
ERROR - 2018-07-26 09:10:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 09:10:35 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:10:35 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:10:35 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:10:35 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-26 09:10:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-26 09:10:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-26 09:10:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-26 09:10:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-26 09:10:35 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-07-26 09:10:35 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-07-26 09:10:35 --> The path to the image is not correct.
ERROR - 2018-07-26 09:10:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-07-26 09:10:55 --> The path to the image is not correct.
ERROR - 2018-07-26 09:10:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 09:10:55 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:10:55 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:10:55 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:10:55 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-26 09:10:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-26 09:10:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-26 09:10:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-26 09:10:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-26 09:10:55 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-07-26 09:10:55 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-07-26 09:10:55 --> The path to the image is not correct.
ERROR - 2018-07-26 09:10:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-07-26 09:10:58 --> The path to the image is not correct.
ERROR - 2018-07-26 09:10:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 09:10:58 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:10:58 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:10:58 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:10:58 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-26 09:10:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-26 09:10:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-26 09:10:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-26 09:10:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-26 09:10:58 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-07-26 09:10:58 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-07-26 09:10:58 --> The path to the image is not correct.
ERROR - 2018-07-26 09:10:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-07-26 09:12:40 --> The path to the image is not correct.
ERROR - 2018-07-26 09:12:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 09:12:51 --> The path to the image is not correct.
ERROR - 2018-07-26 09:12:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 09:12:51 --> Severity: Warning --> Missing argument 4 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:12:51 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:12:51 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-26 09:12:51 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-26 09:12:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-26 09:12:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-26 09:12:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-26 09:12:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-26 09:12:51 --> Severity: Notice --> Undefined variable: width D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 24
ERROR - 2018-07-26 09:12:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-07-26 09:12:51 --> The path to the image is not correct.
ERROR - 2018-07-26 09:12:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-07-26 09:13:14 --> The path to the image is not correct.
ERROR - 2018-07-26 09:13:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 11:03:56 --> 404 Page Not Found: app/Login/index
ERROR - 2018-07-26 11:25:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-26 11:25:59 --> The path to the image is not correct.
ERROR - 2018-07-26 11:25:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-26 11:26:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-26 11:26:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-26 11:27:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-26 11:27:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-26 11:41:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-26 11:41:30 --> 404 Page Not Found: Public/lib

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-02 03:52:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Invoice.php 13
ERROR - 2018-07-02 03:52:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-07-02 03:52:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 03:52:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 03:52:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 03:52:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-07-02 03:52:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-07-02 03:52:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-07-02 03:52:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-07-02 03:52:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-07-02 03:52:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-07-02 03:52:54 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Invoice.php 13
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-07-02 03:54:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-07-02 03:54:14 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-07-02 03:54:27 --> The path to the image is not correct.
ERROR - 2018-07-02 03:54:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 04:13:47 --> The path to the image is not correct.
ERROR - 2018-07-02 04:13:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 04:13:47 --> The path to the image is not correct.
ERROR - 2018-07-02 04:13:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 04:49:09 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 90
ERROR - 2018-07-02 04:49:10 --> The path to the image is not correct.
ERROR - 2018-07-02 04:49:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 04:49:11 --> The path to the image is not correct.
ERROR - 2018-07-02 04:49:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 08:53:51 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-02 08:53:51 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-02 08:53:51 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-02 08:53:51 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-02 08:53:52 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-02 08:59:27 --> The path to the image is not correct.
ERROR - 2018-07-02 08:59:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 08:59:35 --> The path to the image is not correct.
ERROR - 2018-07-02 08:59:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 08:59:35 --> The path to the image is not correct.
ERROR - 2018-07-02 08:59:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 09:01:47 --> The path to the image is not correct.
ERROR - 2018-07-02 09:01:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 09:01:54 --> The path to the image is not correct.
ERROR - 2018-07-02 09:01:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 09:38:31 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-02 09:38:31 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-02 09:38:31 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-02 09:38:32 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-02 09:38:32 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 12
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 167
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 180
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 192
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 30
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-07-02 10:50:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 12
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 167
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 180
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 192
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 30
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-07-02 10:51:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-07-02 10:51:41 --> 404 Page Not Found: admin/Accounts/%3Cdiv%20style=
ERROR - 2018-07-02 10:51:41 --> The path to the image is not correct.
ERROR - 2018-07-02 10:51:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:51:42 --> The path to the image is not correct.
ERROR - 2018-07-02 10:51:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 12
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 167
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 180
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 192
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 30
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-07-02 10:51:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-07-02 10:52:57 --> The path to the image is not correct.
ERROR - 2018-07-02 10:52:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:53:00 --> The path to the image is not correct.
ERROR - 2018-07-02 10:53:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:53:00 --> The path to the image is not correct.
ERROR - 2018-07-02 10:53:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:53:45 --> The path to the image is not correct.
ERROR - 2018-07-02 10:53:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:53:45 --> The path to the image is not correct.
ERROR - 2018-07-02 10:53:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:53:45 --> The path to the image is not correct.
ERROR - 2018-07-02 10:53:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:53:50 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-07-02 10:53:51 --> The path to the image is not correct.
ERROR - 2018-07-02 10:53:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:53:51 --> The path to the image is not correct.
ERROR - 2018-07-02 10:53:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:55:48 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-07-02 10:55:49 --> The path to the image is not correct.
ERROR - 2018-07-02 10:55:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:55:49 --> The path to the image is not correct.
ERROR - 2018-07-02 10:55:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 10:55:49 --> The path to the image is not correct.
ERROR - 2018-07-02 10:55:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:01:12 --> The path to the image is not correct.
ERROR - 2018-07-02 11:01:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:01:12 --> The path to the image is not correct.
ERROR - 2018-07-02 11:01:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:01:12 --> The path to the image is not correct.
ERROR - 2018-07-02 11:01:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:01:18 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 86
ERROR - 2018-07-02 11:01:19 --> The path to the image is not correct.
ERROR - 2018-07-02 11:01:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:01:19 --> The path to the image is not correct.
ERROR - 2018-07-02 11:01:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:01:42 --> The path to the image is not correct.
ERROR - 2018-07-02 11:01:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:01:42 --> The path to the image is not correct.
ERROR - 2018-07-02 11:01:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:01:42 --> The path to the image is not correct.
ERROR - 2018-07-02 11:01:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:01:49 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 86
ERROR - 2018-07-02 11:01:49 --> The path to the image is not correct.
ERROR - 2018-07-02 11:01:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:01:50 --> The path to the image is not correct.
ERROR - 2018-07-02 11:01:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:06 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:06 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:06 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:13 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:13 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:13 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:16 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 90
ERROR - 2018-07-02 11:10:17 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:17 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:37 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:37 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:37 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:40 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 86
ERROR - 2018-07-02 11:10:41 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:10:41 --> The path to the image is not correct.
ERROR - 2018-07-02 11:10:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:05 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:05 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:05 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:09 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 86
ERROR - 2018-07-02 11:11:10 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:10 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:25 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:25 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:25 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:32 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 86
ERROR - 2018-07-02 11:11:33 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:33 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:11:33 --> The path to the image is not correct.
ERROR - 2018-07-02 11:11:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:13:20 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-07-02 11:13:21 --> The path to the image is not correct.
ERROR - 2018-07-02 11:13:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:13:21 --> The path to the image is not correct.
ERROR - 2018-07-02 11:13:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:13:25 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-07-02 11:13:26 --> The path to the image is not correct.
ERROR - 2018-07-02 11:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:13:26 --> The path to the image is not correct.
ERROR - 2018-07-02 11:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:15:56 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-07-02 11:15:57 --> The path to the image is not correct.
ERROR - 2018-07-02 11:15:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:15:57 --> The path to the image is not correct.
ERROR - 2018-07-02 11:15:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:16:02 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-07-02 11:16:02 --> The path to the image is not correct.
ERROR - 2018-07-02 11:16:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:16:02 --> The path to the image is not correct.
ERROR - 2018-07-02 11:16:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:16:05 --> The path to the image is not correct.
ERROR - 2018-07-02 11:16:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:16:05 --> The path to the image is not correct.
ERROR - 2018-07-02 11:16:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:22:38 --> The path to the image is not correct.
ERROR - 2018-07-02 11:22:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:22:38 --> The path to the image is not correct.
ERROR - 2018-07-02 11:22:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:22:39 --> The path to the image is not correct.
ERROR - 2018-07-02 11:22:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:22:42 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-07-02 11:22:43 --> The path to the image is not correct.
ERROR - 2018-07-02 11:22:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:22:43 --> The path to the image is not correct.
ERROR - 2018-07-02 11:22:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:23:28 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-07-02 11:23:29 --> The path to the image is not correct.
ERROR - 2018-07-02 11:23:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:23:29 --> The path to the image is not correct.
ERROR - 2018-07-02 11:23:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:28:33 --> The path to the image is not correct.
ERROR - 2018-07-02 11:28:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:28:33 --> The path to the image is not correct.
ERROR - 2018-07-02 11:28:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:28:34 --> The path to the image is not correct.
ERROR - 2018-07-02 11:28:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:28:40 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-07-02 11:28:41 --> The path to the image is not correct.
ERROR - 2018-07-02 11:28:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:28:41 --> The path to the image is not correct.
ERROR - 2018-07-02 11:28:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:29:03 --> The path to the image is not correct.
ERROR - 2018-07-02 11:29:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:29:03 --> The path to the image is not correct.
ERROR - 2018-07-02 11:29:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:29:03 --> The path to the image is not correct.
ERROR - 2018-07-02 11:29:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:29:07 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 85
ERROR - 2018-07-02 11:29:08 --> The path to the image is not correct.
ERROR - 2018-07-02 11:29:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:29:08 --> The path to the image is not correct.
ERROR - 2018-07-02 11:29:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:29:08 --> The path to the image is not correct.
ERROR - 2018-07-02 11:29:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:30:02 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 80
ERROR - 2018-07-02 11:30:03 --> The path to the image is not correct.
ERROR - 2018-07-02 11:30:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:30:03 --> The path to the image is not correct.
ERROR - 2018-07-02 11:30:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:35:26 --> The path to the image is not correct.
ERROR - 2018-07-02 11:35:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:35:26 --> The path to the image is not correct.
ERROR - 2018-07-02 11:35:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:35:26 --> The path to the image is not correct.
ERROR - 2018-07-02 11:35:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:35:30 --> Severity: Notice --> Undefined property: stdClass::$street1 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 47
ERROR - 2018-07-02 11:35:30 --> Severity: Notice --> Undefined property: stdClass::$street2 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 48
ERROR - 2018-07-02 11:35:30 --> Severity: Notice --> Undefined property: stdClass::$suburb D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 49
ERROR - 2018-07-02 11:35:30 --> Severity: Notice --> Undefined property: stdClass::$city D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 50
ERROR - 2018-07-02 11:35:30 --> Severity: Notice --> Undefined property: stdClass::$postcode D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 51
ERROR - 2018-07-02 11:35:30 --> Severity: Notice --> Undefined property: stdClass::$state D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 52
ERROR - 2018-07-02 11:35:30 --> Severity: Notice --> Undefined property: stdClass::$country D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 53
ERROR - 2018-07-02 11:35:30 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 70
ERROR - 2018-07-02 11:35:30 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 80
ERROR - 2018-07-02 11:35:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-07-02 11:45:58 --> Query error: Unknown column 'u.store_id' in 'on clause' - Invalid query: SELECT `i`.*, `up`.`plan_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`billing_type`, `up`.`who_updated`, `u2`.`display_name` as `updated_by`, `u`.`display_name`, `u`.`email_address`, `sa`.*
FROM `invoice` `i`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `sa` ON `sa`.`store_address_id` = `s`.`address_id`
JOIN `user` `u` ON `u`.`user_id` = `i`.`user_id`
JOIN `user_plan` `up` ON `up`.`user_plan_id` = `i`.`user_plan_id`
JOIN `user` `u2` ON `u2`.`user_id` = `up`.`who_updated`
WHERE `i`.`deleted` IS NULL
AND `i`.`invoice_id` = 59
ERROR - 2018-07-02 11:46:43 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 70
ERROR - 2018-07-02 11:46:43 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 80
ERROR - 2018-07-02 11:46:43 --> The path to the image is not correct.
ERROR - 2018-07-02 11:46:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:46:43 --> The path to the image is not correct.
ERROR - 2018-07-02 11:46:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:46:43 --> The path to the image is not correct.
ERROR - 2018-07-02 11:46:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:46:56 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 70
ERROR - 2018-07-02 11:46:56 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 80
ERROR - 2018-07-02 11:46:56 --> The path to the image is not correct.
ERROR - 2018-07-02 11:46:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:46:56 --> The path to the image is not correct.
ERROR - 2018-07-02 11:46:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:47:11 --> The path to the image is not correct.
ERROR - 2018-07-02 11:47:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:47:11 --> The path to the image is not correct.
ERROR - 2018-07-02 11:47:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:47:11 --> The path to the image is not correct.
ERROR - 2018-07-02 11:47:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:49:53 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 80
ERROR - 2018-07-02 11:49:53 --> The path to the image is not correct.
ERROR - 2018-07-02 11:49:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:49:53 --> The path to the image is not correct.
ERROR - 2018-07-02 11:49:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:49:53 --> The path to the image is not correct.
ERROR - 2018-07-02 11:49:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:50:00 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 80
ERROR - 2018-07-02 11:50:00 --> The path to the image is not correct.
ERROR - 2018-07-02 11:50:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:50:00 --> The path to the image is not correct.
ERROR - 2018-07-02 11:50:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:50:15 --> The path to the image is not correct.
ERROR - 2018-07-02 11:50:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:50:15 --> The path to the image is not correct.
ERROR - 2018-07-02 11:50:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:50:15 --> The path to the image is not correct.
ERROR - 2018-07-02 11:50:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:51:44 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 80
ERROR - 2018-07-02 11:51:44 --> The path to the image is not correct.
ERROR - 2018-07-02 11:51:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:51:44 --> The path to the image is not correct.
ERROR - 2018-07-02 11:51:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:52:30 --> The path to the image is not correct.
ERROR - 2018-07-02 11:52:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:52:30 --> The path to the image is not correct.
ERROR - 2018-07-02 11:52:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:52:36 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 80
ERROR - 2018-07-02 11:52:36 --> The path to the image is not correct.
ERROR - 2018-07-02 11:52:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:52:37 --> The path to the image is not correct.
ERROR - 2018-07-02 11:52:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:53:00 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 80
ERROR - 2018-07-02 11:53:00 --> The path to the image is not correct.
ERROR - 2018-07-02 11:53:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:53:00 --> The path to the image is not correct.
ERROR - 2018-07-02 11:53:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:53:21 --> The path to the image is not correct.
ERROR - 2018-07-02 11:53:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:53:21 --> The path to the image is not correct.
ERROR - 2018-07-02 11:53:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:53:21 --> The path to the image is not correct.
ERROR - 2018-07-02 11:53:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:53:24 --> Severity: Notice --> Undefined variable: address D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 71
ERROR - 2018-07-02 11:53:24 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 80
ERROR - 2018-07-02 11:53:25 --> The path to the image is not correct.
ERROR - 2018-07-02 11:53:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:53:26 --> The path to the image is not correct.
ERROR - 2018-07-02 11:53:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:55:18 --> The path to the image is not correct.
ERROR - 2018-07-02 11:55:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:55:19 --> The path to the image is not correct.
ERROR - 2018-07-02 11:55:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:55:19 --> The path to the image is not correct.
ERROR - 2018-07-02 11:55:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:55:45 --> The path to the image is not correct.
ERROR - 2018-07-02 11:55:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:55:45 --> The path to the image is not correct.
ERROR - 2018-07-02 11:55:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:55:45 --> The path to the image is not correct.
ERROR - 2018-07-02 11:55:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:56:57 --> The path to the image is not correct.
ERROR - 2018-07-02 11:56:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:56:57 --> The path to the image is not correct.
ERROR - 2018-07-02 11:56:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:57:59 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 77
ERROR - 2018-07-02 11:58:00 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:00 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:06 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:06 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:06 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:18 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:18 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:18 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:21 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 77
ERROR - 2018-07-02 11:58:21 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:22 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:22 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:31 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:31 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:31 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:37 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 77
ERROR - 2018-07-02 11:58:38 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 11:58:38 --> The path to the image is not correct.
ERROR - 2018-07-02 11:58:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:10:45 --> The path to the image is not correct.
ERROR - 2018-07-02 12:10:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:10:45 --> The path to the image is not correct.
ERROR - 2018-07-02 12:10:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:10:45 --> The path to the image is not correct.
ERROR - 2018-07-02 12:10:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:10:48 --> Severity: Notice --> Undefined variable: phone_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 76
ERROR - 2018-07-02 12:10:49 --> The path to the image is not correct.
ERROR - 2018-07-02 12:10:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:10:49 --> The path to the image is not correct.
ERROR - 2018-07-02 12:10:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:11:50 --> The path to the image is not correct.
ERROR - 2018-07-02 12:11:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:11:50 --> The path to the image is not correct.
ERROR - 2018-07-02 12:11:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:11:51 --> The path to the image is not correct.
ERROR - 2018-07-02 12:11:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:11:56 --> Query error: Unknown column 'sc.phone_number' in 'field list' - Invalid query: SELECT `i`.*, `sa`.*, `sc`.`phone_number`, `up`.`plan_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`billing_type`, `up`.`who_updated`, `u2`.`display_name` as `updated_by`, `u`.`display_name`, `u`.`email_address`, `s`.`store_name`
FROM `invoice` `i`
JOIN `user` `u` ON `u`.`user_id` = `i`.`user_id`
JOIN `user_plan` `up` ON `up`.`user_plan_id` = `i`.`user_plan_id`
JOIN `user` `u2` ON `u2`.`user_id` = `up`.`who_updated`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `sa` ON `sa`.`store_address_id` = `s`.`address_id`
JOIN `store_contact` `sc` ON `sc`.`contact_id` = `s`.`contact_id`
WHERE `i`.`deleted` IS NULL
AND `i`.`invoice_id` = 77
ERROR - 2018-07-02 12:12:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`up`.`plan_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`billing_typ' at line 1 - Invalid query: SELECT `i`.* `up`.`plan_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`billing_type`, `up`.`who_updated`, `u2`.`display_name` as `updated_by`, `u`.`display_name`, `u`.`email_address`, `s`.`store_name`, `sa`.*, `sc`.`phone_number`
FROM `invoice` `i`
JOIN `user` `u` ON `u`.`user_id` = `i`.`user_id`
JOIN `user_plan` `up` ON `up`.`user_plan_id` = `i`.`user_plan_id`
JOIN `user` `u2` ON `u2`.`user_id` = `up`.`who_updated`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `sa` ON `sa`.`store_address_id` = `s`.`address_id`
JOIN `store_contact` `sc` ON `sc`.`contact_id` = `s`.`contact_id`
WHERE `i`.`deleted` IS NULL
AND `i`.`invoice_id` = 78
ERROR - 2018-07-02 12:12:26 --> Query error: Unknown column 'sc.phone_number' in 'field list' - Invalid query: SELECT `i`.*, `up`.`plan_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`billing_type`, `up`.`who_updated`, `u2`.`display_name` as `updated_by`, `u`.`display_name`, `u`.`email_address`, `s`.`store_name`, `sa`.*, `sc`.`phone_number`
FROM `invoice` `i`
JOIN `user` `u` ON `u`.`user_id` = `i`.`user_id`
JOIN `user_plan` `up` ON `up`.`user_plan_id` = `i`.`user_plan_id`
JOIN `user` `u2` ON `u2`.`user_id` = `up`.`who_updated`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `sa` ON `sa`.`store_address_id` = `s`.`address_id`
JOIN `store_contact` `sc` ON `sc`.`contact_id` = `s`.`contact_id`
WHERE `i`.`deleted` IS NULL
AND `i`.`invoice_id` = 79
ERROR - 2018-07-02 12:13:01 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:01 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:01 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:16 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:17 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:17 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:21 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:21 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:55 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:55 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:55 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:13:55 --> The path to the image is not correct.
ERROR - 2018-07-02 12:13:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:14:00 --> The path to the image is not correct.
ERROR - 2018-07-02 12:14:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:14:00 --> The path to the image is not correct.
ERROR - 2018-07-02 12:14:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:26:55 --> The path to the image is not correct.
ERROR - 2018-07-02 12:26:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:26:56 --> The path to the image is not correct.
ERROR - 2018-07-02 12:26:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:26:56 --> The path to the image is not correct.
ERROR - 2018-07-02 12:26:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:27:01 --> The path to the image is not correct.
ERROR - 2018-07-02 12:27:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:27:01 --> The path to the image is not correct.
ERROR - 2018-07-02 12:27:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:28:04 --> The path to the image is not correct.
ERROR - 2018-07-02 12:28:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:28:04 --> The path to the image is not correct.
ERROR - 2018-07-02 12:28:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:28:04 --> The path to the image is not correct.
ERROR - 2018-07-02 12:28:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:30:27 --> The path to the image is not correct.
ERROR - 2018-07-02 12:30:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:30:27 --> The path to the image is not correct.
ERROR - 2018-07-02 12:30:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:30:27 --> The path to the image is not correct.
ERROR - 2018-07-02 12:30:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:30:31 --> The path to the image is not correct.
ERROR - 2018-07-02 12:30:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:30:31 --> The path to the image is not correct.
ERROR - 2018-07-02 12:30:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:30:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:30:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:31:37 --> The path to the image is not correct.
ERROR - 2018-07-02 12:31:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:31:37 --> The path to the image is not correct.
ERROR - 2018-07-02 12:31:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:31:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:31:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:31:37 --> The path to the image is not correct.
ERROR - 2018-07-02 12:31:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:31:41 --> The path to the image is not correct.
ERROR - 2018-07-02 12:31:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:31:41 --> The path to the image is not correct.
ERROR - 2018-07-02 12:31:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:31:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:31:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:31:42 --> The path to the image is not correct.
ERROR - 2018-07-02 12:31:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:31:56 --> The path to the image is not correct.
ERROR - 2018-07-02 12:31:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:31:56 --> The path to the image is not correct.
ERROR - 2018-07-02 12:31:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:31:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:31:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:31:56 --> The path to the image is not correct.
ERROR - 2018-07-02 12:31:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:32:01 --> The path to the image is not correct.
ERROR - 2018-07-02 12:32:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:32:01 --> The path to the image is not correct.
ERROR - 2018-07-02 12:32:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:32:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:32:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:32:01 --> The path to the image is not correct.
ERROR - 2018-07-02 12:32:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:27 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:27 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:36:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:36:28 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:31 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:32 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:36:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:36:43 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:43 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:36:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:36:43 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:46 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:46 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:36:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:36:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:36:46 --> The path to the image is not correct.
ERROR - 2018-07-02 12:36:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:37:36 --> The path to the image is not correct.
ERROR - 2018-07-02 12:37:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:37:36 --> The path to the image is not correct.
ERROR - 2018-07-02 12:37:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:37:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:37:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:37:37 --> The path to the image is not correct.
ERROR - 2018-07-02 12:37:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:37:40 --> The path to the image is not correct.
ERROR - 2018-07-02 12:37:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:37:40 --> The path to the image is not correct.
ERROR - 2018-07-02 12:37:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:37:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:37:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:37:40 --> The path to the image is not correct.
ERROR - 2018-07-02 12:37:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:38:58 --> The path to the image is not correct.
ERROR - 2018-07-02 12:38:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:38:58 --> The path to the image is not correct.
ERROR - 2018-07-02 12:38:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:38:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:38:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:41:59 --> The path to the image is not correct.
ERROR - 2018-07-02 12:41:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:41:59 --> The path to the image is not correct.
ERROR - 2018-07-02 12:41:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:41:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:41:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:42:00 --> The path to the image is not correct.
ERROR - 2018-07-02 12:42:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:42:03 --> The path to the image is not correct.
ERROR - 2018-07-02 12:42:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:42:03 --> The path to the image is not correct.
ERROR - 2018-07-02 12:42:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:42:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:42:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:42:04 --> The path to the image is not correct.
ERROR - 2018-07-02 12:42:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:45:27 --> The path to the image is not correct.
ERROR - 2018-07-02 12:45:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:45:27 --> The path to the image is not correct.
ERROR - 2018-07-02 12:45:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:45:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:45:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:45:28 --> The path to the image is not correct.
ERROR - 2018-07-02 12:45:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:50:37 --> The path to the image is not correct.
ERROR - 2018-07-02 12:50:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:50:37 --> The path to the image is not correct.
ERROR - 2018-07-02 12:50:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:50:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:50:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:52:38 --> The path to the image is not correct.
ERROR - 2018-07-02 12:52:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:52:38 --> The path to the image is not correct.
ERROR - 2018-07-02 12:52:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:52:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:52:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:52:39 --> The path to the image is not correct.
ERROR - 2018-07-02 12:52:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:52:43 --> The path to the image is not correct.
ERROR - 2018-07-02 12:52:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:52:43 --> The path to the image is not correct.
ERROR - 2018-07-02 12:52:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:52:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:52:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:53:05 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:05 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:53:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:53:05 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:08 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:08 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:53:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:53:08 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:32 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:32 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:53:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:53:33 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:37 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:37 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:53:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:53:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:53:37 --> The path to the image is not correct.
ERROR - 2018-07-02 12:53:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:54:03 --> The path to the image is not correct.
ERROR - 2018-07-02 12:54:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:54:03 --> The path to the image is not correct.
ERROR - 2018-07-02 12:54:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:54:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:54:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-02 12:54:04 --> The path to the image is not correct.
ERROR - 2018-07-02 12:54:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:55:49 --> The path to the image is not correct.
ERROR - 2018-07-02 12:55:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:55:49 --> The path to the image is not correct.
ERROR - 2018-07-02 12:55:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:55:54 --> The path to the image is not correct.
ERROR - 2018-07-02 12:55:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:55:54 --> The path to the image is not correct.
ERROR - 2018-07-02 12:55:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:56:30 --> The path to the image is not correct.
ERROR - 2018-07-02 12:56:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:56:30 --> The path to the image is not correct.
ERROR - 2018-07-02 12:56:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:56:31 --> The path to the image is not correct.
ERROR - 2018-07-02 12:56:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:56:35 --> The path to the image is not correct.
ERROR - 2018-07-02 12:56:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:56:35 --> The path to the image is not correct.
ERROR - 2018-07-02 12:56:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:57:32 --> The path to the image is not correct.
ERROR - 2018-07-02 12:57:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:57:32 --> The path to the image is not correct.
ERROR - 2018-07-02 12:57:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:57:33 --> The path to the image is not correct.
ERROR - 2018-07-02 12:57:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:59:09 --> The path to the image is not correct.
ERROR - 2018-07-02 12:59:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:59:09 --> The path to the image is not correct.
ERROR - 2018-07-02 12:59:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:59:09 --> The path to the image is not correct.
ERROR - 2018-07-02 12:59:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:59:13 --> The path to the image is not correct.
ERROR - 2018-07-02 12:59:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:59:13 --> The path to the image is not correct.
ERROR - 2018-07-02 12:59:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:59:54 --> The path to the image is not correct.
ERROR - 2018-07-02 12:59:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:59:55 --> The path to the image is not correct.
ERROR - 2018-07-02 12:59:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:59:55 --> The path to the image is not correct.
ERROR - 2018-07-02 12:59:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:59:59 --> The path to the image is not correct.
ERROR - 2018-07-02 12:59:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 12:59:59 --> The path to the image is not correct.
ERROR - 2018-07-02 12:59:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:00:55 --> The path to the image is not correct.
ERROR - 2018-07-02 13:00:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:00:55 --> The path to the image is not correct.
ERROR - 2018-07-02 13:00:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:00:55 --> The path to the image is not correct.
ERROR - 2018-07-02 13:00:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:00:59 --> The path to the image is not correct.
ERROR - 2018-07-02 13:00:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:00:59 --> The path to the image is not correct.
ERROR - 2018-07-02 13:00:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:01:46 --> The path to the image is not correct.
ERROR - 2018-07-02 13:01:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:01:46 --> The path to the image is not correct.
ERROR - 2018-07-02 13:01:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:01:47 --> The path to the image is not correct.
ERROR - 2018-07-02 13:01:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:01:51 --> The path to the image is not correct.
ERROR - 2018-07-02 13:01:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:01:51 --> The path to the image is not correct.
ERROR - 2018-07-02 13:01:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:02:19 --> The path to the image is not correct.
ERROR - 2018-07-02 13:02:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:02:19 --> The path to the image is not correct.
ERROR - 2018-07-02 13:02:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:02:19 --> The path to the image is not correct.
ERROR - 2018-07-02 13:02:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:02:23 --> The path to the image is not correct.
ERROR - 2018-07-02 13:02:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:02:23 --> The path to the image is not correct.
ERROR - 2018-07-02 13:02:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:02:42 --> The path to the image is not correct.
ERROR - 2018-07-02 13:02:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:02:42 --> The path to the image is not correct.
ERROR - 2018-07-02 13:02:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:02:42 --> The path to the image is not correct.
ERROR - 2018-07-02 13:02:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:02:46 --> The path to the image is not correct.
ERROR - 2018-07-02 13:02:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:02:46 --> The path to the image is not correct.
ERROR - 2018-07-02 13:02:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:08:43 --> The path to the image is not correct.
ERROR - 2018-07-02 13:08:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:08:43 --> The path to the image is not correct.
ERROR - 2018-07-02 13:08:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:08:43 --> The path to the image is not correct.
ERROR - 2018-07-02 13:08:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:08:46 --> The path to the image is not correct.
ERROR - 2018-07-02 13:08:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:08:46 --> The path to the image is not correct.
ERROR - 2018-07-02 13:08:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:13:52 --> The path to the image is not correct.
ERROR - 2018-07-02 13:13:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:13:52 --> The path to the image is not correct.
ERROR - 2018-07-02 13:13:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:13:52 --> The path to the image is not correct.
ERROR - 2018-07-02 13:13:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:15:21 --> The path to the image is not correct.
ERROR - 2018-07-02 13:15:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:15:21 --> The path to the image is not correct.
ERROR - 2018-07-02 13:15:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:16:36 --> The path to the image is not correct.
ERROR - 2018-07-02 13:16:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:16:37 --> The path to the image is not correct.
ERROR - 2018-07-02 13:16:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:16:37 --> The path to the image is not correct.
ERROR - 2018-07-02 13:16:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:16:40 --> The path to the image is not correct.
ERROR - 2018-07-02 13:16:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:16:40 --> The path to the image is not correct.
ERROR - 2018-07-02 13:16:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-02 13:16:41 --> The path to the image is not correct.
ERROR - 2018-07-02 13:16:41 --> Your server does not support the GD function required to process this type of image.

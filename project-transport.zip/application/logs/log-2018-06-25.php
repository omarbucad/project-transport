<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 13
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 65
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 78
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 90
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 28
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-06-25 02:44:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-06-25 02:44:42 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 02:44:42 --> The path to the image is not correct.
ERROR - 2018-06-25 02:44:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 02:44:42 --> The path to the image is not correct.
ERROR - 2018-06-25 02:44:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 02:59:25 --> The path to the image is not correct.
ERROR - 2018-06-25 02:59:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:02:11 --> The path to the image is not correct.
ERROR - 2018-06-25 03:02:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:02:11 --> The path to the image is not correct.
ERROR - 2018-06-25 03:02:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:02:11 --> The path to the image is not correct.
ERROR - 2018-06-25 03:02:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:02:12 --> The path to the image is not correct.
ERROR - 2018-06-25 03:02:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:02:12 --> The path to the image is not correct.
ERROR - 2018-06-25 03:02:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:02:24 --> The path to the image is not correct.
ERROR - 2018-06-25 03:02:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:05:23 --> The path to the image is not correct.
ERROR - 2018-06-25 03:05:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:05:23 --> The path to the image is not correct.
ERROR - 2018-06-25 03:05:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:05:50 --> The path to the image is not correct.
ERROR - 2018-06-25 03:05:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:05:50 --> The path to the image is not correct.
ERROR - 2018-06-25 03:05:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:05:54 --> The path to the image is not correct.
ERROR - 2018-06-25 03:05:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:05:54 --> The path to the image is not correct.
ERROR - 2018-06-25 03:05:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:24 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:25 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:29 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:29 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:31 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:31 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:41 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:41 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:46 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:46 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:52 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:06:52 --> The path to the image is not correct.
ERROR - 2018-06-25 03:06:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:01 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:01 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:39 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:39 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:41 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:41 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:44 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:44 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:57 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:57 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:58 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:07:58 --> The path to the image is not correct.
ERROR - 2018-06-25 03:07:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:08:18 --> The path to the image is not correct.
ERROR - 2018-06-25 03:08:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:08:18 --> The path to the image is not correct.
ERROR - 2018-06-25 03:08:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:08:20 --> The path to the image is not correct.
ERROR - 2018-06-25 03:08:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:08:20 --> The path to the image is not correct.
ERROR - 2018-06-25 03:08:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:09:12 --> The path to the image is not correct.
ERROR - 2018-06-25 03:09:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:09:13 --> The path to the image is not correct.
ERROR - 2018-06-25 03:09:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:09:13 --> The path to the image is not correct.
ERROR - 2018-06-25 03:09:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:09:13 --> The path to the image is not correct.
ERROR - 2018-06-25 03:09:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:09:20 --> The path to the image is not correct.
ERROR - 2018-06-25 03:09:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:09:20 --> The path to the image is not correct.
ERROR - 2018-06-25 03:09:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:09:43 --> The path to the image is not correct.
ERROR - 2018-06-25 03:09:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:09:43 --> The path to the image is not correct.
ERROR - 2018-06-25 03:09:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:09:51 --> The path to the image is not correct.
ERROR - 2018-06-25 03:09:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:09:51 --> The path to the image is not correct.
ERROR - 2018-06-25 03:09:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:10:02 --> The path to the image is not correct.
ERROR - 2018-06-25 03:10:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:10:02 --> The path to the image is not correct.
ERROR - 2018-06-25 03:10:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:11:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:11:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:11:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:11:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:13:51 --> The path to the image is not correct.
ERROR - 2018-06-25 03:13:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:13:51 --> The path to the image is not correct.
ERROR - 2018-06-25 03:13:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:14:23 --> The path to the image is not correct.
ERROR - 2018-06-25 03:14:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:14:23 --> The path to the image is not correct.
ERROR - 2018-06-25 03:14:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:15:10 --> The path to the image is not correct.
ERROR - 2018-06-25 03:15:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:15:10 --> The path to the image is not correct.
ERROR - 2018-06-25 03:15:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:15:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:15:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:15:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:15:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:15:42 --> The path to the image is not correct.
ERROR - 2018-06-25 03:15:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:15:42 --> The path to the image is not correct.
ERROR - 2018-06-25 03:15:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:16:02 --> The path to the image is not correct.
ERROR - 2018-06-25 03:16:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:16:02 --> The path to the image is not correct.
ERROR - 2018-06-25 03:16:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:16:15 --> The path to the image is not correct.
ERROR - 2018-06-25 03:16:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:16:15 --> The path to the image is not correct.
ERROR - 2018-06-25 03:16:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:16:15 --> The path to the image is not correct.
ERROR - 2018-06-25 03:16:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:16:15 --> The path to the image is not correct.
ERROR - 2018-06-25 03:16:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:16:16 --> The path to the image is not correct.
ERROR - 2018-06-25 03:16:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:16:16 --> The path to the image is not correct.
ERROR - 2018-06-25 03:16:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:17:09 --> The path to the image is not correct.
ERROR - 2018-06-25 03:17:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:17:09 --> The path to the image is not correct.
ERROR - 2018-06-25 03:17:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:17:09 --> The path to the image is not correct.
ERROR - 2018-06-25 03:17:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:17:09 --> The path to the image is not correct.
ERROR - 2018-06-25 03:17:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:18:13 --> The path to the image is not correct.
ERROR - 2018-06-25 03:18:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:18:13 --> The path to the image is not correct.
ERROR - 2018-06-25 03:18:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:18:13 --> The path to the image is not correct.
ERROR - 2018-06-25 03:18:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:18:13 --> The path to the image is not correct.
ERROR - 2018-06-25 03:18:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:18:34 --> The path to the image is not correct.
ERROR - 2018-06-25 03:18:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:18:34 --> The path to the image is not correct.
ERROR - 2018-06-25 03:18:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:19:39 --> The path to the image is not correct.
ERROR - 2018-06-25 03:19:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:19:39 --> The path to the image is not correct.
ERROR - 2018-06-25 03:19:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:19:40 --> The path to the image is not correct.
ERROR - 2018-06-25 03:19:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:19:40 --> The path to the image is not correct.
ERROR - 2018-06-25 03:19:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:19:59 --> The path to the image is not correct.
ERROR - 2018-06-25 03:19:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:19:59 --> The path to the image is not correct.
ERROR - 2018-06-25 03:19:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:20:00 --> The path to the image is not correct.
ERROR - 2018-06-25 03:20:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:20:00 --> The path to the image is not correct.
ERROR - 2018-06-25 03:20:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:20:00 --> The path to the image is not correct.
ERROR - 2018-06-25 03:20:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:20:00 --> The path to the image is not correct.
ERROR - 2018-06-25 03:20:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:20:00 --> The path to the image is not correct.
ERROR - 2018-06-25 03:20:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:20:00 --> The path to the image is not correct.
ERROR - 2018-06-25 03:20:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:20:01 --> The path to the image is not correct.
ERROR - 2018-06-25 03:20:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:20:01 --> The path to the image is not correct.
ERROR - 2018-06-25 03:20:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:20:01 --> The path to the image is not correct.
ERROR - 2018-06-25 03:20:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:20:01 --> The path to the image is not correct.
ERROR - 2018-06-25 03:20:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:21:06 --> The path to the image is not correct.
ERROR - 2018-06-25 03:21:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:21:06 --> The path to the image is not correct.
ERROR - 2018-06-25 03:21:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:21:14 --> The path to the image is not correct.
ERROR - 2018-06-25 03:21:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:21:14 --> The path to the image is not correct.
ERROR - 2018-06-25 03:21:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:21:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:21:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:21:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:21:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:21:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:21:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:21:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:21:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:23:35 --> The path to the image is not correct.
ERROR - 2018-06-25 03:23:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:23:35 --> The path to the image is not correct.
ERROR - 2018-06-25 03:23:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:23:35 --> The path to the image is not correct.
ERROR - 2018-06-25 03:23:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:23:35 --> The path to the image is not correct.
ERROR - 2018-06-25 03:23:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:25:57 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 13
ERROR - 2018-06-25 03:26:08 --> The path to the image is not correct.
ERROR - 2018-06-25 03:26:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:26:08 --> The path to the image is not correct.
ERROR - 2018-06-25 03:26:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:02 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:03 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:06 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:06 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:07 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:07 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:19 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:19 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:21 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:22 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:35 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:27:35 --> The path to the image is not correct.
ERROR - 2018-06-25 03:27:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:28:21 --> The path to the image is not correct.
ERROR - 2018-06-25 03:28:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:28:21 --> The path to the image is not correct.
ERROR - 2018-06-25 03:28:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:28:21 --> The path to the image is not correct.
ERROR - 2018-06-25 03:28:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:28:21 --> The path to the image is not correct.
ERROR - 2018-06-25 03:28:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:30:55 --> The path to the image is not correct.
ERROR - 2018-06-25 03:30:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:30:55 --> The path to the image is not correct.
ERROR - 2018-06-25 03:30:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:32:06 --> The path to the image is not correct.
ERROR - 2018-06-25 03:32:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:32:06 --> The path to the image is not correct.
ERROR - 2018-06-25 03:32:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:32:06 --> The path to the image is not correct.
ERROR - 2018-06-25 03:32:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:32:06 --> The path to the image is not correct.
ERROR - 2018-06-25 03:32:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:32:18 --> The path to the image is not correct.
ERROR - 2018-06-25 03:32:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:32:18 --> The path to the image is not correct.
ERROR - 2018-06-25 03:32:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:32:53 --> The path to the image is not correct.
ERROR - 2018-06-25 03:32:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:32:53 --> The path to the image is not correct.
ERROR - 2018-06-25 03:32:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:33:39 --> The path to the image is not correct.
ERROR - 2018-06-25 03:33:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:33:39 --> The path to the image is not correct.
ERROR - 2018-06-25 03:33:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:36:58 --> The path to the image is not correct.
ERROR - 2018-06-25 03:36:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:36:58 --> The path to the image is not correct.
ERROR - 2018-06-25 03:36:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:37:47 --> The path to the image is not correct.
ERROR - 2018-06-25 03:37:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:37:48 --> The path to the image is not correct.
ERROR - 2018-06-25 03:37:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:38:21 --> The path to the image is not correct.
ERROR - 2018-06-25 03:38:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:38:21 --> The path to the image is not correct.
ERROR - 2018-06-25 03:38:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:38:51 --> The path to the image is not correct.
ERROR - 2018-06-25 03:38:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:39:02 --> The path to the image is not correct.
ERROR - 2018-06-25 03:39:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:39:02 --> The path to the image is not correct.
ERROR - 2018-06-25 03:39:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:39:12 --> The path to the image is not correct.
ERROR - 2018-06-25 03:39:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:39:12 --> The path to the image is not correct.
ERROR - 2018-06-25 03:39:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:39:36 --> The path to the image is not correct.
ERROR - 2018-06-25 03:39:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:39:36 --> The path to the image is not correct.
ERROR - 2018-06-25 03:39:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:39:43 --> The path to the image is not correct.
ERROR - 2018-06-25 03:39:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:39:43 --> The path to the image is not correct.
ERROR - 2018-06-25 03:39:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:40:50 --> Severity: Parsing Error --> syntax error, unexpected 'this' (T_STRING) D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 13
ERROR - 2018-06-25 03:40:57 --> The path to the image is not correct.
ERROR - 2018-06-25 03:40:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:40:57 --> The path to the image is not correct.
ERROR - 2018-06-25 03:40:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:41:03 --> The path to the image is not correct.
ERROR - 2018-06-25 03:41:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:41:03 --> The path to the image is not correct.
ERROR - 2018-06-25 03:41:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:41:08 --> The path to the image is not correct.
ERROR - 2018-06-25 03:41:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:41:08 --> The path to the image is not correct.
ERROR - 2018-06-25 03:41:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:42:33 --> The path to the image is not correct.
ERROR - 2018-06-25 03:42:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:42:45 --> The path to the image is not correct.
ERROR - 2018-06-25 03:42:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:44:10 --> The path to the image is not correct.
ERROR - 2018-06-25 03:44:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:44:11 --> The path to the image is not correct.
ERROR - 2018-06-25 03:44:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:44:11 --> The path to the image is not correct.
ERROR - 2018-06-25 03:44:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:44:11 --> The path to the image is not correct.
ERROR - 2018-06-25 03:44:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:44:11 --> The path to the image is not correct.
ERROR - 2018-06-25 03:44:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:44:11 --> The path to the image is not correct.
ERROR - 2018-06-25 03:44:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:44:12 --> The path to the image is not correct.
ERROR - 2018-06-25 03:44:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:44:12 --> The path to the image is not correct.
ERROR - 2018-06-25 03:44:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:44:16 --> The path to the image is not correct.
ERROR - 2018-06-25 03:44:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:44:16 --> The path to the image is not correct.
ERROR - 2018-06-25 03:44:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:28 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:28 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:29 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:29 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:29 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:29 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:29 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:29 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:55 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:55 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:55 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:55 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:57 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:57 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:57 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:45:57 --> The path to the image is not correct.
ERROR - 2018-06-25 03:45:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:46:23 --> The path to the image is not correct.
ERROR - 2018-06-25 03:46:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:46:23 --> The path to the image is not correct.
ERROR - 2018-06-25 03:46:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:47:27 --> The path to the image is not correct.
ERROR - 2018-06-25 03:47:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:47:27 --> The path to the image is not correct.
ERROR - 2018-06-25 03:47:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:47:44 --> The path to the image is not correct.
ERROR - 2018-06-25 03:47:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:47:44 --> The path to the image is not correct.
ERROR - 2018-06-25 03:47:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:47:45 --> The path to the image is not correct.
ERROR - 2018-06-25 03:47:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:47:45 --> The path to the image is not correct.
ERROR - 2018-06-25 03:47:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:47:45 --> The path to the image is not correct.
ERROR - 2018-06-25 03:47:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:47:45 --> The path to the image is not correct.
ERROR - 2018-06-25 03:47:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:49:36 --> The path to the image is not correct.
ERROR - 2018-06-25 03:49:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:49:36 --> The path to the image is not correct.
ERROR - 2018-06-25 03:49:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:16 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:16 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:16 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:17 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:17 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:17 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:17 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:17 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:17 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:17 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:17 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:37 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:37 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:37 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:53 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:53 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:51:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:51:54 --> The path to the image is not correct.
ERROR - 2018-06-25 03:51:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:52:18 --> The path to the image is not correct.
ERROR - 2018-06-25 03:52:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:52:19 --> The path to the image is not correct.
ERROR - 2018-06-25 03:52:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:52:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:52:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:52:19 --> The path to the image is not correct.
ERROR - 2018-06-25 03:52:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:52:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:52:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:52:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:52:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:52:56 --> The path to the image is not correct.
ERROR - 2018-06-25 03:52:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:54:08 --> The path to the image is not correct.
ERROR - 2018-06-25 03:54:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:54:08 --> The path to the image is not correct.
ERROR - 2018-06-25 03:54:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:54:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:54:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:54:37 --> The path to the image is not correct.
ERROR - 2018-06-25 03:54:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:54:37 --> The path to the image is not correct.
ERROR - 2018-06-25 03:54:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:54:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:54:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:54:37 --> The path to the image is not correct.
ERROR - 2018-06-25 03:54:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:54:52 --> The path to the image is not correct.
ERROR - 2018-06-25 03:54:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:54:52 --> The path to the image is not correct.
ERROR - 2018-06-25 03:54:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:54:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:54:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:54:53 --> The path to the image is not correct.
ERROR - 2018-06-25 03:54:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:55:36 --> The path to the image is not correct.
ERROR - 2018-06-25 03:55:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:55:36 --> The path to the image is not correct.
ERROR - 2018-06-25 03:55:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:55:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:55:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:55:36 --> The path to the image is not correct.
ERROR - 2018-06-25 03:55:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:55:46 --> The path to the image is not correct.
ERROR - 2018-06-25 03:55:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:55:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:55:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:55:46 --> The path to the image is not correct.
ERROR - 2018-06-25 03:55:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:55:46 --> The path to the image is not correct.
ERROR - 2018-06-25 03:55:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:56:48 --> The path to the image is not correct.
ERROR - 2018-06-25 03:56:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:56:48 --> The path to the image is not correct.
ERROR - 2018-06-25 03:56:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:56:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:56:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:02 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:02 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:02 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:03 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:03 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:03 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:03 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:03 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:04 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:04 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:24 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:24 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:24 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:30 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 03:57:30 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 03:57:30 --> The path to the image is not correct.
ERROR - 2018-06-25 03:57:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:02:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:02:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:02:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:02:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:02:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:02:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:02:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:02:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:02:44 --> The path to the image is not correct.
ERROR - 2018-06-25 04:02:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:02:44 --> The path to the image is not correct.
ERROR - 2018-06-25 04:02:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:02:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:02:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:02:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:02:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:03:13 --> The path to the image is not correct.
ERROR - 2018-06-25 04:03:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:03:13 --> The path to the image is not correct.
ERROR - 2018-06-25 04:03:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:03:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:03:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:03:44 --> The path to the image is not correct.
ERROR - 2018-06-25 04:03:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:03:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:03:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:03:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:03:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:05:12 --> The path to the image is not correct.
ERROR - 2018-06-25 04:05:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:05:12 --> The path to the image is not correct.
ERROR - 2018-06-25 04:05:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:05:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:05:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:05:12 --> The path to the image is not correct.
ERROR - 2018-06-25 04:05:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:05:48 --> The path to the image is not correct.
ERROR - 2018-06-25 04:05:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:05:48 --> The path to the image is not correct.
ERROR - 2018-06-25 04:05:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:05:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:05:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:05:48 --> The path to the image is not correct.
ERROR - 2018-06-25 04:05:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:06:44 --> The path to the image is not correct.
ERROR - 2018-06-25 04:06:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:06:44 --> The path to the image is not correct.
ERROR - 2018-06-25 04:06:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:06:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:06:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:07:30 --> The path to the image is not correct.
ERROR - 2018-06-25 04:07:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:07:30 --> The path to the image is not correct.
ERROR - 2018-06-25 04:07:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:07:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:07:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:07:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:07:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:07:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:07:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:07:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:07:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:07:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:07:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:13:26 --> The path to the image is not correct.
ERROR - 2018-06-25 04:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:13:26 --> The path to the image is not correct.
ERROR - 2018-06-25 04:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:13:26 --> The path to the image is not correct.
ERROR - 2018-06-25 04:13:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:14:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:14:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:19:47 --> The path to the image is not correct.
ERROR - 2018-06-25 04:19:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:19:47 --> The path to the image is not correct.
ERROR - 2018-06-25 04:19:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:19:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:19:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:19:47 --> The path to the image is not correct.
ERROR - 2018-06-25 04:19:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:19:47 --> The path to the image is not correct.
ERROR - 2018-06-25 04:19:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:19:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:19:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:19:48 --> The path to the image is not correct.
ERROR - 2018-06-25 04:19:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:19:48 --> The path to the image is not correct.
ERROR - 2018-06-25 04:19:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:19:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:19:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:19:48 --> The path to the image is not correct.
ERROR - 2018-06-25 04:19:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:19:48 --> The path to the image is not correct.
ERROR - 2018-06-25 04:19:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:19:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:19:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:19:48 --> The path to the image is not correct.
ERROR - 2018-06-25 04:19:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:19:49 --> The path to the image is not correct.
ERROR - 2018-06-25 04:19:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:19:58 --> 404 Page Not Found: admin/Accounts/user_plan
ERROR - 2018-06-25 04:21:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:21:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:21:49 --> The path to the image is not correct.
ERROR - 2018-06-25 04:21:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:21:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:21:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:21:49 --> The path to the image is not correct.
ERROR - 2018-06-25 04:21:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:21:49 --> The path to the image is not correct.
ERROR - 2018-06-25 04:21:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:21:56 --> 404 Page Not Found: admin/Accounts/user_plan
ERROR - 2018-06-25 04:23:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:23:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:23:05 --> The path to the image is not correct.
ERROR - 2018-06-25 04:23:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:23:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:23:05 --> The path to the image is not correct.
ERROR - 2018-06-25 04:23:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:23:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:23:06 --> The path to the image is not correct.
ERROR - 2018-06-25 04:23:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:23:12 --> 404 Page Not Found: admin/Accounts/user_plan
ERROR - 2018-06-25 04:25:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:29 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:30 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:30 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:30 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:30 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:30 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:30 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:30 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:31 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:32 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:32 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:32 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:32 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:32 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:32 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:32 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:32 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:32 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:32 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:58 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:58 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:25:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:25:58 --> The path to the image is not correct.
ERROR - 2018-06-25 04:25:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:27:22 --> Severity: Notice --> Undefined property: stdClass::$plan_id D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 265
ERROR - 2018-06-25 04:27:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'active', 1 = 0
WHERE `user_plan_id` IS NULL' at line 1 - Invalid query: UPDATE `user_plan` SET 0 = 'active', 1 = 0
WHERE `user_plan_id` IS NULL
ERROR - 2018-06-25 04:31:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'active', 1 = 0
WHERE `user_plan_id` = '1'' at line 1 - Invalid query: UPDATE `user_plan` SET 0 = 'active', 1 = 0
WHERE `user_plan_id` = '1'
ERROR - 2018-06-25 04:41:58 --> The path to the image is not correct.
ERROR - 2018-06-25 04:41:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:41:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:41:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:41:58 --> The path to the image is not correct.
ERROR - 2018-06-25 04:41:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:42:00 --> The path to the image is not correct.
ERROR - 2018-06-25 04:42:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:42:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:42:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:42:00 --> The path to the image is not correct.
ERROR - 2018-06-25 04:42:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:42:00 --> The path to the image is not correct.
ERROR - 2018-06-25 04:42:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:42:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:42:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:42:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:42:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:42:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:42:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:42:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:42:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:42:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'active', 1 = 0
WHERE `user_plan_id` = '1'' at line 1 - Invalid query: UPDATE `user_plan` SET 0 = 'active', 1 = 0
WHERE `user_plan_id` = '1'
ERROR - 2018-06-25 04:43:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'active', 1 = 0
WHERE `user_plan_id` = '1'' at line 1 - Invalid query: UPDATE `user_plan` SET 0 = 'active', 1 = 0
WHERE `user_plan_id` = '1'
ERROR - 2018-06-25 04:46:00 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:00 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:06 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:06 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:06 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:07 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:07 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:07 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:07 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:07 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:07 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:46:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:46:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:46:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:48:16 --> The path to the image is not correct.
ERROR - 2018-06-25 04:48:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:48:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:18 --> The path to the image is not correct.
ERROR - 2018-06-25 04:48:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:48:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:18 --> The path to the image is not correct.
ERROR - 2018-06-25 04:48:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:48:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:18 --> The path to the image is not correct.
ERROR - 2018-06-25 04:48:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:48:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:35 --> The path to the image is not correct.
ERROR - 2018-06-25 04:48:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:48:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:35 --> The path to the image is not correct.
ERROR - 2018-06-25 04:48:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:36 --> The path to the image is not correct.
ERROR - 2018-06-25 04:48:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:36 --> The path to the image is not correct.
ERROR - 2018-06-25 04:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:48:36 --> The path to the image is not correct.
ERROR - 2018-06-25 04:48:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:48:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:12 --> The path to the image is not correct.
ERROR - 2018-06-25 04:49:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:49:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:12 --> The path to the image is not correct.
ERROR - 2018-06-25 04:49:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:49:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:12 --> The path to the image is not correct.
ERROR - 2018-06-25 04:49:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:49:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:40 --> The path to the image is not correct.
ERROR - 2018-06-25 04:49:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:49:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:41 --> The path to the image is not correct.
ERROR - 2018-06-25 04:49:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:49:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:41 --> The path to the image is not correct.
ERROR - 2018-06-25 04:49:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:49:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:51 --> The path to the image is not correct.
ERROR - 2018-06-25 04:49:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:49:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:49:51 --> The path to the image is not correct.
ERROR - 2018-06-25 04:49:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:49:51 --> The path to the image is not correct.
ERROR - 2018-06-25 04:49:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:50:42 --> The path to the image is not correct.
ERROR - 2018-06-25 04:50:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:50:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:50:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:24 --> The path to the image is not correct.
ERROR - 2018-06-25 04:51:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:51:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:57 --> The path to the image is not correct.
ERROR - 2018-06-25 04:51:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:51:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:58 --> The path to the image is not correct.
ERROR - 2018-06-25 04:51:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:51:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:58 --> The path to the image is not correct.
ERROR - 2018-06-25 04:51:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:51:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:58 --> The path to the image is not correct.
ERROR - 2018-06-25 04:51:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:51:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:59 --> The path to the image is not correct.
ERROR - 2018-06-25 04:51:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:51:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:59 --> The path to the image is not correct.
ERROR - 2018-06-25 04:51:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:51:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:51:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:52:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:52:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:52:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:52:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:52:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:52:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:52:08 --> The path to the image is not correct.
ERROR - 2018-06-25 04:52:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:54:12 --> Severity: Parsing Error --> syntax error, unexpected ']' D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 286
ERROR - 2018-06-25 04:54:38 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ']' D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 285
ERROR - 2018-06-25 04:54:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:54:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:54:45 --> The path to the image is not correct.
ERROR - 2018-06-25 04:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:54:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:55:41 --> The path to the image is not correct.
ERROR - 2018-06-25 04:55:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:55:41 --> The path to the image is not correct.
ERROR - 2018-06-25 04:55:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:55:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:55:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:57:12 --> The path to the image is not correct.
ERROR - 2018-06-25 04:57:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:57:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:57:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 04:57:12 --> The path to the image is not correct.
ERROR - 2018-06-25 04:57:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 04:57:12 --> The path to the image is not correct.
ERROR - 2018-06-25 04:57:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:03 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:03 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:03 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:03 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:04 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:04 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:04 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:04 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:04 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:11 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:11 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:11 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:15 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:15 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:15 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:15 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:15 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:16 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:16 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:16 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:16 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:16 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:18 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:18 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:18 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:19 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:19 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:19 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:20 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:20 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:20 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:01:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:01:20 --> The path to the image is not correct.
ERROR - 2018-06-25 05:01:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:19:34 --> The path to the image is not correct.
ERROR - 2018-06-25 05:19:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:19:34 --> The path to the image is not correct.
ERROR - 2018-06-25 05:19:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:19:51 --> The path to the image is not correct.
ERROR - 2018-06-25 05:19:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:19:51 --> The path to the image is not correct.
ERROR - 2018-06-25 05:19:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:19:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:19:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:19:51 --> The path to the image is not correct.
ERROR - 2018-06-25 05:19:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:31:23 --> The path to the image is not correct.
ERROR - 2018-06-25 05:31:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:31:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:31:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:31:23 --> The path to the image is not correct.
ERROR - 2018-06-25 05:31:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:31:23 --> The path to the image is not correct.
ERROR - 2018-06-25 05:31:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:31:25 --> The path to the image is not correct.
ERROR - 2018-06-25 05:31:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:31:25 --> The path to the image is not correct.
ERROR - 2018-06-25 05:31:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:31:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:31:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:47 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:47 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:38:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:38:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:47 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:47 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:38:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:38:47 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:47 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:38:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:38:47 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:48 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:48 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:48 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:38:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:38:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:38:48 --> The path to the image is not correct.
ERROR - 2018-06-25 05:38:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:50:12 --> The path to the image is not correct.
ERROR - 2018-06-25 05:50:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:50:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:50:12 --> The path to the image is not correct.
ERROR - 2018-06-25 05:50:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:50:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:50:12 --> The path to the image is not correct.
ERROR - 2018-06-25 05:50:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:50:19 --> The path to the image is not correct.
ERROR - 2018-06-25 05:50:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:50:22 --> The path to the image is not correct.
ERROR - 2018-06-25 05:50:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 05:50:22 --> The path to the image is not correct.
ERROR - 2018-06-25 05:50:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:50:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-06-25 05:50:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 08:23:49 --> The path to the image is not correct.
ERROR - 2018-06-25 08:23:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 08:23:53 --> The path to the image is not correct.
ERROR - 2018-06-25 08:23:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 08:23:56 --> Severity: Error --> Call to undefined method Pdf::create_report_checklist() D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 86
ERROR - 2018-06-25 10:23:00 --> The path to the image is not correct.
ERROR - 2018-06-25 10:23:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:23:02 --> The path to the image is not correct.
ERROR - 2018-06-25 10:23:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:23:07 --> The path to the image is not correct.
ERROR - 2018-06-25 10:23:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:23:30 --> The path to the image is not correct.
ERROR - 2018-06-25 10:23:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:23:47 --> The path to the image is not correct.
ERROR - 2018-06-25 10:23:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:23:47 --> The path to the image is not correct.
ERROR - 2018-06-25 10:23:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:23:48 --> The path to the image is not correct.
ERROR - 2018-06-25 10:23:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:26:04 --> The path to the image is not correct.
ERROR - 2018-06-25 10:26:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:32:19 --> The path to the image is not correct.
ERROR - 2018-06-25 10:32:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:32:20 --> The path to the image is not correct.
ERROR - 2018-06-25 10:32:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:32:32 --> The path to the image is not correct.
ERROR - 2018-06-25 10:32:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 10:32:32 --> The path to the image is not correct.
ERROR - 2018-06-25 10:32:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 11:28:16 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 299
ERROR - 2018-06-25 11:28:16 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 301
ERROR - 2018-06-25 11:28:16 --> Query error: Column 'invoice_no' cannot be null - Invalid query: INSERT INTO `invoice` (`invoice_no`, `store_id`, `user_id`, `user_plan_id`, `created`, `price`) VALUES (NULL, '1', '6', 6, 1529918896, 0)
ERROR - 2018-06-25 11:28:35 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 301
ERROR - 2018-06-25 11:28:35 --> Query error: Column 'invoice_no' cannot be null - Invalid query: INSERT INTO `invoice` (`invoice_no`, `store_id`, `user_id`, `user_plan_id`, `created`, `price`) VALUES (NULL, '1', '6', 7, 1529918915, 0)
ERROR - 2018-06-25 11:28:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'invoice_no', 1 = '25062018-00001'
WHERE `invoice_id` = 1' at line 1 - Invalid query: UPDATE `invoice` SET 0 = 'invoice_no', 1 = '25062018-00001'
WHERE `invoice_id` = 1
ERROR - 2018-06-25 11:30:15 --> The path to the image is not correct.
ERROR - 2018-06-25 11:30:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 11:30:16 --> The path to the image is not correct.
ERROR - 2018-06-25 11:30:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 11:31:57 --> The path to the image is not correct.
ERROR - 2018-06-25 11:31:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 11:31:57 --> The path to the image is not correct.
ERROR - 2018-06-25 11:31:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 11:32:13 --> The path to the image is not correct.
ERROR - 2018-06-25 11:32:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 11:32:13 --> The path to the image is not correct.
ERROR - 2018-06-25 11:32:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 11:45:25 --> The path to the image is not correct.
ERROR - 2018-06-25 11:45:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 11:45:26 --> The path to the image is not correct.
ERROR - 2018-06-25 11:45:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 11:45:28 --> The path to the image is not correct.
ERROR - 2018-06-25 11:45:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 11:45:28 --> The path to the image is not correct.
ERROR - 2018-06-25 11:45:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 12:03:15 --> Query error: Unknown column 'up.who_updated' in 'on clause' - Invalid query: SELECT `i`.*, `up`.`plan_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`billing_type`, `up`.`who_updated`, `u2`.`display_name` as `updated_by`, `u`.`display_name`
FROM `invoice` `i`
JOIN `user` `u` ON `u`.`user_id` = `i`.`user_id`
JOIN `user` `u2` ON `u2`.`user_id` = `up`.`who_updated`
JOIN `user_plan` `up` ON `up`.`user_plan_id` = `i`.`user_plan_id`
WHERE `i`.`invoice_id` = 2
ERROR - 2018-06-25 12:12:14 --> The path to the image is not correct.
ERROR - 2018-06-25 12:12:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:01:19 --> Severity: Notice --> Undefined property: stdClass::$invoice_no D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 108
ERROR - 2018-06-25 13:01:19 --> Severity: Notice --> Undefined property: stdClass::$updated_by D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-25 13:01:19 --> Severity: Notice --> Undefined property: stdClass::$price D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 118
ERROR - 2018-06-25 13:01:19 --> Severity: Notice --> Undefined property: stdClass::$invoice_no D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 108
ERROR - 2018-06-25 13:01:19 --> Severity: Notice --> Undefined property: stdClass::$updated_by D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 115
ERROR - 2018-06-25 13:01:19 --> Severity: Notice --> Undefined property: stdClass::$price D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 118
ERROR - 2018-06-25 13:01:19 --> The path to the image is not correct.
ERROR - 2018-06-25 13:01:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:01:19 --> The path to the image is not correct.
ERROR - 2018-06-25 13:01:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:09:49 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 15
ERROR - 2018-06-25 13:09:49 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 17
ERROR - 2018-06-25 13:09:49 --> The path to the image is not correct.
ERROR - 2018-06-25 13:09:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:45:06 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 15
ERROR - 2018-06-25 13:45:06 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 17
ERROR - 2018-06-25 13:45:06 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 23
ERROR - 2018-06-25 13:45:06 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 25
ERROR - 2018-06-25 13:45:06 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:45:06 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:45:06 --> The path to the image is not correct.
ERROR - 2018-06-25 13:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:46:08 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 15
ERROR - 2018-06-25 13:46:08 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 17
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 23
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 25
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:09 --> The path to the image is not correct.
ERROR - 2018-06-25 13:46:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 15
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 17
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 23
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 25
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:09 --> The path to the image is not correct.
ERROR - 2018-06-25 13:46:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 15
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 17
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 23
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 25
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:09 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 15
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 17
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 23
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 25
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:10 --> The path to the image is not correct.
ERROR - 2018-06-25 13:46:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:46:10 --> The path to the image is not correct.
ERROR - 2018-06-25 13:46:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 15
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 17
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 23
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 25
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:10 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:10 --> The path to the image is not correct.
ERROR - 2018-06-25 13:46:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:46:34 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 15
ERROR - 2018-06-25 13:46:34 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 17
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 23
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 25
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:46:58 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:46:59 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-25 13:46:59 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 13:46:59 --> The path to the image is not correct.
ERROR - 2018-06-25 13:46:59 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 13:46:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 23
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 25
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 27
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 126
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:47:22 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 134
ERROR - 2018-06-25 13:47:22 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 13:47:22 --> The path to the image is not correct.
ERROR - 2018-06-25 13:47:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:47:23 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 13:48:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 116
ERROR - 2018-06-25 13:48:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 116
ERROR - 2018-06-25 13:48:03 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 119
ERROR - 2018-06-25 13:48:03 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:03 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:03 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:48:03 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 116
ERROR - 2018-06-25 13:48:03 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 116
ERROR - 2018-06-25 13:48:03 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 119
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 116
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 116
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 119
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 116
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 116
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 119
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:04 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 127
ERROR - 2018-06-25 13:48:04 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 13:48:04 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 13:48:04 --> The path to the image is not correct.
ERROR - 2018-06-25 13:48:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:48:13 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 122
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 122
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 122
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 122
ERROR - 2018-06-25 13:48:14 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:48:14 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 13:48:14 --> The path to the image is not correct.
ERROR - 2018-06-25 13:48:14 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 13:48:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 122
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 122
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 122
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$image_path D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$image_name D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 117
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 120
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$email_address D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 121
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 122
ERROR - 2018-06-25 13:48:25 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 128
ERROR - 2018-06-25 13:48:25 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 13:48:25 --> The path to the image is not correct.
ERROR - 2018-06-25 13:48:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:48:25 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-06-25 13:50:29 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 124
ERROR - 2018-06-25 13:50:29 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 124
ERROR - 2018-06-25 13:50:29 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 124
ERROR - 2018-06-25 13:50:29 --> Severity: Notice --> Undefined property: stdClass::$role D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 124
ERROR - 2018-06-25 13:50:29 --> The path to the image is not correct.
ERROR - 2018-06-25 13:50:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:50:53 --> The path to the image is not correct.
ERROR - 2018-06-25 13:50:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:51:06 --> The path to the image is not correct.
ERROR - 2018-06-25 13:51:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:52:51 --> The path to the image is not correct.
ERROR - 2018-06-25 13:52:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:53:03 --> The path to the image is not correct.
ERROR - 2018-06-25 13:53:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:53:44 --> The path to the image is not correct.
ERROR - 2018-06-25 13:53:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:54:03 --> The path to the image is not correct.
ERROR - 2018-06-25 13:54:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:54:33 --> The path to the image is not correct.
ERROR - 2018-06-25 13:54:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:54:43 --> The path to the image is not correct.
ERROR - 2018-06-25 13:54:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:54:57 --> The path to the image is not correct.
ERROR - 2018-06-25 13:54:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:55:02 --> The path to the image is not correct.
ERROR - 2018-06-25 13:55:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:55:11 --> The path to the image is not correct.
ERROR - 2018-06-25 13:55:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:55:43 --> The path to the image is not correct.
ERROR - 2018-06-25 13:55:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:55:48 --> The path to the image is not correct.
ERROR - 2018-06-25 13:55:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:56:32 --> The path to the image is not correct.
ERROR - 2018-06-25 13:56:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:56:57 --> The path to the image is not correct.
ERROR - 2018-06-25 13:56:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:57:24 --> The path to the image is not correct.
ERROR - 2018-06-25 13:57:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 13:57:49 --> The path to the image is not correct.
ERROR - 2018-06-25 13:57:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 14:00:09 --> The path to the image is not correct.
ERROR - 2018-06-25 14:00:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-25 14:00:19 --> The path to the image is not correct.
ERROR - 2018-06-25 14:00:19 --> Your server does not support the GD function required to process this type of image.

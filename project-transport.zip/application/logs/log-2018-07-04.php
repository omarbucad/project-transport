<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-04 03:24:12 --> The path to the image is not correct.
ERROR - 2018-07-04 03:24:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:24:31 --> The path to the image is not correct.
ERROR - 2018-07-04 03:24:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:24:31 --> The path to the image is not correct.
ERROR - 2018-07-04 03:24:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:45:34 --> The path to the image is not correct.
ERROR - 2018-07-04 03:45:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:52:29 --> The path to the image is not correct.
ERROR - 2018-07-04 03:52:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:52:30 --> The path to the image is not correct.
ERROR - 2018-07-04 03:52:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:52:30 --> The path to the image is not correct.
ERROR - 2018-07-04 03:52:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:53:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:53:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:54:03 --> The path to the image is not correct.
ERROR - 2018-07-04 03:54:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:54:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:54:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:55:06 --> The path to the image is not correct.
ERROR - 2018-07-04 03:55:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:55:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:55:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:55:17 --> The path to the image is not correct.
ERROR - 2018-07-04 03:55:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:55:17 --> The path to the image is not correct.
ERROR - 2018-07-04 03:55:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:55:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:55:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:57:57 --> The path to the image is not correct.
ERROR - 2018-07-04 03:57:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:57:57 --> The path to the image is not correct.
ERROR - 2018-07-04 03:57:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 03:57:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:57:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 03:57:57 --> The path to the image is not correct.
ERROR - 2018-07-04 03:57:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:10:38 --> The path to the image is not correct.
ERROR - 2018-07-04 04:10:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:10:38 --> The path to the image is not correct.
ERROR - 2018-07-04 04:10:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:10:38 --> The path to the image is not correct.
ERROR - 2018-07-04 04:10:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:10:45 --> 404 Page Not Found: admin/Invoice/resend_invoice
ERROR - 2018-07-04 04:11:21 --> The path to the image is not correct.
ERROR - 2018-07-04 04:11:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:11:21 --> The path to the image is not correct.
ERROR - 2018-07-04 04:11:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:11:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:11:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:11:21 --> The path to the image is not correct.
ERROR - 2018-07-04 04:11:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Undefined variable: invoice_id D:\xampp\htdocs\project-transport\application\controllers\admin\Invoice.php 55
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 79
ERROR - 2018-07-04 04:11:23 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 79
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Undefined property: stdClass::$plan_created D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 80
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Undefined property: stdClass::$plan_expiration D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 81
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Undefined property: stdClass::$street1 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 83
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Undefined property: stdClass::$street2 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 84
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Undefined property: stdClass::$suburb D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 85
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Undefined property: stdClass::$city D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 86
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Undefined property: stdClass::$postcode D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 87
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Undefined property: stdClass::$state D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 88
ERROR - 2018-07-04 04:11:23 --> Severity: Notice --> Undefined property: stdClass::$country D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 89
ERROR - 2018-07-04 04:11:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-04 04:11:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-04 04:11:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-04 04:11:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-04 04:11:59 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-04 04:12:09 --> The path to the image is not correct.
ERROR - 2018-07-04 04:12:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:12:09 --> The path to the image is not correct.
ERROR - 2018-07-04 04:12:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:12:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:12:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:12:09 --> The path to the image is not correct.
ERROR - 2018-07-04 04:12:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:13:19 --> The path to the image is not correct.
ERROR - 2018-07-04 04:13:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:13:20 --> The path to the image is not correct.
ERROR - 2018-07-04 04:13:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:13:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:13:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:13:20 --> The path to the image is not correct.
ERROR - 2018-07-04 04:13:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:15:42 --> The path to the image is not correct.
ERROR - 2018-07-04 04:15:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:15:43 --> The path to the image is not correct.
ERROR - 2018-07-04 04:15:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:15:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:15:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:15:45 --> Severity: Notice --> Undefined variable: ajax D:\xampp\htdocs\project-transport\application\controllers\admin\Invoice.php 66
ERROR - 2018-07-04 04:16:32 --> The path to the image is not correct.
ERROR - 2018-07-04 04:16:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:16:32 --> The path to the image is not correct.
ERROR - 2018-07-04 04:16:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:16:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:16:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:26:27 --> The path to the image is not correct.
ERROR - 2018-07-04 04:26:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:26:54 --> The path to the image is not correct.
ERROR - 2018-07-04 04:26:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:26:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:26:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:27:36 --> The path to the image is not correct.
ERROR - 2018-07-04 04:27:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:27:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:27:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:35:51 --> The path to the image is not correct.
ERROR - 2018-07-04 04:35:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:35:51 --> The path to the image is not correct.
ERROR - 2018-07-04 04:35:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:35:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:35:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:35:51 --> The path to the image is not correct.
ERROR - 2018-07-04 04:35:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:36:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:36:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:36:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:36:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:36:56 --> The path to the image is not correct.
ERROR - 2018-07-04 04:36:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:36:56 --> The path to the image is not correct.
ERROR - 2018-07-04 04:36:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:36:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:36:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 04:36:56 --> The path to the image is not correct.
ERROR - 2018-07-04 04:36:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:38:40 --> The path to the image is not correct.
ERROR - 2018-07-04 04:38:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:38:42 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\controllers\app\Vehicle.php 16
ERROR - 2018-07-04 04:38:42 --> The path to the image is not correct.
ERROR - 2018-07-04 04:38:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:38:55 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 04:39:03 --> 404 Page Not Found: api/Loginphp/index
ERROR - 2018-07-04 04:39:22 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 16
ERROR - 2018-07-04 04:39:22 --> The path to the image is not correct.
ERROR - 2018-07-04 04:39:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:39:49 --> The path to the image is not correct.
ERROR - 2018-07-04 04:39:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:39:51 --> The path to the image is not correct.
ERROR - 2018-07-04 04:39:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:39:51 --> The path to the image is not correct.
ERROR - 2018-07-04 04:39:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:40:02 --> The path to the image is not correct.
ERROR - 2018-07-04 04:40:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:40:02 --> The path to the image is not correct.
ERROR - 2018-07-04 04:40:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:40:37 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 04:41:13 --> The path to the image is not correct.
ERROR - 2018-07-04 04:41:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:41:24 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\controllers\app\Vehicle.php 16
ERROR - 2018-07-04 04:41:24 --> The path to the image is not correct.
ERROR - 2018-07-04 04:41:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:41:33 --> The path to the image is not correct.
ERROR - 2018-07-04 04:41:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 04:41:40 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 04:41:54 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 04:47:09 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 04:49:49 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 04:50:21 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 04:51:32 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 04:51:41 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 04:51:49 --> 404 Page Not Found: api//index
ERROR - 2018-07-04 04:51:53 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 04:52:06 --> 404 Page Not Found: api/Loginphp/index
ERROR - 2018-07-04 04:52:17 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:03:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:03:05 --> The path to the image is not correct.
ERROR - 2018-07-04 05:03:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:03:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:03:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:04:18 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\controllers\app\Vehicle.php 16
ERROR - 2018-07-04 05:04:18 --> The path to the image is not correct.
ERROR - 2018-07-04 05:04:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:04:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:04:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:06:41 --> The path to the image is not correct.
ERROR - 2018-07-04 05:06:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:06:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:06:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:06:43 --> The path to the image is not correct.
ERROR - 2018-07-04 05:06:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:06:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:06:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:06:54 --> The path to the image is not correct.
ERROR - 2018-07-04 05:06:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:06:54 --> The path to the image is not correct.
ERROR - 2018-07-04 05:06:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:06:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:06:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:06:59 --> The path to the image is not correct.
ERROR - 2018-07-04 05:06:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:06:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:06:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:07:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:07:28 --> The path to the image is not correct.
ERROR - 2018-07-04 05:07:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:07:28 --> The path to the image is not correct.
ERROR - 2018-07-04 05:07:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:07:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:07:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:07:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:07:45 --> The path to the image is not correct.
ERROR - 2018-07-04 05:07:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:07:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:07:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:08:26 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:08:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:08:44 --> The path to the image is not correct.
ERROR - 2018-07-04 05:08:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:08:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:08:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:08:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 129
ERROR - 2018-07-04 05:08:46 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Profile_model.php 142
ERROR - 2018-07-04 05:08:46 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 138
ERROR - 2018-07-04 05:08:46 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 172
ERROR - 2018-07-04 05:08:46 --> The path to the image is not correct.
ERROR - 2018-07-04 05:08:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:08:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:08:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:09:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 129
ERROR - 2018-07-04 05:09:05 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Profile_model.php 142
ERROR - 2018-07-04 05:09:05 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 138
ERROR - 2018-07-04 05:09:05 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 172
ERROR - 2018-07-04 05:09:05 --> The path to the image is not correct.
ERROR - 2018-07-04 05:09:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:09:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:09:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:11:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:11:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:16:47 --> The path to the image is not correct.
ERROR - 2018-07-04 05:16:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:16:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:16:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:17:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:17:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:17:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:17:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:19:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 131
ERROR - 2018-07-04 05:19:51 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Profile_model.php 144
ERROR - 2018-07-04 05:19:52 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 138
ERROR - 2018-07-04 05:19:52 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 172
ERROR - 2018-07-04 05:19:52 --> The path to the image is not correct.
ERROR - 2018-07-04 05:19:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:19:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:19:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 131
ERROR - 2018-07-04 05:20:06 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Profile_model.php 144
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 138
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 172
ERROR - 2018-07-04 05:20:06 --> The path to the image is not correct.
ERROR - 2018-07-04 05:20:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:20:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:20:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 131
ERROR - 2018-07-04 05:20:06 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Profile_model.php 144
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 138
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 172
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 131
ERROR - 2018-07-04 05:20:06 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Profile_model.php 144
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 138
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 172
ERROR - 2018-07-04 05:20:06 --> The path to the image is not correct.
ERROR - 2018-07-04 05:20:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:20:06 --> The path to the image is not correct.
ERROR - 2018-07-04 05:20:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:20:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:20:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 131
ERROR - 2018-07-04 05:20:06 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Profile_model.php 144
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 138
ERROR - 2018-07-04 05:20:06 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 172
ERROR - 2018-07-04 05:20:06 --> The path to the image is not correct.
ERROR - 2018-07-04 05:20:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:20:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 131
ERROR - 2018-07-04 05:20:07 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Profile_model.php 144
ERROR - 2018-07-04 05:20:07 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 138
ERROR - 2018-07-04 05:20:07 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 172
ERROR - 2018-07-04 05:20:07 --> The path to the image is not correct.
ERROR - 2018-07-04 05:20:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:20:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 131
ERROR - 2018-07-04 05:20:37 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Profile_model.php 144
ERROR - 2018-07-04 05:21:11 --> Query error: Unknown column 'up.user_id' in 'where clause' - Invalid query: SELECT `up`.*, `p`.*
FROM `user_plan` `up`
JOIN `plan` `p` ON `p`.`plan_id` = `up`.`plan_id`
WHERE `up`.`user_id` = '5'
ERROR - 2018-07-04 05:23:49 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 172
ERROR - 2018-07-04 05:23:49 --> The path to the image is not correct.
ERROR - 2018-07-04 05:23:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:23:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:23:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:09 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:18 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:21 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:26 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:26 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:55 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:57 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:58 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:58 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:58 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:59 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:59 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:59 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:59 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:59 --> The path to the image is not correct.
ERROR - 2018-07-04 05:24:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:24:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:25:25 --> The path to the image is not correct.
ERROR - 2018-07-04 05:25:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:25:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:25:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:27:14 --> The path to the image is not correct.
ERROR - 2018-07-04 05:27:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:27:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:27:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:28:47 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:29:38 --> 404 Page Not Found: api/Login/username=%22driver%22&password=%22test1234
ERROR - 2018-07-04 05:29:45 --> The path to the image is not correct.
ERROR - 2018-07-04 05:29:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:29:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:29:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:29:58 --> The path to the image is not correct.
ERROR - 2018-07-04 05:29:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:29:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:29:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:30:28 --> The path to the image is not correct.
ERROR - 2018-07-04 05:30:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:30:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:30:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:23 --> The path to the image is not correct.
ERROR - 2018-07-04 05:31:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:31:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:24 --> The path to the image is not correct.
ERROR - 2018-07-04 05:31:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:31:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:24 --> The path to the image is not correct.
ERROR - 2018-07-04 05:31:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:31:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:24 --> The path to the image is not correct.
ERROR - 2018-07-04 05:31:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:31:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:24 --> The path to the image is not correct.
ERROR - 2018-07-04 05:31:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:31:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:25 --> The path to the image is not correct.
ERROR - 2018-07-04 05:31:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:31:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:31:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:32:09 --> The path to the image is not correct.
ERROR - 2018-07-04 05:32:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:32:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:32:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 05:33:17 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:33:45 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:39:47 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:44:44 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:44:54 --> The path to the image is not correct.
ERROR - 2018-07-04 05:44:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:46:24 --> The path to the image is not correct.
ERROR - 2018-07-04 05:46:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:46:28 --> The path to the image is not correct.
ERROR - 2018-07-04 05:46:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:46:34 --> The path to the image is not correct.
ERROR - 2018-07-04 05:46:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:46:40 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:46:44 --> The path to the image is not correct.
ERROR - 2018-07-04 05:46:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:46:44 --> The path to the image is not correct.
ERROR - 2018-07-04 05:46:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:46:44 --> The path to the image is not correct.
ERROR - 2018-07-04 05:46:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 05:47:05 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:47:15 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:14 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:43 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:44 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:44 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:44 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:44 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:44 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:44 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:45 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:45 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:45 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:45 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:45 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:45 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:46 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:46 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:46 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:46 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:46 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:47 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:47 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:47 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:57 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:57 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:58 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:58 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:58 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:58 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:58 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:59 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:59 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:59 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:59 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:49:59 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 05:50:14 --> Severity: Parsing Error --> syntax error, unexpected 'print_r_die' (T_STRING), expecting function (T_FUNCTION) D:\xampp\htdocs\project-transport\application\controllers\api\login.php 8
ERROR - 2018-07-04 05:50:14 --> Severity: Parsing Error --> syntax error, unexpected 'print_r_die' (T_STRING), expecting function (T_FUNCTION) D:\xampp\htdocs\project-transport\application\controllers\api\login.php 8
ERROR - 2018-07-04 05:50:14 --> Severity: Parsing Error --> syntax error, unexpected 'print_r_die' (T_STRING), expecting function (T_FUNCTION) D:\xampp\htdocs\project-transport\application\controllers\api\login.php 8
ERROR - 2018-07-04 05:50:14 --> Severity: Parsing Error --> syntax error, unexpected 'print_r_die' (T_STRING), expecting function (T_FUNCTION) D:\xampp\htdocs\project-transport\application\controllers\api\login.php 8
ERROR - 2018-07-04 05:51:44 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 06:54:17 --> 404 Page Not Found: api/Signin/index
ERROR - 2018-07-04 06:54:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 24
ERROR - 2018-07-04 06:54:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 25
ERROR - 2018-07-04 07:01:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 07:01:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 07:01:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 07:01:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 07:01:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 07:01:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 07:01:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 07:01:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 07:01:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 07:01:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 07:01:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 07:01:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 07:14:24 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 07:14:24 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 07:23:29 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 07:23:29 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 07:23:33 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 07:23:33 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 07:35:14 --> The path to the image is not correct.
ERROR - 2018-07-04 07:35:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:36:33 --> The path to the image is not correct.
ERROR - 2018-07-04 07:36:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:36:38 --> The path to the image is not correct.
ERROR - 2018-07-04 07:36:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:36:58 --> The path to the image is not correct.
ERROR - 2018-07-04 07:36:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:37:00 --> The path to the image is not correct.
ERROR - 2018-07-04 07:37:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:37:00 --> The path to the image is not correct.
ERROR - 2018-07-04 07:37:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:37:15 --> The path to the image is not correct.
ERROR - 2018-07-04 07:37:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:37:15 --> The path to the image is not correct.
ERROR - 2018-07-04 07:37:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:38:36 --> The path to the image is not correct.
ERROR - 2018-07-04 07:38:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:38:38 --> The path to the image is not correct.
ERROR - 2018-07-04 07:38:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:39:10 --> The path to the image is not correct.
ERROR - 2018-07-04 07:39:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:42:55 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 07:42:58 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 07:42:58 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 07:45:26 --> The path to the image is not correct.
ERROR - 2018-07-04 07:45:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 07:45:49 --> The path to the image is not correct.
ERROR - 2018-07-04 07:45:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:00:28 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:00:28 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:00:29 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:00:29 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:00:30 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:00:30 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:01:23 --> The path to the image is not correct.
ERROR - 2018-07-04 08:01:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:02:11 --> The path to the image is not correct.
ERROR - 2018-07-04 08:02:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:08:04 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:04 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:05 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:05 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:05 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:05 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:05 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:06 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:07 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:07 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:07 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:07 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:07 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:07 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:33 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:33 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:33 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:33 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:33 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:33 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:33 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:33 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:08:33 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:08:33 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:09:50 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:09:50 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:10:15 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:10:15 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:12:17 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:12:17 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:13:17 --> The path to the image is not correct.
ERROR - 2018-07-04 08:13:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:13:21 --> The path to the image is not correct.
ERROR - 2018-07-04 08:13:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:19:22 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:19:22 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:19:48 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:19:48 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:20:18 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:20:18 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:20:20 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:20:20 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:20:21 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:20:21 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:20:21 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:20:21 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:20:21 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:20:21 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:20:24 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:20:24 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:21:45 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:21:45 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:21:57 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:21:57 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:22:51 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:22:51 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:22:56 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:22:56 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:23:03 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 08:23:03 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 08:24:06 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:24:06 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685446)
ERROR - 2018-07-04 08:24:07 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:24:07 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685447)
ERROR - 2018-07-04 08:24:07 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:24:07 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685447)
ERROR - 2018-07-04 08:24:07 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:24:07 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685447)
ERROR - 2018-07-04 08:24:48 --> The path to the image is not correct.
ERROR - 2018-07-04 08:24:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:24:50 --> The path to the image is not correct.
ERROR - 2018-07-04 08:24:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:25:08 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:25:08 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685508)
ERROR - 2018-07-04 08:25:09 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:25:09 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685509)
ERROR - 2018-07-04 08:25:09 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:25:09 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685509)
ERROR - 2018-07-04 08:25:13 --> The path to the image is not correct.
ERROR - 2018-07-04 08:25:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:25:16 --> The path to the image is not correct.
ERROR - 2018-07-04 08:25:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:25:16 --> The path to the image is not correct.
ERROR - 2018-07-04 08:25:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:26:38 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:26:38 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685598)
ERROR - 2018-07-04 08:28:17 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:18 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:19 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:20 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:21 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:21 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:21 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:22 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:22 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:23 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:23 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:23 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:24 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:24 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:25 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:25 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:26 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:26 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:27 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:27 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:27 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:32 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:28:32 --> The path to the image is not correct.
ERROR - 2018-07-04 08:28:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:30:10 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:30:10 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685810)
ERROR - 2018-07-04 08:30:19 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:30:19 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685819)
ERROR - 2018-07-04 08:30:22 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:30:22 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685822)
ERROR - 2018-07-04 08:31:26 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:31:26 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685886)
ERROR - 2018-07-04 08:31:34 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:31:34 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685894)
ERROR - 2018-07-04 08:31:39 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:31:39 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685899)
ERROR - 2018-07-04 08:31:43 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:31:43 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685903)
ERROR - 2018-07-04 08:31:46 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:31:46 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685906)
ERROR - 2018-07-04 08:31:51 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:31:51 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685911)
ERROR - 2018-07-04 08:31:56 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:31:56 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685916)
ERROR - 2018-07-04 08:32:01 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:32:01 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685921)
ERROR - 2018-07-04 08:32:17 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:32:17 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530685937)
ERROR - 2018-07-04 08:35:06 --> The path to the image is not correct.
ERROR - 2018-07-04 08:35:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:35:06 --> The path to the image is not correct.
ERROR - 2018-07-04 08:35:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:37:49 --> The path to the image is not correct.
ERROR - 2018-07-04 08:37:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:37:50 --> The path to the image is not correct.
ERROR - 2018-07-04 08:37:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:39:24 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:39:24 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530686364)
ERROR - 2018-07-04 08:39:25 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:39:25 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530686365)
ERROR - 2018-07-04 08:39:25 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:39:25 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530686365)
ERROR - 2018-07-04 08:39:32 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:39:32 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530686372)
ERROR - 2018-07-04 08:43:07 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:43:07 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530686587)
ERROR - 2018-07-04 08:43:37 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:43:37 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530686617)
ERROR - 2018-07-04 08:50:20 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 08:50:20 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530687020)
ERROR - 2018-07-04 08:54:15 --> The path to the image is not correct.
ERROR - 2018-07-04 08:54:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 08:54:26 --> The path to the image is not correct.
ERROR - 2018-07-04 08:54:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:05:48 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:05:48 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530687948)
ERROR - 2018-07-04 09:05:52 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:05:53 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530687953)
ERROR - 2018-07-04 09:08:12 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:08:12 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530688092)
ERROR - 2018-07-04 09:19:35 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:19:35 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530688775)
ERROR - 2018-07-04 09:20:04 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:20:04 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530688804)
ERROR - 2018-07-04 09:20:24 --> The path to the image is not correct.
ERROR - 2018-07-04 09:20:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:20:27 --> The path to the image is not correct.
ERROR - 2018-07-04 09:20:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:24:40 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:24:40 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530689080)
ERROR - 2018-07-04 09:24:44 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:24:44 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530689084)
ERROR - 2018-07-04 09:24:51 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:24:51 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530689091)
ERROR - 2018-07-04 09:25:24 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:25:24 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:25:24 --> 404 Page Not Found: api/Login/index
ERROR - 2018-07-04 09:25:28 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:25:28 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:25:35 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:25:35 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:26:12 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:26:12 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530689172)
ERROR - 2018-07-04 09:26:31 --> The path to the image is not correct.
ERROR - 2018-07-04 09:26:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:27:01 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:27:01 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:28:33 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:28:33 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:28:38 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:28:38 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:29:11 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:29:11 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:29:31 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:29:31 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:30:56 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:30:56 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:31:11 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:31:11 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:31:12 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:31:12 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:31:12 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:31:12 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:31:14 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:31:14 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:31:16 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:31:16 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:31:22 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:31:22 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:31:29 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:31:29 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:31:51 --> The path to the image is not correct.
ERROR - 2018-07-04 09:31:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:31:53 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:31:53 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:32:08 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:32:08 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:32:29 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:32:29 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:32:43 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:32:43 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:32:45 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:32:45 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:34:49 --> The path to the image is not correct.
ERROR - 2018-07-04 09:34:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:34:51 --> The path to the image is not correct.
ERROR - 2018-07-04 09:34:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:34:51 --> The path to the image is not correct.
ERROR - 2018-07-04 09:34:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:34:58 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 108
ERROR - 2018-07-04 09:34:59 --> The path to the image is not correct.
ERROR - 2018-07-04 09:34:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:34:59 --> The path to the image is not correct.
ERROR - 2018-07-04 09:34:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:35:21 --> The path to the image is not correct.
ERROR - 2018-07-04 09:35:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:35:21 --> The path to the image is not correct.
ERROR - 2018-07-04 09:35:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:35:21 --> The path to the image is not correct.
ERROR - 2018-07-04 09:35:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:35:26 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 108
ERROR - 2018-07-04 09:35:27 --> The path to the image is not correct.
ERROR - 2018-07-04 09:35:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:35:27 --> The path to the image is not correct.
ERROR - 2018-07-04 09:35:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:36:29 --> The path to the image is not correct.
ERROR - 2018-07-04 09:36:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:36:29 --> The path to the image is not correct.
ERROR - 2018-07-04 09:36:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:36:29 --> The path to the image is not correct.
ERROR - 2018-07-04 09:36:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:36:34 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 108
ERROR - 2018-07-04 09:36:35 --> The path to the image is not correct.
ERROR - 2018-07-04 09:36:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:36:35 --> The path to the image is not correct.
ERROR - 2018-07-04 09:36:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:40:35 --> The path to the image is not correct.
ERROR - 2018-07-04 09:40:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:40:35 --> The path to the image is not correct.
ERROR - 2018-07-04 09:40:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:40:44 --> The path to the image is not correct.
ERROR - 2018-07-04 09:40:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:40:44 --> The path to the image is not correct.
ERROR - 2018-07-04 09:40:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:40:44 --> The path to the image is not correct.
ERROR - 2018-07-04 09:40:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:40:44 --> The path to the image is not correct.
ERROR - 2018-07-04 09:40:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:40:44 --> The path to the image is not correct.
ERROR - 2018-07-04 09:40:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:40:44 --> The path to the image is not correct.
ERROR - 2018-07-04 09:40:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:40:53 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 108
ERROR - 2018-07-04 09:40:54 --> The path to the image is not correct.
ERROR - 2018-07-04 09:40:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:40:54 --> The path to the image is not correct.
ERROR - 2018-07-04 09:40:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:41:31 --> The path to the image is not correct.
ERROR - 2018-07-04 09:41:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:41:31 --> The path to the image is not correct.
ERROR - 2018-07-04 09:41:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:41:31 --> The path to the image is not correct.
ERROR - 2018-07-04 09:41:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:41:34 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 108
ERROR - 2018-07-04 09:41:35 --> The path to the image is not correct.
ERROR - 2018-07-04 09:41:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:41:35 --> The path to the image is not correct.
ERROR - 2018-07-04 09:41:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:42:25 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:42:25 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530690145)
ERROR - 2018-07-04 09:42:57 --> The path to the image is not correct.
ERROR - 2018-07-04 09:42:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:42:57 --> The path to the image is not correct.
ERROR - 2018-07-04 09:42:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:43:04 --> Severity: Notice --> Undefined variable: description D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 96
ERROR - 2018-07-04 09:43:04 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 108
ERROR - 2018-07-04 09:43:05 --> The path to the image is not correct.
ERROR - 2018-07-04 09:43:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:43:05 --> The path to the image is not correct.
ERROR - 2018-07-04 09:43:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:43:22 --> The path to the image is not correct.
ERROR - 2018-07-04 09:43:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:43:22 --> The path to the image is not correct.
ERROR - 2018-07-04 09:43:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:43:27 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 108
ERROR - 2018-07-04 09:43:27 --> The path to the image is not correct.
ERROR - 2018-07-04 09:43:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:43:27 --> The path to the image is not correct.
ERROR - 2018-07-04 09:43:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:43:59 --> The path to the image is not correct.
ERROR - 2018-07-04 09:43:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:43:59 --> The path to the image is not correct.
ERROR - 2018-07-04 09:43:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:44:29 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 108
ERROR - 2018-07-04 09:44:30 --> The path to the image is not correct.
ERROR - 2018-07-04 09:44:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:44:30 --> The path to the image is not correct.
ERROR - 2018-07-04 09:44:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:45:14 --> The path to the image is not correct.
ERROR - 2018-07-04 09:45:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:45:14 --> The path to the image is not correct.
ERROR - 2018-07-04 09:45:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:45:14 --> The path to the image is not correct.
ERROR - 2018-07-04 09:45:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:45:17 --> Severity: Notice --> Undefined variable: total_price D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 108
ERROR - 2018-07-04 09:45:18 --> The path to the image is not correct.
ERROR - 2018-07-04 09:45:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:45:18 --> The path to the image is not correct.
ERROR - 2018-07-04 09:45:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:45:31 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:45:31 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530690331)
ERROR - 2018-07-04 09:45:50 --> The path to the image is not correct.
ERROR - 2018-07-04 09:45:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:45:50 --> The path to the image is not correct.
ERROR - 2018-07-04 09:45:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:45:50 --> The path to the image is not correct.
ERROR - 2018-07-04 09:45:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:45:53 --> The path to the image is not correct.
ERROR - 2018-07-04 09:45:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:45:53 --> The path to the image is not correct.
ERROR - 2018-07-04 09:45:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:46:47 --> The path to the image is not correct.
ERROR - 2018-07-04 09:46:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:46:47 --> The path to the image is not correct.
ERROR - 2018-07-04 09:46:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:46:47 --> The path to the image is not correct.
ERROR - 2018-07-04 09:46:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:46:54 --> The path to the image is not correct.
ERROR - 2018-07-04 09:46:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:46:54 --> The path to the image is not correct.
ERROR - 2018-07-04 09:46:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:48:51 --> The path to the image is not correct.
ERROR - 2018-07-04 09:48:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:48:51 --> The path to the image is not correct.
ERROR - 2018-07-04 09:48:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:48:51 --> The path to the image is not correct.
ERROR - 2018-07-04 09:48:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:48:54 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 2490
ERROR - 2018-07-04 09:48:54 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 2514
ERROR - 2018-07-04 09:48:55 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 2490
ERROR - 2018-07-04 09:48:55 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 2514
ERROR - 2018-07-04 09:48:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-07-04 09:49:15 --> The path to the image is not correct.
ERROR - 2018-07-04 09:49:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:49:15 --> The path to the image is not correct.
ERROR - 2018-07-04 09:49:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:49:15 --> The path to the image is not correct.
ERROR - 2018-07-04 09:49:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:49:47 --> The path to the image is not correct.
ERROR - 2018-07-04 09:49:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:49:47 --> The path to the image is not correct.
ERROR - 2018-07-04 09:49:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:49:47 --> The path to the image is not correct.
ERROR - 2018-07-04 09:49:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:49:59 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 09:49:59 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530690599)
ERROR - 2018-07-04 09:50:30 --> The path to the image is not correct.
ERROR - 2018-07-04 09:50:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:50:30 --> The path to the image is not correct.
ERROR - 2018-07-04 09:50:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:50:30 --> The path to the image is not correct.
ERROR - 2018-07-04 09:50:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:50:35 --> The path to the image is not correct.
ERROR - 2018-07-04 09:50:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:50:35 --> The path to the image is not correct.
ERROR - 2018-07-04 09:50:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:52:37 --> The path to the image is not correct.
ERROR - 2018-07-04 09:52:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:52:37 --> The path to the image is not correct.
ERROR - 2018-07-04 09:52:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:52:38 --> The path to the image is not correct.
ERROR - 2018-07-04 09:52:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:52:43 --> The path to the image is not correct.
ERROR - 2018-07-04 09:52:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:52:43 --> The path to the image is not correct.
ERROR - 2018-07-04 09:52:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:53:15 --> The path to the image is not correct.
ERROR - 2018-07-04 09:53:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:53:15 --> The path to the image is not correct.
ERROR - 2018-07-04 09:53:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:53:15 --> The path to the image is not correct.
ERROR - 2018-07-04 09:53:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:53:19 --> The path to the image is not correct.
ERROR - 2018-07-04 09:53:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:53:20 --> The path to the image is not correct.
ERROR - 2018-07-04 09:53:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:54:00 --> The path to the image is not correct.
ERROR - 2018-07-04 09:54:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:54:00 --> The path to the image is not correct.
ERROR - 2018-07-04 09:54:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:54:04 --> The path to the image is not correct.
ERROR - 2018-07-04 09:54:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:54:04 --> The path to the image is not correct.
ERROR - 2018-07-04 09:54:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:54:28 --> The path to the image is not correct.
ERROR - 2018-07-04 09:54:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:54:28 --> The path to the image is not correct.
ERROR - 2018-07-04 09:54:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:54:29 --> The path to the image is not correct.
ERROR - 2018-07-04 09:54:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:54:36 --> The path to the image is not correct.
ERROR - 2018-07-04 09:54:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:54:36 --> The path to the image is not correct.
ERROR - 2018-07-04 09:54:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:54:41 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:54:41 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:55:01 --> The path to the image is not correct.
ERROR - 2018-07-04 09:55:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:55:01 --> The path to the image is not correct.
ERROR - 2018-07-04 09:55:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:55:01 --> The path to the image is not correct.
ERROR - 2018-07-04 09:55:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:55:08 --> The path to the image is not correct.
ERROR - 2018-07-04 09:55:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:55:08 --> The path to the image is not correct.
ERROR - 2018-07-04 09:55:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:58:07 --> The path to the image is not correct.
ERROR - 2018-07-04 09:58:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:58:07 --> The path to the image is not correct.
ERROR - 2018-07-04 09:58:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:58:08 --> The path to the image is not correct.
ERROR - 2018-07-04 09:58:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:58:10 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 09:58:10 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 09:59:01 --> The path to the image is not correct.
ERROR - 2018-07-04 09:59:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:59:01 --> The path to the image is not correct.
ERROR - 2018-07-04 09:59:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:59:01 --> The path to the image is not correct.
ERROR - 2018-07-04 09:59:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:59:08 --> The path to the image is not correct.
ERROR - 2018-07-04 09:59:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 09:59:08 --> The path to the image is not correct.
ERROR - 2018-07-04 09:59:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:02:00 --> The path to the image is not correct.
ERROR - 2018-07-04 10:02:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:02:01 --> The path to the image is not correct.
ERROR - 2018-07-04 10:02:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:03:30 --> The path to the image is not correct.
ERROR - 2018-07-04 10:03:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:03:30 --> The path to the image is not correct.
ERROR - 2018-07-04 10:03:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:03:30 --> The path to the image is not correct.
ERROR - 2018-07-04 10:03:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:03:36 --> The path to the image is not correct.
ERROR - 2018-07-04 10:03:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:03:36 --> The path to the image is not correct.
ERROR - 2018-07-04 10:03:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:03:56 --> The path to the image is not correct.
ERROR - 2018-07-04 10:03:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:03:57 --> The path to the image is not correct.
ERROR - 2018-07-04 10:03:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:03:57 --> The path to the image is not correct.
ERROR - 2018-07-04 10:03:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:04:03 --> The path to the image is not correct.
ERROR - 2018-07-04 10:04:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:04:03 --> The path to the image is not correct.
ERROR - 2018-07-04 10:04:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:04:59 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 10:04:59 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530691499)
ERROR - 2018-07-04 10:05:40 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 10:05:40 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 10:09:34 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 10:09:34 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 10:10:42 --> The path to the image is not correct.
ERROR - 2018-07-04 10:10:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:10:44 --> The path to the image is not correct.
ERROR - 2018-07-04 10:10:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:10:52 --> The path to the image is not correct.
ERROR - 2018-07-04 10:10:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:11:09 --> The path to the image is not correct.
ERROR - 2018-07-04 10:11:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:11:16 --> The path to the image is not correct.
ERROR - 2018-07-04 10:11:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:11:35 --> The path to the image is not correct.
ERROR - 2018-07-04 10:11:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:11:50 --> The path to the image is not correct.
ERROR - 2018-07-04 10:11:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:11:50 --> The path to the image is not correct.
ERROR - 2018-07-04 10:11:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:12:16 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ':' D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 118
ERROR - 2018-07-04 10:12:39 --> The path to the image is not correct.
ERROR - 2018-07-04 10:12:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:12:40 --> The path to the image is not correct.
ERROR - 2018-07-04 10:12:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:13:54 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 10:13:54 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 10:15:01 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 10:15:01 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530692101)
ERROR - 2018-07-04 10:18:24 --> The path to the image is not correct.
ERROR - 2018-07-04 10:18:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:18:24 --> The path to the image is not correct.
ERROR - 2018-07-04 10:18:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:18:24 --> The path to the image is not correct.
ERROR - 2018-07-04 10:18:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:18:29 --> The path to the image is not correct.
ERROR - 2018-07-04 10:18:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:18:30 --> The path to the image is not correct.
ERROR - 2018-07-04 10:18:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:19:20 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 10:19:20 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530692360)
ERROR - 2018-07-04 10:20:13 --> The path to the image is not correct.
ERROR - 2018-07-04 10:20:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:20:13 --> The path to the image is not correct.
ERROR - 2018-07-04 10:20:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:20:13 --> The path to the image is not correct.
ERROR - 2018-07-04 10:20:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:20:20 --> The path to the image is not correct.
ERROR - 2018-07-04 10:20:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:20:21 --> The path to the image is not correct.
ERROR - 2018-07-04 10:20:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:22:04 --> The path to the image is not correct.
ERROR - 2018-07-04 10:22:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:22:04 --> The path to the image is not correct.
ERROR - 2018-07-04 10:22:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:22:04 --> The path to the image is not correct.
ERROR - 2018-07-04 10:22:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:22:11 --> The path to the image is not correct.
ERROR - 2018-07-04 10:22:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:22:12 --> The path to the image is not correct.
ERROR - 2018-07-04 10:22:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:22:12 --> The path to the image is not correct.
ERROR - 2018-07-04 10:22:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:22:15 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 10:22:15 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530692535)
ERROR - 2018-07-04 10:23:07 --> The path to the image is not correct.
ERROR - 2018-07-04 10:23:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:23:07 --> The path to the image is not correct.
ERROR - 2018-07-04 10:23:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:23:07 --> The path to the image is not correct.
ERROR - 2018-07-04 10:23:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:23:11 --> The path to the image is not correct.
ERROR - 2018-07-04 10:23:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:23:11 --> The path to the image is not correct.
ERROR - 2018-07-04 10:23:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:24:04 --> The path to the image is not correct.
ERROR - 2018-07-04 10:24:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:24:04 --> The path to the image is not correct.
ERROR - 2018-07-04 10:24:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:24:05 --> The path to the image is not correct.
ERROR - 2018-07-04 10:24:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:24:11 --> The path to the image is not correct.
ERROR - 2018-07-04 10:24:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:24:11 --> The path to the image is not correct.
ERROR - 2018-07-04 10:24:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:24:30 --> The path to the image is not correct.
ERROR - 2018-07-04 10:24:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:24:30 --> The path to the image is not correct.
ERROR - 2018-07-04 10:24:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:24:31 --> The path to the image is not correct.
ERROR - 2018-07-04 10:24:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:24:34 --> The path to the image is not correct.
ERROR - 2018-07-04 10:24:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:24:34 --> The path to the image is not correct.
ERROR - 2018-07-04 10:24:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:25:06 --> The path to the image is not correct.
ERROR - 2018-07-04 10:25:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:25:06 --> The path to the image is not correct.
ERROR - 2018-07-04 10:25:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:25:41 --> The path to the image is not correct.
ERROR - 2018-07-04 10:25:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:25:41 --> The path to the image is not correct.
ERROR - 2018-07-04 10:25:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:34:05 --> The path to the image is not correct.
ERROR - 2018-07-04 10:34:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:34:25 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 10:34:25 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530693265)
ERROR - 2018-07-04 10:36:01 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 10:36:01 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530693361)
ERROR - 2018-07-04 10:37:36 --> The path to the image is not correct.
ERROR - 2018-07-04 10:37:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 10:37:52 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 10:37:52 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530693472)
ERROR - 2018-07-04 10:38:35 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 10:38:35 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530693515)
ERROR - 2018-07-04 10:56:18 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 10:56:18 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530694578)
ERROR - 2018-07-04 10:58:34 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 10:58:34 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 10:59:05 --> Severity: Notice --> Undefined index: HTTP_USER_AGENT D:\xampp\htdocs\project-transport\application\models\Register_model.php 111
ERROR - 2018-07-04 10:59:05 --> Query error: Column 'user_agent' cannot be null - Invalid query: INSERT INTO `login_trail` (`user_id`, `ip_address`, `user_agent`, `login_time`) VALUES ('2', '192.168.1.126', NULL, 1530694745)
ERROR - 2018-07-04 11:03:13 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 11:03:13 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 11:06:11 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-07-04 11:06:11 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-07-04 11:07:26 --> The path to the image is not correct.
ERROR - 2018-07-04 11:07:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:07:26 --> The path to the image is not correct.
ERROR - 2018-07-04 11:07:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:07:32 --> The path to the image is not correct.
ERROR - 2018-07-04 11:07:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:07:32 --> The path to the image is not correct.
ERROR - 2018-07-04 11:07:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:08:26 --> The path to the image is not correct.
ERROR - 2018-07-04 11:08:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:08:26 --> The path to the image is not correct.
ERROR - 2018-07-04 11:08:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:08:26 --> The path to the image is not correct.
ERROR - 2018-07-04 11:08:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:08:31 --> The path to the image is not correct.
ERROR - 2018-07-04 11:08:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:08:31 --> The path to the image is not correct.
ERROR - 2018-07-04 11:08:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:08:45 --> The path to the image is not correct.
ERROR - 2018-07-04 11:08:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:08:45 --> The path to the image is not correct.
ERROR - 2018-07-04 11:08:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:08:46 --> The path to the image is not correct.
ERROR - 2018-07-04 11:08:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:08:52 --> The path to the image is not correct.
ERROR - 2018-07-04 11:08:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:08:52 --> The path to the image is not correct.
ERROR - 2018-07-04 11:08:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:51:02 --> The path to the image is not correct.
ERROR - 2018-07-04 11:51:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:51:02 --> The path to the image is not correct.
ERROR - 2018-07-04 11:51:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:51:03 --> The path to the image is not correct.
ERROR - 2018-07-04 11:51:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:51:15 --> The path to the image is not correct.
ERROR - 2018-07-04 11:51:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:51:15 --> The path to the image is not correct.
ERROR - 2018-07-04 11:51:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:53:54 --> The path to the image is not correct.
ERROR - 2018-07-04 11:53:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:53:54 --> The path to the image is not correct.
ERROR - 2018-07-04 11:53:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:53:54 --> The path to the image is not correct.
ERROR - 2018-07-04 11:53:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:54:00 --> The path to the image is not correct.
ERROR - 2018-07-04 11:54:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:54:00 --> The path to the image is not correct.
ERROR - 2018-07-04 11:54:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:57:30 --> The path to the image is not correct.
ERROR - 2018-07-04 11:57:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:57:30 --> The path to the image is not correct.
ERROR - 2018-07-04 11:57:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:57:43 --> The path to the image is not correct.
ERROR - 2018-07-04 11:57:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:57:43 --> The path to the image is not correct.
ERROR - 2018-07-04 11:57:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:58:41 --> The path to the image is not correct.
ERROR - 2018-07-04 11:58:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:58:42 --> The path to the image is not correct.
ERROR - 2018-07-04 11:58:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:58:42 --> The path to the image is not correct.
ERROR - 2018-07-04 11:58:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:58:48 --> The path to the image is not correct.
ERROR - 2018-07-04 11:58:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:58:48 --> The path to the image is not correct.
ERROR - 2018-07-04 11:58:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:59:03 --> The path to the image is not correct.
ERROR - 2018-07-04 11:59:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 11:59:03 --> The path to the image is not correct.
ERROR - 2018-07-04 11:59:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:00:55 --> The path to the image is not correct.
ERROR - 2018-07-04 12:00:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:00:55 --> The path to the image is not correct.
ERROR - 2018-07-04 12:00:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:00:56 --> The path to the image is not correct.
ERROR - 2018-07-04 12:00:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:01:04 --> The path to the image is not correct.
ERROR - 2018-07-04 12:01:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:01:04 --> The path to the image is not correct.
ERROR - 2018-07-04 12:01:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:01:59 --> The path to the image is not correct.
ERROR - 2018-07-04 12:01:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:01:59 --> The path to the image is not correct.
ERROR - 2018-07-04 12:01:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:01:59 --> The path to the image is not correct.
ERROR - 2018-07-04 12:01:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:02:05 --> The path to the image is not correct.
ERROR - 2018-07-04 12:02:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:02:05 --> The path to the image is not correct.
ERROR - 2018-07-04 12:02:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:03:05 --> The path to the image is not correct.
ERROR - 2018-07-04 12:03:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:03:06 --> The path to the image is not correct.
ERROR - 2018-07-04 12:03:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:03:06 --> The path to the image is not correct.
ERROR - 2018-07-04 12:03:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:03:11 --> The path to the image is not correct.
ERROR - 2018-07-04 12:03:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:03:11 --> The path to the image is not correct.
ERROR - 2018-07-04 12:03:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:04:00 --> The path to the image is not correct.
ERROR - 2018-07-04 12:04:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:04:00 --> The path to the image is not correct.
ERROR - 2018-07-04 12:04:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:04:00 --> The path to the image is not correct.
ERROR - 2018-07-04 12:04:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:04:07 --> The path to the image is not correct.
ERROR - 2018-07-04 12:04:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:04:07 --> The path to the image is not correct.
ERROR - 2018-07-04 12:04:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:04:48 --> The path to the image is not correct.
ERROR - 2018-07-04 12:04:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:04:48 --> The path to the image is not correct.
ERROR - 2018-07-04 12:04:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:04:48 --> The path to the image is not correct.
ERROR - 2018-07-04 12:04:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:07:20 --> The path to the image is not correct.
ERROR - 2018-07-04 12:07:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:07:21 --> The path to the image is not correct.
ERROR - 2018-07-04 12:07:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:07:21 --> The path to the image is not correct.
ERROR - 2018-07-04 12:07:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:07:36 --> The path to the image is not correct.
ERROR - 2018-07-04 12:07:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:07:36 --> The path to the image is not correct.
ERROR - 2018-07-04 12:07:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:07:36 --> The path to the image is not correct.
ERROR - 2018-07-04 12:07:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:07:41 --> The path to the image is not correct.
ERROR - 2018-07-04 12:07:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:07:41 --> The path to the image is not correct.
ERROR - 2018-07-04 12:07:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:09:43 --> The path to the image is not correct.
ERROR - 2018-07-04 12:09:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:09:43 --> The path to the image is not correct.
ERROR - 2018-07-04 12:09:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:09:43 --> The path to the image is not correct.
ERROR - 2018-07-04 12:09:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:09:48 --> The path to the image is not correct.
ERROR - 2018-07-04 12:09:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:09:49 --> The path to the image is not correct.
ERROR - 2018-07-04 12:09:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:10:39 --> The path to the image is not correct.
ERROR - 2018-07-04 12:10:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:10:39 --> The path to the image is not correct.
ERROR - 2018-07-04 12:10:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:10:40 --> The path to the image is not correct.
ERROR - 2018-07-04 12:10:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:10:43 --> The path to the image is not correct.
ERROR - 2018-07-04 12:10:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:10:43 --> The path to the image is not correct.
ERROR - 2018-07-04 12:10:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:14:07 --> The path to the image is not correct.
ERROR - 2018-07-04 12:14:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:14:08 --> The path to the image is not correct.
ERROR - 2018-07-04 12:14:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:19:01 --> The path to the image is not correct.
ERROR - 2018-07-04 12:19:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:19:01 --> The path to the image is not correct.
ERROR - 2018-07-04 12:19:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:19:01 --> The path to the image is not correct.
ERROR - 2018-07-04 12:19:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:19:28 --> The path to the image is not correct.
ERROR - 2018-07-04 12:19:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:19:28 --> The path to the image is not correct.
ERROR - 2018-07-04 12:19:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:19:28 --> The path to the image is not correct.
ERROR - 2018-07-04 12:19:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:19:33 --> The path to the image is not correct.
ERROR - 2018-07-04 12:19:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:19:33 --> The path to the image is not correct.
ERROR - 2018-07-04 12:19:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:32:28 --> The path to the image is not correct.
ERROR - 2018-07-04 12:32:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:36:43 --> The path to the image is not correct.
ERROR - 2018-07-04 12:36:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:39:55 --> The path to the image is not correct.
ERROR - 2018-07-04 12:39:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:40:13 --> The path to the image is not correct.
ERROR - 2018-07-04 12:40:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:41:24 --> The path to the image is not correct.
ERROR - 2018-07-04 12:41:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:41:31 --> The path to the image is not correct.
ERROR - 2018-07-04 12:41:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:41:48 --> The path to the image is not correct.
ERROR - 2018-07-04 12:41:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:42:02 --> Severity: Warning --> date() expects at least 1 parameter, 0 given D:\xampp\htdocs\project-transport\application\views\backend\page\admin\dashboard.php 99
ERROR - 2018-07-04 12:42:02 --> The path to the image is not correct.
ERROR - 2018-07-04 12:42:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:18 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:34 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:36 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:36 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:36 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:37 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:37 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:37 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:37 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:37 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:38 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:38 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:38 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:43:57 --> The path to the image is not correct.
ERROR - 2018-07-04 12:43:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:44:14 --> The path to the image is not correct.
ERROR - 2018-07-04 12:44:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:44:35 --> The path to the image is not correct.
ERROR - 2018-07-04 12:44:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:44:40 --> The path to the image is not correct.
ERROR - 2018-07-04 12:44:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:45:37 --> The path to the image is not correct.
ERROR - 2018-07-04 12:45:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:45:48 --> The path to the image is not correct.
ERROR - 2018-07-04 12:45:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:46:44 --> The path to the image is not correct.
ERROR - 2018-07-04 12:46:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:46:44 --> The path to the image is not correct.
ERROR - 2018-07-04 12:46:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:52:28 --> The path to the image is not correct.
ERROR - 2018-07-04 12:52:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:52:28 --> The path to the image is not correct.
ERROR - 2018-07-04 12:52:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:52:28 --> The path to the image is not correct.
ERROR - 2018-07-04 12:52:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:52:54 --> The path to the image is not correct.
ERROR - 2018-07-04 12:52:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:52:54 --> The path to the image is not correct.
ERROR - 2018-07-04 12:52:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:15 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:15 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:30 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:30 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:33 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-04 12:54:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 12:54:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 12:54:41 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:41 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 12:54:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 12:54:41 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:46 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:46 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 12:54:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 12:54:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:46 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:50 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:50 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 12:54:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 12:54:50 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:51 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:51 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 12:54:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 12:54:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 12:54:52 --> The path to the image is not correct.
ERROR - 2018-07-04 12:54:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:07:05 --> The path to the image is not correct.
ERROR - 2018-07-04 13:07:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:07:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:07:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:07:05 --> The path to the image is not correct.
ERROR - 2018-07-04 13:07:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:07:16 --> Severity: Notice --> Undefined variable: count D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 127
ERROR - 2018-07-04 13:07:16 --> Query error: Unknown column 'up.created' in 'where clause' - Invalid query: SELECT `u`.*, `up`.`user_plan_id`, `up`.`plan_id`, `up`.`billing_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`updated`, `up`.`active`, `up`.`who_updated`, `u2`.`display_name` as `updated_name`, `p`.`title`
FROM `user` `u`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
JOIN `user` `u2` ON `u2`.`user_id` = `up`.`who_updated`
JOIN `plan` `p` ON `p`.`plan_id` = `up`.`plan_id`
WHERE `up`.`active` = 1
AND `up`.`created` >= 1530655200
AND `up`.`created` <=0
AND `u`.`role` = 'SUPER ADMIN'
ORDER BY `u`.`display_name` ASC
 LIMIT 10
ERROR - 2018-07-04 13:09:14 --> Severity: Notice --> Undefined variable: count D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 125
ERROR - 2018-07-04 13:09:14 --> The path to the image is not correct.
ERROR - 2018-07-04 13:09:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:09:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:09:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:10:31 --> Severity: Warning --> Missing argument 1 for Accounts_model::plan_in_week(), called in D:\xampp\htdocs\project-transport\application\controllers\admin\Dashboard.php on line 22 and defined D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 109
ERROR - 2018-07-04 13:10:31 --> Severity: Notice --> Undefined variable: count D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 125
ERROR - 2018-07-04 13:10:31 --> The path to the image is not correct.
ERROR - 2018-07-04 13:10:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:10:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:10:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:10:58 --> The path to the image is not correct.
ERROR - 2018-07-04 13:10:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:10:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:10:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:17:28 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 110
ERROR - 2018-07-04 13:18:25 --> The path to the image is not correct.
ERROR - 2018-07-04 13:18:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:18:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:18:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:22:24 --> Severity: Parsing Error --> syntax error, unexpected '$to' (T_VARIABLE) D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 121
ERROR - 2018-07-04 13:24:28 --> The path to the image is not correct.
ERROR - 2018-07-04 13:24:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:24:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:24:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:24:29 --> The path to the image is not correct.
ERROR - 2018-07-04 13:24:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:24:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:24:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:24:29 --> The path to the image is not correct.
ERROR - 2018-07-04 13:24:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:24:29 --> The path to the image is not correct.
ERROR - 2018-07-04 13:24:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:24:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:24:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:27:07 --> The path to the image is not correct.
ERROR - 2018-07-04 13:27:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:27:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:27:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:32:58 --> Severity: Warning --> strtotime() expects at least 1 parameter, 0 given D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 121
ERROR - 2018-07-04 13:34:47 --> The path to the image is not correct.
ERROR - 2018-07-04 13:34:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:34:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:34:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:34:47 --> The path to the image is not correct.
ERROR - 2018-07-04 13:34:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:34:47 --> The path to the image is not correct.
ERROR - 2018-07-04 13:34:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:35:38 --> The path to the image is not correct.
ERROR - 2018-07-04 13:35:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:35:38 --> The path to the image is not correct.
ERROR - 2018-07-04 13:35:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:35:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:35:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:35:59 --> The path to the image is not correct.
ERROR - 2018-07-04 13:35:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:35:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:35:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:35:59 --> The path to the image is not correct.
ERROR - 2018-07-04 13:36:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:36:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:36:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:36:00 --> The path to the image is not correct.
ERROR - 2018-07-04 13:36:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:36:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:36:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:18 --> The path to the image is not correct.
ERROR - 2018-07-04 13:47:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:47:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:22 --> The path to the image is not correct.
ERROR - 2018-07-04 13:47:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:47:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:28 --> The path to the image is not correct.
ERROR - 2018-07-04 13:47:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:47:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:31 --> The path to the image is not correct.
ERROR - 2018-07-04 13:47:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:47:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:41 --> The path to the image is not correct.
ERROR - 2018-07-04 13:47:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:47:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:47:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:48:20 --> The path to the image is not correct.
ERROR - 2018-07-04 13:48:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:48:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:48:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:48:23 --> The path to the image is not correct.
ERROR - 2018-07-04 13:48:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:48:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:48:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:48:54 --> The path to the image is not correct.
ERROR - 2018-07-04 13:48:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:48:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:48:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:48:56 --> The path to the image is not correct.
ERROR - 2018-07-04 13:48:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:48:56 --> The path to the image is not correct.
ERROR - 2018-07-04 13:48:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:48:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:48:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:49:48 --> The path to the image is not correct.
ERROR - 2018-07-04 13:49:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-04 13:49:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-04 13:49:48 --> 404 Page Not Found: Public/lib

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-21 02:59:40 --> 404 Page Not Found: app//index
ERROR - 2018-05-21 02:59:44 --> 404 Page Not Found: app/Login/index
ERROR - 2018-05-21 02:59:54 --> The path to the image is not correct.
ERROR - 2018-05-21 02:59:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 03:06:02 --> The path to the image is not correct.
ERROR - 2018-05-21 03:06:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 03:06:02 --> The path to the image is not correct.
ERROR - 2018-05-21 03:06:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:14:10 --> The path to the image is not correct.
ERROR - 2018-05-21 04:14:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:14:20 --> The path to the image is not correct.
ERROR - 2018-05-21 04:14:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:14:20 --> The path to the image is not correct.
ERROR - 2018-05-21 04:14:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:14:23 --> The path to the image is not correct.
ERROR - 2018-05-21 04:14:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:14:29 --> The path to the image is not correct.
ERROR - 2018-05-21 04:14:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:14:57 --> The path to the image is not correct.
ERROR - 2018-05-21 04:14:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:14:59 --> The path to the image is not correct.
ERROR - 2018-05-21 04:14:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:15:04 --> The path to the image is not correct.
ERROR - 2018-05-21 04:15:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:16:24 --> The path to the image is not correct.
ERROR - 2018-05-21 04:16:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:16:58 --> The path to the image is not correct.
ERROR - 2018-05-21 04:16:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:17:29 --> The path to the image is not correct.
ERROR - 2018-05-21 04:17:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:18:53 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:53 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:53 --> Query error: Unknown column 'r.report_id' in 'field list' - Invalid query: SELECT `r`.`report_id`
FROM `report`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
WHERE `u`.`store_id` IS NULL
ERROR - 2018-05-21 04:18:54 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:54 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 82
ERROR - 2018-05-21 04:18:54 --> Query error: Unknown column 'r.report_id' in 'field list' - Invalid query: SELECT `r`.`report_id`
FROM `report`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
WHERE `u`.`store_id` IS NULL
ERROR - 2018-05-21 04:18:58 --> The path to the image is not correct.
ERROR - 2018-05-21 04:18:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:19:17 --> The path to the image is not correct.
ERROR - 2018-05-21 04:19:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:19:39 --> The path to the image is not correct.
ERROR - 2018-05-21 04:19:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:20:44 --> The path to the image is not correct.
ERROR - 2018-05-21 04:20:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:21:18 --> The path to the image is not correct.
ERROR - 2018-05-21 04:21:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:21:23 --> The path to the image is not correct.
ERROR - 2018-05-21 04:21:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:28:31 --> The path to the image is not correct.
ERROR - 2018-05-21 04:28:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:28:38 --> The path to the image is not correct.
ERROR - 2018-05-21 04:28:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:28:38 --> The path to the image is not correct.
ERROR - 2018-05-21 04:28:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:28:46 --> The path to the image is not correct.
ERROR - 2018-05-21 04:28:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:28:51 --> The path to the image is not correct.
ERROR - 2018-05-21 04:28:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:02 --> The path to the image is not correct.
ERROR - 2018-05-21 04:29:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:02 --> The path to the image is not correct.
ERROR - 2018-05-21 04:29:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:06 --> The path to the image is not correct.
ERROR - 2018-05-21 04:29:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:08 --> The path to the image is not correct.
ERROR - 2018-05-21 04:29:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:18 --> The path to the image is not correct.
ERROR - 2018-05-21 04:29:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:18 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-05-21 04:29:18 --> The provided image is not valid.
ERROR - 2018-05-21 04:29:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:24 --> The path to the image is not correct.
ERROR - 2018-05-21 04:29:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:24 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-05-21 04:29:24 --> The provided image is not valid.
ERROR - 2018-05-21 04:29:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:29 --> The path to the image is not correct.
ERROR - 2018-05-21 04:29:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:32 --> The path to the image is not correct.
ERROR - 2018-05-21 04:29:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 04:29:44 --> The path to the image is not correct.
ERROR - 2018-05-21 04:29:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 05:01:04 --> The path to the image is not correct.
ERROR - 2018-05-21 05:01:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 05:01:06 --> The path to the image is not correct.
ERROR - 2018-05-21 05:01:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 05:01:14 --> The path to the image is not correct.
ERROR - 2018-05-21 05:01:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 05:02:10 --> The path to the image is not correct.
ERROR - 2018-05-21 05:02:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 05:03:03 --> The path to the image is not correct.
ERROR - 2018-05-21 05:03:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 05:03:20 --> The path to the image is not correct.
ERROR - 2018-05-21 05:03:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 12:01:08 --> The path to the image is not correct.
ERROR - 2018-05-21 12:01:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 12:01:12 --> The path to the image is not correct.
ERROR - 2018-05-21 12:01:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 12:01:12 --> The path to the image is not correct.
ERROR - 2018-05-21 12:01:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 12:01:16 --> The path to the image is not correct.
ERROR - 2018-05-21 12:01:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 12:01:18 --> The path to the image is not correct.
ERROR - 2018-05-21 12:01:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 12:04:48 --> The path to the image is not correct.
ERROR - 2018-05-21 12:04:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-21 12:04:56 --> The path to the image is not correct.
ERROR - 2018-05-21 12:04:56 --> Your server does not support the GD function required to process this type of image.

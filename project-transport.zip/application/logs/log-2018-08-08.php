<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-08 07:00:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 29
ERROR - 2018-08-08 07:00:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\login.php 30
ERROR - 2018-08-08 10:07:16 --> The path to the image is not correct.
ERROR - 2018-08-08 10:07:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-08 10:07:20 --> The path to the image is not correct.
ERROR - 2018-08-08 10:07:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-08 10:07:22 --> The path to the image is not correct.
ERROR - 2018-08-08 10:07:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-08 10:07:51 --> The path to the image is not correct.
ERROR - 2018-08-08 10:07:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-08 10:07:55 --> The path to the image is not correct.
ERROR - 2018-08-08 10:07:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-08 10:08:00 --> The path to the image is not correct.
ERROR - 2018-08-08 10:08:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-08 10:08:11 --> The path to the image is not correct.
ERROR - 2018-08-08 10:08:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-08 10:08:21 --> The path to the image is not correct.
ERROR - 2018-08-08 10:08:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-08 10:08:22 --> The path to the image is not correct.
ERROR - 2018-08-08 10:08:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-08 10:08:38 --> The path to the image is not correct.
ERROR - 2018-08-08 10:08:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-08 10:08:42 --> The path to the image is not correct.
ERROR - 2018-08-08 10:08:42 --> Your server does not support the GD function required to process this type of image.

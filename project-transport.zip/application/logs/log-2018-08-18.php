<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-18 04:11:05 --> The path to the image is not correct.
ERROR - 2018-08-18 04:11:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 04:11:10 --> The path to the image is not correct.
ERROR - 2018-08-18 04:11:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 04:11:10 --> The path to the image is not correct.
ERROR - 2018-08-18 04:11:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 04:11:13 --> The path to the image is not correct.
ERROR - 2018-08-18 04:11:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 04:11:13 --> The path to the image is not correct.
ERROR - 2018-08-18 04:11:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 04:11:20 --> The path to the image is not correct.
ERROR - 2018-08-18 04:11:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 04:12:24 --> The path to the image is not correct.
ERROR - 2018-08-18 04:12:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 04:12:29 --> The path to the image is not correct.
ERROR - 2018-08-18 04:12:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 04:12:29 --> The path to the image is not correct.
ERROR - 2018-08-18 04:12:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 04:23:35 --> The path to the image is not correct.
ERROR - 2018-08-18 04:23:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 05:08:55 --> The path to the image is not correct.
ERROR - 2018-08-18 05:08:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-18 05:09:00 --> The path to the image is not correct.
ERROR - 2018-08-18 05:09:00 --> Your server does not support the GD function required to process this type of image.

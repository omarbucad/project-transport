<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-29 03:06:53 --> The path to the image is not correct.
ERROR - 2018-05-29 03:06:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-29 03:30:06 --> The path to the image is not correct.
ERROR - 2018-05-29 03:30:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-29 03:30:06 --> The path to the image is not correct.
ERROR - 2018-05-29 03:30:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-29 04:41:47 --> 404 Page Not Found: app/Users/view_user_info
ERROR - 2018-05-29 04:41:51 --> The path to the image is not correct.
ERROR - 2018-05-29 04:41:51 --> Your server does not support the GD function required to process this type of image.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-18 04:28:56 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:26 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:27 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:27 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:27 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:28 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:28 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:28 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:28 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:28 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:28 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:29 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:39 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:41:39 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:50:33 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:50:34 --> 404 Page Not Found: app/Reports/index
ERROR - 2018-04-18 04:50:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\models\Report_model.php 31
ERROR - 2018-04-18 04:50:57 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\models\Report_model.php 31
ERROR - 2018-04-18 04:50:57 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 129
ERROR - 2018-04-18 04:50:57 --> Severity: Notice --> Undefined property: stdClass::$first_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 131
ERROR - 2018-04-18 04:50:57 --> Severity: Notice --> Undefined property: stdClass::$last_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 131
ERROR - 2018-04-18 04:50:57 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 134
ERROR - 2018-04-18 04:50:57 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 129
ERROR - 2018-04-18 04:50:57 --> Severity: Notice --> Undefined property: stdClass::$first_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 131
ERROR - 2018-04-18 04:50:57 --> Severity: Notice --> Undefined property: stdClass::$last_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 131
ERROR - 2018-04-18 04:50:57 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 134
ERROR - 2018-04-18 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\models\Report_model.php 31
ERROR - 2018-04-18 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\models\Report_model.php 31
ERROR - 2018-04-18 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 129
ERROR - 2018-04-18 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$first_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 131
ERROR - 2018-04-18 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$last_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 131
ERROR - 2018-04-18 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 134
ERROR - 2018-04-18 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 129
ERROR - 2018-04-18 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$first_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 131
ERROR - 2018-04-18 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$last_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 131
ERROR - 2018-04-18 04:53:52 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 134
ERROR - 2018-04-18 04:54:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\models\Report_model.php 31
ERROR - 2018-04-18 04:54:11 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\models\Report_model.php 31
ERROR - 2018-04-18 04:54:11 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 129
ERROR - 2018-04-18 04:54:11 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 134
ERROR - 2018-04-18 04:54:11 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 129
ERROR - 2018-04-18 04:54:11 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 134
ERROR - 2018-04-18 05:50:53 --> Query error: Unknown column 'r.id' in 'field list' - Invalid query: SELECT `r`.`id`, `a`.`name`, `a`.`surname`, `r`.`trailer_number`, `vehicle_registration_number`, `start_mileage`, `end_mileage`, `r`.`created`, `rs`.`status`, `rs`.`comment`, `u`.`display_name`
FROM `report` `r`
LEFT JOIN `report_status` `rs` ON `rs`.`report_status_id` = `r`.`status_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-18 05:51:12 --> Query error: Unknown column 'a.name' in 'field list' - Invalid query: SELECT `r`.`report_id`, `a`.`name`, `a`.`surname`, `r`.`trailer_number`, `vehicle_registration_number`, `start_mileage`, `end_mileage`, `r`.`created`, `rs`.`status`, `u`.`display_name`
FROM `report` `r`
LEFT JOIN `report_status` `rs` ON `rs`.`report_status_id` = `r`.`status_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-18 05:51:50 --> Query error: Unknown column 'a.name' in 'field list' - Invalid query: SELECT `r`.`report_id`, `a`.`name`, `a`.`surname`, `r`.`trailer_number`, `vehicle_registration_number`, `start_mileage`, `end_mileage`, `r`.`created`, `rs`.`status`, `u`.`display_name`
FROM `report` `r`
LEFT JOIN `report_status` `rs` ON `rs`.`report_status_id` = `r`.`status_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-18 05:52:30 --> Query error: Unknown column 'rs.report_status_id' in 'on clause' - Invalid query: SELECT `r`.`report_id`, `r`.`trailer_number`, `vehicle_registration_number`, `r`.`start_mileage`, `r`.`end_mileage`, `r`.`created`, `rs`.`status`, `u`.`display_name`
FROM `report` `r`
LEFT JOIN `report_status` `rs` ON `rs`.`report_status_id` = `r`.`status_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
ORDER BY `r`.`created` DESC
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 130
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$report_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 130
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 135
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$report_notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 136
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$status_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 137
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 142
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 130
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$report_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 130
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 135
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$report_notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 136
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$status_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 137
ERROR - 2018-04-18 05:53:04 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 142
ERROR - 2018-04-18 06:02:07 --> Severity: Notice --> Undefined property: stdClass::$report_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 130
ERROR - 2018-04-18 06:02:07 --> Severity: Notice --> Undefined property: stdClass::$report_notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 136
ERROR - 2018-04-18 06:02:07 --> Severity: Notice --> Undefined property: stdClass::$status_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 137
ERROR - 2018-04-18 06:02:07 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 142
ERROR - 2018-04-18 06:02:07 --> Severity: Notice --> Undefined property: stdClass::$report_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 130
ERROR - 2018-04-18 06:02:07 --> Severity: Notice --> Undefined property: stdClass::$report_notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 136
ERROR - 2018-04-18 06:02:07 --> Severity: Notice --> Undefined property: stdClass::$status_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 137
ERROR - 2018-04-18 06:02:07 --> Severity: Notice --> Undefined property: stdClass::$checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 142
ERROR - 2018-04-18 07:25:26 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\models\Report_model.php 38
ERROR - 2018-04-18 07:27:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\models\Report_model.php 37
ERROR - 2018-04-18 07:27:15 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\models\Report_model.php 37
ERROR - 2018-04-18 07:37:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:37:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:37:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:50:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:50:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:50:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:51:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:51:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:51:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:51:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:51:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:51:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:52:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:53:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:53:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:53:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:54:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:54:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:54:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:54:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:54:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:54:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:55:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:55:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:55:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:55:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:55:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:55:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:58:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:58:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:58:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:59:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:59:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 07:59:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:00:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:00:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:00:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:00:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:00:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:00:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:00:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:00:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:00:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:01:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:01:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:01:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:01:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:01:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:01:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:02:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:02:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:02:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:02:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:02:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:02:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:02:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:02:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:02:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:03:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:03:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:03:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:03:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:03:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:03:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:04:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:04:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:04:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:04:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:04:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:04:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:05:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:05:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:05:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:06:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:06:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:06:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:06:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:06:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:06:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:07:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:07:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:07:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:13:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:13:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:13:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:13:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:13:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:13:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:14:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:14:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:14:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:14:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:14:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:14:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:14:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:14:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:14:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:15:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:15:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:15:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:15:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:15:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:15:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:16:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:16:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:16:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:16:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:16:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:16:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:16:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:16:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:16:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:21:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:22:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:28:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:28:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:28:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:29:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:29:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:29:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:29:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:29:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:29:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:30:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:30:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:30:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:31:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:31:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:31:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:31:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:31:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:31:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:32:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:32:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:32:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:32:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:32:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:32:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:33:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:33:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:33:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:34:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:34:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:34:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:35:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:35:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:35:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:36:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:36:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:36:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:38:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:38:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:38:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:42:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:42:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:42:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:45:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:45:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:45:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:46:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:46:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:46:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:46:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:46:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:46:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:46:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:46:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:46:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:47:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:49:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:49:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:49:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:50:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:50:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:50:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:50:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:50:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:50:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:55:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:55:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:55:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:55:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:58:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:58:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:58:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:58:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:58:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 08:58:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:10:17 --> 404 Page Not Found: app/Invoice/index
ERROR - 2018-04-18 09:11:00 --> Query error: Unknown column 'r.status' in 'where clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `c`.`checklist_name`, `u`.`display_name`
FROM `report` `r`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
WHERE `r`.`status` IS NULL
ORDER BY `r`.`created` DESC
ERROR - 2018-04-18 09:39:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:39:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:39:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:39:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:39:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:39:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:41:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:41:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:41:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:41:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:41:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:41:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:47:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:47:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:47:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:47:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:47:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:47:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:34 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 199
ERROR - 2018-04-18 09:49:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:52 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:54 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:54 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:54 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:54 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:54 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:56 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:56 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:56 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:57 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:57 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:57 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:57 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:58 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:58 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:58 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:59 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:59 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:59 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:59 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:49:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:00 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:00 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:00 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:00 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:01 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:50:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:01 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:50:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:01 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 198
ERROR - 2018-04-18 09:50:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:50:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:51:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:51:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:51:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:55:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:55:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:55:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:57:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:57:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:57:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:59:38 --> Severity: Notice --> Undefined property: stdClass::$trailer_number D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 65
ERROR - 2018-04-18 09:59:38 --> Severity: Notice --> Undefined property: stdClass::$note D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 69
ERROR - 2018-04-18 09:59:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:59:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 09:59:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:01:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:01:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:01:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:01:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:01:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:01:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:02:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:02:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:02:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:03:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:03:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:03:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:07:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:07:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:07:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:07:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:07:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:07:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:07:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:07:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:07:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:09:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:09:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:09:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:10:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:10:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:10:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:10:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:10:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:10:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:10:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:12:36 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 215
ERROR - 2018-04-18 10:14:48 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 223
ERROR - 2018-04-18 10:41:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:41:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:41:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:51:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:51:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:51:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:56:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:56:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 10:56:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:01:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:01:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:01:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:03:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:03:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:09:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:09:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:09:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:09:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:12:23 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:12:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:12:23 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:12:54 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:31 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:32 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:32 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:34 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:34 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:34 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:34 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:34 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:35 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:35 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:49 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:50 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:50 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:50 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:50 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:50 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:51 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:51 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:51 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:51 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:51 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:52 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:52 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:52 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:13:52 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:14:29 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:14:40 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:14:55 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\models\Report_model.php 94
ERROR - 2018-04-18 11:15:15 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\models\Report_model.php 95
ERROR - 2018-04-18 11:15:16 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\models\Report_model.php 95
ERROR - 2018-04-18 11:15:16 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\models\Report_model.php 95
ERROR - 2018-04-18 11:15:16 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\models\Report_model.php 95
ERROR - 2018-04-18 11:15:17 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\models\Report_model.php 95
ERROR - 2018-04-18 11:15:17 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\models\Report_model.php 95
ERROR - 2018-04-18 11:16:12 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\project-transport\application\models\Report_model.php 95
ERROR - 2018-04-18 11:16:29 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 95
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 155
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 157
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 158
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 165
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 167
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 175
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 176
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 177
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 180
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 183
ERROR - 2018-04-18 11:30:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view.php 186
ERROR - 2018-04-18 11:30:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:30:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:31:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:31:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:32:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:32:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:32:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:07 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 92
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-18 11:33:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:33:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 106
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 106
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Undefined property: stdClass::$report_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:24 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 92
ERROR - 2018-04-18 11:33:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-18 11:33:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 106
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 106
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Undefined property: stdClass::$report_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 16
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 17
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 18
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 32
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 38
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 50
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 11:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 11:34:24 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 216
ERROR - 2018-04-18 11:34:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:37 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 217
ERROR - 2018-04-18 11:34:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:38 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 217
ERROR - 2018-04-18 11:34:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:38 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 217
ERROR - 2018-04-18 11:34:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:39 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 217
ERROR - 2018-04-18 11:34:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:39 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 217
ERROR - 2018-04-18 11:34:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:53 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 216
ERROR - 2018-04-18 11:34:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:34:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 23
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 23
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 29
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 29
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 35
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 35
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 11:35:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 166
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 166
ERROR - 2018-04-18 11:35:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:35:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:35:53 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 92
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 106
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 106
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined property: stdClass::$report_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 23
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 23
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 29
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 29
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 35
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 35
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 166
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 166
ERROR - 2018-04-18 11:35:53 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 23
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 23
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 29
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 29
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 35
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 35
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 166
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 166
ERROR - 2018-04-18 11:35:54 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 92
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-18 11:35:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:35:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 106
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 106
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined property: stdClass::$report_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 23
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 23
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 29
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 29
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 35
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 35
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:35:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 166
ERROR - 2018-04-18 11:35:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 166
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 27
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 27
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 33
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 33
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 39
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 39
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 164
ERROR - 2018-04-18 11:37:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 164
ERROR - 2018-04-18 11:37:48 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 92
ERROR - 2018-04-18 11:37:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:37:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 105
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 106
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 106
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined property: stdClass::$report_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 9
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 22
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 27
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 27
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 33
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 33
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 39
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 39
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 164
ERROR - 2018-04-18 11:37:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 164
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 27
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 27
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 33
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 33
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 39
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 39
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:38:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:38:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:38:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:40:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 27
ERROR - 2018-04-18 11:40:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 27
ERROR - 2018-04-18 11:40:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 33
ERROR - 2018-04-18 11:40:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 33
ERROR - 2018-04-18 11:40:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 39
ERROR - 2018-04-18 11:40:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 39
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:40:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:40:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:40:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 27
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 27
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 33
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 33
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 39
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 39
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:41:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:41:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 11:41:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:41:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 48
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 48
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 51
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 51
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 93
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 93
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 107
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 107
ERROR - 2018-04-18 11:42:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 114
ERROR - 2018-04-18 11:42:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 114
ERROR - 2018-04-18 11:42:49 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 11:42:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 11:42:49 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 11:42:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 11:42:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:42:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 41
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 48
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 48
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 51
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 51
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 93
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 93
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 107
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 107
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 114
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 114
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 11:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 11:43:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:43:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 37
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 37
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 44
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 60
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 60
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:46:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:48:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:48:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:48:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:48:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:48:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:48:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:48:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:48:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:48:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:48:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:48:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:48:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:48:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:48:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:48:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:48:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 52
ERROR - 2018-04-18 11:48:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 52
ERROR - 2018-04-18 11:48:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 55
ERROR - 2018-04-18 11:48:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 55
ERROR - 2018-04-18 11:48:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:48:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 104
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 104
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 11:48:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 11:48:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:48:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 52
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 52
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 55
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 55
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 104
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 104
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 11:49:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 11:49:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:49:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 45
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 52
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 52
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 55
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 55
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 104
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 104
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 11:50:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 11:50:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:50:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 48
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 48
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 55
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 55
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 93
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 93
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 107
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 107
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 114
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 114
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 135
ERROR - 2018-04-18 11:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 135
ERROR - 2018-04-18 11:51:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:51:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 53
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 53
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 60
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 60
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:52:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:52:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:52:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 53
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 53
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 60
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 60
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:52:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:52:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:52:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 53
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 53
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 60
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 60
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 53
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 53
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 60
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 60
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:52:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 11:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:52:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 52
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 52
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 59
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 59
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 69
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 69
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 104
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 104
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 11:53:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 11:53:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 11:53:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 11:53:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 11:53:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 11:53:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 11:53:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 11:53:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:53:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:53:26 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 52
ERROR - 2018-04-18 11:53:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 52
ERROR - 2018-04-18 11:53:26 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 59
ERROR - 2018-04-18 11:53:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 59
ERROR - 2018-04-18 11:53:26 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:53:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:53:26 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 69
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 69
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 104
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 104
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 11:53:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 11:53:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:53:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:55:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:55:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:55:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 47
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 54
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 57
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 64
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 99
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:55:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 11:55:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:55:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:56:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 55
ERROR - 2018-04-18 11:56:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 55
ERROR - 2018-04-18 11:56:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:56:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 62
ERROR - 2018-04-18 11:56:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:56:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:56:14 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 107
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 107
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 114
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 114
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 135
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 135
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 142
ERROR - 2018-04-18 11:56:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 142
ERROR - 2018-04-18 11:56:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:56:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 56
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 66
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 66
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 101
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 101
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 108
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 108
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 11:56:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 11:56:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:56:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:05 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:23 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:57:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:57:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:58:19 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:58:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 88
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:58:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 11:58:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 11:58:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 58
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 65
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 75
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 103
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 110
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 12:01:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 12:01:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:01:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:01:33 --> 404 Page Not Found: app/Setup/settings
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 61
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 61
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 141
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 141
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-04-18 12:05:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-04-18 12:05:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:05:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:06:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 61
ERROR - 2018-04-18 12:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 61
ERROR - 2018-04-18 12:06:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 12:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 68
ERROR - 2018-04-18 12:06:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 12:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 12:06:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 12:06:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 12:06:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 106
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 113
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 120
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 127
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 134
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 141
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 141
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-04-18 12:06:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-04-18 12:06:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:06:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:07:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 12:07:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 63
ERROR - 2018-04-18 12:07:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 12:07:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 12:07:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 12:07:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 12:07:08 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 12:07:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 108
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 108
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 12:07:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 12:07:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:07:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 66
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 66
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 83
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 83
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 12:15:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 12:15:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:15:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 69
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 69
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 76
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 86
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 92
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 114
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 114
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 135
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 135
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 142
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 142
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 149
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 149
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-04-18 12:15:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-04-18 12:15:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:15:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 93
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 93
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 12:33:28 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 12:33:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 12:33:29 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 12:33:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 12:33:29 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 12:33:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 12:33:29 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 12:33:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 12:33:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 12:33:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 13:22:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 13:22:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:22:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 13:22:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 13:22:31 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 13:22:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 13:22:31 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 13:22:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 13:22:31 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 13:22:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 13:22:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:22:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:22:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:22:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:22:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 13:23:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 13:23:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 13:23:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 13:23:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 13:23:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 13:23:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 13:23:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 13:23:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:23:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 13:23:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 13:23:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:23:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 83
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 83
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 13:24:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 13:24:31 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 160
ERROR - 2018-04-18 13:24:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 160
ERROR - 2018-04-18 13:24:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:24:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 83
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 83
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 160
ERROR - 2018-04-18 13:25:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 160
ERROR - 2018-04-18 13:25:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:25:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:25:49 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:25:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:25:49 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:25:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:25:49 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:25:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:25:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 70
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 93
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 93
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 13:26:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 13:26:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 13:26:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:26:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:28:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:28:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:28:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 83
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 83
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 160
ERROR - 2018-04-18 13:28:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 160
ERROR - 2018-04-18 13:28:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:28:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 73
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 80
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 83
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 83
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 90
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 125
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 139
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 160
ERROR - 2018-04-18 13:29:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 160
ERROR - 2018-04-18 13:29:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:29:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:30:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:30:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:30:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:30:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:30:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:31:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:31:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:31:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:32:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:32:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:32:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 72
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 79
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 82
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 89
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 117
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 131
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 138
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:33:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 159
ERROR - 2018-04-18 13:33:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:33:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 13:33:46 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:33:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:33:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:33:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 101
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 101
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 108
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 108
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 118
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 124
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 146
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 160
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 160
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 174
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 174
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 181
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 181
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 188
ERROR - 2018-04-18 13:34:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 188
ERROR - 2018-04-18 13:34:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:34:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 95
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 98
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 105
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 111
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 168
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 13:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-04-18 13:34:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:34:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:36:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:36:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:36:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:37:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:37:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:37:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:37:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:37:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:37:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 13:38:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 13:38:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 164
ERROR - 2018-04-18 14:00:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 164
ERROR - 2018-04-18 14:00:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:00:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 14:02:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 14:02:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:02:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 14:02:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 14:02:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:02:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 71
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 78
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 88
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 14:03:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-18 14:03:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 14:03:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-18 14:03:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 14:03:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-18 14:03:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 14:03:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-18 14:03:21 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 14:03:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-04-18 14:03:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:03:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 14:03:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 14:03:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:03:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 74
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 81
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 91
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 97
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 14:04:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 161
ERROR - 2018-04-18 14:04:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:04:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 14:05:54 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 164
ERROR - 2018-04-18 14:05:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 164
ERROR - 2018-04-18 14:05:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:05:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 77
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 84
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 87
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 94
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 100
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 157
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 164
ERROR - 2018-04-18 14:06:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 164
ERROR - 2018-04-18 14:06:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:06:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:06:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 14:06:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 14:06:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 14:06:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 14:06:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 135
ERROR - 2018-04-18 14:06:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 135
ERROR - 2018-04-18 14:06:57 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 142
ERROR - 2018-04-18 14:06:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 142
ERROR - 2018-04-18 14:06:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 149
ERROR - 2018-04-18 14:06:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 149
ERROR - 2018-04-18 14:06:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-04-18 14:06:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-04-18 14:06:58 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-04-18 14:06:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-04-18 14:06:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:06:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 121
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 135
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 135
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 142
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 142
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 149
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 149
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-04-18 14:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-04-18 14:07:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:07:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 108
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 108
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 14:10:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-18 14:10:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-18 14:10:13 --> 404 Page Not Found: Public/lib

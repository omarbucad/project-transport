<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: website_title D:\xampp\htdocs\project-transport\application\views\frontend\login.php 5
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 15
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 16
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 17
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 18
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 19
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 20
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 23
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 24
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: application_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 53
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: application_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 66
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: csrf_token_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 86
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: csrf_hash D:\xampp\htdocs\project-transport\application\views\frontend\login.php 86
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: application_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 110
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 117
ERROR - 2018-04-06 03:10:57 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 118
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: website_title D:\xampp\htdocs\project-transport\application\views\frontend\login.php 5
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 15
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 16
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 17
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 18
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 19
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 20
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 23
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 24
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: application_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 53
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: application_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 66
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: csrf_token_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 86
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: csrf_hash D:\xampp\htdocs\project-transport\application\views\frontend\login.php 86
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: application_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 110
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 117
ERROR - 2018-04-06 03:13:48 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 118
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: website_title D:\xampp\htdocs\project-transport\application\views\frontend\login.php 5
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 15
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 16
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 17
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 18
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 19
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 20
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 23
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 24
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: application_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 53
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: application_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 66
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: csrf_token_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 86
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: csrf_hash D:\xampp\htdocs\project-transport\application\views\frontend\login.php 86
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: application_name D:\xampp\htdocs\project-transport\application\views\frontend\login.php 110
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 117
ERROR - 2018-04-06 03:14:44 --> Severity: Notice --> Undefined variable: version D:\xampp\htdocs\project-transport\application\views\frontend\login.php 118
ERROR - 2018-04-06 03:21:43 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-06 03:22:00 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-06 03:22:13 --> 404 Page Not Found: app/Setup/general
ERROR - 2018-04-06 03:31:06 --> 404 Page Not Found: Welcomelogin/index
ERROR - 2018-04-06 05:10:38 --> 404 Page Not Found: app/Welcome/index
ERROR - 2018-04-06 05:18:16 --> 404 Page Not Found: app/Welcome/index

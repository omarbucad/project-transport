<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-07 08:29:25 --> The path to the image is not correct.
ERROR - 2018-06-07 08:29:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-07 08:36:59 --> The path to the image is not correct.
ERROR - 2018-06-07 08:36:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-07 08:37:00 --> The path to the image is not correct.
ERROR - 2018-06-07 08:37:00 --> Your server does not support the GD function required to process this type of image.

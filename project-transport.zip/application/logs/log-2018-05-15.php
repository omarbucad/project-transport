<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-15 03:02:44 --> The path to the image is not correct.
ERROR - 2018-05-15 03:02:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-15 03:02:54 --> The path to the image is not correct.
ERROR - 2018-05-15 03:02:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-15 03:41:28 --> The path to the image is not correct.
ERROR - 2018-05-15 03:41:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-15 03:42:02 --> The path to the image is not correct.
ERROR - 2018-05-15 03:42:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-15 03:42:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-15 03:42:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-15 07:05:45 --> The path to the image is not correct.
ERROR - 2018-05-15 07:05:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-15 07:05:50 --> The path to the image is not correct.
ERROR - 2018-05-15 07:05:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-15 08:38:19 --> The path to the image is not correct.
ERROR - 2018-05-15 08:38:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-15 08:38:22 --> The path to the image is not correct.
ERROR - 2018-05-15 08:38:22 --> Your server does not support the GD function required to process this type of image.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-06 03:00:00 --> The path to the image is not correct.
ERROR - 2018-06-06 03:00:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-06 03:22:32 --> The path to the image is not correct.
ERROR - 2018-06-06 03:22:32 --> Your server does not support the GD function required to process this type of image.

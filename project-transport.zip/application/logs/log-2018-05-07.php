<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-07 03:49:56 --> 404 Page Not Found: app/Login/index
ERROR - 2018-05-07 03:49:58 --> 404 Page Not Found: app//index
ERROR - 2018-05-07 03:50:02 --> 404 Page Not Found: app//index
ERROR - 2018-05-07 03:50:31 --> The path to the image is not correct.
ERROR - 2018-05-07 03:50:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:36:31 --> The path to the image is not correct.
ERROR - 2018-05-07 04:36:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:38:51 --> The path to the image is not correct.
ERROR - 2018-05-07 04:38:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:43:07 --> The path to the image is not correct.
ERROR - 2018-05-07 04:43:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:46:54 --> The path to the image is not correct.
ERROR - 2018-05-07 04:46:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:47:17 --> The path to the image is not correct.
ERROR - 2018-05-07 04:47:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:49:32 --> The path to the image is not correct.
ERROR - 2018-05-07 04:49:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:49:37 --> The path to the image is not correct.
ERROR - 2018-05-07 04:49:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:50:00 --> The path to the image is not correct.
ERROR - 2018-05-07 04:50:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:50:21 --> The path to the image is not correct.
ERROR - 2018-05-07 04:50:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:50:44 --> The path to the image is not correct.
ERROR - 2018-05-07 04:50:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:51:15 --> The path to the image is not correct.
ERROR - 2018-05-07 04:51:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:51:26 --> The path to the image is not correct.
ERROR - 2018-05-07 04:51:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:52:24 --> The path to the image is not correct.
ERROR - 2018-05-07 04:52:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:53:35 --> The path to the image is not correct.
ERROR - 2018-05-07 04:53:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:54:43 --> The path to the image is not correct.
ERROR - 2018-05-07 04:54:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:55:01 --> The path to the image is not correct.
ERROR - 2018-05-07 04:55:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:57:11 --> The path to the image is not correct.
ERROR - 2018-05-07 04:57:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 04:58:09 --> The path to the image is not correct.
ERROR - 2018-05-07 04:58:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:09:39 --> The path to the image is not correct.
ERROR - 2018-05-07 05:09:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:10:47 --> The path to the image is not correct.
ERROR - 2018-05-07 05:10:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:11:40 --> The path to the image is not correct.
ERROR - 2018-05-07 05:11:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:14:53 --> The path to the image is not correct.
ERROR - 2018-05-07 05:14:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:15:49 --> The path to the image is not correct.
ERROR - 2018-05-07 05:15:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:16:35 --> The path to the image is not correct.
ERROR - 2018-05-07 05:16:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:16:35 --> The path to the image is not correct.
ERROR - 2018-05-07 05:16:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:16:36 --> The path to the image is not correct.
ERROR - 2018-05-07 05:16:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:18:11 --> The path to the image is not correct.
ERROR - 2018-05-07 05:18:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:20:52 --> The path to the image is not correct.
ERROR - 2018-05-07 05:20:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:23:02 --> The path to the image is not correct.
ERROR - 2018-05-07 05:23:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:23:37 --> The path to the image is not correct.
ERROR - 2018-05-07 05:23:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:26:17 --> The path to the image is not correct.
ERROR - 2018-05-07 05:26:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:32:51 --> The path to the image is not correct.
ERROR - 2018-05-07 05:32:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:33:58 --> The path to the image is not correct.
ERROR - 2018-05-07 05:33:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:35:54 --> The path to the image is not correct.
ERROR - 2018-05-07 05:35:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:36:11 --> The path to the image is not correct.
ERROR - 2018-05-07 05:36:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:36:42 --> The path to the image is not correct.
ERROR - 2018-05-07 05:36:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:38:01 --> The path to the image is not correct.
ERROR - 2018-05-07 05:38:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:38:20 --> The path to the image is not correct.
ERROR - 2018-05-07 05:38:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:39:28 --> The path to the image is not correct.
ERROR - 2018-05-07 05:39:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:41:36 --> The path to the image is not correct.
ERROR - 2018-05-07 05:41:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:42:07 --> The path to the image is not correct.
ERROR - 2018-05-07 05:42:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:42:15 --> The path to the image is not correct.
ERROR - 2018-05-07 05:42:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:42:19 --> The path to the image is not correct.
ERROR - 2018-05-07 05:42:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:42:36 --> The path to the image is not correct.
ERROR - 2018-05-07 05:42:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:44:43 --> The path to the image is not correct.
ERROR - 2018-05-07 05:44:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:45:02 --> The path to the image is not correct.
ERROR - 2018-05-07 05:45:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:45:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:45:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:45:27 --> The path to the image is not correct.
ERROR - 2018-05-07 05:45:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:45:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:45:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:45:49 --> The path to the image is not correct.
ERROR - 2018-05-07 05:45:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:45:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:45:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:45:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:45:51 --> The path to the image is not correct.
ERROR - 2018-05-07 05:45:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:45:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:46:01 --> The path to the image is not correct.
ERROR - 2018-05-07 05:46:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:46:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:46:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:46:13 --> The path to the image is not correct.
ERROR - 2018-05-07 05:46:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:46:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:46:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:46:34 --> The path to the image is not correct.
ERROR - 2018-05-07 05:46:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:46:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:46:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:46:45 --> The path to the image is not correct.
ERROR - 2018-05-07 05:46:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:46:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:46:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:47:10 --> The path to the image is not correct.
ERROR - 2018-05-07 05:47:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:47:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:47:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:47:50 --> The path to the image is not correct.
ERROR - 2018-05-07 05:47:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:47:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:47:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:48:07 --> The path to the image is not correct.
ERROR - 2018-05-07 05:48:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:48:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:48:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:48:34 --> The path to the image is not correct.
ERROR - 2018-05-07 05:48:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:48:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:48:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:48:44 --> The path to the image is not correct.
ERROR - 2018-05-07 05:48:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:48:44 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-07 05:48:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:48:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:50:38 --> The path to the image is not correct.
ERROR - 2018-05-07 05:50:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:50:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:50:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:02 --> The path to the image is not correct.
ERROR - 2018-05-07 05:51:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:51:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:11 --> The path to the image is not correct.
ERROR - 2018-05-07 05:51:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:51:11 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-07 05:51:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:20 --> The path to the image is not correct.
ERROR - 2018-05-07 05:51:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:51:20 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-07 05:51:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:24 --> The path to the image is not correct.
ERROR - 2018-05-07 05:51:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:51:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:29 --> The path to the image is not correct.
ERROR - 2018-05-07 05:51:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:51:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:33 --> The path to the image is not correct.
ERROR - 2018-05-07 05:51:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:51:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:36 --> The path to the image is not correct.
ERROR - 2018-05-07 05:51:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:51:36 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-07 05:51:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:44 --> The path to the image is not correct.
ERROR - 2018-05-07 05:51:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:51:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:47 --> The path to the image is not correct.
ERROR - 2018-05-07 05:51:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:51:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:51:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:52:57 --> The path to the image is not correct.
ERROR - 2018-05-07 05:52:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:52:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:52:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:54:39 --> The path to the image is not correct.
ERROR - 2018-05-07 05:54:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:54:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:54:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:54:42 --> The path to the image is not correct.
ERROR - 2018-05-07 05:54:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:54:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:54:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:54:45 --> The path to the image is not correct.
ERROR - 2018-05-07 05:54:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 05:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 05:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:21:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:21:50 --> The path to the image is not correct.
ERROR - 2018-05-07 07:21:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:21:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 07:23:25 --> The path to the image is not correct.
ERROR - 2018-05-07 07:23:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 07:23:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:23:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:23:29 --> The path to the image is not correct.
ERROR - 2018-05-07 07:23:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 07:23:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:23:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:24:04 --> The path to the image is not correct.
ERROR - 2018-05-07 07:24:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 07:24:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:24:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:24:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:24:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:24:06 --> The path to the image is not correct.
ERROR - 2018-05-07 07:24:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 07:24:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:24:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:24:53 --> The path to the image is not correct.
ERROR - 2018-05-07 07:24:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 07:25:11 --> The path to the image is not correct.
ERROR - 2018-05-07 07:25:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 07:25:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:25:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:25:17 --> The path to the image is not correct.
ERROR - 2018-05-07 07:25:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 07:25:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:25:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:25:21 --> The path to the image is not correct.
ERROR - 2018-05-07 07:25:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 07:25:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:25:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:25:33 --> The path to the image is not correct.
ERROR - 2018-05-07 07:25:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 07:25:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:25:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 07:49:02 --> The path to the image is not correct.
ERROR - 2018-05-07 07:49:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 08:22:40 --> The path to the image is not correct.
ERROR - 2018-05-07 08:22:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 08:22:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:22:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:22:43 --> The path to the image is not correct.
ERROR - 2018-05-07 08:22:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 08:22:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:22:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:23:38 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-07 08:23:38 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-07 08:23:38 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-07 08:23:38 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-07 08:23:38 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-07 08:42:12 --> The path to the image is not correct.
ERROR - 2018-05-07 08:42:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 08:42:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:42:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:43:17 --> The path to the image is not correct.
ERROR - 2018-05-07 08:43:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:43:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:43:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 08:59:14 --> The path to the image is not correct.
ERROR - 2018-05-07 08:59:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 08:59:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:59:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:59:19 --> The path to the image is not correct.
ERROR - 2018-05-07 08:59:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 08:59:19 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-07 08:59:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 08:59:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-07 09:01:16 --> The path to the image is not correct.
ERROR - 2018-05-07 09:01:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 09:01:25 --> The path to the image is not correct.
ERROR - 2018-05-07 09:01:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 09:29:39 --> Query error: Unknown column 's.store_name' in 'field list' - Invalid query: SELECT `s`.`store_name`, `s`.`address_id`, `sa`.*
FROM `store`
JOIN `store_address` `sa` ON `sa`.`store_address_id` = `s`.`address_id`
WHERE `store_id` = '1'
ERROR - 2018-05-07 09:29:50 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 204
ERROR - 2018-05-07 09:29:50 --> The path to the image is not correct.
ERROR - 2018-05-07 09:29:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 09:30:20 --> The path to the image is not correct.
ERROR - 2018-05-07 09:30:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 09:51:47 --> Query error: Unknown column 's.store_name' in 'field list' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `rs`.`signature`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`, `s`.`store_name`, `s`.`address_id`, `sa`.*
FROM `report` `r`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `store_address` `sa` ON `sa`.`store_address_id` = `s`.`address_id`
WHERE `r`.`report_by` = '2'
AND `c`.`checklist_id` = '1'
AND `r`.`vehicle_registration_number` = 'XM 2013'
AND `r`.`created` >= 1525644000
AND `r`.`created` <= 1526248740
AND `store_id` = '1'
ORDER BY `r`.`created` ASC
ERROR - 2018-05-07 10:23:07 --> Query error: Unknown column 's.store_name' in 'field list' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `rs`.`signature`, `c`.`checklist_name`, `u`.`display_name`, `u2`.`display_name` as `updated_by`, `s`.`store_name`, `s`.`address_id`, `sa`.*
FROM `report` `r`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
JOIN `user` `u2` ON `u2`.`user_id` = `rs`.`user_id`
JOIN `store_address` `sa` ON `sa`.`store_address_id` = `s`.`address_id`
WHERE `r`.`report_by` = '2'
AND `c`.`checklist_id` = '1'
AND `r`.`vehicle_registration_number` = 'XM 2013'
AND `r`.`created` >= 1525644000
AND `r`.`created` <= 1526248740
AND `store_id` = '1'
ORDER BY `r`.`created` ASC
ERROR - 2018-05-07 10:23:28 --> The path to the image is not correct.
ERROR - 2018-05-07 10:23:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 12:00:12 --> The path to the image is not correct.
ERROR - 2018-05-07 12:00:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-07 12:09:20 --> The path to the image is not correct.
ERROR - 2018-05-07 12:09:20 --> Your server does not support the GD function required to process this type of image.

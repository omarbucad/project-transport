<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-10 04:10:43 --> The path to the image is not correct.
ERROR - 2018-08-10 04:10:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:10:50 --> The path to the image is not correct.
ERROR - 2018-08-10 04:10:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:11:22 --> The path to the image is not correct.
ERROR - 2018-08-10 04:11:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:11:23 --> The path to the image is not correct.
ERROR - 2018-08-10 04:11:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:14:41 --> The path to the image is not correct.
ERROR - 2018-08-10 04:14:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:14:45 --> The path to the image is not correct.
ERROR - 2018-08-10 04:14:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:53:59 --> The path to the image is not correct.
ERROR - 2018-08-10 04:53:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:54:05 --> The path to the image is not correct.
ERROR - 2018-08-10 04:54:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:54:14 --> The path to the image is not correct.
ERROR - 2018-08-10 04:54:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:54:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 04:54:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 04:55:29 --> The path to the image is not correct.
ERROR - 2018-08-10 04:55:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:55:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 04:55:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 04:58:14 --> The path to the image is not correct.
ERROR - 2018-08-10 04:58:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 04:58:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 04:58:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 04:58:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 04:58:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:02:22 --> The path to the image is not correct.
ERROR - 2018-08-10 05:02:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:02:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:02:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:02:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:02:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:02:57 --> The path to the image is not correct.
ERROR - 2018-08-10 05:02:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:02:57 --> The path to the image is not correct.
ERROR - 2018-08-10 05:02:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:02:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:02:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:02:58 --> The path to the image is not correct.
ERROR - 2018-08-10 05:02:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:02:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:02:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:03:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:03:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:03:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:03:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-08-10 05:03:21 --> The path to the image is not correct.
ERROR - 2018-08-10 05:03:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:05:56 --> The path to the image is not correct.
ERROR - 2018-08-10 05:05:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:05:56 --> The path to the image is not correct.
ERROR - 2018-08-10 05:05:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:12:07 --> The path to the image is not correct.
ERROR - 2018-08-10 05:12:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:13:17 --> The path to the image is not correct.
ERROR - 2018-08-10 05:13:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:19:25 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 221
ERROR - 2018-08-10 05:19:25 --> The path to the image is not correct.
ERROR - 2018-08-10 05:19:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:19:45 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 216
ERROR - 2018-08-10 05:19:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 216
ERROR - 2018-08-10 05:19:45 --> Severity: Notice --> Undefined property: stdClass::$images D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 216
ERROR - 2018-08-10 05:19:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 216
ERROR - 2018-08-10 05:19:45 --> The path to the image is not correct.
ERROR - 2018-08-10 05:19:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:20:03 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-08-10 05:20:04 --> The path to the image is not correct.
ERROR - 2018-08-10 05:20:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:20:15 --> The path to the image is not correct.
ERROR - 2018-08-10 05:20:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:20:27 --> The path to the image is not correct.
ERROR - 2018-08-10 05:20:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:21:07 --> The path to the image is not correct.
ERROR - 2018-08-10 05:21:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:21:38 --> The path to the image is not correct.
ERROR - 2018-08-10 05:21:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:21:38 --> The path to the image is not correct.
ERROR - 2018-08-10 05:21:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:21:38 --> The path to the image is not correct.
ERROR - 2018-08-10 05:21:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:21:38 --> The path to the image is not correct.
ERROR - 2018-08-10 05:21:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:21:38 --> The path to the image is not correct.
ERROR - 2018-08-10 05:21:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:21:38 --> The path to the image is not correct.
ERROR - 2018-08-10 05:21:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:21:38 --> The path to the image is not correct.
ERROR - 2018-08-10 05:21:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:21:39 --> The path to the image is not correct.
ERROR - 2018-08-10 05:21:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:21:42 --> The path to the image is not correct.
ERROR - 2018-08-10 05:21:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:22:23 --> 404 Page Not Found: Thumbs/report
ERROR - 2018-08-10 05:22:23 --> The path to the image is not correct.
ERROR - 2018-08-10 05:22:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:22:23 --> 404 Page Not Found: Thumbs/report
ERROR - 2018-08-10 05:22:23 --> 404 Page Not Found: Thumbs/report
ERROR - 2018-08-10 05:22:23 --> 404 Page Not Found: Thumbs/report
ERROR - 2018-08-10 05:22:23 --> 404 Page Not Found: Thumbs/report
ERROR - 2018-08-10 05:22:23 --> 404 Page Not Found: Thumbs/report
ERROR - 2018-08-10 05:22:25 --> 404 Page Not Found: Thumbs/report
ERROR - 2018-08-10 05:22:36 --> The path to the image is not correct.
ERROR - 2018-08-10 05:22:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:30:07 --> The path to the image is not correct.
ERROR - 2018-08-10 05:30:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:30:10 --> The path to the image is not correct.
ERROR - 2018-08-10 05:30:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:30:32 --> The path to the image is not correct.
ERROR - 2018-08-10 05:30:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:30:38 --> The path to the image is not correct.
ERROR - 2018-08-10 05:30:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:31:43 --> Severity: Notice --> getimagesize(): Read error! D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-08-10 05:31:43 --> The provided image is not valid.
ERROR - 2018-08-10 05:31:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 05:31:43 --> Severity: Warning --> readfile(public/upload/report/2018/08/thumbnail/500x500_191_1244_1_1533867146.PNG): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-08-10 05:45:08 --> The path to the image is not correct.
ERROR - 2018-08-10 05:45:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 06:02:57 --> The path to the image is not correct.
ERROR - 2018-08-10 06:02:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 07:37:20 --> The path to the image is not correct.
ERROR - 2018-08-10 07:37:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 07:37:25 --> The path to the image is not correct.
ERROR - 2018-08-10 07:37:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 07:37:25 --> The path to the image is not correct.
ERROR - 2018-08-10 07:37:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 07:37:44 --> The path to the image is not correct.
ERROR - 2018-08-10 07:37:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 07:38:22 --> The path to the image is not correct.
ERROR - 2018-08-10 07:38:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-10 07:38:22 --> The path to the image is not correct.
ERROR - 2018-08-10 07:38:22 --> Your server does not support the GD function required to process this type of image.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-03 02:40:32 --> The path to the image is not correct.
ERROR - 2018-07-03 02:40:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 02:40:34 --> The path to the image is not correct.
ERROR - 2018-07-03 02:40:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 02:40:34 --> The path to the image is not correct.
ERROR - 2018-07-03 02:40:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 04:26:37 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-03 04:26:37 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-03 04:26:37 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-03 04:26:37 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-03 04:26:37 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-03 08:10:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 12
ERROR - 2018-07-03 08:10:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 167
ERROR - 2018-07-03 08:10:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 180
ERROR - 2018-07-03 08:10:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Accounts_model.php 192
ERROR - 2018-07-03 08:10:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 30
ERROR - 2018-07-03 08:10:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 19
ERROR - 2018-07-03 08:10:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-03 08:10:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-03 08:10:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 22
ERROR - 2018-07-03 08:10:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 26
ERROR - 2018-07-03 08:10:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\header.php 27
ERROR - 2018-07-03 08:10:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 15
ERROR - 2018-07-03 08:10:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 25
ERROR - 2018-07-03 08:10:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 37
ERROR - 2018-07-03 08:10:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\common\side.php 79
ERROR - 2018-07-03 08:10:05 --> 404 Page Not Found: admin/%3Cdiv%20style=/index
ERROR - 2018-07-03 08:10:05 --> The path to the image is not correct.
ERROR - 2018-07-03 08:10:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:10:05 --> The path to the image is not correct.
ERROR - 2018-07-03 08:10:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:11:06 --> 404 Page Not Found: Logout/index
ERROR - 2018-07-03 08:11:22 --> The path to the image is not correct.
ERROR - 2018-07-03 08:11:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:11:26 --> The path to the image is not correct.
ERROR - 2018-07-03 08:11:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:11:27 --> The path to the image is not correct.
ERROR - 2018-07-03 08:11:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:24:24 --> The path to the image is not correct.
ERROR - 2018-07-03 08:24:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:24:24 --> The path to the image is not correct.
ERROR - 2018-07-03 08:24:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:24:24 --> The path to the image is not correct.
ERROR - 2018-07-03 08:24:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:24:29 --> The path to the image is not correct.
ERROR - 2018-07-03 08:24:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:24:29 --> The path to the image is not correct.
ERROR - 2018-07-03 08:24:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:25:41 --> The path to the image is not correct.
ERROR - 2018-07-03 08:25:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:25:41 --> The path to the image is not correct.
ERROR - 2018-07-03 08:25:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:25:41 --> The path to the image is not correct.
ERROR - 2018-07-03 08:25:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:25:46 --> The path to the image is not correct.
ERROR - 2018-07-03 08:25:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:25:46 --> The path to the image is not correct.
ERROR - 2018-07-03 08:25:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:33:45 --> The path to the image is not correct.
ERROR - 2018-07-03 08:33:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:33:45 --> The path to the image is not correct.
ERROR - 2018-07-03 08:33:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:33:45 --> The path to the image is not correct.
ERROR - 2018-07-03 08:33:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:33:48 --> The path to the image is not correct.
ERROR - 2018-07-03 08:33:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:33:48 --> The path to the image is not correct.
ERROR - 2018-07-03 08:33:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:33:48 --> The path to the image is not correct.
ERROR - 2018-07-03 08:33:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:34:04 --> The path to the image is not correct.
ERROR - 2018-07-03 08:34:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 08:34:04 --> The path to the image is not correct.
ERROR - 2018-07-03 08:34:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 09:16:22 --> The path to the image is not correct.
ERROR - 2018-07-03 09:16:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 09:16:22 --> The path to the image is not correct.
ERROR - 2018-07-03 09:16:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 09:16:24 --> The path to the image is not correct.
ERROR - 2018-07-03 09:16:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 10:34:43 --> Query error: Unknown column 'up.plan_type' in 'field list' - Invalid query: SELECT `u`.`user_id`, `u`.`display_name`, `u`.`email_address`, `u`.`role`, `u`.`store_id`, `u`.`image_path`, `u`.`image_name`, `up`.`plan_type`, `a1`.`country`
FROM `user` `u`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `a1` ON `a1`.`store_address_id` = `s`.`address_id`
WHERE `u`.`username` = 'devadmin'
AND `u`.`password` = '21232f297a57a5a743894a0e4a801fc3'
AND `up`.`active` = 1
ERROR - 2018-07-03 10:36:19 --> Query error: Unknown column 'up.plan_type' in 'field list' - Invalid query: SELECT `u`.`user_id`, `u`.`display_name`, `u`.`email_address`, `u`.`role`, `u`.`store_id`, `u`.`image_path`, `u`.`image_name`, `p`.`plan_id`, `p`.`title`, `up`.`plan_type`, `a1`.`country`
FROM `user` `u`
JOIN `plan` `p` ON `p`.`plan_id` = `up`.`plan_id`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `a1` ON `a1`.`store_address_id` = `s`.`address_id`
WHERE `u`.`username` = 'devadmin'
AND `u`.`password` = '21232f297a57a5a743894a0e4a801fc3'
AND `up`.`active` = 1
ERROR - 2018-07-03 10:36:45 --> Query error: Unknown column 'up.plan_id' in 'on clause' - Invalid query: SELECT `u`.`user_id`, `u`.`display_name`, `u`.`email_address`, `u`.`role`, `u`.`store_id`, `u`.`image_path`, `u`.`image_name`, `p`.`plan_id`, `p`.`title`, `a1`.`country`
FROM `user` `u`
JOIN `plan` `p` ON `p`.`plan_id` = `up`.`plan_id`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `a1` ON `a1`.`store_address_id` = `s`.`address_id`
WHERE `u`.`username` = 'devadmin'
AND `u`.`password` = '21232f297a57a5a743894a0e4a801fc3'
AND `up`.`active` = 1
ERROR - 2018-07-03 10:37:10 --> Query error: Unknown column 'up.plan_id' in 'on clause' - Invalid query: SELECT `u`.`user_id`, `u`.`display_name`, `u`.`email_address`, `u`.`role`, `u`.`store_id`, `u`.`image_path`, `u`.`image_name`, `p`.`plan_id`, `p`.`title`, `a1`.`country`
FROM `user` `u`
JOIN `plan` `p` ON `p`.`plan_id` = `up`.`plan_id`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `a1` ON `a1`.`store_address_id` = `s`.`address_id`
WHERE `u`.`username` = 'devadmin'
AND `u`.`password` = '21232f297a57a5a743894a0e4a801fc3'
AND `up`.`active` = 1
ERROR - 2018-07-03 10:41:35 --> Query error: Unknown column 'up.plan_id' in 'on clause' - Invalid query: SELECT `u`.`user_id`, `u`.`display_name`, `u`.`email_address`, `u`.`role`, `u`.`store_id`, `u`.`image_path`, `u`.`image_name`, `p`.`plan_id`, `p`.`title`, `a1`.`country`
FROM `user` `u`
JOIN `plan` `p` ON `p`.`plan_id` = `up`.`plan_id`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `a1` ON `a1`.`store_address_id` = `s`.`address_id`
WHERE `u`.`username` = 'devadmin'
AND `u`.`password` = '21232f297a57a5a743894a0e4a801fc3'
AND `up`.`active` = 1
ERROR - 2018-07-03 10:41:38 --> Query error: Unknown column 'up.plan_id' in 'on clause' - Invalid query: SELECT `u`.`user_id`, `u`.`display_name`, `u`.`email_address`, `u`.`role`, `u`.`store_id`, `u`.`image_path`, `u`.`image_name`, `p`.`plan_id`, `p`.`title`, `a1`.`country`
FROM `user` `u`
JOIN `plan` `p` ON `p`.`plan_id` = `up`.`plan_id`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
JOIN `store` `s` ON `s`.`store_id` = `u`.`store_id`
JOIN `store_address` `a1` ON `a1`.`store_address_id` = `s`.`address_id`
WHERE `u`.`username` = 'devadmin'
AND `u`.`password` = '21232f297a57a5a743894a0e4a801fc3'
AND `up`.`active` = 1
ERROR - 2018-07-03 10:49:25 --> The path to the image is not correct.
ERROR - 2018-07-03 10:49:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 10:51:01 --> Query error: Unknown column 'up.plan_type' in 'field list' - Invalid query: SELECT `u`.*, `up`.`user_plan_id`, `up`.`plan_type`, `up`.`billing_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`updated`, `up`.`active`, `up`.`who_updated`, `u2`.`display_name` as `updated_name`
FROM `user` `u`
JOIN `user_plan` `up` ON `up`.`store_id` = `u`.`store_id`
JOIN `user` `u2` ON `u2`.`user_id` = `up`.`who_updated`
WHERE `up`.`active` = 1
ERROR - 2018-07-03 10:57:46 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 30
ERROR - 2018-07-03 10:57:46 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 164
ERROR - 2018-07-03 10:57:46 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 164
ERROR - 2018-07-03 10:57:46 --> The path to the image is not correct.
ERROR - 2018-07-03 10:57:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 10:57:47 --> The path to the image is not correct.
ERROR - 2018-07-03 10:57:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:00:00 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 30
ERROR - 2018-07-03 11:00:01 --> The path to the image is not correct.
ERROR - 2018-07-03 11:00:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:00:01 --> The path to the image is not correct.
ERROR - 2018-07-03 11:00:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:00:10 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 30
ERROR - 2018-07-03 11:00:10 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 164
ERROR - 2018-07-03 11:00:10 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\accounts\manage_accounts.php 164
ERROR - 2018-07-03 11:00:10 --> The path to the image is not correct.
ERROR - 2018-07-03 11:00:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:00:10 --> The path to the image is not correct.
ERROR - 2018-07-03 11:00:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:00:21 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\controllers\admin\Accounts.php 30
ERROR - 2018-07-03 11:00:21 --> The path to the image is not correct.
ERROR - 2018-07-03 11:00:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:00:21 --> The path to the image is not correct.
ERROR - 2018-07-03 11:00:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:01:07 --> The path to the image is not correct.
ERROR - 2018-07-03 11:01:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:01:07 --> The path to the image is not correct.
ERROR - 2018-07-03 11:01:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:01:19 --> Query error: Unknown column 'up.plan_type' in 'field list' - Invalid query: SELECT `i`.*, `u`.`display_name`, `u`.`username`, `u`.`email_address`, `up`.`plan_type`, `up`.`plan_created`, `up`.`plan_expiration`, `up`.`billing_type`, `up`.`who_updated`, `up`.`active`, `up`.`user_plan_id`, `u2`.`display_name` as `updated_by`
FROM `invoice` `i`
JOIN `user` `u` ON `u`.`user_id` = `i`.`user_id`
JOIN `user_plan` `up` ON `up`.`user_plan_id` = `i`.`user_plan_id`
JOIN `user` `u2` ON `u2`.`user_id` = `up`.`who_updated`
WHERE `i`.`deleted` IS NULL
ERROR - 2018-07-03 11:02:42 --> Severity: Notice --> Undefined property: stdClass::$plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\admin\invoice\invoice.php 123
ERROR - 2018-07-03 11:02:42 --> The path to the image is not correct.
ERROR - 2018-07-03 11:02:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:03:03 --> The path to the image is not correct.
ERROR - 2018-07-03 11:03:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:04:22 --> The path to the image is not correct.
ERROR - 2018-07-03 11:04:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:05:19 --> The path to the image is not correct.
ERROR - 2018-07-03 11:05:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:28 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:28 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:43 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:43 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:49 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:53 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:54 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:54 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:54 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:55 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:17:55 --> The path to the image is not correct.
ERROR - 2018-07-03 11:17:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:20:39 --> The path to the image is not correct.
ERROR - 2018-07-03 11:20:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:20:39 --> The path to the image is not correct.
ERROR - 2018-07-03 11:20:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:20:43 --> The path to the image is not correct.
ERROR - 2018-07-03 11:20:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:20:46 --> The path to the image is not correct.
ERROR - 2018-07-03 11:20:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:20:46 --> The path to the image is not correct.
ERROR - 2018-07-03 11:20:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:22:30 --> The path to the image is not correct.
ERROR - 2018-07-03 11:22:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:22:30 --> The path to the image is not correct.
ERROR - 2018-07-03 11:22:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:23:28 --> The path to the image is not correct.
ERROR - 2018-07-03 11:23:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:23:28 --> The path to the image is not correct.
ERROR - 2018-07-03 11:23:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:23:29 --> The path to the image is not correct.
ERROR - 2018-07-03 11:23:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:23:29 --> The path to the image is not correct.
ERROR - 2018-07-03 11:23:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 49
ERROR - 2018-07-03 11:26:23 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 49
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined property: stdClass::$plan_created D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 50
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined property: stdClass::$plan_expiration D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 51
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined property: stdClass::$street1 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 53
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined property: stdClass::$street2 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 54
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined property: stdClass::$suburb D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 55
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined property: stdClass::$city D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 56
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined property: stdClass::$postcode D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 57
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined property: stdClass::$state D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 58
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined property: stdClass::$country D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 59
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined property: stdClass::$invoice_no D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 83
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 43
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined variable: billing_type D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 53
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 59
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined variable: display_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 68
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined variable: phone D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 77
ERROR - 2018-07-03 11:26:23 --> Severity: Notice --> Undefined variable: plan_type D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 91
ERROR - 2018-07-03 11:26:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-07-03 11:27:24 --> The path to the image is not correct.
ERROR - 2018-07-03 11:27:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:27:29 --> The path to the image is not correct.
ERROR - 2018-07-03 11:27:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:27:32 --> The path to the image is not correct.
ERROR - 2018-07-03 11:27:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:27:54 --> The path to the image is not correct.
ERROR - 2018-07-03 11:27:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:27:54 --> The path to the image is not correct.
ERROR - 2018-07-03 11:27:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:28:51 --> The path to the image is not correct.
ERROR - 2018-07-03 11:28:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:28:51 --> The path to the image is not correct.
ERROR - 2018-07-03 11:28:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:28:52 --> The path to the image is not correct.
ERROR - 2018-07-03 11:28:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 49
ERROR - 2018-07-03 11:29:21 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 49
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined property: stdClass::$plan_created D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 50
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined property: stdClass::$plan_expiration D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 51
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined property: stdClass::$street1 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 53
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined property: stdClass::$street2 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 54
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined property: stdClass::$suburb D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 55
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined property: stdClass::$city D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 56
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined property: stdClass::$postcode D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 57
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined property: stdClass::$state D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 58
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined property: stdClass::$country D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 59
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined property: stdClass::$invoice_no D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 83
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 43
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined variable: billing_type D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 53
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 59
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined variable: display_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 68
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined variable: phone D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 77
ERROR - 2018-07-03 11:29:21 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 91
ERROR - 2018-07-03 11:29:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 49
ERROR - 2018-07-03 11:30:17 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 49
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$plan_created D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 50
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$plan_expiration D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 51
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$street1 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 53
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$street2 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 54
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$suburb D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 55
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$city D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 56
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$postcode D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 57
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$state D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 58
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$country D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 59
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$invoice_no D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 83
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 43
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined variable: billing_type D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 53
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 59
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined variable: display_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 68
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined variable: phone D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 77
ERROR - 2018-07-03 11:30:17 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 91
ERROR - 2018-07-03 11:30:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-07-03 11:30:38 --> The path to the image is not correct.
ERROR - 2018-07-03 11:30:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:30:46 --> The path to the image is not correct.
ERROR - 2018-07-03 11:30:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:35:28 --> The path to the image is not correct.
ERROR - 2018-07-03 11:35:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:35:51 --> The path to the image is not correct.
ERROR - 2018-07-03 11:35:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:35:51 --> The path to the image is not correct.
ERROR - 2018-07-03 11:35:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:35:52 --> The path to the image is not correct.
ERROR - 2018-07-03 11:35:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:35:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 49
ERROR - 2018-07-03 11:35:55 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 49
ERROR - 2018-07-03 11:35:55 --> Severity: Notice --> Undefined property: stdClass::$plan_created D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 50
ERROR - 2018-07-03 11:35:55 --> Severity: Notice --> Undefined property: stdClass::$plan_expiration D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 51
ERROR - 2018-07-03 11:35:55 --> Severity: Notice --> Undefined property: stdClass::$street1 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 53
ERROR - 2018-07-03 11:35:55 --> Severity: Notice --> Undefined property: stdClass::$street2 D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 54
ERROR - 2018-07-03 11:35:55 --> Severity: Notice --> Undefined property: stdClass::$suburb D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 55
ERROR - 2018-07-03 11:35:55 --> Severity: Notice --> Undefined property: stdClass::$city D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 56
ERROR - 2018-07-03 11:35:55 --> Severity: Notice --> Undefined property: stdClass::$postcode D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 57
ERROR - 2018-07-03 11:35:55 --> Severity: Notice --> Undefined property: stdClass::$state D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 58
ERROR - 2018-07-03 11:35:55 --> Severity: Notice --> Undefined property: stdClass::$country D:\xampp\htdocs\project-transport\application\models\Invoice_model.php 59
ERROR - 2018-07-03 11:35:56 --> Severity: Notice --> Undefined property: stdClass::$invoice_no D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 83
ERROR - 2018-07-03 11:35:56 --> Severity: Notice --> Undefined variable: invoice_no D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 43
ERROR - 2018-07-03 11:35:56 --> Severity: Notice --> Undefined variable: billing_type D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 53
ERROR - 2018-07-03 11:35:56 --> Severity: Notice --> Undefined variable: store_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 59
ERROR - 2018-07-03 11:35:56 --> Severity: Notice --> Undefined variable: display_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 68
ERROR - 2018-07-03 11:35:56 --> Severity: Notice --> Undefined variable: phone D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 77
ERROR - 2018-07-03 11:35:56 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\plan_invoice.php 91
ERROR - 2018-07-03 11:35:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\helpers\url_helper.php 561
ERROR - 2018-07-03 11:37:06 --> The path to the image is not correct.
ERROR - 2018-07-03 11:37:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:37:07 --> The path to the image is not correct.
ERROR - 2018-07-03 11:37:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:39:36 --> The path to the image is not correct.
ERROR - 2018-07-03 11:39:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:39:36 --> The path to the image is not correct.
ERROR - 2018-07-03 11:39:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:39:36 --> The path to the image is not correct.
ERROR - 2018-07-03 11:39:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:39:36 --> The path to the image is not correct.
ERROR - 2018-07-03 11:39:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:39:37 --> The path to the image is not correct.
ERROR - 2018-07-03 11:39:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:39:37 --> The path to the image is not correct.
ERROR - 2018-07-03 11:39:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:39:37 --> The path to the image is not correct.
ERROR - 2018-07-03 11:39:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:39:37 --> The path to the image is not correct.
ERROR - 2018-07-03 11:39:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:45:06 --> The path to the image is not correct.
ERROR - 2018-07-03 11:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:45:06 --> The path to the image is not correct.
ERROR - 2018-07-03 11:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:45:06 --> The path to the image is not correct.
ERROR - 2018-07-03 11:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:45:06 --> The path to the image is not correct.
ERROR - 2018-07-03 11:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:45:06 --> The path to the image is not correct.
ERROR - 2018-07-03 11:45:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:45:07 --> The path to the image is not correct.
ERROR - 2018-07-03 11:45:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:45:07 --> The path to the image is not correct.
ERROR - 2018-07-03 11:45:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:45:07 --> The path to the image is not correct.
ERROR - 2018-07-03 11:45:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:45:07 --> The path to the image is not correct.
ERROR - 2018-07-03 11:45:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-03 11:45:10 --> The path to the image is not correct.
ERROR - 2018-07-03 11:45:10 --> Your server does not support the GD function required to process this type of image.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-04 03:21:15 --> The path to the image is not correct.
ERROR - 2018-05-04 03:21:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:22:38 --> The path to the image is not correct.
ERROR - 2018-05-04 03:22:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:22:43 --> The path to the image is not correct.
ERROR - 2018-05-04 03:22:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:22:49 --> The path to the image is not correct.
ERROR - 2018-05-04 03:22:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:35:14 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 229
ERROR - 2018-05-04 03:35:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 229
ERROR - 2018-05-04 03:35:14 --> The path to the image is not correct.
ERROR - 2018-05-04 03:35:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:36:22 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 229
ERROR - 2018-05-04 03:36:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 229
ERROR - 2018-05-04 03:36:22 --> The path to the image is not correct.
ERROR - 2018-05-04 03:36:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:37:33 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 241
ERROR - 2018-05-04 03:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 241
ERROR - 2018-05-04 03:37:34 --> The path to the image is not correct.
ERROR - 2018-05-04 03:37:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:37:58 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 241
ERROR - 2018-05-04 03:37:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 241
ERROR - 2018-05-04 03:37:58 --> The path to the image is not correct.
ERROR - 2018-05-04 03:37:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:38:30 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 242
ERROR - 2018-05-04 03:38:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 242
ERROR - 2018-05-04 03:38:30 --> The path to the image is not correct.
ERROR - 2018-05-04 03:38:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:43:25 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 03:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 03:43:25 --> The path to the image is not correct.
ERROR - 2018-05-04 03:43:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:43:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:43:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:44:08 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 03:44:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 03:44:08 --> The path to the image is not correct.
ERROR - 2018-05-04 03:44:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:44:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:44:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:44:57 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 03:44:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 03:44:57 --> The path to the image is not correct.
ERROR - 2018-05-04 03:44:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:44:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:44:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined property: stdClass::$vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 117
ERROR - 2018-05-04 03:48:44 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 03:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 03:48:44 --> The path to the image is not correct.
ERROR - 2018-05-04 03:48:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:48:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:48:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:50:01 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 03:50:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 03:50:01 --> The path to the image is not correct.
ERROR - 2018-05-04 03:50:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:50:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:50:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:52:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:52:23 --> The path to the image is not correct.
ERROR - 2018-05-04 03:52:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:52:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:52:33 --> The path to the image is not correct.
ERROR - 2018-05-04 03:52:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:52:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:52:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:53:36 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 03:53:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 03:53:36 --> The path to the image is not correct.
ERROR - 2018-05-04 03:53:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:53:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:53:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:53:43 --> The path to the image is not correct.
ERROR - 2018-05-04 03:53:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:53:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:53:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:53:51 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 03:53:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 03:53:51 --> The path to the image is not correct.
ERROR - 2018-05-04 03:53:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 03:53:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 03:53:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:10:17 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-05-04 04:10:17 --> The provided image is not valid.
ERROR - 2018-05-04 04:10:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:10:17 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-05-04 04:10:17 --> The provided image is not valid.
ERROR - 2018-05-04 04:10:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:10:17 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/checklist/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-05-04 04:10:17 --> The provided image is not valid.
ERROR - 2018-05-04 04:10:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:34 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:12:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\project-transport\application\controllers\api\Checklist.php 116
ERROR - 2018-05-04 04:20:04 --> Severity: Warning --> Attempt to assign property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 197
ERROR - 2018-05-04 04:39:07 --> Severity: Notice --> Undefined variable: checklist_list D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 04:39:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 208
ERROR - 2018-05-04 04:39:07 --> The path to the image is not correct.
ERROR - 2018-05-04 04:39:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:39:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:39:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:39:30 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 04:39:31 --> The path to the image is not correct.
ERROR - 2018-05-04 04:39:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:39:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:39:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:39:43 --> The path to the image is not correct.
ERROR - 2018-05-04 04:39:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:39:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:39:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:48:01 --> The path to the image is not correct.
ERROR - 2018-05-04 04:48:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:48:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:48:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> Severity: Notice --> Undefined property: stdClass::$checklist_is_check D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:00 --> The path to the image is not correct.
ERROR - 2018-05-04 04:49:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:49:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:49:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:49:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:49 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:49 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:49 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:49 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:49 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:49:50 --> The path to the image is not correct.
ERROR - 2018-05-04 04:49:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:49:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:49:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:50:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:11 --> The path to the image is not correct.
ERROR - 2018-05-04 04:50:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:50:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:50:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:43 --> The path to the image is not correct.
ERROR - 2018-05-04 04:50:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:50:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:50:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:44 --> The path to the image is not correct.
ERROR - 2018-05-04 04:50:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:50:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:50:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:50:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:50:46 --> The path to the image is not correct.
ERROR - 2018-05-04 04:50:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:50:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:50:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:05 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> The path to the image is not correct.
ERROR - 2018-05-04 04:51:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:51:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:51:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> The path to the image is not correct.
ERROR - 2018-05-04 04:51:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:51:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:51:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:51:08 --> The path to the image is not correct.
ERROR - 2018-05-04 04:51:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:51:08 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Undefined property: stdClass::$Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:11 --> The path to the image is not correct.
ERROR - 2018-05-04 04:51:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:51:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:51:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:51:37 --> The path to the image is not correct.
ERROR - 2018-05-04 04:51:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:51:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:51:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 209
ERROR - 2018-05-04 04:52:24 --> The path to the image is not correct.
ERROR - 2018-05-04 04:52:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:52:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:52:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:53:42 --> The path to the image is not correct.
ERROR - 2018-05-04 04:53:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:53:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:53:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:56:41 --> The path to the image is not correct.
ERROR - 2018-05-04 04:56:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:56:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:56:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:57:37 --> The path to the image is not correct.
ERROR - 2018-05-04 04:57:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 04:57:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 04:57:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:02:41 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 228
ERROR - 2018-05-04 05:02:41 --> The path to the image is not correct.
ERROR - 2018-05-04 05:02:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:02:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:02:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:03:04 --> The path to the image is not correct.
ERROR - 2018-05-04 05:03:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:03:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:03:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:04:28 --> The path to the image is not correct.
ERROR - 2018-05-04 05:04:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:04:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:04:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:10:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 202
ERROR - 2018-05-04 05:10:46 --> The path to the image is not correct.
ERROR - 2018-05-04 05:10:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:10:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:10:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:14:08 --> The path to the image is not correct.
ERROR - 2018-05-04 05:14:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:14:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:14:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:05 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:06 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:07 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:08 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:09 --> The path to the image is not correct.
ERROR - 2018-05-04 05:21:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:21:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:21:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:21:20 --> The path to the image is not correct.
ERROR - 2018-05-04 05:21:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:21:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:21:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:45 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:46 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 210
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 211
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 212
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 213
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 215
ERROR - 2018-05-04 05:21:49 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 05:21:49 --> The path to the image is not correct.
ERROR - 2018-05-04 05:21:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:21:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:21:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:22:37 --> The path to the image is not correct.
ERROR - 2018-05-04 05:22:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:22:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:22:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:23:45 --> The path to the image is not correct.
ERROR - 2018-05-04 05:23:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:23:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:23:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:26:04 --> The path to the image is not correct.
ERROR - 2018-05-04 05:26:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:26:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:26:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 05:27:10 --> The path to the image is not correct.
ERROR - 2018-05-04 05:27:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:27:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:27:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:29:47 --> The path to the image is not correct.
ERROR - 2018-05-04 05:29:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:29:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:29:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:30:40 --> The path to the image is not correct.
ERROR - 2018-05-04 05:30:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:30:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:30:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:30:49 --> The path to the image is not correct.
ERROR - 2018-05-04 05:30:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:30:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:30:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:32:48 --> The path to the image is not correct.
ERROR - 2018-05-04 05:32:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 05:32:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 05:32:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 07:53:24 --> The path to the image is not correct.
ERROR - 2018-05-04 07:53:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 07:53:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 07:53:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 07:53:30 --> The path to the image is not correct.
ERROR - 2018-05-04 07:53:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 07:53:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 07:53:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 07:54:59 --> The path to the image is not correct.
ERROR - 2018-05-04 07:54:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 07:54:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 07:54:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 07:55:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 07:55:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 07:55:37 --> The path to the image is not correct.
ERROR - 2018-05-04 07:55:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 07:56:02 --> The path to the image is not correct.
ERROR - 2018-05-04 07:56:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 07:56:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 07:56:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:05:23 --> The path to the image is not correct.
ERROR - 2018-05-04 08:05:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:05:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:05:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:06:21 --> The path to the image is not correct.
ERROR - 2018-05-04 08:06:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:06:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:06:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:06:32 --> The path to the image is not correct.
ERROR - 2018-05-04 08:06:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:06:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:06:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:07:08 --> The path to the image is not correct.
ERROR - 2018-05-04 08:07:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:07:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:07:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:07:10 --> The path to the image is not correct.
ERROR - 2018-05-04 08:07:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:07:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:07:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:07:10 --> The path to the image is not correct.
ERROR - 2018-05-04 08:07:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:07:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:07:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:07:11 --> The path to the image is not correct.
ERROR - 2018-05-04 08:07:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:07:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:07:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:07:11 --> The path to the image is not correct.
ERROR - 2018-05-04 08:07:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:07:11 --> The path to the image is not correct.
ERROR - 2018-05-04 08:07:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:07:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:07:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:08:44 --> The path to the image is not correct.
ERROR - 2018-05-04 08:08:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:08:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:08:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:12:10 --> The path to the image is not correct.
ERROR - 2018-05-04 08:12:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:12:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:12:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:12:41 --> The path to the image is not correct.
ERROR - 2018-05-04 08:12:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:12:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:12:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:13:38 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:13:38 --> The path to the image is not correct.
ERROR - 2018-05-04 08:13:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:13:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:13:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:14:40 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:14:40 --> The path to the image is not correct.
ERROR - 2018-05-04 08:14:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:14:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:14:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:16:30 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 218
ERROR - 2018-05-04 08:16:30 --> The path to the image is not correct.
ERROR - 2018-05-04 08:16:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:16:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:16:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:17:09 --> The path to the image is not correct.
ERROR - 2018-05-04 08:17:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:17:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:17:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:17:45 --> The path to the image is not correct.
ERROR - 2018-05-04 08:17:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:17:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:17:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:17:52 --> The path to the image is not correct.
ERROR - 2018-05-04 08:17:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:17:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:17:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:18:26 --> The path to the image is not correct.
ERROR - 2018-05-04 08:18:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:18:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:18:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:19:10 --> The path to the image is not correct.
ERROR - 2018-05-04 08:19:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:19:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:19:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:20:37 --> The path to the image is not correct.
ERROR - 2018-05-04 08:20:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:20:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:20:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:20:49 --> The path to the image is not correct.
ERROR - 2018-05-04 08:20:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:20:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:20:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:21:01 --> The path to the image is not correct.
ERROR - 2018-05-04 08:21:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:21:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:21:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:24:00 --> The path to the image is not correct.
ERROR - 2018-05-04 08:24:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:24:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:24:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 217
ERROR - 2018-05-04 08:24:09 --> The path to the image is not correct.
ERROR - 2018-05-04 08:24:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:24:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:24:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:24:44 --> Severity: Notice --> Undefined variable: i D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:24:44 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:24:44 --> The path to the image is not correct.
ERROR - 2018-05-04 08:24:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:24:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:24:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:24:58 --> The path to the image is not correct.
ERROR - 2018-05-04 08:24:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:25:15 --> The path to the image is not correct.
ERROR - 2018-05-04 08:25:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:25:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:25:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:25:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:25:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:25:48 --> The path to the image is not correct.
ERROR - 2018-05-04 08:25:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:55 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:56 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:56 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:27:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:27:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:27:56 --> The path to the image is not correct.
ERROR - 2018-05-04 08:27:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:28:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:12 --> The path to the image is not correct.
ERROR - 2018-05-04 08:28:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:28:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:28:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:28:41 --> The path to the image is not correct.
ERROR - 2018-05-04 08:28:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:28:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:28:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:29:43 --> The path to the image is not correct.
ERROR - 2018-05-04 08:29:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:29:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:29:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:29:59 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:29:59 --> The path to the image is not correct.
ERROR - 2018-05-04 08:29:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:29:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:29:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:30:07 --> The path to the image is not correct.
ERROR - 2018-05-04 08:30:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:30:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:30:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:31:02 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:31:02 --> The path to the image is not correct.
ERROR - 2018-05-04 08:31:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:31:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:31:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:31:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:31:31 --> The path to the image is not correct.
ERROR - 2018-05-04 08:31:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:31:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:31:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:32:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:32:02 --> The path to the image is not correct.
ERROR - 2018-05-04 08:32:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:32:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:32:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:33:18 --> The path to the image is not correct.
ERROR - 2018-05-04 08:33:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:33:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:33:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:33:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:33:45 --> The path to the image is not correct.
ERROR - 2018-05-04 08:33:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:33:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:33:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:33:54 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:33:54 --> The path to the image is not correct.
ERROR - 2018-05-04 08:33:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:33:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:33:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:36:40 --> The path to the image is not correct.
ERROR - 2018-05-04 08:36:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:36:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:36:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:37:29 --> The path to the image is not correct.
ERROR - 2018-05-04 08:37:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:37:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:37:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:38:00 --> Severity: Warning --> Illegal offset type D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:38:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 216
ERROR - 2018-05-04 08:38:00 --> The path to the image is not correct.
ERROR - 2018-05-04 08:38:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:38:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:38:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:40:19 --> The path to the image is not correct.
ERROR - 2018-05-04 08:40:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:40:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:41:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 08:41:02 --> The path to the image is not correct.
ERROR - 2018-05-04 08:41:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:41:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:41:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:41:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_weekly.php 214
ERROR - 2018-05-04 08:41:14 --> The path to the image is not correct.
ERROR - 2018-05-04 08:41:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:41:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:41:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:41:48 --> The path to the image is not correct.
ERROR - 2018-05-04 08:41:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:41:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:41:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:42:04 --> The path to the image is not correct.
ERROR - 2018-05-04 08:42:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:42:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:42:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:42:18 --> The path to the image is not correct.
ERROR - 2018-05-04 08:42:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:42:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:42:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:43:00 --> The path to the image is not correct.
ERROR - 2018-05-04 08:43:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:43:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:43:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:43:07 --> The path to the image is not correct.
ERROR - 2018-05-04 08:43:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:43:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:43:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:43:14 --> The path to the image is not correct.
ERROR - 2018-05-04 08:43:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:43:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:43:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:44:02 --> The path to the image is not correct.
ERROR - 2018-05-04 08:44:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:44:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:44:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:44:35 --> The path to the image is not correct.
ERROR - 2018-05-04 08:44:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:44:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:44:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:44:47 --> The path to the image is not correct.
ERROR - 2018-05-04 08:44:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:44:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:44:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:46:07 --> The path to the image is not correct.
ERROR - 2018-05-04 08:46:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:46:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:51:30 --> The path to the image is not correct.
ERROR - 2018-05-04 08:51:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:51:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:51:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:51:30 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-04 08:51:30 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-04 08:51:30 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-04 08:51:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-04 08:51:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-04 08:51:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-04 08:51:30 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/signature/2018/05): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-05-04 08:51:30 --> The provided image is not valid.
ERROR - 2018-05-04 08:51:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-04 08:51:30 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-04 08:51:30 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-05-04 08:51:30 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-05-04 08:51:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-05-04 08:51:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-05-04 08:51:30 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-05-04 08:51:30 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/signature/2018/05): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-05-04 08:51:30 --> The provided image is not valid.
ERROR - 2018-05-04 08:51:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-05-04 08:52:12 --> The path to the image is not correct.
ERROR - 2018-05-04 08:52:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:52:12 --> 404 Page Not Found: Images/signature
ERROR - 2018-05-04 08:52:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:52:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:52:12 --> 404 Page Not Found: Images/signature
ERROR - 2018-05-04 08:52:33 --> The path to the image is not correct.
ERROR - 2018-05-04 08:52:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:52:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:52:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:53:34 --> The path to the image is not correct.
ERROR - 2018-05-04 08:53:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:53:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:53:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:55:36 --> The path to the image is not correct.
ERROR - 2018-05-04 08:55:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 08:55:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 08:55:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:36:53 --> The path to the image is not correct.
ERROR - 2018-05-04 09:36:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:36:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:36:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:38:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:38:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:38:38 --> The path to the image is not correct.
ERROR - 2018-05-04 09:38:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:46:41 --> The path to the image is not correct.
ERROR - 2018-05-04 09:46:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:46:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:46:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:47:15 --> The path to the image is not correct.
ERROR - 2018-05-04 09:47:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:47:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:47:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:49:26 --> The path to the image is not correct.
ERROR - 2018-05-04 09:49:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:49:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:49:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:49:35 --> The path to the image is not correct.
ERROR - 2018-05-04 09:49:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:49:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:49:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:49:45 --> The path to the image is not correct.
ERROR - 2018-05-04 09:49:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:49:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:50:30 --> The path to the image is not correct.
ERROR - 2018-05-04 09:50:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:50:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:50:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:50:44 --> The path to the image is not correct.
ERROR - 2018-05-04 09:50:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:50:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:50:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:51:23 --> The path to the image is not correct.
ERROR - 2018-05-04 09:51:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:51:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:51:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:53:34 --> The path to the image is not correct.
ERROR - 2018-05-04 09:53:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:53:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:53:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:55:30 --> The path to the image is not correct.
ERROR - 2018-05-04 09:55:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:55:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:55:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:56:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:56:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:57:42 --> The path to the image is not correct.
ERROR - 2018-05-04 09:57:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:57:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:57:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:59:00 --> The path to the image is not correct.
ERROR - 2018-05-04 09:59:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 09:59:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 09:59:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:04:05 --> The path to the image is not correct.
ERROR - 2018-05-04 10:04:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:04:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:04:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:04:09 --> The path to the image is not correct.
ERROR - 2018-05-04 10:04:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:04:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:04:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:04:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:04:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:04:32 --> The path to the image is not correct.
ERROR - 2018-05-04 10:04:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:06:12 --> The path to the image is not correct.
ERROR - 2018-05-04 10:06:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:06:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:06:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:09:23 --> The path to the image is not correct.
ERROR - 2018-05-04 10:09:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:09:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:09:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:09:37 --> The path to the image is not correct.
ERROR - 2018-05-04 10:09:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:09:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:09:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:11:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:11:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:11:12 --> The path to the image is not correct.
ERROR - 2018-05-04 10:11:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:11:27 --> The path to the image is not correct.
ERROR - 2018-05-04 10:11:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:11:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:11:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:11:28 --> The path to the image is not correct.
ERROR - 2018-05-04 10:11:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:11:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:11:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:13:15 --> The path to the image is not correct.
ERROR - 2018-05-04 10:13:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:13:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:13:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:13:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:13:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:13:28 --> The path to the image is not correct.
ERROR - 2018-05-04 10:13:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:13:29 --> The path to the image is not correct.
ERROR - 2018-05-04 10:13:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:13:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:13:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:13:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:13:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:13:29 --> The path to the image is not correct.
ERROR - 2018-05-04 10:13:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:16:50 --> The path to the image is not correct.
ERROR - 2018-05-04 10:16:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:16:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:16:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:17:00 --> The path to the image is not correct.
ERROR - 2018-05-04 10:17:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:17:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:17:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:17:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:17:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:17:10 --> The path to the image is not correct.
ERROR - 2018-05-04 10:17:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:17:18 --> The path to the image is not correct.
ERROR - 2018-05-04 10:17:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:17:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:17:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:20:31 --> The path to the image is not correct.
ERROR - 2018-05-04 10:20:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:20:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:20:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:20:33 --> The path to the image is not correct.
ERROR - 2018-05-04 10:20:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:20:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:20:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:20:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:20:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:20:53 --> The path to the image is not correct.
ERROR - 2018-05-04 10:20:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:21:47 --> The path to the image is not correct.
ERROR - 2018-05-04 10:21:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:21:47 --> The path to the image is not correct.
ERROR - 2018-05-04 10:21:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:21:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:21:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:21:48 --> The path to the image is not correct.
ERROR - 2018-05-04 10:21:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:21:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:21:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:23:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:23:21 --> The path to the image is not correct.
ERROR - 2018-05-04 10:23:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:23:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:28:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:28:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:28:20 --> The path to the image is not correct.
ERROR - 2018-05-04 10:28:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:28:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:28:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:28:53 --> The path to the image is not correct.
ERROR - 2018-05-04 10:28:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:35:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:35:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:35:59 --> The path to the image is not correct.
ERROR - 2018-05-04 10:35:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:39:05 --> The path to the image is not correct.
ERROR - 2018-05-04 10:39:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:39:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:39:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:47:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:47:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:47:20 --> The path to the image is not correct.
ERROR - 2018-05-04 10:47:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:50:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:50:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:50:13 --> The path to the image is not correct.
ERROR - 2018-05-04 10:50:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:50:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:50:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:50:35 --> The path to the image is not correct.
ERROR - 2018-05-04 10:50:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:50:44 --> The path to the image is not correct.
ERROR - 2018-05-04 10:50:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:50:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:50:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:52:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:52:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:52:49 --> The path to the image is not correct.
ERROR - 2018-05-04 10:52:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:53:06 --> The path to the image is not correct.
ERROR - 2018-05-04 10:53:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:53:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:53:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:53:24 --> The path to the image is not correct.
ERROR - 2018-05-04 10:53:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:53:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:53:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 10:56:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:56:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 10:56:34 --> The path to the image is not correct.
ERROR - 2018-05-04 10:56:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:02:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:02:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:02:41 --> The path to the image is not correct.
ERROR - 2018-05-04 11:02:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:03:20 --> The path to the image is not correct.
ERROR - 2018-05-04 11:03:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:03:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:03:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:04:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:04:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:04:14 --> The path to the image is not correct.
ERROR - 2018-05-04 11:04:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:06:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:06:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:06:10 --> The path to the image is not correct.
ERROR - 2018-05-04 11:06:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:06:22 --> The path to the image is not correct.
ERROR - 2018-05-04 11:06:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:06:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:06:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:06:39 --> The path to the image is not correct.
ERROR - 2018-05-04 11:06:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:06:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:06:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:06:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:06:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:06:52 --> The path to the image is not correct.
ERROR - 2018-05-04 11:06:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:07:17 --> The path to the image is not correct.
ERROR - 2018-05-04 11:07:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:07:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:07:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:09:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:09:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:09:29 --> The path to the image is not correct.
ERROR - 2018-05-04 11:09:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:10:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:10:38 --> The path to the image is not correct.
ERROR - 2018-05-04 11:10:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:13:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:13:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:13:25 --> The path to the image is not correct.
ERROR - 2018-05-04 11:13:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:13:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:13:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:13:36 --> The path to the image is not correct.
ERROR - 2018-05-04 11:13:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:17:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:17:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:17:33 --> The path to the image is not correct.
ERROR - 2018-05-04 11:17:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:18:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:18:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:18:19 --> The path to the image is not correct.
ERROR - 2018-05-04 11:18:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:19:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:19:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:19:23 --> The path to the image is not correct.
ERROR - 2018-05-04 11:19:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:20:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:20:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:20:49 --> The path to the image is not correct.
ERROR - 2018-05-04 11:20:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:24:18 --> The path to the image is not correct.
ERROR - 2018-05-04 11:24:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:24:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:24:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:24:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:24:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:24:44 --> The path to the image is not correct.
ERROR - 2018-05-04 11:24:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:25:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:25:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:25:41 --> The path to the image is not correct.
ERROR - 2018-05-04 11:25:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:25:50 --> The path to the image is not correct.
ERROR - 2018-05-04 11:25:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:25:50 --> The path to the image is not correct.
ERROR - 2018-05-04 11:25:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:25:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:25:51 --> The path to the image is not correct.
ERROR - 2018-05-04 11:25:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:25:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:25:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:30:19 --> 404 Page Not Found: Public/upload
ERROR - 2018-05-04 11:30:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:30:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:30:20 --> The path to the image is not correct.
ERROR - 2018-05-04 11:30:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:30:37 --> The path to the image is not correct.
ERROR - 2018-05-04 11:30:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:30:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:30:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:31:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:31:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:31:43 --> The path to the image is not correct.
ERROR - 2018-05-04 11:31:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:34:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:34:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:34:33 --> The path to the image is not correct.
ERROR - 2018-05-04 11:34:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-04 11:35:10 --> The path to the image is not correct.
ERROR - 2018-05-04 11:35:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:35:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-05-04 11:35:10 --> Your server does not support the GD function required to process this type of image.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-09 02:48:25 --> The path to the image is not correct.
ERROR - 2018-07-09 02:48:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:48:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 02:48:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 02:53:58 --> The path to the image is not correct.
ERROR - 2018-07-09 02:53:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:55:16 --> The path to the image is not correct.
ERROR - 2018-07-09 02:55:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:55:19 --> The path to the image is not correct.
ERROR - 2018-07-09 02:55:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:55:57 --> The path to the image is not correct.
ERROR - 2018-07-09 02:55:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:58:03 --> The path to the image is not correct.
ERROR - 2018-07-09 02:58:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:58:21 --> The path to the image is not correct.
ERROR - 2018-07-09 02:58:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:58:25 --> The path to the image is not correct.
ERROR - 2018-07-09 02:58:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:58:29 --> The path to the image is not correct.
ERROR - 2018-07-09 02:58:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:58:34 --> The path to the image is not correct.
ERROR - 2018-07-09 02:58:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:58:36 --> The path to the image is not correct.
ERROR - 2018-07-09 02:58:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 02:58:39 --> The path to the image is not correct.
ERROR - 2018-07-09 02:58:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:00:14 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:00:14 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:00:14 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:00:14 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:00:14 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:00:17 --> The path to the image is not correct.
ERROR - 2018-07-09 03:00:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:00:21 --> The path to the image is not correct.
ERROR - 2018-07-09 03:00:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:12:06 --> The path to the image is not correct.
ERROR - 2018-07-09 03:12:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:12:08 --> The path to the image is not correct.
ERROR - 2018-07-09 03:12:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:26:46 --> The path to the image is not correct.
ERROR - 2018-07-09 03:26:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:26:49 --> The path to the image is not correct.
ERROR - 2018-07-09 03:26:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:26:53 --> The path to the image is not correct.
ERROR - 2018-07-09 03:26:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:26:53 --> The path to the image is not correct.
ERROR - 2018-07-09 03:26:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:30:48 --> The path to the image is not correct.
ERROR - 2018-07-09 03:30:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:30:49 --> The path to the image is not correct.
ERROR - 2018-07-09 03:30:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:30:49 --> The path to the image is not correct.
ERROR - 2018-07-09 03:30:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:30:49 --> The path to the image is not correct.
ERROR - 2018-07-09 03:30:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:30:50 --> The path to the image is not correct.
ERROR - 2018-07-09 03:30:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:30:54 --> The path to the image is not correct.
ERROR - 2018-07-09 03:30:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:33:22 --> The path to the image is not correct.
ERROR - 2018-07-09 03:33:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:33:25 --> The path to the image is not correct.
ERROR - 2018-07-09 03:33:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:33:33 --> The path to the image is not correct.
ERROR - 2018-07-09 03:33:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:34:06 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:34:06 --> The path to the image is not correct.
ERROR - 2018-07-09 03:34:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:40:59 --> Severity: Parsing Error --> syntax error, unexpected '$result' (T_VARIABLE) D:\xampp\htdocs\project-transport\application\models\Report_model.php 110
ERROR - 2018-07-09 03:41:07 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:41:07 --> The path to the image is not correct.
ERROR - 2018-07-09 03:41:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:41:12 --> The path to the image is not correct.
ERROR - 2018-07-09 03:41:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:41:17 --> Query error: Column 'report_id' in where clause is ambiguous - Invalid query: SELECT `rc`.*, `ci`.`item_name`
FROM `report_checklist` `rc`
JOIN `checklist_items` `ci` ON `ci`.`id` = `rc`.`checklist_item_id`
JOIN `report_images` `ri` ON `ri`.`report_checklist_id` = `rc`.`checklist_item_id`
WHERE `report_id` = '34'
ERROR - 2018-07-09 03:42:27 --> Query error: Column 'report_id' in where clause is ambiguous - Invalid query: SELECT `rc`.*, `ci`.`item_name`, `ri`.`image_path`, `ri`.`image_name`
FROM `report_checklist` `rc`
JOIN `checklist_items` `ci` ON `ci`.`id` = `rc`.`checklist_item_id`
JOIN `report_images` `ri` ON `ri`.`report_checklist_id` = `rc`.`checklist_item_id`
WHERE `report_id` = '34'
ERROR - 2018-07-09 03:42:27 --> Query error: Column 'report_id' in where clause is ambiguous - Invalid query: SELECT `rc`.*, `ci`.`item_name`, `ri`.`image_path`, `ri`.`image_name`
FROM `report_checklist` `rc`
JOIN `checklist_items` `ci` ON `ci`.`id` = `rc`.`checklist_item_id`
JOIN `report_images` `ri` ON `ri`.`report_checklist_id` = `rc`.`checklist_item_id`
WHERE `report_id` = '34'
ERROR - 2018-07-09 03:42:27 --> Query error: Column 'report_id' in where clause is ambiguous - Invalid query: SELECT `rc`.*, `ci`.`item_name`, `ri`.`image_path`, `ri`.`image_name`
FROM `report_checklist` `rc`
JOIN `checklist_items` `ci` ON `ci`.`id` = `rc`.`checklist_item_id`
JOIN `report_images` `ri` ON `ri`.`report_checklist_id` = `rc`.`checklist_item_id`
WHERE `report_id` = '34'
ERROR - 2018-07-09 03:42:28 --> Query error: Column 'report_id' in where clause is ambiguous - Invalid query: SELECT `rc`.*, `ci`.`item_name`, `ri`.`image_path`, `ri`.`image_name`
FROM `report_checklist` `rc`
JOIN `checklist_items` `ci` ON `ci`.`id` = `rc`.`checklist_item_id`
JOIN `report_images` `ri` ON `ri`.`report_checklist_id` = `rc`.`checklist_item_id`
WHERE `report_id` = '34'
ERROR - 2018-07-09 03:42:48 --> The path to the image is not correct.
ERROR - 2018-07-09 03:42:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:43:12 --> Query error: Column 'report_id' in where clause is ambiguous - Invalid query: SELECT `rc`.*, `ci`.`item_name`, `ri`.`image_path`, `ri`.`image_name`
FROM `report_checklist` `rc`
JOIN `checklist_items` `ci` ON `ci`.`id` = `rc`.`checklist_item_id`
JOIN `report_images` `ri` ON `ri`.`report_checklist_id` = `ci`.`id`
WHERE `report_id` = '34'
ERROR - 2018-07-09 03:43:24 --> The path to the image is not correct.
ERROR - 2018-07-09 03:43:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:43:30 --> The path to the image is not correct.
ERROR - 2018-07-09 03:43:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:45:10 --> The path to the image is not correct.
ERROR - 2018-07-09 03:45:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:50:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:50:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:50:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:50:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:50:14 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 03:53:17 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:53:29 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined property: stdClass::$notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 155
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 3 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 11 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 12 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 13 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 14 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 15 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 16 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:29 --> Severity: Notice --> Undefined offset: 24 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:30 --> Severity: Notice --> Undefined offset: 25 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:30 --> Severity: Notice --> Undefined offset: 26 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:30 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 203
ERROR - 2018-07-09 03:53:30 --> The path to the image is not correct.
ERROR - 2018-07-09 03:53:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:55:25 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:55:25 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-07-09 03:55:25 --> Severity: Notice --> Undefined property: stdClass::$notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-07-09 03:55:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 155
ERROR - 2018-07-09 03:55:25 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 03:55:25 --> The path to the image is not correct.
ERROR - 2018-07-09 03:55:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:55:25 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:55:25 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-07-09 03:55:25 --> Severity: Notice --> Undefined property: stdClass::$notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-07-09 03:55:25 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 155
ERROR - 2018-07-09 03:55:25 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 03:55:25 --> The path to the image is not correct.
ERROR - 2018-07-09 03:55:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:55:52 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:55:52 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-07-09 03:55:52 --> Severity: Notice --> Undefined property: stdClass::$notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-07-09 03:55:52 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 155
ERROR - 2018-07-09 03:55:52 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 03:55:53 --> The path to the image is not correct.
ERROR - 2018-07-09 03:55:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:55:53 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:55:53 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-07-09 03:55:53 --> Severity: Notice --> Undefined property: stdClass::$notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-07-09 03:55:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 155
ERROR - 2018-07-09 03:55:53 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 03:55:53 --> The path to the image is not correct.
ERROR - 2018-07-09 03:55:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:55:53 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:55:53 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-07-09 03:55:53 --> Severity: Notice --> Undefined property: stdClass::$notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-07-09 03:55:53 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 155
ERROR - 2018-07-09 03:55:53 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 03:55:53 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:55:53 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 155
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 03:55:54 --> The path to the image is not correct.
ERROR - 2018-07-09 03:55:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:55:54 --> The path to the image is not correct.
ERROR - 2018-07-09 03:55:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:55:54 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 155
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 03:55:54 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 155
ERROR - 2018-07-09 03:55:54 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 03:55:54 --> The path to the image is not correct.
ERROR - 2018-07-09 03:55:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:57:02 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:57:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:57:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:57:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:57:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:57:26 --> Severity: Warning --> Creating default object from empty value D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 03:57:26 --> Severity: Notice --> Undefined property: stdClass::$display_name D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-07-09 03:57:26 --> Severity: Notice --> Undefined property: stdClass::$notes D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 153
ERROR - 2018-07-09 03:57:26 --> Severity: Notice --> Undefined property: stdClass::$status D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 155
ERROR - 2018-07-09 03:57:26 --> Severity: Notice --> Undefined property: stdClass::$created D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 03:57:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 03:57:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 03:57:27 --> The path to the image is not correct.
ERROR - 2018-07-09 03:57:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:58:03 --> The path to the image is not correct.
ERROR - 2018-07-09 03:58:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 03:59:21 --> Severity: Notice --> Undefined variable: result_report_images D:\xampp\htdocs\project-transport\application\models\Report_model.php 116
ERROR - 2018-07-09 04:06:34 --> The path to the image is not correct.
ERROR - 2018-07-09 04:06:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:06:34 --> The path to the image is not correct.
ERROR - 2018-07-09 04:06:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:06:34 --> The path to the image is not correct.
ERROR - 2018-07-09 04:06:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:06:46 --> The path to the image is not correct.
ERROR - 2018-07-09 04:06:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:06:50 --> The path to the image is not correct.
ERROR - 2018-07-09 04:06:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:06:54 --> The path to the image is not correct.
ERROR - 2018-07-09 04:06:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:07:22 --> The path to the image is not correct.
ERROR - 2018-07-09 04:07:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:08:31 --> The path to the image is not correct.
ERROR - 2018-07-09 04:08:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:08:34 --> The path to the image is not correct.
ERROR - 2018-07-09 04:08:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:08:34 --> The path to the image is not correct.
ERROR - 2018-07-09 04:08:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:11:54 --> The path to the image is not correct.
ERROR - 2018-07-09 04:11:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:12:27 --> The path to the image is not correct.
ERROR - 2018-07-09 04:12:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:12:49 --> The path to the image is not correct.
ERROR - 2018-07-09 04:12:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:12:58 --> The path to the image is not correct.
ERROR - 2018-07-09 04:12:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:14:27 --> The path to the image is not correct.
ERROR - 2018-07-09 04:14:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:14:30 --> The path to the image is not correct.
ERROR - 2018-07-09 04:14:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:14:30 --> The path to the image is not correct.
ERROR - 2018-07-09 04:14:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:14:31 --> The path to the image is not correct.
ERROR - 2018-07-09 04:14:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:14:31 --> The path to the image is not correct.
ERROR - 2018-07-09 04:14:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:14:32 --> The path to the image is not correct.
ERROR - 2018-07-09 04:14:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:14:32 --> The path to the image is not correct.
ERROR - 2018-07-09 04:14:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:14:34 --> The path to the image is not correct.
ERROR - 2018-07-09 04:14:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:15:24 --> The path to the image is not correct.
ERROR - 2018-07-09 04:15:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:15:29 --> The path to the image is not correct.
ERROR - 2018-07-09 04:15:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:15:29 --> The path to the image is not correct.
ERROR - 2018-07-09 04:15:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:15:59 --> The path to the image is not correct.
ERROR - 2018-07-09 04:15:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:15:59 --> The path to the image is not correct.
ERROR - 2018-07-09 04:15:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:16:56 --> The path to the image is not correct.
ERROR - 2018-07-09 04:16:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:17:33 --> The path to the image is not correct.
ERROR - 2018-07-09 04:17:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:17:39 --> The path to the image is not correct.
ERROR - 2018-07-09 04:17:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:17:57 --> The path to the image is not correct.
ERROR - 2018-07-09 04:17:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:30:23 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 04:30:23 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 04:30:23 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 04:30:23 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 04:30:23 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 04:32:03 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 04:32:04 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 04:32:04 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 04:32:04 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 04:32:04 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 04:36:06 --> The path to the image is not correct.
ERROR - 2018-07-09 04:36:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:36:07 --> The path to the image is not correct.
ERROR - 2018-07-09 04:36:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:36:08 --> The path to the image is not correct.
ERROR - 2018-07-09 04:36:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:37:28 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\project-transport\application\models\Report_model.php 115
ERROR - 2018-07-09 04:37:47 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\project-transport\application\models\Report_model.php 115
ERROR - 2018-07-09 04:37:52 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\project-transport\application\models\Report_model.php 115
ERROR - 2018-07-09 04:43:58 --> Severity: Parsing Error --> syntax error, unexpected '$result' (T_VARIABLE) D:\xampp\htdocs\project-transport\application\models\Report_model.php 110
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:25 --> The path to the image is not correct.
ERROR - 2018-07-09 04:44:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:50 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:44:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:15 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:15 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:16 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:16 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:16 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:16 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:16 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:17 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:18 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:45:18 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:46:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:46:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:46:54 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:46:54 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:47:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:47:25 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:47:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:47:26 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:47:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:47:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:47:37 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:47:38 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:48:17 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:17 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:37 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:37 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:37 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:37 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:37 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:37 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:38 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:38 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:38 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:38 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:38 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:38 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:38 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:38 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:38 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:38 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:39 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:39 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:39 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:39 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:48:54 --> The path to the image is not correct.
ERROR - 2018-07-09 04:48:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 04:50:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:50:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:50:29 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:50:29 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:50:50 --> Severity: Error --> Call to undefined function is_empty() D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:50:58 --> Severity: Error --> Call to undefined function isempty() D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:51:42 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:51:42 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 114
ERROR - 2018-07-09 04:53:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:53:10 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:53:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:53:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:53:10 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:53:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:53:10 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:53:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\system\core\Common.php 570
ERROR - 2018-07-09 04:53:10 --> Severity: Error --> Cannot access empty property D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Undefined variable: image_name D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 04:54:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Report_model.php 113
ERROR - 2018-07-09 05:06:29 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\project-transport\application\models\Report_model.php 119
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:34 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 05:12:34 --> The path to the image is not correct.
ERROR - 2018-07-09 05:12:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:12:34 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$fullpath D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 204
ERROR - 2018-07-09 05:12:35 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 05:12:35 --> The path to the image is not correct.
ERROR - 2018-07-09 05:12:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:12:35 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 05:12:52 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 05:12:52 --> The path to the image is not correct.
ERROR - 2018-07-09 05:12:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:12:52 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 05:12:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:12:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:20:26 --> The path to the image is not correct.
ERROR - 2018-07-09 05:20:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:20:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:20:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:08 --> The path to the image is not correct.
ERROR - 2018-07-09 05:21:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:21:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:11 --> The path to the image is not correct.
ERROR - 2018-07-09 05:21:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:16 --> The path to the image is not correct.
ERROR - 2018-07-09 05:21:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:21:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:18 --> The path to the image is not correct.
ERROR - 2018-07-09 05:21:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:21:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:19 --> The path to the image is not correct.
ERROR - 2018-07-09 05:21:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:21:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:42 --> The path to the image is not correct.
ERROR - 2018-07-09 05:21:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:21:42 --> The path to the image is not correct.
ERROR - 2018-07-09 05:21:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:21:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:21:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:23:43 --> The path to the image is not correct.
ERROR - 2018-07-09 05:23:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:23:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:23:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:23:46 --> The path to the image is not correct.
ERROR - 2018-07-09 05:23:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:23:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:23:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:28:16 --> The path to the image is not correct.
ERROR - 2018-07-09 05:28:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:28:16 --> The path to the image is not correct.
ERROR - 2018-07-09 05:28:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:28:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:28:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:28:28 --> The path to the image is not correct.
ERROR - 2018-07-09 05:28:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:28:28 --> The path to the image is not correct.
ERROR - 2018-07-09 05:28:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:28:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:28:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:28:31 --> The path to the image is not correct.
ERROR - 2018-07-09 05:28:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:28:31 --> The path to the image is not correct.
ERROR - 2018-07-09 05:28:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:28:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:28:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:28:33 --> The path to the image is not correct.
ERROR - 2018-07-09 05:28:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:28:34 --> The path to the image is not correct.
ERROR - 2018-07-09 05:28:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:28:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:28:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:30:03 --> The path to the image is not correct.
ERROR - 2018-07-09 05:30:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:30:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:30:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:30:06 --> The path to the image is not correct.
ERROR - 2018-07-09 05:30:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:30:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:30:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Undefined property: stdClass::$item_image D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 05:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 228
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Undefined property: stdClass::$item_image D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 05:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 228
ERROR - 2018-07-09 05:56:22 --> The path to the image is not correct.
ERROR - 2018-07-09 05:56:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-07-09 05:56:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:56:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 141
ERROR - 2018-07-09 05:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-07-09 05:56:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 149
ERROR - 2018-07-09 05:56:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-07-09 05:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-07-09 05:56:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 208
ERROR - 2018-07-09 05:56:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 208
ERROR - 2018-07-09 05:57:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 05:57:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 223
ERROR - 2018-07-09 05:57:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 05:57:23 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 223
ERROR - 2018-07-09 05:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 05:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-07-09 05:57:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-07-09 05:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 05:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-07-09 05:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-07-09 05:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-07-09 05:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 141
ERROR - 2018-07-09 05:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-07-09 05:57:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 149
ERROR - 2018-07-09 05:57:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-07-09 05:57:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-07-09 05:57:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 208
ERROR - 2018-07-09 05:57:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 208
ERROR - 2018-07-09 05:57:24 --> The path to the image is not correct.
ERROR - 2018-07-09 05:57:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:57:52 --> The path to the image is not correct.
ERROR - 2018-07-09 05:57:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:57:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:57:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:57:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:57:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:57:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:58:20 --> The path to the image is not correct.
ERROR - 2018-07-09 05:58:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:58:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:58:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:58:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:58:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:58:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:59:11 --> The path to the image is not correct.
ERROR - 2018-07-09 05:59:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:59:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:59:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:59:12 --> The path to the image is not correct.
ERROR - 2018-07-09 05:59:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:59:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:59:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:59:12 --> The path to the image is not correct.
ERROR - 2018-07-09 05:59:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 05:59:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:59:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:59:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:59:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 05:59:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:05:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:05:51 --> The path to the image is not correct.
ERROR - 2018-07-09 06:05:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:05:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:05:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:05:55 --> The path to the image is not correct.
ERROR - 2018-07-09 06:05:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:05:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:05:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:05:57 --> The path to the image is not correct.
ERROR - 2018-07-09 06:05:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:05:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:05:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:05:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:11 --> The path to the image is not correct.
ERROR - 2018-07-09 06:08:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:08:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:36 --> The path to the image is not correct.
ERROR - 2018-07-09 06:08:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:08:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:36 --> The path to the image is not correct.
ERROR - 2018-07-09 06:08:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:08:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:37 --> The path to the image is not correct.
ERROR - 2018-07-09 06:08:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:08:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:37 --> The path to the image is not correct.
ERROR - 2018-07-09 06:08:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:08:37 --> The path to the image is not correct.
ERROR - 2018-07-09 06:08:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:08:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:08:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:15:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:15:36 --> The path to the image is not correct.
ERROR - 2018-07-09 06:15:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:15:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:15:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:15:41 --> The path to the image is not correct.
ERROR - 2018-07-09 06:15:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:15:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:15:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:15:42 --> The path to the image is not correct.
ERROR - 2018-07-09 06:15:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:15:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:15:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:32 --> The path to the image is not correct.
ERROR - 2018-07-09 06:16:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:16:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:34 --> The path to the image is not correct.
ERROR - 2018-07-09 06:16:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:16:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:36 --> The path to the image is not correct.
ERROR - 2018-07-09 06:16:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:16:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:37 --> The path to the image is not correct.
ERROR - 2018-07-09 06:16:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:16:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:39 --> The path to the image is not correct.
ERROR - 2018-07-09 06:16:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:16:39 --> The path to the image is not correct.
ERROR - 2018-07-09 06:16:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:16:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:16:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:25:34 --> Severity: Parsing Error --> syntax error, unexpected '$result' (T_VARIABLE) D:\xampp\htdocs\project-transport\application\models\Report_model.php 122
ERROR - 2018-07-09 06:25:51 --> Severity: Notice --> Undefined variable: report_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 220
ERROR - 2018-07-09 06:25:51 --> Severity: Notice --> Undefined variable: report_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 220
ERROR - 2018-07-09 06:25:51 --> The path to the image is not correct.
ERROR - 2018-07-09 06:25:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:25:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:25:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:26:29 --> The path to the image is not correct.
ERROR - 2018-07-09 06:26:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:26:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:26:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:26:46 --> The path to the image is not correct.
ERROR - 2018-07-09 06:26:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:26:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:26:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:27:29 --> The path to the image is not correct.
ERROR - 2018-07-09 06:27:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:27:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:27:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:27:32 --> The path to the image is not correct.
ERROR - 2018-07-09 06:27:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:27:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:27:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:27:54 --> The path to the image is not correct.
ERROR - 2018-07-09 06:27:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:27:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:27:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:28:06 --> The path to the image is not correct.
ERROR - 2018-07-09 06:28:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:28:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:28:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:28:17 --> The path to the image is not correct.
ERROR - 2018-07-09 06:28:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:28:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:28:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:29:27 --> The path to the image is not correct.
ERROR - 2018-07-09 06:29:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:29:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:29:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:29:47 --> The path to the image is not correct.
ERROR - 2018-07-09 06:29:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:29:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:29:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:50:40 --> The path to the image is not correct.
ERROR - 2018-07-09 06:50:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:50:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:50:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:50:41 --> 404 Page Not Found: app/Reports/report_images
ERROR - 2018-07-09 06:51:07 --> The path to the image is not correct.
ERROR - 2018-07-09 06:51:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:51:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:51:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:51:11 --> 404 Page Not Found: app/Reports/report_images
ERROR - 2018-07-09 06:51:33 --> The path to the image is not correct.
ERROR - 2018-07-09 06:51:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:51:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:51:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:51:34 --> Severity: Notice --> Undefined property: Report::$report D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 82
ERROR - 2018-07-09 06:51:34 --> Severity: Error --> Call to a member function report_checklist_images() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 82
ERROR - 2018-07-09 06:52:00 --> The path to the image is not correct.
ERROR - 2018-07-09 06:52:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:52:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:52:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:53:05 --> The path to the image is not correct.
ERROR - 2018-07-09 06:53:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:53:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:53:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:54:01 --> The path to the image is not correct.
ERROR - 2018-07-09 06:54:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:54:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:54:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:54:28 --> The path to the image is not correct.
ERROR - 2018-07-09 06:54:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:54:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:54:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:54:45 --> The path to the image is not correct.
ERROR - 2018-07-09 06:54:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:55:31 --> The path to the image is not correct.
ERROR - 2018-07-09 06:55:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:55:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:55:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:55:32 --> The path to the image is not correct.
ERROR - 2018-07-09 06:55:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:55:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:55:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:55:46 --> The path to the image is not correct.
ERROR - 2018-07-09 06:55:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:55:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:55:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:57:43 --> The path to the image is not correct.
ERROR - 2018-07-09 06:57:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:57:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:57:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:58:07 --> The path to the image is not correct.
ERROR - 2018-07-09 06:58:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:58:07 --> The path to the image is not correct.
ERROR - 2018-07-09 06:58:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:58:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:58:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:58:08 --> The path to the image is not correct.
ERROR - 2018-07-09 06:58:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 06:58:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 06:58:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:00:22 --> The path to the image is not correct.
ERROR - 2018-07-09 07:00:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:44:45 --> The path to the image is not correct.
ERROR - 2018-07-09 07:44:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:44:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:44:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:45:44 --> The path to the image is not correct.
ERROR - 2018-07-09 07:45:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:45:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:45:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:45:46 --> The path to the image is not correct.
ERROR - 2018-07-09 07:45:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:45:46 --> The path to the image is not correct.
ERROR - 2018-07-09 07:45:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:45:46 --> The path to the image is not correct.
ERROR - 2018-07-09 07:45:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:45:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:45:47 --> The path to the image is not correct.
ERROR - 2018-07-09 07:45:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:45:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:45:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:47:34 --> The path to the image is not correct.
ERROR - 2018-07-09 07:47:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:47:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:47:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:49:47 --> The path to the image is not correct.
ERROR - 2018-07-09 07:49:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:49:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:49:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:50:19 --> The path to the image is not correct.
ERROR - 2018-07-09 07:50:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:50:19 --> The path to the image is not correct.
ERROR - 2018-07-09 07:50:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:50:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:50:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:52:39 --> The path to the image is not correct.
ERROR - 2018-07-09 07:52:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:52:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:52:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:53:01 --> The path to the image is not correct.
ERROR - 2018-07-09 07:53:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:53:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:53:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:54:02 --> The path to the image is not correct.
ERROR - 2018-07-09 07:54:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:54:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:54:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:54:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:54:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:54:49 --> The path to the image is not correct.
ERROR - 2018-07-09 07:54:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:54:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:54:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:55:31 --> The path to the image is not correct.
ERROR - 2018-07-09 07:55:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 07:55:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:55:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:55:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 07:55:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:00:19 --> The path to the image is not correct.
ERROR - 2018-07-09 08:00:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:00:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:00:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:00:21 --> The path to the image is not correct.
ERROR - 2018-07-09 08:00:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:00:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:00:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:01:17 --> The path to the image is not correct.
ERROR - 2018-07-09 08:01:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:01:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:01:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:01:38 --> The path to the image is not correct.
ERROR - 2018-07-09 08:01:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:01:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:01:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:01:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:01:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:02:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 08:02:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 08:02:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 08:02:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 08:02:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 08:03:38 --> The path to the image is not correct.
ERROR - 2018-07-09 08:03:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:03:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:03:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:02 --> The path to the image is not correct.
ERROR - 2018-07-09 08:05:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:05:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:50 --> The path to the image is not correct.
ERROR - 2018-07-09 08:05:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:05:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:50 --> The path to the image is not correct.
ERROR - 2018-07-09 08:05:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:05:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:50 --> The path to the image is not correct.
ERROR - 2018-07-09 08:05:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:05:50 --> The path to the image is not correct.
ERROR - 2018-07-09 08:05:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:05:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:51 --> The path to the image is not correct.
ERROR - 2018-07-09 08:05:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:05:51 --> The path to the image is not correct.
ERROR - 2018-07-09 08:05:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:05:51 --> The path to the image is not correct.
ERROR - 2018-07-09 08:05:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:05:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:52 --> The path to the image is not correct.
ERROR - 2018-07-09 08:05:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:05:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:05:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:06:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:06:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:07:50 --> The path to the image is not correct.
ERROR - 2018-07-09 08:07:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:07:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:07:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:07:59 --> The path to the image is not correct.
ERROR - 2018-07-09 08:07:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:08:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:08:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:09:00 --> The path to the image is not correct.
ERROR - 2018-07-09 08:09:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:09:00 --> The path to the image is not correct.
ERROR - 2018-07-09 08:09:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:09:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:09:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:09:00 --> The path to the image is not correct.
ERROR - 2018-07-09 08:09:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:09:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:09:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:10:16 --> The path to the image is not correct.
ERROR - 2018-07-09 08:10:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:10:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:10:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:10:51 --> The path to the image is not correct.
ERROR - 2018-07-09 08:10:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:10:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:10:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:11:10 --> The path to the image is not correct.
ERROR - 2018-07-09 08:11:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:11:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:11:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:12:41 --> The path to the image is not correct.
ERROR - 2018-07-09 08:12:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:12:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:12:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:12:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:12:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:13:03 --> The path to the image is not correct.
ERROR - 2018-07-09 08:13:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:13:03 --> The path to the image is not correct.
ERROR - 2018-07-09 08:13:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:13:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:13:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:13:48 --> The path to the image is not correct.
ERROR - 2018-07-09 08:13:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:13:49 --> The path to the image is not correct.
ERROR - 2018-07-09 08:13:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:13:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:13:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:14:07 --> The path to the image is not correct.
ERROR - 2018-07-09 08:14:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:14:09 --> The path to the image is not correct.
ERROR - 2018-07-09 08:14:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:14:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:14:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:14:45 --> The path to the image is not correct.
ERROR - 2018-07-09 08:14:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:14:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:14:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:14:59 --> The path to the image is not correct.
ERROR - 2018-07-09 08:14:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:14:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:14:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:15:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:15:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:16:21 --> The path to the image is not correct.
ERROR - 2018-07-09 08:16:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:16:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:16:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:16:33 --> The path to the image is not correct.
ERROR - 2018-07-09 08:16:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:16:33 --> The path to the image is not correct.
ERROR - 2018-07-09 08:16:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:16:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:16:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:16:58 --> The path to the image is not correct.
ERROR - 2018-07-09 08:16:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:16:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:16:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:18:28 --> The path to the image is not correct.
ERROR - 2018-07-09 08:18:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:18:29 --> The path to the image is not correct.
ERROR - 2018-07-09 08:18:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:18:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:18:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:19:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:19:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:20:14 --> The path to the image is not correct.
ERROR - 2018-07-09 08:20:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:20:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:20:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:20:54 --> The path to the image is not correct.
ERROR - 2018-07-09 08:20:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:20:54 --> The path to the image is not correct.
ERROR - 2018-07-09 08:20:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:20:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:20:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:20:57 --> The path to the image is not correct.
ERROR - 2018-07-09 08:20:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:20:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:20:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:20:59 --> The path to the image is not correct.
ERROR - 2018-07-09 08:20:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:20:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:20:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:21:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:21:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:22:27 --> The path to the image is not correct.
ERROR - 2018-07-09 08:22:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:22:31 --> 404 Page Not Found: Thumbs/report
ERROR - 2018-07-09 08:24:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:24:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:24:36 --> The path to the image is not correct.
ERROR - 2018-07-09 08:24:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:24:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:24:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:24:38 --> The path to the image is not correct.
ERROR - 2018-07-09 08:24:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:24:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:24:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:24:40 --> The path to the image is not correct.
ERROR - 2018-07-09 08:24:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:24:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:24:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:24:42 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-09 08:24:42 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-09 08:24:42 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-09 08:24:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-09 08:24:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-09 08:24:42 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-07-09 08:24:42 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/report/2018/07): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-07-09 08:24:42 --> The provided image is not valid.
ERROR - 2018-07-09 08:24:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-07-09 08:24:45 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-09 08:24:45 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-09 08:24:45 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-09 08:24:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-09 08:24:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-09 08:24:45 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-07-09 08:24:45 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/report/2018/07): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-07-09 08:24:45 --> The provided image is not valid.
ERROR - 2018-07-09 08:24:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-07-09 08:25:31 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-09 08:25:31 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-07-09 08:25:31 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-07-09 08:25:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-07-09 08:25:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-07-09 08:25:31 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-07-09 08:25:31 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/report/2018/07): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-07-09 08:25:31 --> The provided image is not valid.
ERROR - 2018-07-09 08:25:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-07-09 08:25:34 --> The path to the image is not correct.
ERROR - 2018-07-09 08:25:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:28:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 246
ERROR - 2018-07-09 08:28:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:28:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 246
ERROR - 2018-07-09 08:28:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:28:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 246
ERROR - 2018-07-09 08:28:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:28:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 246
ERROR - 2018-07-09 08:28:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:28:37 --> The path to the image is not correct.
ERROR - 2018-07-09 08:28:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:28:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:29:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:29:59 --> The path to the image is not correct.
ERROR - 2018-07-09 08:29:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:30:45 --> The path to the image is not correct.
ERROR - 2018-07-09 08:30:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:30:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:30:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:30:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:30:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:30:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:30:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:32:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:32:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:32:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:32:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:32:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:32:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:32:40 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:32:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 223
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 223
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 223
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 223
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 223
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 223
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 223
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 222
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 223
ERROR - 2018-07-09 08:33:52 --> The path to the image is not correct.
ERROR - 2018-07-09 08:33:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 141
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 149
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-07-09 08:33:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-07-09 08:33:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 208
ERROR - 2018-07-09 08:33:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 208
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 96
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 102
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 132
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 141
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 145
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 149
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-07-09 08:33:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 163
ERROR - 2018-07-09 08:33:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 208
ERROR - 2018-07-09 08:33:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 208
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:34:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 248
ERROR - 2018-07-09 08:34:35 --> The path to the image is not correct.
ERROR - 2018-07-09 08:34:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:34:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:34:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:34:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:34:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:34:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:34:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:34:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:34:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:34:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:34:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:34:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:34:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:34:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:34:56 --> The path to the image is not correct.
ERROR - 2018-07-09 08:34:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 6
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 128
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 148
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 152
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 156
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 158
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 167
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 171
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 175
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:34:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 189
ERROR - 2018-07-09 08:34:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:34:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 234
ERROR - 2018-07-09 08:34:58 --> The path to the image is not correct.
ERROR - 2018-07-09 08:34:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:36:49 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:36:49 --> Severity: Notice --> Object of class stdClass to string conversion D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:36:49 --> Severity: Notice --> Undefined variable: Object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:36:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:36:49 --> The path to the image is not correct.
ERROR - 2018-07-09 08:36:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:36:56 --> The path to the image is not correct.
ERROR - 2018-07-09 08:36:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:37:27 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 247
ERROR - 2018-07-09 08:37:27 --> The path to the image is not correct.
ERROR - 2018-07-09 08:37:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:37:49 --> The path to the image is not correct.
ERROR - 2018-07-09 08:37:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:38:06 --> The path to the image is not correct.
ERROR - 2018-07-09 08:38:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:38:12 --> The path to the image is not correct.
ERROR - 2018-07-09 08:38:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:38:37 --> The path to the image is not correct.
ERROR - 2018-07-09 08:38:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:55:15 --> The path to the image is not correct.
ERROR - 2018-07-09 08:55:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:55:17 --> The path to the image is not correct.
ERROR - 2018-07-09 08:55:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 08:59:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 08:59:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:05:12 --> Severity: Notice --> Undefined property: stdClass::$report_checklist_id D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 245
ERROR - 2018-07-09 09:05:12 --> The path to the image is not correct.
ERROR - 2018-07-09 09:05:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:05:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:05:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:05:39 --> The path to the image is not correct.
ERROR - 2018-07-09 09:05:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:05:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:05:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:05:51 --> The path to the image is not correct.
ERROR - 2018-07-09 09:05:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:05:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:05:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:05:53 --> 404 Page Not Found: app/Report/view_image
ERROR - 2018-07-09 09:05:56 --> 404 Page Not Found: app/Report/view_image
ERROR - 2018-07-09 09:07:20 --> The path to the image is not correct.
ERROR - 2018-07-09 09:07:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:07:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:07:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:07:22 --> 404 Page Not Found: app/Report/view_image
ERROR - 2018-07-09 09:07:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 09:07:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 09:07:57 --> The path to the image is not correct.
ERROR - 2018-07-09 09:07:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:07:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:07:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:08:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:08:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:09:26 --> The path to the image is not correct.
ERROR - 2018-07-09 09:09:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:09:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:09:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:09:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:09:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:10:19 --> The path to the image is not correct.
ERROR - 2018-07-09 09:10:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:10:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:10:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:10:20 --> The path to the image is not correct.
ERROR - 2018-07-09 09:10:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:10:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:10:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:10:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:10:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:10:51 --> The path to the image is not correct.
ERROR - 2018-07-09 09:10:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:10:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:10:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:14:59 --> The path to the image is not correct.
ERROR - 2018-07-09 09:14:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:15:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:15:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:15:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:15:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:15:55 --> The path to the image is not correct.
ERROR - 2018-07-09 09:15:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:15:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:15:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:16:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:16:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:16:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:16:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:16:26 --> The path to the image is not correct.
ERROR - 2018-07-09 09:16:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:16:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:16:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:16:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:16:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:17:47 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\apimobile\login.php 29
ERROR - 2018-07-09 09:17:47 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\apimobile\login.php 30
ERROR - 2018-07-09 09:18:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 09:18:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 09:20:59 --> The path to the image is not correct.
ERROR - 2018-07-09 09:20:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:20:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:20:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:21:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:21:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:15 --> The path to the image is not correct.
ERROR - 2018-07-09 09:22:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:22:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:32 --> The path to the image is not correct.
ERROR - 2018-07-09 09:22:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:22:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:34 --> The path to the image is not correct.
ERROR - 2018-07-09 09:22:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:22:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:59 --> The path to the image is not correct.
ERROR - 2018-07-09 09:22:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:22:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:22:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:23:08 --> The path to the image is not correct.
ERROR - 2018-07-09 09:23:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:23:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:23:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:24:39 --> The path to the image is not correct.
ERROR - 2018-07-09 09:24:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:24:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:24:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:24:43 --> The path to the image is not correct.
ERROR - 2018-07-09 09:24:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:24:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:24:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:24:46 --> The path to the image is not correct.
ERROR - 2018-07-09 09:24:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:24:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:24:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:24:51 --> The path to the image is not correct.
ERROR - 2018-07-09 09:24:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:24:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:24:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:35:09 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\apimobile\login.php 29
ERROR - 2018-07-09 09:35:09 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\apimobile\login.php 30
ERROR - 2018-07-09 09:36:21 --> Severity: Notice --> Undefined property: stdClass::$username D:\xampp\htdocs\project-transport\application\controllers\apimobile\login.php 29
ERROR - 2018-07-09 09:36:21 --> Severity: Notice --> Undefined property: stdClass::$password D:\xampp\htdocs\project-transport\application\controllers\apimobile\login.php 30
ERROR - 2018-07-09 09:39:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 09:39:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 09:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 09:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 09:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 09:44:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 09:49:35 --> The path to the image is not correct.
ERROR - 2018-07-09 09:49:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:49:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:49:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:49:37 --> The path to the image is not correct.
ERROR - 2018-07-09 09:49:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 09:49:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 09:49:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:18:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 10:18:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 10:22:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 10:22:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 10:22:30 --> The path to the image is not correct.
ERROR - 2018-07-09 10:22:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:22:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:33 --> The path to the image is not correct.
ERROR - 2018-07-09 10:22:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:22:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 10:22:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 10:22:47 --> The path to the image is not correct.
ERROR - 2018-07-09 10:22:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:22:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:50 --> The path to the image is not correct.
ERROR - 2018-07-09 10:22:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:22:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:56 --> The path to the image is not correct.
ERROR - 2018-07-09 10:22:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:22:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:22:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:23:13 --> The path to the image is not correct.
ERROR - 2018-07-09 10:23:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:23:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:23:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:23:18 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 10:23:18 --> The path to the image is not correct.
ERROR - 2018-07-09 10:23:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:23:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:23:43 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 10:23:43 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 10:23:44 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 10:23:44 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 10:23:44 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-09 10:34:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 10:34:07 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 10:37:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 10:37:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 10:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 10:38:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 10:39:13 --> The path to the image is not correct.
ERROR - 2018-07-09 10:39:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:39:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:16 --> The path to the image is not correct.
ERROR - 2018-07-09 10:39:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:39:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:20 --> The path to the image is not correct.
ERROR - 2018-07-09 10:39:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:39:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:21 --> The path to the image is not correct.
ERROR - 2018-07-09 10:39:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:39:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:24 --> The path to the image is not correct.
ERROR - 2018-07-09 10:39:24 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:39:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:26 --> The path to the image is not correct.
ERROR - 2018-07-09 10:39:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:39:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:37 --> The path to the image is not correct.
ERROR - 2018-07-09 10:39:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 10:39:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:39:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 10:53:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 10:53:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 10:54:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 10:54:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 10:55:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 25
ERROR - 2018-07-09 10:55:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\controllers\api\Report.php 26
ERROR - 2018-07-09 11:10:31 --> The path to the image is not correct.
ERROR - 2018-07-09 11:10:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:10:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:10:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:10:34 --> The path to the image is not correct.
ERROR - 2018-07-09 11:10:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:10:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:10:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:10:40 --> The path to the image is not correct.
ERROR - 2018-07-09 11:10:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:10:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:10:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:10:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:10:45 --> The path to the image is not correct.
ERROR - 2018-07-09 11:10:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:10:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:10:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:10:48 --> The path to the image is not correct.
ERROR - 2018-07-09 11:10:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:10:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:10:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:14:37 --> The path to the image is not correct.
ERROR - 2018-07-09 11:14:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:14:38 --> The path to the image is not correct.
ERROR - 2018-07-09 11:14:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:14:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:14:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:14:44 --> The path to the image is not correct.
ERROR - 2018-07-09 11:14:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:14:44 --> The path to the image is not correct.
ERROR - 2018-07-09 11:14:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:14:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:14:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:14:49 --> The path to the image is not correct.
ERROR - 2018-07-09 11:14:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:14:49 --> The path to the image is not correct.
ERROR - 2018-07-09 11:14:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:14:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:14:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:18:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:19:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:19:07 --> The path to the image is not correct.
ERROR - 2018-07-09 11:19:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:19:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:19:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:19:10 --> The path to the image is not correct.
ERROR - 2018-07-09 11:19:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:19:10 --> The path to the image is not correct.
ERROR - 2018-07-09 11:19:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:19:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:19:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:24:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:24:07 --> The path to the image is not correct.
ERROR - 2018-07-09 11:24:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:24:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:24:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:24:09 --> The path to the image is not correct.
ERROR - 2018-07-09 11:24:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:24:09 --> The path to the image is not correct.
ERROR - 2018-07-09 11:24:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:24:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:24:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:40:23 --> The path to the image is not correct.
ERROR - 2018-07-09 11:40:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:40:23 --> The path to the image is not correct.
ERROR - 2018-07-09 11:40:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:40:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:40:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:41:29 --> The path to the image is not correct.
ERROR - 2018-07-09 11:41:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:41:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:41:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:45:29 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ':' D:\xampp\htdocs\project-transport\application\views\backend\page\users\view.php 16
ERROR - 2018-07-09 11:45:29 --> The path to the image is not correct.
ERROR - 2018-07-09 11:45:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:45:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:45:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:45:40 --> The path to the image is not correct.
ERROR - 2018-07-09 11:45:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:45:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:45:48 --> Severity: Notice --> Undefined property: stdClass::$no_accounts D:\xampp\htdocs\project-transport\application\views\backend\page\users\view.php 16
ERROR - 2018-07-09 11:45:48 --> The path to the image is not correct.
ERROR - 2018-07-09 11:45:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:45:48 --> The path to the image is not correct.
ERROR - 2018-07-09 11:45:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:45:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:45:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:46:08 --> Severity: Notice --> Undefined property: stdClass::$no_accounts D:\xampp\htdocs\project-transport\application\views\backend\page\users\view.php 11
ERROR - 2018-07-09 11:46:08 --> The path to the image is not correct.
ERROR - 2018-07-09 11:46:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:46:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:46:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:46:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:46:22 --> The path to the image is not correct.
ERROR - 2018-07-09 11:46:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:46:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:46:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:46:26 --> The path to the image is not correct.
ERROR - 2018-07-09 11:46:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:46:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:46:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:46:26 --> The path to the image is not correct.
ERROR - 2018-07-09 11:46:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:48:00 --> The path to the image is not correct.
ERROR - 2018-07-09 11:48:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:48:00 --> The path to the image is not correct.
ERROR - 2018-07-09 11:48:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:48:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:48:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:52:20 --> The path to the image is not correct.
ERROR - 2018-07-09 11:52:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:52:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:52:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:52:23 --> The path to the image is not correct.
ERROR - 2018-07-09 11:52:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-09 11:52:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 11:52:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:12:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:16:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:17:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:21:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:21:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:22:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:22:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:22:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:22:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-07-09 13:22:54 --> 404 Page Not Found: Public/lib

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-19 03:16:15 --> 404 Page Not Found: apimobile//index
ERROR - 2018-07-19 03:16:17 --> 404 Page Not Found: apimobile//index
ERROR - 2018-07-19 03:16:25 --> 404 Page Not Found: apimobile/Save_checklist/index
ERROR - 2018-07-19 03:16:46 --> Severity: Notice --> Undefined property: stdClass::$store_id D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 23
ERROR - 2018-07-19 03:16:46 --> Severity: Notice --> Undefined property: stdClass::$user_id D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 24
ERROR - 2018-07-19 05:47:49 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 05:47:50 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 05:47:50 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 05:47:50 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 05:47:50 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 07:03:16 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 07:03:16 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 07:03:16 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 07:03:16 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 07:03:16 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 07:15:51 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 07:15:51 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 07:15:51 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 07:15:51 --> 404 Page Not Found: Public/upload
ERROR - 2018-07-19 07:15:51 --> 404 Page Not Found: Public/upload

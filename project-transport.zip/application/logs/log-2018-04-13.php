<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-13 03:20:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 03:20:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 03:20:22 --> The path to the image is not correct.
ERROR - 2018-04-13 03:20:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 03:20:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 03:20:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 03:21:00 --> The path to the image is not correct.
ERROR - 2018-04-13 03:21:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 03:21:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 03:21:00 --> The path to the image is not correct.
ERROR - 2018-04-13 03:21:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 03:21:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 03:37:44 --> The path to the image is not correct.
ERROR - 2018-04-13 03:37:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 03:37:44 --> The path to the image is not correct.
ERROR - 2018-04-13 03:37:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 03:37:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 03:37:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 03:57:12 --> The path to the image is not correct.
ERROR - 2018-04-13 03:57:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 03:57:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 03:57:12 --> The path to the image is not correct.
ERROR - 2018-04-13 03:57:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 03:57:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 04:39:17 --> The path to the image is not correct.
ERROR - 2018-04-13 04:39:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 04:39:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 04:39:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 04:39:17 --> The path to the image is not correct.
ERROR - 2018-04-13 04:39:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:00:14 --> The path to the image is not correct.
ERROR - 2018-04-13 05:00:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:00:14 --> The path to the image is not correct.
ERROR - 2018-04-13 05:00:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:00:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:00:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:01:02 --> The path to the image is not correct.
ERROR - 2018-04-13 05:01:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:01:02 --> The path to the image is not correct.
ERROR - 2018-04-13 05:01:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:01:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:01:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:09:22 --> The path to the image is not correct.
ERROR - 2018-04-13 05:09:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:09:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:09:22 --> The path to the image is not correct.
ERROR - 2018-04-13 05:09:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:09:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:09:43 --> The path to the image is not correct.
ERROR - 2018-04-13 05:09:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:09:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:09:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:09:43 --> The path to the image is not correct.
ERROR - 2018-04-13 05:09:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:11:53 --> The path to the image is not correct.
ERROR - 2018-04-13 05:11:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:11:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:11:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:11:53 --> The path to the image is not correct.
ERROR - 2018-04-13 05:11:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:12:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:12:34 --> Severity: Notice --> Use of undefined constant street1 - assumed 'street1' D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:12:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:12:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\models\Profile_model.php 48
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:13:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\models\Profile_model.php 51
ERROR - 2018-04-13 05:14:53 --> The path to the image is not correct.
ERROR - 2018-04-13 05:14:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:14:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:14:53 --> The path to the image is not correct.
ERROR - 2018-04-13 05:14:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:14:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:17:37 --> Severity: Parsing Error --> syntax error, unexpected ']' D:\xampp\htdocs\project-transport\application\models\Profile_model.php 63
ERROR - 2018-04-13 05:17:49 --> Severity: Notice --> Undefined variable: _FILE D:\xampp\htdocs\project-transport\application\models\Profile_model.php 79
ERROR - 2018-04-13 05:21:04 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Profile_model.php 79
ERROR - 2018-04-13 05:21:05 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Profile_model.php 79
ERROR - 2018-04-13 05:21:05 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Profile_model.php 79
ERROR - 2018-04-13 05:21:06 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Profile_model.php 79
ERROR - 2018-04-13 05:21:06 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Profile_model.php 79
ERROR - 2018-04-13 05:21:06 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Profile_model.php 79
ERROR - 2018-04-13 05:21:06 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Profile_model.php 79
ERROR - 2018-04-13 05:21:07 --> Severity: Notice --> Undefined index: file D:\xampp\htdocs\project-transport\application\models\Profile_model.php 79
ERROR - 2018-04-13 05:21:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:21:44 --> The path to the image is not correct.
ERROR - 2018-04-13 05:21:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:21:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:21:44 --> The path to the image is not correct.
ERROR - 2018-04-13 05:21:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:26:31 --> The path to the image is not correct.
ERROR - 2018-04-13 05:26:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:26:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:26:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:26:31 --> The path to the image is not correct.
ERROR - 2018-04-13 05:26:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:27:53 --> The path to the image is not correct.
ERROR - 2018-04-13 05:27:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:27:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:27:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:27:53 --> The path to the image is not correct.
ERROR - 2018-04-13 05:27:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:29:01 --> The path to the image is not correct.
ERROR - 2018-04-13 05:29:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:29:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:29:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:29:01 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:32:06 --> The path to the image is not correct.
ERROR - 2018-04-13 05:32:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:32:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:32:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:32:06 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:34:20 --> The path to the image is not correct.
ERROR - 2018-04-13 05:34:20 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:34:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:34:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:34:20 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:34:33 --> The path to the image is not correct.
ERROR - 2018-04-13 05:34:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:34:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:34:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:34:33 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:34:59 --> The path to the image is not correct.
ERROR - 2018-04-13 05:34:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:34:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:34:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:34:59 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:35:41 --> The path to the image is not correct.
ERROR - 2018-04-13 05:35:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:35:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:35:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:35:42 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:35:56 --> The path to the image is not correct.
ERROR - 2018-04-13 05:35:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:35:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:35:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:35:56 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:37:34 --> The path to the image is not correct.
ERROR - 2018-04-13 05:37:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:37:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:37:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:37:34 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:37:38 --> The path to the image is not correct.
ERROR - 2018-04-13 05:37:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:37:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:37:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:37:38 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:39:15 --> The path to the image is not correct.
ERROR - 2018-04-13 05:39:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:39:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:39:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:39:16 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:40:03 --> The path to the image is not correct.
ERROR - 2018-04-13 05:40:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:40:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:40:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:40:03 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:40:23 --> The path to the image is not correct.
ERROR - 2018-04-13 05:40:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:40:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:40:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:40:23 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:41:41 --> The path to the image is not correct.
ERROR - 2018-04-13 05:41:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:41:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:41:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:41:41 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:46:14 --> The path to the image is not correct.
ERROR - 2018-04-13 05:46:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:46:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:46:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:46:14 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:48:50 --> The path to the image is not correct.
ERROR - 2018-04-13 05:48:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:48:50 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:48:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:48:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:48:59 --> The path to the image is not correct.
ERROR - 2018-04-13 05:48:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:48:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:48:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:48:59 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:50:04 --> The path to the image is not correct.
ERROR - 2018-04-13 05:50:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:50:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:50:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:50:04 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:50:25 --> The path to the image is not correct.
ERROR - 2018-04-13 05:50:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:50:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:50:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:50:25 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:51:31 --> The path to the image is not correct.
ERROR - 2018-04-13 05:51:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:51:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:51:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:51:31 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:51:53 --> Severity: Notice --> Undefined variable: user_id D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 136
ERROR - 2018-04-13 05:51:53 --> The path to the image is not correct.
ERROR - 2018-04-13 05:51:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:51:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:51:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:51:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:52:30 --> The path to the image is not correct.
ERROR - 2018-04-13 05:52:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:52:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:52:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:52:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:53:51 --> The path to the image is not correct.
ERROR - 2018-04-13 05:53:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:53:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:53:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:53:51 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:53:59 --> Severity: Notice --> Undefined variable: user_id D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 136
ERROR - 2018-04-13 05:53:59 --> The path to the image is not correct.
ERROR - 2018-04-13 05:53:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:53:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:53:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:53:59 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:54:04 --> Severity: Notice --> Undefined variable: user_id D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 136
ERROR - 2018-04-13 05:54:04 --> The path to the image is not correct.
ERROR - 2018-04-13 05:54:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:54:04 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:54:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:54:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:54:27 --> The path to the image is not correct.
ERROR - 2018-04-13 05:54:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 05:54:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:54:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 05:54:27 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 05:54:28 --> Severity: Notice --> Undefined variable: user_id D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 136
ERROR - 2018-04-13 05:54:28 --> Severity: Warning --> Missing argument 1 for print_r_die(), called in D:\xampp\htdocs\project-transport\application\models\Profile_model.php on line 80 and defined D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 6
ERROR - 2018-04-13 05:54:28 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 9
ERROR - 2018-04-13 06:54:48 --> Severity: Warning --> Missing argument 1 for print_r_die(), called in D:\xampp\htdocs\project-transport\application\models\Profile_model.php on line 80 and defined D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 6
ERROR - 2018-04-13 06:54:48 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 9
ERROR - 2018-04-13 06:55:13 --> The path to the image is not correct.
ERROR - 2018-04-13 06:55:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 06:55:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 06:55:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 06:55:14 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 06:57:13 --> The path to the image is not correct.
ERROR - 2018-04-13 06:57:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 06:57:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-13 06:57:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 06:57:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 06:57:14 --> The path to the image is not correct.
ERROR - 2018-04-13 06:57:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 06:57:14 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-13 06:57:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 06:57:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 06:58:50 --> The path to the image is not correct.
ERROR - 2018-04-13 06:58:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 06:58:50 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523590084_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 06:58:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 06:58:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 06:59:47 --> The path to the image is not correct.
ERROR - 2018-04-13 06:59:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 06:59:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 06:59:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 06:59:48 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523595587_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:00:51 --> Severity: Parsing Error --> syntax error, unexpected '$year' (T_VARIABLE), expecting ']' D:\xampp\htdocs\project-transport\application\models\Profile_model.php 111
ERROR - 2018-04-13 07:01:03 --> The path to the image is not correct.
ERROR - 2018-04-13 07:01:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:01:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:01:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:01:03 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523595587_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:01:31 --> The path to the image is not correct.
ERROR - 2018-04-13 07:01:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:01:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:01:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:01:31 --> The path to the image is not correct.
ERROR - 2018-04-13 07:01:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:02:14 --> The path to the image is not correct.
ERROR - 2018-04-13 07:02:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:02:14 --> The path to the image is not correct.
ERROR - 2018-04-13 07:02:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:02:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:02:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:02:15 --> The path to the image is not correct.
ERROR - 2018-04-13 07:02:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:02:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:02:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:02:15 --> The path to the image is not correct.
ERROR - 2018-04-13 07:02:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:05:28 --> The path to the image is not correct.
ERROR - 2018-04-13 07:05:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:05:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:05:28 --> The path to the image is not correct.
ERROR - 2018-04-13 07:05:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:05:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:06:38 --> The path to the image is not correct.
ERROR - 2018-04-13 07:06:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:06:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:06:38 --> The path to the image is not correct.
ERROR - 2018-04-13 07:06:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:06:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:06:46 --> The path to the image is not correct.
ERROR - 2018-04-13 07:06:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:06:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:06:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:06:46 --> The path to the image is not correct.
ERROR - 2018-04-13 07:06:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:12:40 --> The path to the image is not correct.
ERROR - 2018-04-13 07:12:40 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:12:40 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-13 07:12:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:12:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:14:07 --> The path to the image is not correct.
ERROR - 2018-04-13 07:14:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:14:07 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-13 07:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:14:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:14:15 --> The path to the image is not correct.
ERROR - 2018-04-13 07:14:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:14:15 --> 404 Page Not Found: 2018/04
ERROR - 2018-04-13 07:14:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:14:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:15:42 --> The path to the image is not correct.
ERROR - 2018-04-13 07:15:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:15:42 --> 404 Page Not Found: 2018/04
ERROR - 2018-04-13 07:15:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:15:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:46 --> The path to the image is not correct.
ERROR - 2018-04-13 07:28:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:28:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:47 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:28:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:47 --> The path to the image is not correct.
ERROR - 2018-04-13 07:28:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:28:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:47 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:28:47 --> The path to the image is not correct.
ERROR - 2018-04-13 07:28:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:28:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:48 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:28:48 --> The path to the image is not correct.
ERROR - 2018-04-13 07:28:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:28:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:48 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:28:48 --> The path to the image is not correct.
ERROR - 2018-04-13 07:28:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:28:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:28:48 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:29:00 --> The path to the image is not correct.
ERROR - 2018-04-13 07:29:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:29:00 --> 404 Page Not Found: Thumbs/public
ERROR - 2018-04-13 07:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:29:00 --> The path to the image is not correct.
ERROR - 2018-04-13 07:29:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:29:00 --> 404 Page Not Found: Thumbs/public
ERROR - 2018-04-13 07:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:29:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:29:01 --> The path to the image is not correct.
ERROR - 2018-04-13 07:29:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:29:01 --> 404 Page Not Found: Thumbs/public
ERROR - 2018-04-13 07:29:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:29:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:29:01 --> The path to the image is not correct.
ERROR - 2018-04-13 07:29:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:29:01 --> 404 Page Not Found: Thumbs/public
ERROR - 2018-04-13 07:29:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:29:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:54 --> The path to the image is not correct.
ERROR - 2018-04-13 07:34:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:34:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:54 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:34:54 --> The path to the image is not correct.
ERROR - 2018-04-13 07:34:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:34:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:54 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:34:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:54 --> The path to the image is not correct.
ERROR - 2018-04-13 07:34:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:34:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:55 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:34:55 --> The path to the image is not correct.
ERROR - 2018-04-13 07:34:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:34:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:55 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:34:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:55 --> The path to the image is not correct.
ERROR - 2018-04-13 07:34:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:34:55 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:34:55 --> The path to the image is not correct.
ERROR - 2018-04-13 07:34:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:34:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:55 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:34:55 --> The path to the image is not correct.
ERROR - 2018-04-13 07:34:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:34:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:34:56 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:28 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:28 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:29 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:30 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:30 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:30 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:30 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:30 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:30 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:30 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:30 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:31 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:31 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:31 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:31 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:31 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:31 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:31 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:31 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:32 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:32 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:32 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:32 --> The path to the image is not correct.
ERROR - 2018-04-13 07:35:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:35:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:35:32 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:35:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:36:45 --> The path to the image is not correct.
ERROR - 2018-04-13 07:36:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:36:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:36:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:36:45 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523596455_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:37:30 --> The path to the image is not correct.
ERROR - 2018-04-13 07:37:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:37:30 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-13 07:37:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:37:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:37:31 --> The path to the image is not correct.
ERROR - 2018-04-13 07:37:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:37:31 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-13 07:37:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:37:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:37:32 --> The path to the image is not correct.
ERROR - 2018-04-13 07:37:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:37:32 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-13 07:37:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:37:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:38:10 --> The path to the image is not correct.
ERROR - 2018-04-13 07:38:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:38:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:38:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:38:10 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523597890_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:45:36 --> 404 Page Not Found: Public/upload
ERROR - 2018-04-13 07:46:50 --> The path to the image is not correct.
ERROR - 2018-04-13 07:46:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:46:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:46:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:46:50 --> Severity: Warning --> Missing argument 5 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-13 07:46:51 --> Severity: Warning --> Missing argument 6 for Thumbs::images() D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 12
ERROR - 2018-04-13 07:46:51 --> Severity: Notice --> Undefined variable: img D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 16
ERROR - 2018-04-13 07:46:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 20
ERROR - 2018-04-13 07:46:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 23
ERROR - 2018-04-13 07:46:51 --> Severity: Notice --> Undefined variable: height D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 25
ERROR - 2018-04-13 07:46:51 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/project-transport/public/upload/user/2018/04): failed to open stream: Permission denied D:\xampp\htdocs\project-transport\system\libraries\Image_lib.php 1651
ERROR - 2018-04-13 07:46:51 --> The provided image is not valid.
ERROR - 2018-04-13 07:46:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 31
ERROR - 2018-04-13 07:47:06 --> The path to the image is not correct.
ERROR - 2018-04-13 07:47:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:47:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:47:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:53:31 --> The path to the image is not correct.
ERROR - 2018-04-13 07:53:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:53:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:53:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:53:31 --> Severity: Warning --> readfile(public/upload/user/2018/04/thumbnail/150x150_c81e728d9d4c2f636f067f89cc14862c_1523597890_haha.jpg): failed to open stream: No such file or directory D:\xampp\htdocs\project-transport\application\controllers\Thumbs.php 33
ERROR - 2018-04-13 07:53:51 --> The path to the image is not correct.
ERROR - 2018-04-13 07:53:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:53:51 --> The path to the image is not correct.
ERROR - 2018-04-13 07:53:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:53:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:53:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:53:59 --> The path to the image is not correct.
ERROR - 2018-04-13 07:53:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:53:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:53:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:54:56 --> The path to the image is not correct.
ERROR - 2018-04-13 07:54:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 07:54:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 07:54:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:05:55 --> The path to the image is not correct.
ERROR - 2018-04-13 08:05:55 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:05:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:05:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:38:29 --> The path to the image is not correct.
ERROR - 2018-04-13 08:38:29 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:38:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:38:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:38:31 --> Severity: Error --> Call to undefined method Accounts_model::get_userplan() D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 159
ERROR - 2018-04-13 08:39:15 --> Severity: Notice --> Undefined variable: setup_page D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 6
ERROR - 2018-04-13 08:39:15 --> Severity: Notice --> Undefined variable: setup_page D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 7
ERROR - 2018-04-13 08:39:15 --> Severity: Notice --> Undefined variable: setup_page D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 10
ERROR - 2018-04-13 08:39:15 --> The path to the image is not correct.
ERROR - 2018-04-13 08:39:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:39:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:39:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:13 --> Severity: Warning --> Missing argument 1 for Setup::account() D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 157
ERROR - 2018-04-13 08:50:13 --> Severity: Notice --> Undefined variable: type D:\xampp\htdocs\project-transport\application\controllers\app\Setup.php 158
ERROR - 2018-04-13 08:50:13 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:14 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:15 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:16 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:16 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:16 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:17 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:17 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:17 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:17 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:18 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:18 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:18 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:33 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:42 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:45 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:45 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:46 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:46 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:47 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:47 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:48 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:48 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:49 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:49 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:50 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:50 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:50 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:51 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:51 --> The path to the image is not correct.
ERROR - 2018-04-13 08:50:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:50:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:50:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:51:36 --> The path to the image is not correct.
ERROR - 2018-04-13 08:51:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:51:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:51:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:54:12 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 20
ERROR - 2018-04-13 08:54:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\account\view.php 20
ERROR - 2018-04-13 08:54:12 --> The path to the image is not correct.
ERROR - 2018-04-13 08:54:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:54:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:54:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:57:19 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `user_plan`
WHERE `user_id` = '2'
ERROR - 2018-04-13 08:57:43 --> The path to the image is not correct.
ERROR - 2018-04-13 08:57:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:57:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:57:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:58:08 --> The path to the image is not correct.
ERROR - 2018-04-13 08:58:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:58:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:58:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:58:46 --> The path to the image is not correct.
ERROR - 2018-04-13 08:58:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:58:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:58:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:59:32 --> The path to the image is not correct.
ERROR - 2018-04-13 08:59:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 08:59:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 08:59:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:00:02 --> The path to the image is not correct.
ERROR - 2018-04-13 09:00:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:00:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:00:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:00:03 --> The path to the image is not correct.
ERROR - 2018-04-13 09:00:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:00:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:00:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:00:04 --> The path to the image is not correct.
ERROR - 2018-04-13 09:00:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:00:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:00:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:00:04 --> The path to the image is not correct.
ERROR - 2018-04-13 09:00:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:00:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:00:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:00:16 --> The path to the image is not correct.
ERROR - 2018-04-13 09:00:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:00:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:00:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:02:01 --> The path to the image is not correct.
ERROR - 2018-04-13 09:02:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:02:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:02:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:02:45 --> The path to the image is not correct.
ERROR - 2018-04-13 09:02:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:02:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:02:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:03:05 --> The path to the image is not correct.
ERROR - 2018-04-13 09:03:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:03:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:03:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:03:46 --> The path to the image is not correct.
ERROR - 2018-04-13 09:03:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:03:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:03:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:04:17 --> The path to the image is not correct.
ERROR - 2018-04-13 09:04:17 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:04:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:04:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:07:38 --> The path to the image is not correct.
ERROR - 2018-04-13 09:07:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:07:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:07:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:07:52 --> The path to the image is not correct.
ERROR - 2018-04-13 09:07:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:07:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:07:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:09:18 --> The path to the image is not correct.
ERROR - 2018-04-13 09:09:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:09:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:09:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:12:07 --> The path to the image is not correct.
ERROR - 2018-04-13 09:12:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:12:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:12:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:13:31 --> The path to the image is not correct.
ERROR - 2018-04-13 09:13:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:13:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:13:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:17:46 --> The path to the image is not correct.
ERROR - 2018-04-13 09:17:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:17:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:17:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:17:51 --> The path to the image is not correct.
ERROR - 2018-04-13 09:17:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:17:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:17:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:18:18 --> The path to the image is not correct.
ERROR - 2018-04-13 09:18:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:18:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:18:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:18:43 --> The path to the image is not correct.
ERROR - 2018-04-13 09:18:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:18:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:18:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:20:06 --> The path to the image is not correct.
ERROR - 2018-04-13 09:20:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:20:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:20:36 --> The path to the image is not correct.
ERROR - 2018-04-13 09:20:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:20:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:20:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:21:47 --> The path to the image is not correct.
ERROR - 2018-04-13 09:21:47 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:21:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:21:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:22:31 --> The path to the image is not correct.
ERROR - 2018-04-13 09:22:31 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:22:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:22:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:22:38 --> The path to the image is not correct.
ERROR - 2018-04-13 09:22:38 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:22:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:22:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:24:56 --> The path to the image is not correct.
ERROR - 2018-04-13 09:24:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:24:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:24:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:24:57 --> The path to the image is not correct.
ERROR - 2018-04-13 09:24:57 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:24:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:25:00 --> The path to the image is not correct.
ERROR - 2018-04-13 09:25:00 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:25:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:25:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:26:27 --> The path to the image is not correct.
ERROR - 2018-04-13 09:26:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-13 09:26:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 09:26:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-13 11:34:07 --> 404 Page Not Found: app/Reports/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-13 04:01:36 --> The path to the image is not correct.
ERROR - 2018-06-13 04:01:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-13 04:01:39 --> The path to the image is not correct.
ERROR - 2018-06-13 04:01:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-06-13 04:01:39 --> The path to the image is not correct.
ERROR - 2018-06-13 04:01:39 --> Your server does not support the GD function required to process this type of image.

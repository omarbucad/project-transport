<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-14 05:25:05 --> The path to the image is not correct.
ERROR - 2018-08-14 05:25:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 05:25:08 --> The path to the image is not correct.
ERROR - 2018-08-14 05:25:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecreatefrompng(): gd-png:  fatal libpng error: incorrect header check D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7284
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecreatefrompng(): gd-png error: setjmp returns error condition D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7284
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecreatefrompng(): 'http://192.168.1.117/project-transport/public/upload/signature/2018/08/82_1533539501.PNG' is not a valid PNG file D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7284
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorsforindex() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7334
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:39 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:40 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:41 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:42 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:43 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecreatefrompng(): gd-png:  fatal libpng error: incorrect header check D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7284
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecreatefrompng(): gd-png error: setjmp returns error condition D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7284
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecreatefrompng(): 'http://192.168.1.117/project-transport/public/upload/signature/2018/08/167_1533792622.PNG' is not a valid PNG file D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7284
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorsforindex() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7334
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:52 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:53 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:54 --> Severity: Warning --> imagecolorat() expects parameter 1 to be resource, boolean given D:\xampp\htdocs\project-transport\application\third_party\pdf\vendor\tecnickcom\tcpdf\tcpdf.php 7293
ERROR - 2018-08-14 05:25:57 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-14 05:26:02 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-14 05:26:10 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-14 05:26:13 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-14 05:26:17 --> 404 Page Not Found: Public/upload
ERROR - 2018-08-14 05:42:15 --> Severity: Notice --> Undefined property: Checklist::$reports D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 196
ERROR - 2018-08-14 05:42:15 --> Severity: Error --> Call to a member function get_report_by_id() on null D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 196
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\libraries\Pdf.php 39
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: report_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 34
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: created D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 36
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: start_mileage D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 40
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: end_mileage D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 42
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: vehicle_registration_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 46
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: trailer_number D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 47
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: display_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 55
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: report_notes D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 59
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: checklist_name D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 63
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: report_checklist D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 67
ERROR - 2018-08-14 05:46:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 67
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: report_statuses D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 92
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 92
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Undefined variable: report_statuses D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 93
ERROR - 2018-08-14 05:46:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\pdf\report_checklist.php 93
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5223
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_x D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5545
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5581
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 4 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined index: td_y D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5345
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 5 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:03 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 6 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 7 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 8 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 9 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 10 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 11 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 11 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 11 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 11 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 11 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 11 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 11 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 11 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 11 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 12 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 12 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 12 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:04 --> Severity: Notice --> Undefined offset: 12 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 12 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 12 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 12 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 12 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 12 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 13 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 13 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 13 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 13 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 13 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 13 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 13 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 13 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 13 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 17 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 18 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:05 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 19 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 20 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 21 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 22 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:06 --> Severity: Notice --> Undefined offset: 23 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 24 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 24 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 24 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 24 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 24 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 24 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 24 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 24 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 24 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 25 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 25 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 25 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 25 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 25 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 25 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 25 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 25 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 25 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 26 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 26 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 26 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 26 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 26 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 26 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 26 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 26 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 26 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 27 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:07 --> Severity: Notice --> Undefined offset: 28 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 29 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 30 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 31 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 32 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:08 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 33 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 34 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 34 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 34 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 34 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 34 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 34 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 34 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 34 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 34 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 35 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 35 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 35 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 35 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 35 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 35 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 35 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 35 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 35 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 36 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5215
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 36 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5540
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 36 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5546
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 36 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5547
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 36 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5554
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 36 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5562
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 36 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5563
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 36 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5644
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined offset: 36 D:\xampp\htdocs\project-transport\application\third_party\pdf\src\Html2Pdf.php 5337
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined index: path D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 143
ERROR - 2018-08-14 05:46:09 --> Severity: Notice --> Undefined index: filename D:\xampp\htdocs\project-transport\application\controllers\apimobile\Checklist.php 144
ERROR - 2018-08-14 08:06:51 --> The path to the image is not correct.
ERROR - 2018-08-14 08:06:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:06:54 --> The path to the image is not correct.
ERROR - 2018-08-14 08:06:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:06:54 --> The path to the image is not correct.
ERROR - 2018-08-14 08:06:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:06:58 --> The path to the image is not correct.
ERROR - 2018-08-14 08:06:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:06:58 --> The path to the image is not correct.
ERROR - 2018-08-14 08:06:58 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:02 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:02 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:03 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:03 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:05 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:05 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:06 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:06 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:06 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:12 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:12 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:13 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:13 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:14 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:14 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:15 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:15 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:15 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:15 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:15 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:21 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:21 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:23 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:07:23 --> The path to the image is not correct.
ERROR - 2018-08-14 08:07:23 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:08:54 --> The path to the image is not correct.
ERROR - 2018-08-14 08:08:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:09:09 --> The path to the image is not correct.
ERROR - 2018-08-14 08:09:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:09:09 --> The path to the image is not correct.
ERROR - 2018-08-14 08:09:09 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:09:30 --> The path to the image is not correct.
ERROR - 2018-08-14 08:09:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:09:30 --> The path to the image is not correct.
ERROR - 2018-08-14 08:09:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:09:42 --> The path to the image is not correct.
ERROR - 2018-08-14 08:09:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:09:43 --> The path to the image is not correct.
ERROR - 2018-08-14 08:09:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:10:53 --> The path to the image is not correct.
ERROR - 2018-08-14 08:10:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:10:53 --> The path to the image is not correct.
ERROR - 2018-08-14 08:10:53 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:10 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:11 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:11 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:38 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:39 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:39 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:43 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:43 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:44 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:44 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:44 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:51 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:51 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:51 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:52 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:11:52 --> The path to the image is not correct.
ERROR - 2018-08-14 08:11:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:12:07 --> The path to the image is not correct.
ERROR - 2018-08-14 08:12:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:12:07 --> The path to the image is not correct.
ERROR - 2018-08-14 08:12:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:12:08 --> The path to the image is not correct.
ERROR - 2018-08-14 08:12:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:12:08 --> The path to the image is not correct.
ERROR - 2018-08-14 08:12:08 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:12:16 --> The path to the image is not correct.
ERROR - 2018-08-14 08:12:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:12:16 --> The path to the image is not correct.
ERROR - 2018-08-14 08:12:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:12:18 --> The path to the image is not correct.
ERROR - 2018-08-14 08:12:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:12:19 --> The path to the image is not correct.
ERROR - 2018-08-14 08:12:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:13:34 --> The path to the image is not correct.
ERROR - 2018-08-14 08:13:34 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-08-14 08:13:34 --> The path to the image is not correct.
ERROR - 2018-08-14 08:13:34 --> Your server does not support the GD function required to process this type of image.

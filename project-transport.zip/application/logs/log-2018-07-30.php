<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-30 08:23:10 --> The path to the image is not correct.
ERROR - 2018-07-30 08:23:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-30 08:23:13 --> The path to the image is not correct.
ERROR - 2018-07-30 08:23:13 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-30 08:23:16 --> The path to the image is not correct.
ERROR - 2018-07-30 08:23:16 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-30 08:23:49 --> The path to the image is not correct.
ERROR - 2018-07-30 08:23:49 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-30 08:23:51 --> The path to the image is not correct.
ERROR - 2018-07-30 08:23:51 --> Your server does not support the GD function required to process this type of image.

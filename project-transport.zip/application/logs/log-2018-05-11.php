<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-11 02:48:27 --> The path to the image is not correct.
ERROR - 2018-05-11 02:48:27 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-11 02:48:30 --> The path to the image is not correct.
ERROR - 2018-05-11 02:48:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-11 05:12:42 --> The path to the image is not correct.
ERROR - 2018-05-11 05:12:42 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-11 07:16:36 --> The path to the image is not correct.
ERROR - 2018-05-11 07:16:36 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-11 07:22:54 --> The path to the image is not correct.
ERROR - 2018-05-11 07:22:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-05-11 07:22:57 --> The path to the image is not correct.
ERROR - 2018-05-11 07:22:57 --> Your server does not support the GD function required to process this type of image.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-19 02:07:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:07:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:07:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:07:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:07:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 109
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 109
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-19 02:07:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-19 02:07:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:07:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 109
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 109
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 116
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 123
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 130
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 137
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 144
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-19 02:08:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 151
ERROR - 2018-04-19 02:08:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:08:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 108
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 108
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 115
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 122
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 129
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 136
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 143
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-19 02:08:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 150
ERROR - 2018-04-19 02:08:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:08:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-19 02:10:19 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-19 02:10:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:10:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 112
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 119
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 126
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 133
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 140
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 147
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Undefined variable: value D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-19 02:10:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 154
ERROR - 2018-04-19 02:10:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:10:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:13:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:13:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:13:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:13:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:17:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:17:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:17:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:17:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:17:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:17:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:17:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:17:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:17:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:17:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:18:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:18:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:18:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:18:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:19:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:19:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:20:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:20:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:22:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:38:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:38:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:38:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:38:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:38:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:38:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:38:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:38:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:39:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:39:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:52:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:52:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:52:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:52:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:52:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:52:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:52:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:52:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:53:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:53:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:53:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:53:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:53:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 02:53:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:05:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:05:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:05:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:05:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:09:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:09:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:13:53 --> Severity: Notice --> Undefined property: stdClass::$report_status D:\xampp\htdocs\project-transport\application\models\Report_model.php 99
ERROR - 2018-04-19 03:13:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:13:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:13:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:13:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:14:01 --> Severity: Notice --> Undefined property: stdClass::$report_status D:\xampp\htdocs\project-transport\application\models\Report_model.php 99
ERROR - 2018-04-19 03:15:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:15:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:15:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:15:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:16:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:16:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:16:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:16:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:16:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:16:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:16:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:16:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:17:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:17:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:19:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:19:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:19:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:19:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:20:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:20:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:20:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:20:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:20:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:20:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:20:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:20:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:21:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:21:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:22:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:23:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:23:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:23:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:23:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:23:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:23:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:23:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:23:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:24:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:24:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:24:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:24:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:25:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:25:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:25:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:25:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:26:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:26:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:27:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:27:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:28:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:28:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:29:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:29:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:30:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:30:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:30:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:30:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:31:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:31:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:36:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:36:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:11 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:37:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:12 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:37:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:12 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:37:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:12 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:37:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:13 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:37:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:19 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:37:19 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:37:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:19 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:37:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:33 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:37:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:37:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:38:03 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:38:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:38:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:38:59 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:38:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:38:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:38:59 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:39:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:39:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:39:00 --> Severity: Notice --> Use of undefined constant GOOGLE_API_KEY - assumed 'GOOGLE_API_KEY' D:\xampp\htdocs\project-transport\application\views\backend\page\report\view_report.php 1
ERROR - 2018-04-19 03:39:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:39:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:40:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:41:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:41:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:41:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:41:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:41:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:41:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:41:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:41:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:42:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:43:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:43:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:43:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:43:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:43:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:43:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:44:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:44:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:44:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:44:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:45:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:45:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:45:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:45:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:46:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:46:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:46:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:46:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:51:01 --> Severity: Notice --> Use of undefined constant INNER - assumed 'INNER' D:\xampp\htdocs\project-transport\application\models\Report_model.php 103
ERROR - 2018-04-19 03:52:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:52:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:52:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:52:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:55:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:55:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:55:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:55:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:56:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:56:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:59:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:59:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:59:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:59:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 03:59:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:00:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:00:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:03:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:03:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:03:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:03:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:06:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:06:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:07:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:07:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:07:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:07:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:08:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:08:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:09:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:09:55 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:10:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:10:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:10:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:10:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:10:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:10:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:10:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:11:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:11:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:11:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:11:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:13:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:13:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:13:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:13:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:15:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:15:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:15:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:15:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:16:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:16:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:16:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:16:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:16:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:16:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:16:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:16:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:17:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:17:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:18:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:18:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:18:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:18:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:18:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:18:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:20:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:20:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:20:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:20:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:37:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:37:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:37:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:37:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:37:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:37:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:37:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:37:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:38:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:38:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:38:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:38:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:38:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:38:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:39:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:39:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:39:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:39:15 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:39:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:39:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:39:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:39:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:39:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:39:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:40:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:40:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:40:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:40:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:40:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:40:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:40:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:40:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:40:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:42:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:42:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:42:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:42:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:43:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:43:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:44:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:44:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:44:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:44:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:45:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:45:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:45:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:45:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:45:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:45:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:45:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:45:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:47:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:47:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:47:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:47:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:47:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:47:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:48:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:48:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:49:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:49:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:50:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:50:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:50:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:50:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:50:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:50:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:50:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:50:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:51:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:51:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:51:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:51:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:52:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:52:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:52:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:52:02 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:52:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:52:14 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:53:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:53:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:53:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:53:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:53:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:53:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:54:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:54:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:54:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:54:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:54:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:54:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:55:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:55:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:55:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:55:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:55:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:55:32 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:55:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:55:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:56:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:56:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:56:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 04:56:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:00:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:00:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:00:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:00:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:00:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:00:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:00:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:01:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:01:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:01:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:01:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:02:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:02:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:03:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:03:09 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:04:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:04:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:04:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:04:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:04:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:04:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:05:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:05:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:07:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:07:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:07:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:07:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:09:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:09:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:09:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:09:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:46:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:46:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:46:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:46:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:47:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:47:13 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:48:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:48:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:52:46 --> Severity: Compile Error --> Cannot redeclare Accounts::edit() D:\xampp\htdocs\project-transport\application\controllers\app\Accounts.php 99
ERROR - 2018-04-19 05:53:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:53:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:53:04 --> The path to the image is not correct.
ERROR - 2018-04-19 05:53:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 05:54:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:54:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:54:48 --> The path to the image is not correct.
ERROR - 2018-04-19 05:54:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:54:48 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 05:54:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:56:41 --> The path to the image is not correct.
ERROR - 2018-04-19 05:56:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:56:41 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 05:56:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:56:56 --> The path to the image is not correct.
ERROR - 2018-04-19 05:56:56 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:56:56 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 05:56:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:58:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:58:06 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:58:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:58:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:58:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:58:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:59:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 05:59:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:10 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:10 --> The path to the image is not correct.
ERROR - 2018-04-19 06:00:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 06:00:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:33 --> The path to the image is not correct.
ERROR - 2018-04-19 06:00:33 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 06:00:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:34 --> The path to the image is not correct.
ERROR - 2018-04-19 06:00:34 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 06:00:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:35 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:35 --> The path to the image is not correct.
ERROR - 2018-04-19 06:00:35 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 06:00:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:44 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:00:45 --> The path to the image is not correct.
ERROR - 2018-04-19 06:00:45 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 06:50:38 --> Query error: Unknown column 'r.deleted' in 'where clause' - Invalid query: SELECT `r`.*, `rs`.`status`, `rs`.`created` as `status_created`, `c`.`checklist_name`, `u`.`display_name`
FROM `report` `r`
JOIN `report_status` `rs` ON `rs`.`id` = `r`.`status_id`
JOIN `checklist` `c` ON `c`.`checklist_id` = `r`.`checklist_id`
JOIN `user` `u` ON `u`.`user_id` = `r`.`report_by`
WHERE `r`.`deleted` IS NULL
ORDER BY `r`.`created` DESC
ERROR - 2018-04-19 06:51:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:51:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:58:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:58:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:58:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 06:58:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:04:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:04:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:04:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:04:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:04:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:04:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:04:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:04:47 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:06:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:06:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:06:28 --> The path to the image is not correct.
ERROR - 2018-04-19 07:06:28 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 07:07:46 --> The path to the image is not correct.
ERROR - 2018-04-19 07:07:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-04-19 07:07:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:07:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:53:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:53:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:53:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:53:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:53:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:53:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:54:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:55:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:55:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:55:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:55:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:55:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:55:50 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:56:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:56:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:56:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:56:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:57:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 07:57:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:16:06 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 35
ERROR - 2018-04-19 08:16:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:16:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:16:18 --> Query error: Column 'status' cannot be null - Invalid query: INSERT INTO `report_status` (`report_id`, `user_id`, `status`, `notes`, `created`) VALUES ('5', '2', NULL, NULL, 1524118578)
ERROR - 2018-04-19 08:19:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:19:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:19:17 --> Query error: Column 'status' cannot be null - Invalid query: INSERT INTO `report_status` (`report_id`, `user_id`, `status`, `notes`, `created`) VALUES ('5', '2', NULL, NULL, 1524118757)
ERROR - 2018-04-19 08:19:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:19:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:19:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:19:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:19:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:19:28 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:19:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:19:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:19:31 --> Query error: Column 'status' cannot be null - Invalid query: INSERT INTO `report_status` (`report_id`, `user_id`, `status`, `notes`, `created`) VALUES ('5', '2', NULL, NULL, 1524118771)
ERROR - 2018-04-19 08:24:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:24:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:24:11 --> Query error: Column 'status' cannot be null - Invalid query: INSERT INTO `report_status` (`report_id`, `user_id`, `status`, `notes`, `created`) VALUES ('5', '2', NULL, NULL, 1524119051)
ERROR - 2018-04-19 08:24:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:24:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:24:34 --> Query error: Column 'status' cannot be null - Invalid query: INSERT INTO `report_status` (`report_id`, `user_id`, `status`, `notes`, `created`) VALUES ('5', '2', NULL, NULL, 1524119074)
ERROR - 2018-04-19 08:25:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:25:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:25:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:25:12 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:26:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:26:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:27:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:27:27 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:27:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:27:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:28:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:28:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:28:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:28:59 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:37:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:37:07 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:37:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:37:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:49:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:49:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:49:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:49:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:49:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:49:43 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:50:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:50:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:50:52 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:54:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:54:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:55:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:55:01 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:56:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:56:57 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:57:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:57:51 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:58:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:58:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:58:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:58:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:58:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:58:33 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:59:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:59:19 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:59:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 08:59:37 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:01:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:01:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:01:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:01:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:01:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:01:48 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:06:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:06:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:08:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:08:39 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:08:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:08:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:08:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:08:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:09:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:09:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:09:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:09:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:12:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:12:03 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:12:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:12:29 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:12:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:12:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:13:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:13:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:13:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:13:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:18:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:18:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:18:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:18:08 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:21:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:21:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:21:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:21:31 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:21:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:21:36 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:22:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:22:58 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:23:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:23:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:24:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:24:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:24:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:24:41 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:25:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 09:25:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:19:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:19:53 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:24:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:24:16 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:24:20 --> Severity: Notice --> Undefined property: Report::$invoice D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 16
ERROR - 2018-04-19 10:24:20 --> Severity: Error --> Call to a member function get_reports_list() on null D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 16
ERROR - 2018-04-19 10:24:36 --> Severity: Notice --> Undefined property: stdClass::$status_raw D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 85
ERROR - 2018-04-19 10:24:36 --> Severity: Notice --> Undefined property: stdClass::$status_raw D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 85
ERROR - 2018-04-19 10:24:36 --> Severity: Notice --> Undefined property: stdClass::$status_raw D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 85
ERROR - 2018-04-19 10:24:36 --> Severity: Notice --> Undefined property: stdClass::$status_raw D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 85
ERROR - 2018-04-19 10:24:36 --> Severity: Notice --> Undefined property: stdClass::$status_raw D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 85
ERROR - 2018-04-19 10:24:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 278
ERROR - 2018-04-19 10:24:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 279
ERROR - 2018-04-19 10:24:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 280
ERROR - 2018-04-19 10:24:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 283
ERROR - 2018-04-19 10:24:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 284
ERROR - 2018-04-19 10:24:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 285
ERROR - 2018-04-19 10:24:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 288
ERROR - 2018-04-19 10:24:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 289
ERROR - 2018-04-19 10:26:40 --> Severity: Notice --> Undefined property: stdClass::$raw_status D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 85
ERROR - 2018-04-19 10:26:40 --> Severity: Notice --> Undefined property: stdClass::$raw_status D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 85
ERROR - 2018-04-19 10:26:40 --> Severity: Notice --> Undefined property: stdClass::$raw_status D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 85
ERROR - 2018-04-19 10:26:40 --> Severity: Notice --> Undefined property: stdClass::$raw_status D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 85
ERROR - 2018-04-19 10:26:40 --> Severity: Notice --> Undefined property: stdClass::$raw_status D:\xampp\htdocs\project-transport\application\controllers\app\Report.php 85
ERROR - 2018-04-19 10:26:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 278
ERROR - 2018-04-19 10:26:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 279
ERROR - 2018-04-19 10:26:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 280
ERROR - 2018-04-19 10:26:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 283
ERROR - 2018-04-19 10:26:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 284
ERROR - 2018-04-19 10:26:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 285
ERROR - 2018-04-19 10:26:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 288
ERROR - 2018-04-19 10:26:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\project-transport\system\core\Exceptions.php:271) D:\xampp\htdocs\project-transport\application\helpers\common_helper.php 289
ERROR - 2018-04-19 10:28:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:28:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:30:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:30:20 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:30:21 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:30:22 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:30:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:30:24 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:31:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:31:30 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:31:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:31:38 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:31:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:31:46 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:32:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:32:00 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:32:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:32:23 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:58:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:58:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:58:18 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:58:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:58:45 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:59:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:59:17 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:59:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:59:25 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:59:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:59:40 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:59:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:59:49 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:59:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 10:59:54 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 11:00:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 11:00:05 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 11:00:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 11:00:11 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 11:00:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 11:00:26 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 11:00:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 11:00:42 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 11:01:04 --> 404 Page Not Found: Public/lib
ERROR - 2018-04-19 11:01:04 --> 404 Page Not Found: Public/lib

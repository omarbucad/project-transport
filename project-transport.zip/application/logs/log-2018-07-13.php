<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-13 03:49:43 --> The path to the image is not correct.
ERROR - 2018-07-13 03:49:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2018-07-13 03:50:27 --> The path to the image is not correct.
ERROR - 2018-07-13 03:50:27 --> Your server does not support the GD function required to process this type of image.
